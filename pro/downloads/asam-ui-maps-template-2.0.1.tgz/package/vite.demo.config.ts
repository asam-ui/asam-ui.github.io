import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
export default defineConfig({
	plugins: [vue()],
	build: { outDir: 'demo-dist', target: 'es2022' },
	preview: { host: '127.0.0.1', port: 43848, strictPort: true }
});
