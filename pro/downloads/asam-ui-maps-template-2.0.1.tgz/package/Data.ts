import type { MapDataset, MapFeature, MapGeometry, Position } from './Types.js';
import { createAsamMessageError } from '@asam-ui/pro/i18n';
import type {} from './I18nParameters.js';

export function validPosition(value: unknown): value is Position {
	return (
		Array.isArray(value) &&
		value.length === 2 &&
		value.every(Number.isFinite) &&
		Math.abs(value[0]) <= 180 &&
		Math.abs(value[1]) <= 90
	);
}
function validGeometry(value: MapGeometry): boolean {
	if (!value || typeof value !== 'object') return false;
	if (value.type === 'Point') return validPosition(value.coordinates);
	if (value.type === 'LineString')
		return (
			Array.isArray(value.coordinates) &&
			value.coordinates.length >= 2 &&
			value.coordinates.every(validPosition)
		);
	if (value.type === 'Polygon')
		return (
			Array.isArray(value.coordinates) &&
			value.coordinates.length > 0 &&
			value.coordinates.every(
				(ring) =>
					Array.isArray(ring) &&
					ring.length >= 4 &&
					ring.every(validPosition) &&
					ring[0][0] === ring.at(-1)?.[0] &&
					ring[0][1] === ring.at(-1)?.[1]
			)
		);
	return false;
}
/** Copy the supported GeoJSON subset; reject atomically, never partially show invalid data. */
export function copyDataset(value: MapDataset): MapDataset {
	if (
		!value ||
		value.type !== 'FeatureCollection' ||
		!Array.isArray(value.features) ||
		value.features.length > 500
	)
		throw createAsamMessageError(
			'数据必须是最多500项的示意 GeoJSON',
			'app.templates.maps.dataInvalid'
		);
	const ids = new Set<string>();
	for (const feature of value.features) {
		if (
			!feature ||
			feature.type !== 'Feature' ||
			typeof feature.id !== 'string' ||
			!feature.id.trim() ||
			ids.has(feature.id) ||
			!feature.properties ||
			!['title', 'category', 'description'].every(
				(key) =>
					typeof feature.properties[key as keyof MapFeature['properties']] === 'string'
			) ||
			!validGeometry(feature.geometry)
		)
			throw createAsamMessageError(
				'GeoJSON 标识、属性或 WGS84 坐标无效',
				'app.templates.maps.featureInvalid'
			);
		ids.add(feature.id);
	}
	return structuredClone(value);
}
export const demoData: MapDataset = {
	type: 'FeatureCollection',
	features: [
		{
			type: 'Feature',
			id: 'atelier',
			properties: {
				title: '北岸设计室',
				category: '工作空间',
				description: '沿水岸步道到达的共享设计空间。项目自制示意点位。'
			},
			geometry: { type: 'Point', coordinates: [120.152, 30.274] }
		},
		{
			type: 'Feature',
			id: 'library',
			properties: {
				title: '水庭阅览室',
				category: '公共空间',
				description: '面向社区开放的阅读空间。位置不代表真实地址。'
			},
			geometry: { type: 'Point', coordinates: [120.165, 30.281] }
		},
		{
			type: 'Feature',
			id: 'garden',
			properties: {
				title: '南园工坊',
				category: '工作空间',
				description: '毗邻示意绿地的手作工坊，无真实运营信息。'
			},
			geometry: { type: 'Point', coordinates: [120.173, 30.266] }
		},
		{
			type: 'Feature',
			id: 'walk',
			properties: {
				title: '水岸步道',
				category: '步道',
				description: '项目自绘线覆盖示例。'
			},
			geometry: {
				type: 'LineString',
				coordinates: [
					[120.14, 30.26],
					[120.151, 30.267],
					[120.16, 30.276],
					[120.178, 30.287]
				]
			}
		},
		{
			type: 'Feature',
			id: 'park',
			properties: {
				title: '示意绿地',
				category: '绿地',
				description: '项目自绘面覆盖示例。'
			},
			geometry: {
				type: 'Polygon',
				coordinates: [
					[
						[120.164, 30.258],
						[120.184, 30.26],
						[120.182, 30.274],
						[120.169, 30.271],
						[120.164, 30.258]
					]
				]
			}
		}
	]
};
