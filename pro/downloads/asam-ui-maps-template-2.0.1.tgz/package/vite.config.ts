import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
export default defineConfig({
	plugins: [vue()],
	build: {
		lib: { entry: 'index.ts', formats: ['es'], fileName: 'maps', cssFileName: 'maps-template' },
		rollupOptions: {
			external: (id) =>
				id === 'vue' ||
				id === 'element-plus' ||
				id.startsWith('element-plus/') ||
				/^@asam-ui\/(ui|pro)(\/|$)/.test(id)
		},
		target: 'es2022'
	}
});
