<template>
	<AsamConfigProvider :i18n="i18n">
		<main class="asam-map-page asam-map-minimal" :data-size="size" :data-theme="theme">
			<header class="asam-map-header">
				<div>
					<p class="asam-map-eyebrow">ASAM / LOCAL ATLAS</p>
					<h1>{{ i18n.t('app.templates.maps.minimalTitle') }}</h1>
					<p>{{ i18n.t('app.templates.maps.minimalIntro') }}</p>
				</div>
				<span class="asam-map-label">{{
					i18n.t('app.templates.maps.localCoordinates')
				}}</span>
			</header>
			<MapToolbar
				:controller="controller"
				:categories="categories"
				:locked="locked"
				@fit="canvas?.fitAll()"
				@zoom="canvas?.zoomBy($event)"
			/>
			<div class="asam-map-minimal-body">
				<MapStage
					ref="canvas"
					:controller="controller"
					:provider="provider"
					:locked="locked"
					:size="size"
					:reload="reload"
					@view="view = $event"
				/><PointList :controller="controller" :locked="locked" />
			</div>
			<footer class="asam-map-footer">
				<span>{{ provider.title }}</span
				><span
					>{{ i18n.t('app.templates.maps.zoom') }} {{ view.zoom }} /
					{{ view.center.map((n) => n.toFixed(4)).join(' · ') }}</span
				><span v-if="readonly">{{ i18n.t('app.templates.maps.readonly') }}</span
				><span v-if="disabled">{{ i18n.t('app.templates.maps.disabled') }}</span>
			</footer>
		</main>
	</AsamConfigProvider>
</template>

<script setup lang="ts">
import { AsamConfigProvider } from '@asam-ui/ui';
import MapStage from './MapStage.vue';
import MapToolbar from './MapToolbar.vue';
import PointList from './PointList.vue';
import { useMapPage } from './useMapPage.js';
import type { MapPageEmits, MapPageProps } from './Types.js';
const props = withDefaults(defineProps<MapPageProps>(), { permitted: true });
const emit = defineEmits<MapPageEmits>();
const { provider, controller, canvas, view, locked, size, categories, reload, i18n } = useMapPage(
	props,
	emit
);
defineExpose({ controller, reload, focusMap: () => canvas.value?.focusMap() });
</script>
