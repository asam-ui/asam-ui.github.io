<template>
	<section class="asam-map-stage" :aria-label="i18n.t('app.templates.maps.stage')">
		<AsamPageSkeleton
			v-if="controller.state.status === 'loading'"
			layout="detail"
			:count="3"
			:size="size"
			:label="i18n.t('app.templates.maps.loading')"
		/>
		<AsamStatePanel
			v-else-if="!['ready', 'empty'].includes(controller.state.status)"
			:title="
				i18n.t(
					titleKeys[controller.state.status as keyof typeof titleKeys] ??
						'app.templates.maps.idle'
				)
			"
			:description="controller.displayError.value || i18n.t('app.templates.maps.localHint')"
			:tone="controller.state.status === 'error' ? 'error' : 'info'"
			:size="size"
			:actions="controller.state.status === 'forbidden' ? noActions : retryActions"
		/>
		<template v-else>
			<MapCanvas
				ref="canvas"
				:data="controller.state.data"
				:features="controller.features.value"
				:selected="controller.selected.value"
				:provider="provider"
				:locked="locked"
				:position="controller.state.position"
				@select="controller.select"
				@error="controller.fail"
				@view="$emit('view', $event)"
			/>
			<div v-if="controller.state.status === 'empty'" class="asam-map-empty">
				<AsamStatePanel
					:title="i18n.t('app.templates.maps.empty')"
					:description="i18n.t('app.templates.maps.emptyDescription')"
					:size="size"
				/>
			</div>
		</template>
		<div class="asam-map-attribution">
			Leaflet 1.9.4 · {{ provider.attribution
			}}<template v-if="provider.tiles"> · {{ provider.tiles.attribution }}</template>
		</div>
	</section>
</template>

<script setup lang="ts">
import { useMapI18n } from './I18n.js';
const i18n = useMapI18n();
import { ref } from 'vue';
import { AsamPageSkeleton, AsamStatePanel } from '@asam-ui/pro';
import MapCanvas from './MapCanvas.vue';
import type { MapController } from './Controller.js';
import type { MapCanvasExpose, MapPageProps, MapProvider, MapViewState } from './Types.js';
const props = defineProps<{
	controller: MapController;
	provider: MapProvider;
	locked: boolean;
	size: MapPageProps['size'];
	reload: () => Promise<boolean>;
}>();
defineEmits<{ view: [value: MapViewState] }>();
const canvas = ref<MapCanvasExpose | null>(null);
const noActions: [] = [];
const retryActions = [
	{
		id: 'retry',
		get label() {
			return i18n.t('app.templates.maps.retry');
		},
		run: async () => {
			await props.reload();
		}
	}
];
const titleKeys = {
	error: 'app.templates.maps.error',
	forbidden: 'app.templates.maps.forbidden',
	cancelled: 'app.templates.maps.cancelled',
	disposed: 'app.templates.maps.disposed'
} as const;
defineExpose<MapCanvasExpose>({
	fitAll: () => canvas.value?.fitAll(),
	zoomBy: (delta) => canvas.value?.zoomBy(delta),
	focusMap: () => canvas.value?.focusMap()
});
</script>
