import { createApp } from 'vue';
import 'element-plus/dist/index.css';
import 'element-plus/theme-chalk/dark/css-vars.css';
import '@asam-ui/ui/style.css';
import '@asam-ui/pro/style.css';
import '@asam-ui/maps-template/style.css';
import App from './App.vue';
createApp(App).mount('#app');
