<!-- eslint-disable vue/html-indent -- Template layout follows the repository Prettier configuration. -->
<template>
	<AsamConfigProvider :i18n="i18n">
		<Isolation v-if="isolation" />
		<template v-else>
			<nav :aria-label="i18n.t('app.templates.maps.exampleControls')" class="demo-controls">
				<label
					>{{ i18n.t('app.templates.maps.exampleFamily') }}
					<AsamSelect :model-value="family" @update:model-value="updateFamily">
						<AsamOption value="minimal" label="minimal">minimal</AsamOption>
						<AsamOption value="brand" label="brand">brand</AsamOption>
						<AsamOption value="tech" label="tech">tech</AsamOption>
					</AsamSelect></label
				><label
					>{{ i18n.t('app.templates.maps.exampleSize') }}
					<AsamSelect :model-value="size" @update:model-value="updateSize">
						<AsamOption value="small" label="small">small</AsamOption>
						<AsamOption value="default" label="default">default</AsamOption>
						<AsamOption value="big" label="big">big</AsamOption>
						<AsamOption value="large" label="large">large</AsamOption>
					</AsamSelect></label
				><label
					>{{ i18n.t('app.templates.maps.exampleTheme') }}
					<AsamSelect :model-value="theme" @update:model-value="updateTheme">
						<AsamOption value="light" label="light">light</AsamOption>
						<AsamOption value="dark" label="dark">dark</AsamOption>
					</AsamSelect></label
				><label
					>{{ i18n.t('app.templates.maps.exampleStatus') }}
					<AsamSelect :model-value="scenario" @update:model-value="updateScenario">
						<AsamOption value="normal" label="normal">normal</AsamOption>
						<AsamOption value="loading" label="loading">loading</AsamOption>
						<AsamOption value="empty" label="empty">empty</AsamOption>
						<AsamOption value="invalid" label="invalid">invalid</AsamOption>
						<AsamOption value="error" label="error">error</AsamOption>
						<AsamOption value="missing-key" label="missing-key">missing-key</AsamOption>
						<AsamOption value="tiles-error" label="tiles-error">tiles-error</AsamOption>
					</AsamSelect></label
				><label
					><AsamCheckboxItem
						:model-value="permitted"
						@update:model-value="updateBoolean('permitted', $event)"
					/>{{ i18n.t('app.templates.maps.examplePermission') }}</label
				><label
					><AsamCheckboxItem
						:model-value="readonly"
						@update:model-value="updateBoolean('readonly', $event)"
					/>{{ i18n.t('app.templates.maps.exampleReadonly') }}</label
				><label
					><AsamCheckboxItem
						:model-value="disabled"
						@update:model-value="updateBoolean('disabled', $event)"
					/>{{ i18n.t('app.templates.maps.exampleDisabled') }}</label
				><AsamButton @click="mounted = !mounted">
					{{
						mounted
							? i18n.t('app.templates.maps.exampleUnmount')
							: i18n.t('app.templates.maps.exampleRemount')
					}}
				</AsamButton>
			</nav>
			<component
				:is="components[family]"
				v-if="mounted"
				ref="page"
				:provider="provider"
				identity="demo-user"
				:size="size"
				:theme="theme"
				:permitted="permitted"
				:readonly="readonly"
				:disabled="disabled"
			/>
		</template>
	</AsamConfigProvider>
</template>

<script setup lang="ts">
import { AsamSelect, AsamOption, AsamCheckboxItem } from '@asam-ui/ui';

import { AsamButton } from '@asam-ui/ui';

import { AsamConfigProvider } from '@asam-ui/ui';
import { useMapI18n } from '../I18n.js';
const i18n = useMapI18n();
import { computed, ref } from 'vue';
import { BrandMap, MinimalMap, TechMap, localProvider } from '@asam-ui/maps-template';
import type { MapPageProps, MapProvider } from '@asam-ui/maps-template';
import Isolation from './Isolation.vue';
const isolation = new URLSearchParams(location.search).has('isolation');
const components = { minimal: MinimalMap, brand: BrandMap, tech: TechMap };
const family = ref<keyof typeof components>('minimal');
const size = ref<MapPageProps['size']>('default');
const theme = ref<'light' | 'dark'>('light');
const permitted = ref(true),
	readonly = ref(false),
	disabled = ref(false),
	mounted = ref(true);
const scenario = ref('normal');
function updateFamily(value: unknown) {
	if (value === 'minimal' || value === 'brand' || value === 'tech') family.value = value;
}
function updateSize(value: unknown) {
	if (value === 'small' || value === 'default' || value === 'big' || value === 'large')
		size.value = value;
}
function updateTheme(value: unknown) {
	if (value === 'light' || value === 'dark') theme.value = value;
}
function updateScenario(value: unknown) {
	if (typeof value === 'string') scenario.value = value;
}
function updateBoolean(key: 'permitted' | 'readonly' | 'disabled', value: unknown) {
	if (typeof value === 'boolean') ({ permitted, readonly, disabled })[key].value = value;
}
const page = ref();
const provider = computed<MapProvider>(() => {
	const base = localProvider(),
		mode = scenario.value;
	return {
		...base,
		id: `demo-${mode}`,
		requiresKey: mode === 'missing-key',
		tiles:
			mode === 'tiles-error'
				? {
						url: 'https://tiles.invalid/{z}/{x}/{y}.png',
						attribution: '仅失败测试，不代表实际供应方'
					}
				: undefined,
		async load(context) {
			if (mode === 'loading')
				return new Promise((_, reject) =>
					context.signal.addEventListener(
						'abort',
						() => reject(new DOMException('取消', 'AbortError')),
						{ once: true }
					)
				);
			if (mode === 'error') throw new Error('示意供应方失败，可重新加载');
			if (mode === 'empty') return { type: 'FeatureCollection', features: [] };
			const data = await base.load(context);
			if (mode === 'invalid')
				return {
					...data,
					features: [
						{ ...data.features[0], geometry: { type: 'Point', coordinates: [999, 30] } }
					]
				};
			return data;
		}
	};
});
</script>

<style>
.demo-controls {
	display: flex;
	flex-wrap: wrap;
	gap: 16px;
	align-items: center;
	padding: 14px 24px;
	background: #eef1f5;
	color: #263344;
	font:
		12px/1.8 system-ui,
		sans-serif;
	border-bottom: 1px solid #ced5df;
}
.demo-controls label {
	display: flex;
	gap: 5px;
	align-items: center;
}
.demo-controls button,
.demo-controls select {
	min-height: 30px;
}
</style>
