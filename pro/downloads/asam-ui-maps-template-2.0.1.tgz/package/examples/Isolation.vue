<template>
	<AsamConfigProvider :i18n="i18n">
		<section>
			<nav class="demo-controls" :aria-label="i18n.t('app.templates.maps.exampleSessions')">
				<AsamButton @click="mode = mode === 'normal' ? 'pending' : 'normal'">
					{{ i18n.t('app.templates.maps.exampleProvider') }}</AsamButton
				><AsamButton @click="identity = String(Number(identity) + 1)">
					{{ i18n.t('app.templates.maps.exampleIdentity') }}</AsamButton
				><AsamButton @click="resolveLoads()">
					{{ i18n.t('app.templates.maps.exampleResolveLoad') }}</AsamButton
				><AsamButton @click="locationMode = 'pending'">
					{{ i18n.t('app.templates.maps.exampleLocationPending') }}</AsamButton
				><AsamButton @click="locationMode = 'timeout'">
					{{ i18n.t('app.templates.maps.exampleLocationTimeout') }}</AsamButton
				><AsamButton @click="locationMode = 'unsupported'">
					{{ i18n.t('app.templates.maps.exampleLocationUnsupported') }}</AsamButton
				><AsamButton @click="resolveLocations()">
					{{ i18n.t('app.templates.maps.exampleResolveLocation') }}</AsamButton
				><output>{{
					i18n.t('app.templates.maps.exampleReleased', { count: releases })
				}}</output>
			</nav>
			<div class="isolation-left">
				<MinimalMap :provider="provider" :identity="identity" :location="location" />
			</div>
			<div class="isolation-right"><MinimalMap /></div>
		</section>
	</AsamConfigProvider>
</template>

<script setup lang="ts">
import { AsamButton } from '@asam-ui/ui';

defineOptions({ name: 'MapSessionIsolation' });
import { AsamConfigProvider } from '@asam-ui/ui';
import { useMapI18n } from '../I18n.js';
const i18n = useMapI18n();
import { computed, ref } from 'vue';
import { MinimalMap, localProvider } from '@asam-ui/maps-template';
import type { MapDataset, Position, MapProvider, LocationPort } from '@asam-ui/maps-template';
const mode = ref('normal'),
	identity = ref('0'),
	releases = ref(0),
	locationMode = ref('pending');
const loads: (() => void)[] = [],
	locations: (() => void)[] = [];
const provider = computed<MapProvider>(() => {
	const base = localProvider(),
		pending = mode.value === 'pending';
	return {
		...base,
		id: mode.value,
		release: () => {
			releases.value++;
		},
		async load(context) {
			if (!pending) return base.load(context);
			return new Promise<MapDataset>((resolve) =>
				loads.push(async () =>
					resolve(await base.load({ ...context, signal: new AbortController().signal }))
				)
			);
		}
	};
});
const location: LocationPort = {
	locate: async () => {
		if (locationMode.value === 'timeout') throw { code: 3 };
		if (locationMode.value === 'unsupported') throw { code: 0 };
		return new Promise<Position>((resolve) => locations.push(() => resolve([120.162, 30.274])));
	}
};
function resolveLoads() {
	for (const resolve of loads.splice(0)) resolve();
}
function resolveLocations() {
	for (const resolve of locations.splice(0)) resolve();
}
</script>
