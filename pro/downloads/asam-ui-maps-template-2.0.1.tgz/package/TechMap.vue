<template>
	<AsamConfigProvider :i18n="i18n">
		<main class="asam-map-page asam-map-tech" :data-size="size" :data-theme="theme ?? 'dark'">
			<header class="asam-map-header">
				<div>
					<p class="asam-map-eyebrow">ASAM / SPATIAL CONSOLE</p>
					<h1>{{ i18n.t('app.templates.maps.techTitle') }}</h1>
				</div>
				<div class="asam-map-telemetry">
					<span>WGS84 → EPSG3857</span
					><strong>{{ i18n.t(statusKeys[controller.state.status]) }}</strong
					><span>LOCAL / KEY FREE</span>
				</div>
			</header>
			<div class="asam-map-tech-body">
				<MapStage
					ref="canvas"
					:controller="controller"
					:provider="provider"
					:locked="locked"
					:size="size"
					:reload="reload"
					@view="view = $event"
				/>
				<aside>
					<p class="asam-map-eyebrow">{{ i18n.t('app.templates.maps.pointIndex') }}</p>
					<PointList :controller="controller" :locked="locked" />
					<dl class="asam-map-coordinates">
						<dt>{{ i18n.t('app.templates.maps.longitude') }}</dt>
						<dd>{{ view.center[0].toFixed(5) }}</dd>
						<dt>{{ i18n.t('app.templates.maps.latitude') }}</dt>
						<dd>{{ view.center[1].toFixed(5) }}</dd>
						<dt>{{ i18n.t('app.templates.maps.zoomLabel') }}</dt>
						<dd>{{ view.zoom }}</dd>
					</dl>
				</aside>
			</div>
			<footer class="asam-map-tech-controls">
				<MapToolbar
					:controller="controller"
					:categories="categories"
					:locked="locked"
					@fit="canvas?.fitAll()"
					@zoom="canvas?.zoomBy($event)"
				/>
				<p>
					{{ provider.title }} · {{ i18n.t('app.templates.maps.local')
					}}<span v-if="readonly"> · {{ i18n.t('app.templates.maps.readonly') }}</span
					><span v-if="disabled"> · {{ i18n.t('app.templates.maps.disabled') }}</span>
				</p>
			</footer>
		</main>
	</AsamConfigProvider>
</template>

<script setup lang="ts">
import { AsamConfigProvider } from '@asam-ui/ui';
import MapStage from './MapStage.vue';
import MapToolbar from './MapToolbar.vue';
import PointList from './PointList.vue';
import { useMapPage } from './useMapPage.js';
import type { MapPageEmits, MapPageProps } from './Types.js';
const props = withDefaults(defineProps<MapPageProps>(), { permitted: true });
const emit = defineEmits<MapPageEmits>();
const { provider, controller, canvas, view, locked, size, categories, reload, i18n } = useMapPage(
	props,
	emit
);
const statusKeys = {
	idle: 'app.templates.maps.statusIdle',
	loading: 'app.templates.maps.statusLoading',
	ready: 'app.templates.maps.statusReady',
	empty: 'app.templates.maps.statusEmpty',
	error: 'app.templates.maps.statusError',
	forbidden: 'app.templates.maps.statusForbidden',
	cancelled: 'app.templates.maps.statusCancelled',
	disposed: 'app.templates.maps.statusDisposed'
} as const;
defineExpose({ controller, reload, focusMap: () => canvas.value?.focusMap() });
</script>
