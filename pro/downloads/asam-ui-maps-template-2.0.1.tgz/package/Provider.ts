import { demoData } from './Data.js';
import type { LocationPort, MapProvider } from './Types.js';

export function localProvider(): MapProvider {
	return {
		id: 'asam-local',
		title: '水岸街区 · 本地示意',
		attribution: 'ASAM 自制示意数据 · 非真实底图',
		async load({ signal }) {
			if (signal.aborted) throw new DOMException('已取消', 'AbortError');
			return structuredClone(demoData);
		}
	};
}
export function browserLocation(): LocationPort {
	return {
		locate(signal) {
			return new Promise((resolve, reject) => {
				if (signal.aborted) return reject(new DOMException('已取消', 'AbortError'));
				if (typeof navigator === 'undefined' || !navigator.geolocation)
					return reject({ code: 0 });
				const cancel = () => reject(new DOMException('已取消', 'AbortError'));
				signal.addEventListener('abort', cancel, { once: true });
				navigator.geolocation.getCurrentPosition(
					(result) => {
						signal.removeEventListener('abort', cancel);
						resolve([result.coords.longitude, result.coords.latitude]);
					},
					(error) => {
						signal.removeEventListener('abort', cancel);
						reject(error);
					},
					{ enableHighAccuracy: false, timeout: 8000, maximumAge: 0 }
				);
			});
		}
	};
}
