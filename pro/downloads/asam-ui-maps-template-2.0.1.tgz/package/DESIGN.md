# 三族设计取舍与参考

任务是 ASAM 的前端地图模板，面向需要可修改 SFC 的工程使用者。沿 ASAM 现有 tokens/四尺寸/状态语义，以本地街区数据组织空间浏览；默认没有外部图片、字体或地理资源。

参考输入：已确认 PAGE-TEMPLATE-DESIGN-20261018 与 P30-MAP-DESKTOP-DECISIONS-20261019（固定base 2d814770）。视觉参考为本文件给出的可复现结构蓝图和本卡真实预览，不声称获得未提供的设计稿。三族源文件分别为 MinimalMap.vue、BrandMap.vue、TechMap.vue。

| 族       | 实际读过的 Skill                                                                                        | 采用                                                      | 本任务取舍                                                                                           |
| -------- | ------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| 克制简约 | C:/Users/Administrator/.agents/skills/minimalist-ui/SKILL.md                                            | 平面边界、节制留白、文字层次、无外部图片                  | 使用系统字与 ASAM token；不引入字体、图标包或巨幅营销间距；地图在小屏可操作                          |
| 品牌分栏 | C:/Users/Administrator/.agents/skills/design-taste-frontend/SKILL.md                                    | 版面层次、品牌侧栏、单一品牌色、窄屏严格折叠；dials 4/2/5 | 该Skill主适用营销页，本卡只采纳其适用构图原则，Vue/ASAM优先，不照搬React/Motion/Tailwind或商业站结构 |
| 深色科技 | C:/Users/Administrator/.agents/skills/high-end-visual-design/SKILL.md；industrial-brutalist-ui/SKILL.md | 仪表信息分区、mono坐标、右栏观测与底部控制                | 不引入玻璃重阴影、噪点/CRT、装饰状态灯或悬浮旋转；浅色依然可用，深色仅默认值                         |

构图蓝图：Minimal 为“横向标题→全宽工具→宽地图+窄右目录→元数据”；Brand 为“纵向品牌与目录｜标题+工具+地图”；Tech 为“标题+真实状态→地图｜点位+坐标→全宽底部控制”。图形都是 SDK 真实线/面与 CSS 本地网格，编号 marker 为 DOM 文本，无第三方图形复制。

CSS 只对详情入场做160ms淡入/4px位移，按钮反馈120ms；不推迟地图操作。prefers-reduced-motion 关闭动效。地图自身关闭 zoom/fade/inertia 动画以保持操作可预测。760px以下折为单列，地图至少340px，原生焦点高亮保留；工具的触控最低高度32px。

每族同样支持明暗、四尺寸、状态/只读/权限与恢复；三族变体由真实构图完成，不能用 theme 切换冒新族。正常、修改、还原实际生产预览和截图索引放外部交付原件，由独立QA逐族核查。
