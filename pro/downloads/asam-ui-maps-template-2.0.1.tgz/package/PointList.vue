<template>
	<section class="asam-map-points" :aria-label="i18n.t('app.templates.maps.points')">
		<div class="asam-map-list-heading">
			<h2>{{ i18n.t('app.templates.maps.pointsTitle') }}</h2>
			<span>{{
				i18n.t('app.templates.maps.pointCount', { count: controller.points.value.length })
			}}</span>
		</div>
		<p v-if="!controller.points.value.length" role="status">
			{{ i18n.t('app.templates.maps.noMatches') }}
		</p>
		<ol>
			<li v-for="(point, index) in controller.points.value" :key="point.id">
				<AsamButton
					class="asam-map-point"
					type="default"
					text
					:data-point-id="point.id"
					:aria-pressed="controller.state.selected === point.id"
					:disabled="locked"
					@click="controller.select(point.id)"
				>
					<span class="asam-map-point-content">
						<span class="asam-map-number">{{
							String(index + 1).padStart(2, '0')
						}}</span>
						<span>
							<strong>{{ point.properties.title }}</strong>
							<small>{{ point.properties.category }}</small>
						</span>
						<span aria-hidden="true">↗</span>
					</span>
				</AsamButton>
			</li>
		</ol>
		<section
			v-if="controller.selected.value"
			class="asam-map-detail"
			:aria-label="i18n.t('app.templates.maps.detail')"
		>
			<h3>{{ controller.selected.value.properties.title }}</h3>
			<p>{{ controller.selected.value.properties.description }}</p>
			<AsamButton type="default" @click="controller.select(null)">
				{{ i18n.t('app.templates.maps.closeDetail') }}
			</AsamButton>
		</section>
	</section>
</template>

<script setup lang="ts">
import { AsamButton } from '@asam-ui/ui';
import { useMapI18n } from './I18n.js';
const i18n = useMapI18n();
import type { MapController } from './Controller.js';
defineProps<{ controller: MapController; locked: boolean }>();
</script>
