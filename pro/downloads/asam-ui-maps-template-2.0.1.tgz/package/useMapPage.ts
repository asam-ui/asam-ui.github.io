import { computed, onBeforeUnmount, ref, watch } from 'vue';
import { useAsamControlSize } from '@asam-ui/ui';
import { createMapController } from './Controller.js';
import { localProvider } from './Provider.js';
import { useMapI18n } from './I18n.js';
import type { MapCanvasExpose, MapPageProps, MapPageEmits, MapViewState } from './Types.js';

export function useMapPage(
	props: MapPageProps,
	emit: {
		(event: 'select', feature: MapPageEmits['select'][0]): void;
		(event: 'status', status: MapPageEmits['status'][0]): void;
		(event: 'location', status: MapPageEmits['location'][0]): void;
	}
) {
	const i18n = useMapI18n();
	const fallback = localProvider();
	const provider = computed(() => props.provider ?? fallback);
	const controller = createMapController(props.location, i18n);
	const canvas = ref<MapCanvasExpose | null>(null);
	const view = ref<MapViewState>({ zoom: 13, center: [120.162, 30.274] });
	const locked = computed(() => !!props.readonly || !!props.disabled);
	const size = useAsamControlSize(() => props.size);
	const categories = computed(() => [
		...new Set(
			controller.state.data?.features
				.filter((feature) => feature.geometry.type === 'Point')
				.map((feature) => feature.properties.category) ?? []
		)
	]);
	function reload() {
		return controller.load(
			provider.value,
			props.identity ?? '',
			props.permitted !== false,
			locked.value
		);
	}
	watch(() => [provider.value, props.identity, props.permitted, locked.value], reload, {
		immediate: true
	});
	watch(
		() => controller.selected.value,
		(value) => emit('select', value)
	);
	watch(
		() => controller.state.status,
		(value) => emit('status', value),
		{ immediate: true }
	);
	watch(
		() => controller.state.locationStatus,
		(value) => emit('location', value)
	);
	onBeforeUnmount(controller.dispose);
	return { provider, controller, canvas, view, locked, size, categories, reload, i18n };
}
