# Agent 使用与增量修改

先读 capability.json，再按需读 API.md/Types.ts 和所选族 SFC。意图“离线地图/点位筛选/地图侧栏”对应本模板；真实在线底图、GCJ02转换、后台授权和CL接口不在已验范围。先核工程版本和样式，不默认将源码/位置/Key上传外部服务。

选择 MinimalMap（目录型）、BrandMap（品牌分栏）、TechMap（观测型）。需要改标题/信息结构直接修改对应普通SFC；换点位用 typed MapProvider 返回合法 GeoJSON，不改 SDK 内部。每次身份变化传新的 identity；页面权限传 permitted；定位只经明确用户按钮。

正常修改配方：

1. 正常包消费者先固定 maps tar、UI/Pro tar、lock、模板源码与浏览器收据。
2. 将完整普通 SFC 从包 source 导出复制到应用自己的目录，保相对依赖。将 MinimalMap 的“水岸生活地图”改为“社区空间导览”，将同版 Data.ts 的北岸设计室改为“北岸创作站”，不改变其余族/数据协议。
3. 重新构建生产库/包与消费者，执行同一类型和交互断言；新增名字必须出现在真实 marker/list 中，popup仍可键盘关闭，无新增默认网络。
4. 从固定正常Git源码还原两个文件；再次构建正常包、安装和生产预览。逐项比较 source/dist/tar/配置/锁身份，记录修改确实变化和还原恢复；不以手改DOM、运行时注入或静态图片替代。

独立验证脚本 variant.mjs 按上述“正常→修改→还原”生成独立可读来源及包；每阶段都保留自己安装元数据和浏览器结果。修改模式是工程修改，不安装Agent运行时，原组件不因开发套件停用而失效。

异常定位：error先读provider/key/合法GeoJSON/tiles许可/CSP；forbidden核宿主授权；cancelled用reload；定位denied/timeout允许用户再次主动尝试。发现未知坐标系先停止该数据接入并说明缺项，不自动换算。失败、NOT_RUN和未测在线供应方保留，不夸大为完整产品/双宿主已验。

公共接入差额见 INTEGRATION-PROPOSAL.md，只交主控串行处理；本卡不写官网导航或agent聚合后端。
