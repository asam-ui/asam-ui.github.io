<template>
	<div
		ref="element"
		class="asam-map-canvas"
		role="region"
		:aria-label="i18n.t('app.templates.maps.canvas')"
	/>
</template>

<script setup lang="ts">
import { useMapI18n } from './I18n.js';
const i18n = useMapI18n();
import {
	getCurrentInstance,
	h,
	nextTick,
	onBeforeUnmount,
	onMounted,
	ref,
	render as renderVNode,
	watch,
	watchEffect
} from 'vue';
import { AsamButton } from '@asam-ui/ui';
import { createAsamMessageError } from '@asam-ui/pro/i18n';
import type * as Leaflet from 'leaflet';
import type {
	MapCanvasExpose,
	MapDataset,
	MapFeature,
	MapProvider,
	MapViewState,
	Position
} from './Types.js';
const props = defineProps<{
	data: MapDataset | null;
	features: readonly MapFeature[];
	selected: MapFeature | null;
	provider: MapProvider;
	locked: boolean;
	position: Position | null;
}>();
const emit = defineEmits<{
	select: [id: string | null];
	error: [message: string, source?: Error];
	view: [state: MapViewState];
}>();
const element = ref<HTMLElement | null>(null);
let sdk: typeof Leaflet | undefined;
let map: Leaflet.Map | undefined;
let group: Leaflet.FeatureGroup | undefined;
let userLocation: Leaflet.CircleMarker | undefined;
let observer: ResizeObserver | undefined;
let media: MediaQueryList | undefined;
let epoch = 0;
let destroyed = false;
const markers = new Map<string, Leaflet.Marker>();
let popupOrigin: HTMLElement | null = null;
let popupSelection: string | null = null;
let focusRequest = 0;
let replacingPopup = false;
const appContext = getCurrentInstance()?.appContext;
let popupLabels: { content: HTMLElement; actions: HTMLElement; title: string } | undefined;
// Translate existing DOM only. Language changes never recreate layers or request resources.
function updateLabels() {
	if (popupLabels) {
		popupLabels.content.setAttribute(
			'aria-label',
			i18n.t('app.templates.maps.popup', { title: popupLabels.title })
		);
	}
	for (const [id, marker] of markers) {
		const feature = props.features.find((item) => item.id === id);
		if (feature)
			marker
				.getElement()
				?.setAttribute(
					'aria-label',
					i18n.t('app.templates.maps.selectPoint', { title: feature.properties.title })
				);
	}
}
watchEffect(updateLabels);
function releasePopupControls() {
	if (!popupLabels) return;
	renderVNode(null, popupLabels.actions);
	popupLabels = undefined;
}
function dispose() {
	epoch++;
	focusRequest++;
	observer?.disconnect();
	observer = undefined;
	media?.removeEventListener('change', motion);
	media = undefined;
	map?.off();
	map?.remove();
	map = undefined;
	group = undefined;
	userLocation = undefined;
	markers.clear();
	popupOrigin = null;
	popupSelection = null;
	releasePopupControls();
}
function motion() {
	if (media?.matches) map?.stop();
}
function frameData() {
	if (!map || !group) return;
	const bounds = group.getBounds();
	if (bounds.isValid()) map.fitBounds(bounds, { padding: [36, 36], maxZoom: 14, animate: false });
}
function fitAll() {
	if (!props.locked) frameData();
}
function restorePopupFocus() {
	const origin = popupOrigin;
	popupOrigin = null;
	popupSelection = null;
	if (!origin) return;
	const request = ++focusRequest;
	void nextTick(() => {
		if (destroyed || request !== focusRequest) return;
		const page = element.value?.closest('.asam-map-page');
		// Resolve after sibling list updates, so a removed trigger cannot briefly take focus.
		const replacement = origin.dataset.pointId
			? Array.from(page?.querySelectorAll<HTMLElement>('[data-point-id]') ?? []).find(
					(node) =>
						node.dataset.pointId === origin.dataset.pointId &&
						node.className === origin.className &&
						!node.matches(':disabled')
				)
			: undefined;
		const target = origin.isConnected && !origin.matches(':disabled') ? origin : replacement;
		if (target) target.focus({ preventScroll: true });
		else
			page?.querySelector<HTMLElement>(
				'.asam-map-category-select input:not(:disabled)'
			)?.focus({
				preventScroll: true
			});
	});
}
function view() {
	if (!map) return;
	const center = map.getCenter();
	emit('view', { zoom: map.getZoom(), center: [center.lng, center.lat] });
}
function selectPopup() {
	if (!map || !sdk) return;
	const nextSelection = props.selected?.id ?? null;
	const preserveOrigin = nextSelection !== null && nextSelection === popupSelection;
	if (nextSelection !== null) focusRequest++;
	// Replacing a selection must not focus the previous trigger. Clearing it must.
	replacingPopup = nextSelection !== null;
	map.closePopup();
	releasePopupControls();
	replacingPopup = false;
	if (props.locked || !props.selected) {
		restorePopupFocus();
		return;
	}
	const feature = props.selected;
	const marker = markers.get(feature.id);
	if (!marker) return;
	if (!preserveOrigin) {
		popupOrigin = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		popupSelection = nextSelection;
	}
	const content = document.createElement('section');
	content.className = 'asam-map-popup';
	content.tabIndex = -1;
	const title = document.createElement('strong');
	title.textContent = feature.properties.title;
	const description = document.createElement('p');
	description.textContent = feature.properties.description;
	const actions = document.createElement('div');
	popupLabels = { content, actions, title: feature.properties.title };
	updateLabels();
	const closeButton = h(
		AsamButton,
		{ type: 'default', nativeType: 'button', onClick: () => map?.closePopup() },
		{ default: () => i18n.t('app.templates.maps.closePopup') }
	);
	closeButton.appContext = appContext ?? null;
	renderVNode(closeButton, actions);
	content.append(title, description, actions);
	marker.bindPopup(content, { closeButton: false, autoPan: true }).openPopup();
	content.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			event.preventDefault();
			map?.closePopup();
		}
	});
	actions.querySelector('button')?.focus({ preventScroll: true });
}
function render() {
	if (!map || !sdk) return;
	replacingPopup = true;
	group?.remove();
	replacingPopup = false;
	markers.clear();
	group = sdk.featureGroup().addTo(map);
	for (const feature of props.features) {
		const geometry = feature.geometry;
		if (geometry.type === 'Point') {
			const badge = document.createElement('span');
			badge.className = 'asam-map-pin';
			badge.textContent = String(markers.size + 1);
			const marker = sdk
				.marker([geometry.coordinates[1], geometry.coordinates[0]], {
					icon: sdk.divIcon({
						html: badge,
						className: 'asam-map-marker',
						iconSize: [32, 32],
						iconAnchor: [16, 16]
					}),
					title: feature.properties.title,
					alt: feature.properties.title,
					keyboard: !props.locked,
					interactive: !props.locked,
					autoPanOnFocus: false
				})
				.addTo(group);
			marker.on('click', () => {
				if (!props.locked) emit('select', feature.id);
			});
			const node = marker.getElement();
			if (node) {
				node.dataset.pointId = feature.id;
				node.setAttribute('role', 'button');
				node.setAttribute('aria-disabled', String(props.locked));
				node.addEventListener('keydown', (event) => {
					if (event.key === ' ' || event.key === 'Enter') {
						event.preventDefault();
						if (!props.locked) emit('select', feature.id);
					}
				});
			}
			markers.set(feature.id, marker);
		} else {
			const coordinates =
				geometry.type === 'LineString'
					? geometry.coordinates.map((point) => [...point])
					: geometry.coordinates.map((ring) => ring.map((point) => [...point]));
			const layer = sdk.geoJSON(
				{
					type: 'Feature',
					properties: {},
					geometry: { type: geometry.type, coordinates }
				} as GeoJSON.Feature,
				{
					interactive: false,
					style: {
						color: geometry.type === 'Polygon' ? '#53927a' : '#6785a4',
						weight: geometry.type === 'Polygon' ? 2 : 5,
						fillOpacity: 0.16,
						dashArray: geometry.type === 'LineString' ? '8 6' : undefined
					}
				}
			);
			layer.addTo(group);
		}
	}
	updateLabels();
	selectPopup();
}
function updateLocation() {
	userLocation?.remove();
	userLocation = undefined;
	if (!props.position || !sdk || !map || props.locked) return;
	userLocation = sdk
		.circleMarker([props.position[1], props.position[0]], {
			radius: 9,
			color: '#1769a8',
			fillOpacity: 0.8,
			interactive: false
		})
		.addTo(map);
	map.setView(userLocation.getLatLng(), 14, { animate: false });
}
async function mount() {
	dispose();
	if (!props.data || !element.value || destroyed) return;
	const current = epoch;
	try {
		sdk = await import('leaflet');
		if (current !== epoch || destroyed || !element.value) return;
		media = matchMedia('(prefers-reduced-motion: reduce)');
		media.addEventListener('change', motion);
		map = sdk.map(element.value, {
			...props.provider.options,
			crs: sdk.CRS.EPSG3857,
			center: [30.274, 120.162],
			zoom: 13,
			zoomControl: false,
			attributionControl: false,
			dragging: !props.locked,
			keyboard: !props.locked,
			scrollWheelZoom: !props.locked,
			doubleClickZoom: !props.locked,
			touchZoom: !props.locked,
			boxZoom: !props.locked,
			zoomAnimation: false,
			fadeAnimation: false,
			markerZoomAnimation: false,
			inertia: false
		});
		if (props.locked) element.value.setAttribute('tabindex', '-1');
		map.on('moveend zoomend', view);
		map.on('popupclose', () => {
			if (replacingPopup) return;
			releasePopupControls();
			emit('select', null);
			restorePopupFocus();
		});
		if (props.provider.tiles) {
			const tiles = props.provider.tiles;
			// Only host-supplied public HTTPS tile endpoints. No default network layer.
			if (!tiles.url.startsWith('https://') || !tiles.attribution.trim())
				throw createAsamMessageError(
					'瓦片须为授权 HTTPS 资源且提供署名',
					'app.templates.maps.tilesInvalid'
				);
			const url = tiles.url.replace(
				'{key}',
				encodeURIComponent(props.provider.clientKey ?? '')
			);
			const layer = sdk.tileLayer(url, tiles.options);
			layer.on('tileerror', () => {
				if (current === epoch && !destroyed)
					emit(
						'error',
						'地图瓦片资源加载失败，请检查供应方后重试',
						createAsamMessageError(
							'地图瓦片资源加载失败，请检查供应方后重试',
							'app.templates.maps.tileError'
						)
					);
			});
			layer.addTo(map);
		}
		render();
		// Initial/data framing is programmatic display, independent of interaction locks.
		frameData();
		view();
		updateLocation();
		observer = new ResizeObserver(() => {
			const popup = props.selected ? markers.get(props.selected.id)?.getPopup() : undefined;
			const active = document.activeElement;
			const focused =
				active instanceof HTMLElement &&
				popup?.isOpen() &&
				popup.getElement()?.contains(active)
					? active
					: undefined;
			map?.invalidateSize({ animate: false });
			// Ask Leaflet's public popup API to fit an already open popup after resizing.
			popup?.update();
			// The public update may detach and reinsert the focused content synchronously.
			// Restore only focus lost to that operation, without taking it from another control.
			if (
				focused?.isConnected &&
				!destroyed &&
				popup?.isOpen() &&
				popup.getElement()?.contains(focused) &&
				!focused.matches(':disabled') &&
				!focused.closest('[inert]') &&
				focused.getClientRects().length > 0 &&
				(document.activeElement === document.body ||
					document.activeElement === document.documentElement)
			)
				focused.focus({ preventScroll: true });
		});
		observer.observe(element.value);
	} catch {
		if (current === epoch && !destroyed) {
			dispose();
			emit(
				'error',
				'地图实例或资源初始化失败',
				createAsamMessageError(
					'地图实例或资源初始化失败',
					'app.templates.maps.initializeError'
				)
			);
		}
	}
}
watch(() => [props.data, props.provider, props.locked], mount);
watch(() => props.features, render);
watch(() => props.selected, selectPopup);
watch(() => props.position, updateLocation);
onMounted(mount);
onBeforeUnmount(() => {
	destroyed = true;
	dispose();
});
defineExpose<MapCanvasExpose>({
	fitAll,
	zoomBy(delta) {
		if (!props.locked && Number.isFinite(delta))
			map?.setZoom(map.getZoom() + delta, { animate: false });
	},
	focusMap() {
		if (!props.locked) element.value?.focus();
	}
});
</script>
