<template>
	<div class="asam-map-toolbar" :aria-label="i18n.t('app.templates.maps.toolbar')">
		<div class="asam-map-category">
			<span>{{ i18n.t('app.templates.maps.category') }}</span>
			<AsamSelect
				class="asam-map-category-select"
				:aria-label="i18n.t('app.templates.maps.category')"
				:model-value="controller.state.filter"
				:empty-values="[null, undefined]"
				:disabled="locked || controller.state.status !== 'ready'"
				@update:model-value="updateCategory"
			>
				<AsamOption value="" :label="i18n.t('app.templates.maps.allCategories')" />
				<AsamOption
					v-for="category in categories"
					:key="category"
					:value="category"
					:label="category"
				/>
			</AsamSelect>
		</div>
		<AsamButton
			type="default"
			:disabled="locked || controller.state.status !== 'ready'"
			@click="
				controller.filter('');
				controller.select(null);
			"
		>
			{{ i18n.t('app.templates.maps.clear') }}
		</AsamButton>
		<AsamButton
			type="default"
			:disabled="locked || controller.state.status !== 'ready'"
			@click="$emit('fit')"
		>
			{{ i18n.t('app.templates.maps.fit') }}
		</AsamButton>
		<AsamButton
			type="primary"
			:disabled="
				locked ||
				controller.state.status !== 'ready' ||
				controller.state.locationStatus === 'pending'
			"
			@click="controller.locate()"
		>
			{{ i18n.t('app.templates.maps.locate') }}
		</AsamButton>
		<AsamButton
			type="default"
			v-if="controller.state.locationStatus === 'pending'"
			@click="controller.cancelLocation()"
		>
			{{ i18n.t('app.templates.maps.cancelLocation') }}
		</AsamButton>
		<AsamButton
			type="default"
			v-if="controller.state.status === 'loading'"
			@click="controller.cancel()"
		>
			{{ i18n.t('app.templates.maps.cancelLoad') }}
		</AsamButton>
		<AsamButton
			type="default"
			:disabled="locked || controller.state.status !== 'ready'"
			:aria-label="i18n.t('app.templates.maps.zoomIn')"
			@click="$emit('zoom', 1)"
		>
			＋
		</AsamButton>
		<AsamButton
			type="default"
			:disabled="locked || controller.state.status !== 'ready'"
			:aria-label="i18n.t('app.templates.maps.zoomOut')"
			@click="$emit('zoom', -1)"
		>
			−
		</AsamButton>
		<p class="asam-map-location" role="status">
			{{ i18n.t(locationKeys[controller.state.locationStatus]) }}
		</p>
		<p v-if="controller.state.cleanupError" role="alert">
			{{ controller.displayCleanupError.value }}
		</p>
	</div>
</template>

<script setup lang="ts">
import { AsamButton, AsamOption, AsamSelect } from '@asam-ui/ui';
import { useMapI18n } from './I18n.js';
const i18n = useMapI18n();
import type { MapController } from './Controller.js';
import type { LocationStatus } from './Types.js';
import type { MapMessageParameters } from './I18nParameters.js';
const props = defineProps<{ controller: MapController; categories: string[]; locked: boolean }>();
defineEmits<{ fit: []; zoom: [delta: number] }>();
const locationKeys = {
	idle: 'app.templates.maps.locationIdle',
	pending: 'app.templates.maps.locationPending',
	success: 'app.templates.maps.locationSuccess',
	denied: 'app.templates.maps.locationDenied',
	timeout: 'app.templates.maps.locationTimeout',
	unavailable: 'app.templates.maps.locationUnavailable',
	unsupported: 'app.templates.maps.locationUnsupported',
	cancelled: 'app.templates.maps.locationCancelled'
} as const satisfies Record<LocationStatus, keyof MapMessageParameters>;

function updateCategory(value: unknown) {
	if (typeof value === 'string') props.controller.filter(value);
}
</script>
