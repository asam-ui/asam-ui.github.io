<template>
	<AsamConfigProvider :i18n="i18n">
		<main class="asam-map-page asam-map-brand" :data-size="size" :data-theme="theme">
			<aside class="asam-map-brand-rail">
				<p class="asam-map-eyebrow">ASAM PLACES</p>
				<h1>{{ i18n.t('app.templates.maps.brandTitle') }}</h1>
				<p>{{ i18n.t('app.templates.maps.brandSubtitle') }}</p>
				<div class="asam-map-brand-rule" />
				<p>{{ i18n.t('app.templates.maps.brandNeighborhood') }}</p>
				<PointList :controller="controller" :locked="locked" /><small>{{
					i18n.t('app.templates.maps.brandDisclaimer')
				}}</small>
			</aside>
			<section class="asam-map-brand-main">
				<header class="asam-map-header">
					<div>
						<p class="asam-map-eyebrow">
							{{ i18n.t('app.templates.maps.brandEdition') }}
						</p>
						<h2>{{ i18n.t('app.templates.maps.brandHeading') }}</h2>
					</div>
					<span class="asam-map-label">{{
						i18n.t('app.templates.maps.localCoordinates')
					}}</span>
				</header>
				<MapToolbar
					:controller="controller"
					:categories="categories"
					:locked="locked"
					@fit="canvas?.fitAll()"
					@zoom="canvas?.zoomBy($event)"
				/><MapStage
					ref="canvas"
					:controller="controller"
					:provider="provider"
					:locked="locked"
					:size="size"
					:reload="reload"
					@view="view = $event"
				/>
				<footer class="asam-map-footer">
					<span>{{ provider.title }}</span
					><span>{{ i18n.t('app.templates.maps.zoom') }} {{ view.zoom }}</span
					><span v-if="readonly">{{ i18n.t('app.templates.maps.readonly') }}</span
					><span v-if="disabled">{{ i18n.t('app.templates.maps.disabled') }}</span>
				</footer>
			</section>
		</main>
	</AsamConfigProvider>
</template>

<script setup lang="ts">
import { AsamConfigProvider } from '@asam-ui/ui';
import MapStage from './MapStage.vue';
import MapToolbar from './MapToolbar.vue';
import PointList from './PointList.vue';
import { useMapPage } from './useMapPage.js';
import type { MapPageEmits, MapPageProps } from './Types.js';
const props = withDefaults(defineProps<MapPageProps>(), { permitted: true });
const emit = defineEmits<MapPageEmits>();
const { provider, controller, canvas, view, locked, size, categories, reload, i18n } = useMapPage(
	props,
	emit
);
defineExpose({ controller, reload, focusMap: () => canvas.value?.focusMap() });
</script>
