import { useAsamProI18n } from '@asam-ui/pro/i18n';
import { mapMessagesEn } from './I18nEn.js';
import { mapMessagesZh } from './I18nZh.js';
export const mapMessageDefaults = Object.freeze({ en: mapMessagesEn, 'zh-CN': mapMessagesZh });
export function useMapI18n() {
	return useAsamProI18n(mapMessageDefaults);
}
