# 主控精确接入差额

本候选只新增 templates/maps/ 与 tests/v2/maps/。不需要修改 UI/Pro 出口、tokens、根 package/workspace/锁或导航协议。模板为独立源码与包交付，禁止把本卡安装输出提交根仓。

050同源索引可新增 id=asam.template.maps、标题“本地示意地图”、版本0.1.0-alpha.1、families=MinimalMap/BrandMap/TechMap，指向本目录 README/API/Types/AGENT/capability 与完整SFC。公开预览由050按本包 examples 的同版本构建提供，不能放Storybook或未授权在线地图。

051按 capability.json 增量引用能力/意图，按 AGENT.md 提供选择风格、typed provider/坐标/状态和正常修改还原配方；不新增每页MCP/Skill服务。052如消费本模板，应固定本实际tar与资料版本并重放自己的宿主任务；本DEV自测不替跨宿主结论。

导航消费者只需在现有 V2-032 的 components allowlist 添加本应用普通 Map 页面，由宿主菜单/visible处理权限。无需修改navigation源码。实际canonical聚合、官网或Agent入口由原owner/唯一主控处理，本卡不越界代写。
