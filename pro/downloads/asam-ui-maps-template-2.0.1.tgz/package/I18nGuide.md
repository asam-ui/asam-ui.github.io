# 统一语言接入

父级 UI/应用 Provider 绑定宿主已有 i18n；`useMapPage` 使用 `useMapI18n()` 补本地缺省资源，并将 scope 传入模板子树和控制器。没有第二个 currentLocale、全局 storage 或默认联网翻译地址。`I18n*.ts` 仅随地图模板交付，不进入 UI/Pro 核心。

命名空间为 `app.templates.maps.*`。`pointCount.count`、`exampleReleased.count` 是数字，`popup.title` 与 `selectPoint.title` 为原始宿主点位标题。所有工具、状态、默认标题、ARIA、点位目录与示例外围文案中英齐备；host 覆盖/注册优先。未配置统一语言时保留旧默认。供应方名称、署名、点位类别/标题/描述、坐标和 GeoJSON 原样保留。

`createMapController(location?, owner?)` 兼容旧签名；工厂只释放自己的派生 scope。`state.error/cleanupError` 是原诊断，`displayError/displayCleanupError` 在展示时解析明确标记的自有错误。供应方异常即使等于自有中文也保持原文。`fail(message, source?)` 第一参数及既有调用方兼容，第二参数只传显式标记的自有 Error。

语言变化只更新 Vue 文本与 Leaflet 已有 marker/popup 的文本/ARIA；不会重建地图、图层、请求或定位，不改选择、filter、数据与视口模型。原生 Popup 的 `update()` 只在既有 ResizeObserver 中处理打开弹层的窗口缩放布局。坐标、地图交互和数据校验仍使用原逻辑及 Leaflet 公共 API。

地图包构建将 UI/Pro 全部公开子路径保留为 external，防止将第二套语言内核打入模板包。依赖固定为 Leaflet 1.9.4、@types/leaflet 1.9.21，以及 manifest 指定的正常 UI/Pro peers。第三语言及原生 locale、异步资源就绪与持久化由宿主负责。可复制正常包消费根组件与验证见 `tests/i18n-pro-display/consumer/templates/`。
