# ASAM 地图前端模板

本地示意地图，P30 / V2-048。不是实际商业底图，不表示真实地点、道路或边界。默认离线资源、无账号/Key、无外网请求；安装依赖本身仍需要已有缓存或合法软件源。

三个普通 Vue SFC 同版同契约：MinimalMap 顶栏与右侧点位目录；BrandMap 品牌左栏与地图主区；TechMap 观测台、右侧坐标信息与底部工具。均含完整点线面、点击/键盘选择、筛选、弹层与侧栏、全部定位、拖缩放、主动定位、状态恢复和清理。

```vue
<template>
	<MinimalMap :provider="provider" identity="preview-user" size="default" />
</template>
<script setup lang="ts">
import { MinimalMap, localProvider } from '@asam-ui/maps-template';
const provider = localProvider();
</script>
```

应用入口按顺序引入 element-plus/dist/index.css、element-plus/theme-chalk/dark/css-vars.css、@asam-ui/ui/style.css、@asam-ui/pro/style.css、@asam-ui/maps-template/style.css。examples 是完整包消费入口，三族源码和 API 一起分发，停用开发工具后应用仍是普通 Vue 项目。

依赖版本固定于 package.json；模板是独立 pnpm workspace。内部未公开的 ASAM 版本由已验同版 tar 输入，不假定 npm 公网可安装。验证配方见 tests/v2/maps；先复用固定依赖产物并校验哈希，独立安装，再构建地图包并在第二个 consumer 中正常安装真实 tar、类型检查和生产构建。不使用源码 alias 或借用他人可变 node_modules。公共根配置与官网接入只给主控 proposal，不改其他 owner。

导航：本模板可作为 V2-032 components allowlist 中的普通页面，以其公开 NavigationOptions/load/visible 接口挂载。路由/页签释放由已验 NavigationShell 管理，本模板只释放自己的地图。无需改变 Navigation 协议、添加路由算法或依赖真实 CL。状态：直接消费 @asam-ui/pro 的 AsamPageSkeleton/AsamStatePanel，不复制其动作与状态算法。地图加载/坐标/位置的私有会话属于本模板责任。

复用与差额：原树没有 templates/maps；已验 V2-032 提供页面导航入口、V2-035 提供请求/错误接入依据，现有 display/states 提供可复用状态组件。差额是 Leaflet 公开适配、有限 GeoJSON 校验、地图会话、三族 SFC 与本卡资料。没有新增公共 UI/Pro API，无旧地图 API 删除；新 consumer 从示例接入，无破坏性迁移。已有业务地图要先明确其坐标系和数据/瓦片许可，不能直接替换为本地示意。

设计依据见 DESIGN.md；公开契约见 API.md 和 Types.ts；实际 Agent 修改及还原方法见 AGENT.md；许可见 THIRD_PARTY_NOTICES.md。capability.json 提供050/051可同源引用的最小条目，不另建 MCP、Skill 或文档站。
