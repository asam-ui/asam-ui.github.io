# 地图模板 API · 0.1.0-alpha.1

Vue 3.5.34 / Element Plus 2.14.7 / ASAM UI、Pro 0.1.0-alpha.1 / Leaflet 1.9.4。
公开类型源为 Types.ts；地图执行代码只使用 Leaflet 公开 API。无 CL、后台或 Agent 运行时依赖。

MinimalMap、BrandMap、TechMap 使用相同 props、事件和 expose。三者是可编辑普通 SFC，页面没有额外 slot；特殊布局直接修改 SFC，避免把布局抽象为复杂协议。

| 输入                | 类型 / 默认                          | 行为                                                                                    |
| ------------------- | ------------------------------------ | --------------------------------------------------------------------------------------- |
| provider            | MapProvider / 每实例 localProvider() | 默认仅自制本地 GeoJSON，不请求瓦片、图片、字体或定位                                    |
| identity            | string / 空                          | 变化即废止旧加载、选择、定位与资源，重新加载；传稳定身份标识，不传凭据                  |
| permitted           | boolean / true                       | false 不调用供应方，不保留原地图或数据；UI 权限不代替后端鉴权                           |
| readonly / disabled | boolean / false                      | 禁止地图与点位交互、筛选、定位、缩放；保留示意图展示，变化重新取得会话                  |
| size                | small/default/big/large              | 默认继承 useAsamControlSize 的 group/Form/provider，控件28/32/36/40px；窄屏工具至少32px |
| theme               | light/dark                           | Minimal/Brand 默认 light，Tech 默认 dark；可明确切换，局部 CSS 变量不修改全局主题       |
| location            | LocationPort / browserLocation()     | 每实例固定；替换端口请重挂组件。仅主动按钮触发，坐标只在实例内显示                      |

| 事件 / 公开方法 | 内容               | 契约                                                                                                        |
| --------------- | ------------------ | ----------------------------------------------------------------------------------------------------------- |
| select          | MapFeature 或 null | 地图 marker 与侧栏双向选择；筛选消失/弹层关闭后归 null；只读不选中                                          |
| status          | MapStatus          | idle/loading/ready/empty/error/forbidden/cancelled/disposed；Vue 事件不保证收齐同 tick 的中间状态           |
| location        | LocationStatus     | idle/pending/success/denied/timeout/unavailable/unsupported/cancelled                                       |
| reload()        | Promise<boolean>   | 最新合法数据载入为 true；失败、禁止、过期为 false                                                           |
| focusMap()      | void               | 可交互且挂载完成时将焦点移到地图                                                                            |
| controller      | MapController      | 实例私有，只读 state/features/points/selected；load/select/filter/locate/cancelLocation/fail/cancel/dispose |

controller.load(provider, identity, permitted=true, locked=false) 会立即清除旧数据与选择；cancel 清除资源和数据并进入 cancelled；dispose 幂等，之后 load 返回 false，其他变更无效。state.cleanupError 单独保留宿主 release 失败诊断，工具栏显示提示，不被后继加载覆盖。
filter 按点位 category 精确匹配，线面覆盖保留；未知类别是“无匹配点位”，全空 FeatureCollection 是 empty。
select 仅接收当前可见 Point id，未知值清空；同类别标题可以重复，id 必须唯一。
异常文本以 Vue 插值/textContent 展示。没有把属性、署名、Key 或标题作为 HTML 执行。

MapProvider 必填 id/title/attribution/load，load({signal,identity}) 返回 Promise<MapDataset>。每次会话可提供 release()，失效/取消/卸载时调用一次；宿主负责终止自有请求及 SDK 副作用，不能在忽略 signal 后重新分配无人管理的资源。release 异常显示释放失败诊断，不阻清理。
requiresKey=true 且 clientKey 空时不调用 load。clientKey 仅为允许暴露到浏览器的凭据；没有代理或秘密存储能力。
options 只接受 minZoom/maxZoom/zoomSnap/zoomDelta，crs 固定 EPSG3857；地图动画默认关闭，减少动态时仍可操作。
tiles 为显式宿主注入：HTTPS URL、纯文本 attribution、可选 minZoom/maxZoom/tileSize/zoomOffset；{key} 经 URL 编码，{z}/{x}/{y} 交 Leaflet。宿主确认域名、许可、CSP、费用及公开凭据后才注入。SDK 许可不授予瓦片权利。资源失败清空地图并显示可重试错误。本次在线供应方未测，tiles.invalid 只用于被本地拦截的失败测试。

MapDataset 只支持 FeatureCollection / Feature / Point、LineString、Polygon。Position 精确为 WGS84 [longitude,latitude] 两个有限数，经度±180、纬度±90；不猜测 GCJ02/BD09。Leaflet 内部显示坐标为 [latitude,longitude]，EPSG3857 在极区按 SDK 公开行为截取显示，数据本身不改写；实际本地示例纬度约30°。
LineString 至少2点；Polygon 每环至少4点且首尾一致；最多500 features。整个集合验证并复制后一次提交，无效坐标/重复id/未支持几何不部分显示。

browserLocation 使用 getCurrentPosition（非 watchPosition），8秒超时，不自动请求高精度。浏览器原生一次定位不能强制撤回，取消信号和代数隔离会忽略迟到结果；宿主可注入可中止 LocationPort。取消、身份/权限变化、卸载均清除本实例位置。定位拒绝/超时等不会毁掉原示意图，可重新主动尝试。

键盘：地图方向键/加减键由 Leaflet 执行；marker Enter/Space、侧栏 button 均可选中。详情打开后焦点到关闭按钮，侧栏关闭/popup关闭/Escape均在DOM更新后恢复原有效触发点；同一逻辑点位重绘时解析其替代节点，点位被筛选移除时回退到本实例类别筛选器。替换选择不先抢回旧触发点。实例卸载释放 observer、SDK事件、地图实例及媒体查询监听。

控件尺寸依据ASAM公开asamControlSizeMetrics，按钮横向padding同为14/16/18/20px。32px圆形marker是图形标识，不按控件四档重缩放；760px以下工具按钮设至少32px以保触控，small下拉框仍保持公开28px。初始加载与数据变化的程序化全部取景独立于readonly/disabled，合法远处点位仍可见；禁用的用户拖动、键盘移动、缩放/全部定位按钮不因此恢复。
