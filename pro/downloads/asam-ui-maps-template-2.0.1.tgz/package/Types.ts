import type { AsamControlSize } from '@asam-ui/ui';
import type { MapOptions, TileLayerOptions } from 'leaflet';

/** RFC7946: WGS84 [longitude, latitude], never Leaflet [latitude, longitude]. */
export type Position = readonly [longitude: number, latitude: number];
export type MapGeometry =
	| { type: 'Point'; coordinates: Position }
	| { type: 'LineString'; coordinates: readonly Position[] }
	| { type: 'Polygon'; coordinates: readonly (readonly Position[])[] };
export interface MapFeature {
	type: 'Feature';
	id: string;
	properties: { title: string; category: string; description: string };
	geometry: MapGeometry;
}
export interface MapDataset {
	type: 'FeatureCollection';
	features: readonly MapFeature[];
}
export interface MapTiles {
	url: string;
	/** Plain text. SDK/data licenses are independent. */
	attribution: string;
	options?: Pick<TileLayerOptions, 'minZoom' | 'maxZoom' | 'tileSize' | 'zoomOffset'>;
}
export interface MapProvider {
	id: string;
	title: string;
	attribution: string;
	load: (context: { signal: AbortSignal; identity: string }) => Promise<MapDataset>;
	tiles?: MapTiles;
	/** Only an explicitly public browser credential; never a server secret. */
	clientKey?: string;
	requiresKey?: boolean;
	/** Optional host cleanup; called once for each acquired session, including stale loads. */
	release?: () => void;
	options?: Pick<MapOptions, 'minZoom' | 'maxZoom' | 'zoomSnap' | 'zoomDelta'>;
}
export type MapStatus =
	'idle' | 'loading' | 'ready' | 'empty' | 'error' | 'forbidden' | 'cancelled' | 'disposed';
export type LocationStatus =
	| 'idle'
	| 'pending'
	| 'success'
	| 'denied'
	| 'timeout'
	| 'unavailable'
	| 'unsupported'
	| 'cancelled';
export interface LocationPort {
	locate: (signal: AbortSignal) => Promise<Position>;
}
export interface MapPageProps {
	provider?: MapProvider;
	identity?: string;
	permitted?: boolean;
	readonly?: boolean;
	disabled?: boolean;
	size?: AsamControlSize;
	theme?: 'light' | 'dark';
	location?: LocationPort;
}
export interface MapPageEmits {
	select: [feature: MapFeature | null];
	status: [status: MapStatus];
	location: [status: LocationStatus];
}
export interface MapViewState {
	zoom: number;
	center: Position;
}
export interface MapCanvasExpose {
	fitAll: () => void;
	zoomBy: (delta: number) => void;
	focusMap: () => void;
}
