import { computed, reactive, readonly, shallowRef } from 'vue';
import { extendAsamI18n } from '@asam-ui/ui/i18n';
import type { AsamI18n } from '@asam-ui/ui/i18n';
import { createAsamMessageError, formatFieldError } from '@asam-ui/pro/i18n';
import { mapMessageDefaults } from './I18n.js';
import { copyDataset, validPosition } from './Data.js';
import { browserLocation } from './Provider.js';
import type {
	LocationPort,
	LocationStatus,
	MapDataset,
	MapProvider,
	MapStatus,
	Position
} from './Types.js';

export function createMapController(location: LocationPort = browserLocation(), owner?: AsamI18n) {
	const i18n = owner ? extendAsamI18n(owner, mapMessageDefaults) : undefined;
	const errorSource = shallowRef<Error>();
	const cleanupSource = shallowRef<Error>();
	const state = reactive({
		status: 'idle' as MapStatus,
		data: null as MapDataset | null,
		filter: '',
		selected: null as string | null,
		error: '',
		cleanupError: '',
		locationStatus: 'idle' as LocationStatus,
		position: null as Position | null,
		locked: false
	});
	let generation = 0;
	let locationGeneration = 0;
	let request: AbortController | undefined;
	let locationRequest: AbortController | undefined;
	let release: (() => void) | undefined;
	let disposed = false;
	const features = computed(
		() =>
			state.data?.features.filter(
				(feature) =>
					feature.geometry.type !== 'Point' ||
					!state.filter ||
					feature.properties.category === state.filter
			) ?? []
	);
	const points = computed(() =>
		features.value.filter((feature) => feature.geometry.type === 'Point')
	);
	const selected = computed(
		() => points.value.find((point) => point.id === state.selected) ?? null
	);
	function cancelLocation() {
		locationGeneration++;
		locationRequest?.abort();
		locationRequest = undefined;
		state.position = null;
		if (state.locationStatus === 'pending' || state.locationStatus === 'success')
			state.locationStatus = 'cancelled';
	}
	function clear() {
		generation++;
		request?.abort();
		request = undefined;
		cancelLocation();
		const cleanup = release;
		release = undefined;
		try {
			cleanup?.();
		} catch {
			state.cleanupError = '供应方资源释放失败，请检查宿主 release 回调';
			cleanupSource.value = createAsamMessageError(
				state.cleanupError,
				'app.templates.maps.cleanupError'
			);
		}
		state.data = null;
		state.selected = null;
		state.filter = '';
	}
	async function load(provider: MapProvider, identity: string, permitted = true, locked = false) {
		if (disposed) return false;
		clear();
		state.error = '';
		errorSource.value = undefined;
		state.locked = locked;
		if (!permitted) {
			state.status = 'forbidden';
			return false;
		}
		state.status = 'loading';
		const epoch = generation;
		request = new AbortController();
		release = provider.release;
		try {
			if (!provider.id.trim() || !provider.attribution.trim())
				throw createAsamMessageError(
					'供应方标识及署名不能为空',
					'app.templates.maps.providerInvalid'
				);
			if (provider.requiresKey && !provider.clientKey?.trim())
				throw createAsamMessageError(
					'缺少允许公开的客户端 Key',
					'app.templates.maps.keyMissing'
				);
			const data = copyDataset(await provider.load({ signal: request.signal, identity }));
			if (disposed || epoch !== generation) return false;
			state.data = data;
			state.status = data.features.length ? 'ready' : 'empty';
			return true;
		} catch (error) {
			if (disposed || epoch !== generation) return false;
			clear();
			state.status = 'error';
			state.error = error instanceof Error ? error.message : '地图加载失败';
			errorSource.value =
				error instanceof Error
					? error
					: createAsamMessageError(state.error, 'app.templates.maps.error');
			return false;
		}
	}
	function select(id: string | null) {
		if (disposed || state.locked || state.status !== 'ready') return;
		state.selected = id && points.value.some((point) => point.id === id) ? id : null;
	}
	function filter(category: string) {
		if (disposed || state.locked) return;
		state.filter = category;
		if (!selected.value) state.selected = null;
	}
	async function locate() {
		if (
			disposed ||
			state.locked ||
			state.status !== 'ready' ||
			state.locationStatus === 'pending'
		)
			return;
		cancelLocation();
		const epoch = locationGeneration;
		locationRequest = new AbortController();
		state.locationStatus = 'pending';
		try {
			const position = await location.locate(locationRequest.signal);
			if (disposed || epoch !== locationGeneration) return;
			if (!validPosition(position)) throw { code: 2 };
			state.position = position;
			state.locationStatus = 'success';
		} catch (error) {
			if (disposed || epoch !== locationGeneration) return;
			const code =
				typeof error === 'object' && error !== null && 'code' in error
					? error.code
					: undefined;
			state.locationStatus =
				code === 0
					? 'unsupported'
					: code === 1
						? 'denied'
						: code === 3
							? 'timeout'
							: 'unavailable';
		}
	}
	function fail(message: string, source?: Error) {
		if (disposed) return;
		clear();
		state.error = message;
		errorSource.value = source;
		state.status = 'error';
	}
	function cancel() {
		if (!disposed) {
			clear();
			state.status = 'cancelled';
		}
	}
	function dispose() {
		if (!disposed) {
			clear();
			disposed = true;
			state.status = 'disposed';
			i18n?.dispose();
		}
	}
	return {
		state: readonly(state),
		displayError: computed(() =>
			i18n && errorSource.value ? formatFieldError(errorSource.value, i18n) : state.error
		),
		displayCleanupError: computed(() =>
			i18n && cleanupSource.value
				? formatFieldError(cleanupSource.value, i18n)
				: state.cleanupError
		),
		features,
		points,
		selected,
		load,
		select,
		filter,
		locate,
		cancelLocation,
		fail,
		cancel,
		dispose
	};
}
export type MapController = ReturnType<typeof createMapController>;
