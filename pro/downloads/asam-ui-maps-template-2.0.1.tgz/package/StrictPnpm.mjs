import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
const cli = process.env.npm_execpath;
if (!cli || !fs.existsSync(cli)) throw Error('请从正常 pnpm 命令启动');
// pnpm 11.9.0 exports pnpm_config_verify_deps_before_run=false to lifecycle
// children, overriding even workspace and CLI settings. Restore error for this child.
const env = { ...process.env, pnpm_config_verify_deps_before_run: 'error' };
const config = spawnSync(process.execPath, [cli, 'config', 'get', 'verifyDepsBeforeRun'], {
	env,
	encoding: 'utf8'
});
if (config.status !== 0 || config.stdout.trim() !== 'error')
	throw Error('子 pnpm 依赖检查未实际启用');
console.log(`ASAM child verifyDepsBeforeRun=${config.stdout.trim()}`);
const result = spawnSync(process.execPath, [cli, ...process.argv.slice(2)], {
	env,
	stdio: 'inherit'
});
process.exitCode = result.status ?? 1;
