/** 基于固定 @vant/use 1.6.0 公共契约；不复制上游实现。 */
export { onMountedOrActivated } from '@vant/use';
