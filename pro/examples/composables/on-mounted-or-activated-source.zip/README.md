# 挂载或重新激活

首次挂载执行一次，KeepAlive重新激活时再次执行。

## 导入

```ts
import { onMountedOrActivated } from '@asam-ui/pro/application/composables/on-mounted-or-activated';
// 同时支持 Application.composables 分类访问。
```

## 最小与完整示例

[最小用法](./examples/MinimalExample.vue)；[完整示例](./examples/App.vue)及[启动入口](./examples/main.ts)。关联和自定义字段示例需同时保留同目录子组件与key文件。能力本体只引用公开入口；卸载/重挂外壳、UI样式和按钮属于演示依赖，不作为纯Hook必要运行时。完整工程由官网同源下载生成器补齐Vite、TypeScript和正常依赖锁定配置。

## 参数与返回值

以下为固定依赖@vant/use1.6.0的相关公开声明；可解析的完整类型随正常包DTS分发。ASAM适配以本目录index.ts和Types.ts为准。

```ts
export declare function onMountedOrActivated(hook: () => any): void;
```

## 环境与生命周期

在setup调用，首次激活不重复执行。非KeepAlive组件只会首次挂载执行；卸载后新实例重新计数。

可视示例使用@asam-ui/ui和Element Plus的公开样式，业务接口由宿主提供。来源与许可证见Pro包THIRD_PARTY_NOTICES.md。
