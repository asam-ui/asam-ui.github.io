import { createApp } from 'vue';
import 'element-plus/dist/index.css';
import '@asam-ui/ui/style.css';
import App from './App.vue';
createApp(App).mount('#app');
