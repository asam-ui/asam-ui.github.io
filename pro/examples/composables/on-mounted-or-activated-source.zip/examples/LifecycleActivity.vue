<template>
	<p>缓存中的内容</p>
</template>
<script setup lang="ts">
import { onMountedOrActivated } from '../index.js';
const emit = defineEmits<{ active: [] }>();
onMountedOrActivated(() => emit('active'));
</script>
