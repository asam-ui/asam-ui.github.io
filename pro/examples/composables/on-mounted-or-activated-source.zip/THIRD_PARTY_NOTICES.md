# 第三方能力来源

Pro 应用组合式能力通过正式依赖 `@vant/use@1.6.0` 的公开入口复用实现，不依赖 Vant UI 或其样式。

上游：[Vant Use](https://github.com/youzan/vant/tree/main/packages/vant-use)。许可证：MIT。版权：Youzan、Chen Jiahan and other contributors。上游包自身包含其发布声明；安装后的第三方代码仍受其许可证约束。

ASAM 增量为分类/能力出口、自动导入映射、示例及 `AsamCustomField` 表单桥接。`flattenVNodes`、`sortChildren`、`supportsPassive` 不属于 Pro 公开 API，不提供自动导入。上游内部使用自己的辅助函数不构成 ASAM 新增出口。

`useEventListener` 在非浏览器时补齐可调用的停止函数；`useChildren` 在父组件更新时调用上游现有排序函数，同步已关联实例的索引。这两处是薄适配，不复制或改写上游监听/排序算法。父子关联使用上游同样的 Vue 实例协议，按项目锁定的 Vue 版本验证。
