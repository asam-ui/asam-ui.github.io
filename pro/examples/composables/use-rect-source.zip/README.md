# 元素矩形

读取元素或元素ref当前的DOM矩形。

## 导入

```ts
import { useRect } from '@asam-ui/pro/application/composables/use-rect';
// 同时支持 Application.composables 分类访问。
```

## 最小与完整示例

[最小用法](./examples/MinimalExample.vue)；[完整示例](./examples/App.vue)及[启动入口](./examples/main.ts)。关联和自定义字段示例需同时保留同目录子组件与key文件。能力本体只引用公开入口；卸载/重挂外壳、UI样式和按钮属于演示依赖，不作为纯Hook必要运行时。完整工程由官网同源下载生成器补齐Vite、TypeScript和正常依赖锁定配置。

## 参数与返回值

以下为固定依赖@vant/use1.6.0的相关公开声明；可解析的完整类型随正常包DTS分发。ASAM适配以本目录index.ts和Types.ts为准。

```ts
import { Ref } from 'vue';

export declare const useRect: (
	elementOrRef: Element | Window | Ref<Element | Window | undefined>
) => DOMRect;
```

## 环境与生命周期

同步快照；挂载后测量，尺寸变化后按需再次调用。空目标返回上游零矩形，不代表真实尺寸。

可视示例使用@asam-ui/ui和Element Plus的公开样式，业务接口由宿主提供。来源与许可证见Pro包THIRD_PARTY_NOTICES.md。
