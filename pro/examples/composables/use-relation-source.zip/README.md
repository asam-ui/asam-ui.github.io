# 父子组件关联

使用同一InjectionKey建立复合组件的父子关系并读取顺序索引。

## 导入

```ts
import { useParent, useChildren } from '@asam-ui/pro/application/composables/use-relation';
// 同时支持 Application.composables 分类访问。
```

## 最小与完整示例

[最小用法](./examples/MinimalExample.vue)；[完整示例](./examples/App.vue)及[启动入口](./examples/main.ts)。关联和自定义字段示例需同时保留同目录子组件与key文件。能力本体只引用公开入口；卸载/重挂外壳、UI样式和按钮属于演示依赖，不作为纯Hook必要运行时。完整工程由官网同源下载生成器补齐Vite、TypeScript和正常依赖锁定配置。

## 参数与返回值

以下为固定依赖@vant/use1.6.0的相关公开声明；可解析的完整类型随正常包DTS分发。ASAM适配以本目录index.ts和Types.ts为准。

```ts
import {
	VNode,
	InjectionKey,
	VNodeNormalizedChildren,
	ComponentPublicInstance,
	ComponentInternalInstance
} from 'vue';

export declare function useChildren<
	Child extends ComponentPublicInstance = ComponentPublicInstance<{}, any>,
	ProvideValue = never
>(
	key: InjectionKey<ProvideValue>
): {
	children: Child[];
	linkChildren: (value?: ProvideValue) => void;
};

import { InjectionKey, ComponentPublicInstance, ComponentInternalInstance } from 'vue';

type ParentProvide<T> = T & {
	link(child: ComponentInternalInstance): void;
	unlink(child: ComponentInternalInstance): void;
	children: ComponentPublicInstance[];
	internalChildren: ComponentInternalInstance[];
};

export declare function useParent<T>(key: InjectionKey<ParentProvide<T>>):
	| {
			parent: ParentProvide<T>;
			index: import('vue').ComputedRef<number>;
	  }
	| {
			parent: null;
			index: import('vue').Ref<number>;
	  };

export {};
```

## 环境与生命周期

高级组件作者能力，使用Vue实例关系，固定Vue3.5.34兼容基线。不能将该能力当普通业务页面依赖；不公开两个上游实例树辅助函数。

可视示例使用@asam-ui/ui和Element Plus的公开样式，业务接口由宿主提供。来源与许可证见Pro包THIRD_PARTY_NOTICES.md。
