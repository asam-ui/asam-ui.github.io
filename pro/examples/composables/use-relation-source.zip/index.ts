/** 基于固定 @vant/use 1.6.0 公共契约；不复制上游实现。 */
import { getCurrentInstance, onUpdated } from 'vue';
import type { ComponentInternalInstance, ComponentPublicInstance, InjectionKey } from 'vue';
import {
	useChildren as useUpstreamChildren,
	sortChildren as sortUpstreamChildren
} from '@vant/use';

export { useParent } from '@vant/use';

/**
 * 上游只在子项首次关联时排序。复用其公开排序实现，在父组件更新后同步既有实例的索引。
 * 这是 Vue 实例关联能力的版本适配，不对外导出 sortChildren/flattenVNodes。
 */
export function useChildren<
	Child extends ComponentPublicInstance = ComponentPublicInstance,
	ProvideValue = never
>(key: InjectionKey<ProvideValue>) {
	const owner = getCurrentInstance();
	const result = useUpstreamChildren<Child, ProvideValue>(key);
	onUpdated(() => {
		if (!owner) return;
		// Vue 类型不公开 provides；只接受同一上游 key、同一 children 身份的实际绑定。
		const bindings: unknown = Reflect.get(owner, 'provides');
		if (!bindings || typeof bindings !== 'object') return;
		const binding: unknown = Reflect.get(bindings, key as symbol);
		if (!binding || typeof binding !== 'object') return;
		const internals: unknown = Reflect.get(binding, 'internalChildren');
		if (Reflect.get(binding, 'children') === result.children && Array.isArray(internals))
			sortUpstreamChildren(owner, result.children, internals as ComponentInternalInstance[]);
	});
	return result;
}
