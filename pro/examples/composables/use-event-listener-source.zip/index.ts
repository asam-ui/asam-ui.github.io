/** 基于固定 @vant/use 1.6.0 公共契约；不复制上游实现。 */
import { useEventListener as useUpstreamEventListener } from '@vant/use';
import type { UseEventListenerOptions } from '@vant/use';

/** 非浏览器环境补齐已声明的停止函数，不改变上游事件监听算法。 */
export function useEventListener<K extends keyof DocumentEventMap>(
	type: K,
	listener: (event: DocumentEventMap[K]) => void,
	options?: UseEventListenerOptions
): () => void;
export function useEventListener(
	type: string,
	listener: EventListener,
	options?: UseEventListenerOptions
): () => void;
export function useEventListener(
	type: string,
	listener: EventListener,
	options?: UseEventListenerOptions
): () => void {
	return useUpstreamEventListener(type, listener, options) ?? (() => undefined);
}
export type { UseEventListenerOptions } from '@vant/use';
