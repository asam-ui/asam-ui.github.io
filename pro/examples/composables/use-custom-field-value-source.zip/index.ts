/** 基于固定 @vant/use 1.6.0 公共契约；不复制上游实现。 */
import { getCurrentScope, inject, onScopeDispose } from 'vue';
import {
	CUSTOM_FIELD_INJECTION_KEY,
	useCustomFieldValue as useVantCustomFieldValue
} from '@vant/use';
export { CUSTOM_FIELD_INJECTION_KEY } from '@vant/use';

/** 复用上游登记与观察，只补充登记者作用域结束时的所有权释放。 */
export function useCustomFieldValue(customValue: () => unknown): void {
	const field = inject(CUSTOM_FIELD_INJECTION_KEY, null);
	const previous = field?.customValue.value;
	useVantCustomFieldValue(customValue);
	if (field && !previous && field.customValue.value === customValue && getCurrentScope()) {
		onScopeDispose(() => {
			if (field.customValue.value === customValue) field.customValue.value = undefined;
		});
	}
}
export type { CustomFieldInjectionValue } from '@vant/use';
export { default as AsamCustomField } from './AsamCustomField.vue';
export type * from './Types.js';
