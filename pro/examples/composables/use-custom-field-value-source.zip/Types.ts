import type { VNode } from 'vue';
import type { AsamFormItemExpose, AsamFormItemProps } from '@asam-ui/ui';

/** prop、rules、label 等 FormItem 参数透传给 ASAM 公开组件。 */
export interface AsamCustomFieldProps extends AsamFormItemProps {
	modelValue: unknown;
}
export interface AsamCustomFieldSlots {
	/** 内部 ASAM/EP 控件应设 validate-event=false，由本桥接统一触发校验。 */
	default?: (scope: {
		value: unknown;
		update: (value: unknown) => void;
		blur: () => void;
	}) => VNode[];
	label?: (scope: { label: string }) => VNode[];
	error?: (scope: { error: string }) => VNode[];
	help?: () => VNode[];
}
export interface AsamCustomFieldExpose {
	getValue(): unknown;
	validate(trigger?: string): ReturnType<AsamFormItemExpose['validate']>;
	clearValidate(): void;
	resetField(): void;
}
