<template>
	<AsamFormItem ref="item" v-bind="{ ...$attrs, ...itemProps }">
		<template v-if="$slots.label" #label="scope"><slot name="label" v-bind="scope" /></template>
		<slot :value="modelValue" :update="update" :blur="blur" />
		<template v-if="$slots.error" #error="scope"><slot name="error" v-bind="scope" /></template>
		<template v-if="$slots.help" #help><slot name="help" /></template>
	</AsamFormItem>
</template>

<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, provide, ref, shallowRef } from 'vue';
import type { PropType } from 'vue';
import { CUSTOM_FIELD_INJECTION_KEY } from '@vant/use';
import { formItemProps } from 'element-plus';
import { AsamFormItem } from '@asam-ui/ui';
import type { AsamControlSize, AsamFormItemExpose } from '@asam-ui/ui';
import type { AsamCustomFieldExpose, AsamCustomFieldSlots } from './Types.js';

defineOptions({ name: 'AsamCustomField', inheritAttrs: false });
const props = defineProps({
	...formItemProps,
	modelValue: { type: null as unknown as PropType<unknown>, required: true },
	help: { type: String, default: undefined },
	size: { type: String as PropType<AsamControlSize>, default: undefined }
});
const emit = defineEmits<{ 'update:modelValue': [value: unknown] }>();
defineSlots<AsamCustomFieldSlots>();
const item = ref<AsamFormItemExpose>();
const customValue = shallowRef<() => unknown>();
const itemProps = computed(() => {
	const { modelValue, ...forwarded } = props;
	void modelValue;
	return forwarded;
});
let disposed = false;
let validation = 0;
let pendingInput: { value: unknown } | undefined;

/** 等宿主模型完成更新后，才通过 FormItem 公开接口触发校验。 */
function validateWithTrigger(trigger: 'onBlur' | 'onChange' | 'onSubmit') {
	// 上游也会观察外部模型重置。只有 slot.update 发起的用户变更触发 change 校验，
	// 避免父表单 resetFields 刚清空校验后又因回显初始值重新报错。
	if (
		trigger === 'onChange' &&
		(!pendingInput || !Object.is(pendingInput.value, props.modelValue))
	)
		return;
	const revision = ++validation;
	void nextTick(() => {
		if (disposed || revision !== validation) return;
		const publicTrigger =
			trigger === 'onSubmit' ? '' : trigger === 'onBlur' ? 'blur' : 'change';
		void item.value?.validate(publicTrigger).catch(() => undefined);
	});
}
function clearValidate() {
	validation++;
	item.value?.clearValidate();
}
function update(value: unknown) {
	if (disposed) return;
	const input = { value };
	pendingInput = input;
	emit('update:modelValue', value);
	void nextTick(() => {
		if (pendingInput === input) pendingInput = undefined;
	});
}
function blur() {
	validateWithTrigger('onBlur');
}
provide(CUSTOM_FIELD_INJECTION_KEY, {
	customValue,
	resetValidation: clearValidate,
	validateWithTrigger
});
onBeforeUnmount(() => {
	disposed = true;
	validation++;
	pendingInput = undefined;
	customValue.value = undefined;
});
defineExpose({
	getValue: () => (customValue.value ? customValue.value() : props.modelValue),
	validate: (trigger = '') => item.value?.validate(trigger) ?? Promise.resolve(true),
	clearValidate,
	resetField: () => {
		validation++;
		item.value?.resetField();
	}
} satisfies AsamCustomFieldExpose);
</script>
