# 自定义字段桥接

把自定义值读取和交互校验接入真实ASAM表单；注入key仅作高级兼容接口。

## 导入

```ts
import {
	useCustomFieldValue,
	AsamCustomField
} from '@asam-ui/pro/application/composables/use-custom-field-value';
// 同时支持 Application.composables 分类访问。
```

## 最小与完整示例

[最小用法](./examples/MinimalExample.vue)；[完整示例](./examples/App.vue)及[启动入口](./examples/main.ts)。关联和自定义字段示例需同时保留同目录子组件与key文件。能力本体只引用公开入口；卸载/重挂外壳、UI样式和按钮属于演示依赖，不作为纯Hook必要运行时。完整工程由官网同源下载生成器补齐Vite、TypeScript和正常依赖锁定配置。

## 参数与返回值

以下为固定依赖@vant/use1.6.0的相关公开声明；可解析的完整类型随正常包DTS分发。ASAM适配以本目录index.ts和Types.ts为准。

```ts
import { InjectionKey, Ref } from 'vue';

export type CustomFieldInjectionValue = {
	customValue: Ref<(() => unknown) | undefined>;
	resetValidation: () => void;
	validateWithTrigger: (trigger: 'onBlur' | 'onChange' | 'onSubmit') => void;
};

export declare const CUSTOM_FIELD_INJECTION_KEY: InjectionKey<CustomFieldInjectionValue>;

export declare function useCustomFieldValue(customValue: () => unknown): void;
```

## 环境与生命周期

子组件中调用Hook，父桥接透传FormItem公开属性。内层ASAM/EP控件关闭validate-event以避免重复校验；slot.update表示用户变更，程序化模型更改需按需显式validate。无provider时不会自动接入普通表单。

在setup或活动effect scope中登记。编辑器的作用域结束时只释放本次拥有的getter；字段容器保持挂载、编辑器通过v-if重建后会重新登记，取值和change校验使用新实例。

可视示例使用@asam-ui/ui和Element Plus的公开样式，业务接口由宿主提供。来源与许可证见Pro包THIRD_PARTY_NOTICES.md。
