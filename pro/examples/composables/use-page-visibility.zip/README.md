# 页面可见性完整示例

使用Node22.19+的22.x及pnpm11.9.0。解压后在本目录运行：

```sh
pnpm install --frozen-lockfile
pnpm run typecheck
pnpm run dev
pnpm run build
```

vendor内是配套正常UI/Pro包，安装通过公开exports解析，不使用源码alias或借用网站node_modules。保留vendor目录与锁文件；不要只复制App.vue。src/MinimalExample.vue是核心用法，App.vue的卸载/重挂按钮与UI样式为演示宿主。纯Hook本身无需Router或Vant UI。

共享页面级状态与监听；浏览器切页或最小化可触发变化。服务端不提供真实页面可见性，也不是组件v-if状态。

根分类访问与叶子静态导入均受支持；本示例优先叶子入口。自动导入可在现有Vite配置中合并AsamProResolver与asamProAutoImports，需要时单独安装相应可选插件，参见Pro包README。更换vendor包后应重新固定正常锁文件，不能沿用旧包完整性。

既有编辑器传递依赖可能报告Tiptap peer版本告警，见包兼容说明；本示例不通过改写上游或升级依赖隐藏该告警。

本工程默认运行与文档页内相同的最小示例，入口见src/inline-entry.ts。完整App及作者宿主仍保留在src目录中，可按其依赖单独接入。场景源码ZIP保留同名相对路径，正常包仅位于完整工程vendor目录。
