<template>
	<output aria-live="polite">{{ width }} × {{ height }}</output>
</template>
<script setup lang="ts">
import { useWindowSize } from '../index.js';
const { width, height } = useWindowSize();
</script>
