<template>
	<output aria-live="polite">页面状态：{{ visibility }}</output>
</template>
<script setup lang="ts">
import { usePageVisibility } from '../index.js';
const visibility = usePageVisibility();
</script>
