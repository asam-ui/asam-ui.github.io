/** 基于固定 @vant/use 1.6.0 公共契约；不复制上游实现。 */
export { useCountDown } from '@vant/use';
export type { CurrentTime, UseCountDownOptions } from '@vant/use';
