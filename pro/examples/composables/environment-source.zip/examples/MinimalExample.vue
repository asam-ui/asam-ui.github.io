<template>
	<output>{{ inBrowser ? '浏览器环境' : '非浏览器环境' }}</output>
</template>
<script setup lang="ts">
import { inBrowser } from '../index.js';
</script>
