# Third-party notices

`@asam-ui/ui` uses the following direct runtime dependencies for AsamEditor. The
library build is configured to treat them as external dependencies installed by
the consumer's package manager. Package metadata and license files were checked
on 2026-09-25.

| Package                         | Version  | License | License source                                                                        |
| ------------------------------- | -------- | ------- | ------------------------------------------------------------------------------------- |
| `@tiptap/core`                  | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@tiptap/pm`                    | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@tiptap/vue-3`                 | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@tiptap/starter-kit`           | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@tiptap/extensions`            | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@tiptap/extension-image`       | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@tiptap/extension-placeholder` | `3.31.3` | MIT     | [Tiptap LICENSE](https://github.com/ueberdosis/tiptap/blob/main/LICENSE.md)           |
| `@floating-ui/dom`              | `1.8.0`  | MIT     | [Floating UI LICENSE](https://github.com/floating-ui/floating-ui/blob/master/LICENSE) |

This table summarizes direct dependencies only; it is not an exhaustive list of
transitive packages. At that check, the lockfile resolved 50 direct and transitive
runtime packages, all with MIT license files in the checked local installation.
The installed distributions carry their respective license texts. Applications
that bundle or redistribute these dependencies must preserve their applicable
copyright and license notices. Check the actual resolved dependencies and build
output before distribution. No Tiptap Pro package, UI component, template, or
sample asset is part of this package.

## Component compatibility sources and build helpers

Cascader, Image, ImageViewer and Anchor delegate their basic public behavior to
the installed Element Plus 2.14.7 components. ASAM supplies its styles and
documented advanced value adapters; it does not carry derived setup/render
implementations, bounded zoom, keyboard focus patches or Anchor scroll handling.

The former compatibility implementations used Element Plus gitHead
`77d5c32c4ebcfffde67e51f6325c6d350ca668a0`. Their original source identities
are retained here for historical provenance: the Cascader distribution module
SHA256 was `bac94ed4602841106d134f39056fdaca0d7fbb711fc8ff4339b7fac65391ea82`;
Anchor source `packages/components/anchor/src/anchor.vue` SHA256 was
`3a60f68d455f3e582ecffd4639c78ee24fcbf0a2bcfe0ce0cddf03583d78af2f`.
These historical identities do not imply that the derived runtime remains in
this native-delegation candidate. The original Element Plus license follows.

Build helper inputs are pinned to VueUse core 15.0.0, Element Plus Icons Vue
2.3.2 and Lodash ES 4.18.1. Other components may still use these helpers;
removing the four derived implementations does not remove their notices.
VueUse shared and metadata 15.0.0 carry the same license text as core. The
following original notices remain applicable to retained source and helper
inputs; the installed Element Plus components and Vue remain peer dependencies.

### Element Plus 2.14.7 Cascader, Image, ImageViewer and Anchor source

```text
MIT License

Copyright (c) 2020-PRESENT Element Plus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### VueUse core, shared and metadata 15.0.0

```text
MIT License

Copyright (c) 2019-PRESENT Anthony Fu<https://github.com/antfu>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Element Plus Icons Vue 2.3.2

```text
The MIT License (MIT)

Copyright (c) 2020-PRESENT Element Plus (https://github.com/element-plus)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Lodash ES 4.18.1

```text
Copyright OpenJS Foundation and other contributors <https://openjsf.org/>

Based on Underscore.js, copyright Jeremy Ashkenas,
DocumentCloud and Investigative Reporters & Editors <http://underscorejs.org/>

This software consists of voluntary contributions made by many
individuals. For exact contribution history, see the revision history
available at https://github.com/lodash/lodash

The following license applies to all parts of this software except as
documented below:

====

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

====

Copyright and related rights for sample code are waived via CC0. Sample
code is defined as all source code displayed within the prose of the
documentation.

CC0: http://creativecommons.org/publicdomain/zero/1.0/

====

Files located in the node_modules and vendor directories are externally
maintained libraries used by this software which have their own
licenses; we recommend you read them, as their terms may differ from the
terms above.
```

## Vue SFC export helper

The component build emits the Vue SFC export helper from `@vitejs/plugin-vue`
6.0.9. The following original notice applies to that emitted helper code.

```text
MIT License

Copyright (c) 2019-present, Yuxi (Evan) You and Vite contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

```

## Private declaration snapshots

The normal declaration build redistributes 590 Element Plus 2.14.7 ES declarations
and 295 Element Plus Icons Vue 2.3.2 declarations under `dist/_upstream`.
The original declaration and producer-patch hashes, module-path adaptations and
output hashes are recorded in `dist/_upstream/provenance.json` and the build input
`tools/eng-006/upstream-declarations.lock.json`. The fixed Element Plus source
identity is `77d5c32c4ebcfffde67e51f6325c6d350ca668a0`.

Eight Element Plus declarations receive the recorded strong-type corrections.
Relative declaration references use explicit NodeNext extensions. The Color
class, installation key, table placeholder key and loading directive declaration
are exact re-exports of the original peer declaration leaves, preserving private
member and unique-symbol identity. These snapshots have no runtime entry point.

The complete original MIT licenses are redistributed with each declaration
snapshot at `dist/_upstream/element-plus/LICENSE` and
`dist/_upstream/icons-vue/LICENSE`. The Element Plus and Icons Vue copyright and
license texts above also apply to these declaration derivatives. External type
providers remain normal installed dependencies; their declarations are not
copied into these snapshots.
