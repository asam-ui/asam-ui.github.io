# 1.0 基础中英切换

独立的 UI 1.0.0 正常包工程；不与 2.0 Pro 包混用。

Node22.19+的22.x、pnpm11.9.0。保留vendor、锁文件、pnpm-workspace.yaml和patches，运行：

pnpm install --frozen-lockfile
pnpm run typecheck
pnpm run dev
pnpm run build

本工程使用配套正常包的公开入口；不引用网站源码或借用网站node_modules。本例是UI 1.0.0，不含2.0 Pro。 同版本号的历史归档不自动等同于vendor内这份包，请保留完整性锁定。

示例按钮、标题、业务字典和用户输入属于演示宿主；库自有默认由公开scope解析。切换语言不应重建模型或再次请求。法语只演示显式注册的片段与原生locale，未宣称完整ASAM法语、RTL、所有地区格式或hydration。
