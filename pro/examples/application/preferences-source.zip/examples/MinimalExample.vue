<template>
	<p role="status">{{ preferences.locale.value }}：{{ preferences.t('hello') }}</p>
	<AsamButton @click="preferences.choose({ locale: 'zh-CN' })">中文</AsamButton>
	<AsamButton @click="preferences.choose({ locale: 'en' })">English</AsamButton>
	<AsamButton @click="preferences.reset()">恢复默认偏好</AsamButton>
</template>
<script setup lang="ts">
import { onBeforeUnmount } from 'vue';
import { AsamButton } from '@asam-ui/ui';
import { createPreferences, memoryStorage } from '../index.js';
const preferences = createPreferences({
	app: 'preferences-minimal',
	owner: ['local-demo'],
	storage: memoryStorage(),
	dictionaries: { 'zh-CN': { hello: '你好' }, en: { hello: 'Hello' } },
	fallbackLocale: 'zh-CN'
});
onBeforeUnmount(() => preferences.dispose());
</script>
