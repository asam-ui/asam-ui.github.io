import { toValue } from 'vue';
import type { MaybeRefOrGetter } from 'vue';
import type { AsamI18nOptions } from '@asam-ui/ui/i18n';
import { createAsamProI18n } from '../../i18n/index.js';
import { createPreferences } from './Preferences.js';
import type { PreferenceController } from './Preferences.js';
import type { PreferenceOptions } from './Types.js';

/** Bind component messages to the existing preference owner; never write its locale back. */
export function bindPreferencesI18n(
	preferences: Pick<PreferenceController, 'locale'>,
	options?: MaybeRefOrGetter<Omit<AsamI18nOptions, 'locale'> | undefined>
) {
	return createAsamProI18n(() => ({ ...toValue(options), locale: preferences.locale.value }));
}

/** One owner for stored preferences and component scope; business dictionaries remain separate. */
export function createPreferencesI18n(
	options: PreferenceOptions,
	i18nOptions?: MaybeRefOrGetter<Omit<AsamI18nOptions, 'locale'> | undefined>
) {
	const preferences = createPreferences(options);
	const i18n = bindPreferencesI18n(preferences, () => ({
		fallbackLocale: options.fallbackLocale,
		...toValue(i18nOptions)
	}));
	return {
		preferences,
		i18n,
		dispose() {
			i18n.dispose();
			preferences.dispose();
		}
	};
}
