import { readonly, shallowRef } from 'vue';

export type LocaleLoadStatus =
	'idle' | 'loading' | 'ready' | 'failed' | 'unsupported' | 'stale' | 'disposed';
export interface LocaleLoadResult {
	readonly status: Exclude<LocaleLoadStatus, 'idle' | 'loading'>;
	readonly locale: string;
}
export interface LocaleLoaderOptions<Resource> {
	/** Host allowlist; preferences dictionaries must contain each selectable language. */
	readonly locales: readonly string[];
	readonly load: (locale: string, context: { readonly signal: AbortSignal }) => Promise<Resource>;
	/** Synchronous host registration; no preference write occurs until registration succeeds. */
	readonly register: (locale: string, resource: Resource) => void;
	readonly choose: (locale: string) => boolean;
}

/** Latest selection wins; the host supplies loading and registration, with no built-in network. */
export function createLocaleLoader<Resource>(options: LocaleLoaderOptions<Resource>) {
	const status = shallowRef<LocaleLoadStatus>('idle');
	const requestedLocale = shallowRef<string>();
	let generation = 0;
	let disposed = false;
	let controller: AbortController | undefined;
	async function choose(locale: string): Promise<LocaleLoadResult> {
		if (disposed) return { status: 'disposed', locale };
		const token = ++generation;
		controller?.abort();
		controller = new AbortController();
		requestedLocale.value = locale;
		if (!options.locales.includes(locale)) {
			status.value = 'unsupported';
			return { status: 'unsupported', locale };
		}
		status.value = 'loading';
		const current = () => !disposed && token === generation;
		try {
			const resource = await options.load(locale, { signal: controller.signal });
			if (!current()) return { status: disposed ? 'disposed' : 'stale', locale };
			const registered: unknown = options.register(locale, resource);
			if (
				registered !== null &&
				(typeof registered === 'object' || typeof registered === 'function') &&
				'then' in registered
			) {
				void Promise.resolve(registered).catch(() => undefined);
				throw new TypeError('Locale registration must be synchronous');
			}
			if (!current()) return { status: disposed ? 'disposed' : 'stale', locale };
			const accepted = options.choose(locale);
			if (!current()) return { status: disposed ? 'disposed' : 'stale', locale };
			status.value = accepted ? 'ready' : 'failed';
			return { status: accepted ? 'ready' : 'failed', locale };
		} catch {
			if (!current()) return { status: disposed ? 'disposed' : 'stale', locale };
			status.value = 'failed';
			return { status: 'failed', locale };
		}
	}
	return {
		status: readonly(status),
		requestedLocale: readonly(requestedLocale),
		choose,
		dispose() {
			if (disposed) return;
			disposed = true;
			generation++;
			controller?.abort();
			controller = undefined;
			status.value = 'disposed';
		}
	};
}
