# 应用导航

Vue Router、菜单、页签与缓存由独立控制器连接。宿主提供router、components资源白名单、load与fallback，卸载时dispose；真实会话与服务端授权由应用负责。

## 导入

同一个Pro包同时支持分类访问与精确叶子导入，无需复制实现目录：

```ts
import { createNavigation, NavigationShell } from '@asam-ui/pro/application/navigation';
import { Application } from '@asam-ui/pro';
// Application.navigation与叶子入口共享同一实现。
```

类型从同一叶子路径使用import type；分类类型从@asam-ui/pro/types访问。自动导入使用@asam-ui/pro/resolver的asamProAutoImports({ abilities: ['navigation'] })，或按名称白名单启用。能力公开组件使用AsamProResolver；不默认全量注入全局。

## 最小与完整示例

examples/MinimalExample.vue展示本能力的核心配置和释放；examples/内完整场景保留路由、provider及本地fixture。官网提供逐文件复制/下载、能力源码与完整可运行ZIP。ZIP已包含main.ts、Vite配置、配套正常UI/Pro包及可移植pnpm锁文件；解压后运行pnpm install --frozen-lockfile、pnpm run dev、pnpm run typecheck、pnpm run build，无需手写网站宿主。

当前配套Vue3.5.34、EP2.14.7、UI/Pro0.1.0-alpha.1；导航与完整路由示例使用Vue Router4.6.3。展示组件需按element-plus/dist/index.css、@asam-ui/ui/style.css、@asam-ui/pro/style.css顺序引入样式。应用拥有router、provider、会话、业务接口与资源，能力不得反向依赖examples或网站。

## 控制器

`createNavigation(options)` 返回独立控制器。完整类型见 Types.ts。必需 router、components、load、fallback；components 只接受本地显式映射，不执行远端字符串。load 收到 signal/scope；reload(scope?) 取消旧代，忽略 signal 的旧请求同样不能覆盖新版本或在卸载后报错。加载、校验和注册失败保留上一版本并可 reload 重试。所有候选记录在离开确认或 fallback 跳转前，先用同版 Vue Router 公开 createRouterMatcher 和宿主 parser options 完成注册语法预检；临时 matcher 随即丢弃，不持有 history、不注册到宿主，也不参与实际导航。非法参数正则等解析失败时，当前路由、页签与缓存实例保持不变。空数组是合法版本，关闭模块动态页。id/路径重复、宿主路径冲突、父级缺失、父子循环和未知资源均拒绝整批。父子结构用于菜单组织元数据，页面路由采用明确绝对路径，不创建第二套路由匹配引擎。

`navigate(location, replace=false)` 使用真实 router，支持路径/名称/params/query 与上游重定向；未匹配、确认取消/异常、导航失败返回 false。重复当前导航是成功的无操作。快速连续确认只允许最新一次生效。确认在路由切换前执行；close/refresh/update 另有操作确认，若随后发生真实跳转还会经过 navigate 确认。宿主确认应无副作用且允许重复询问。取消保留当前内容和页签。

`menu/visibleMenu/tabs/pages/active/error/loading/revision` 是只读状态。error 不暴露后端异常正文。`close(ids)`、`closeOthers()`、`closeAll()` 保护固定页，关闭当前先导航到第一个剩余页或 fallback，再删除页签。`refresh(id=active)` 只改变目标缓存身份对应 epoch，立即销毁并重建该实例。`move(id,targetId)` 只重排非固定页，不改变路由和缓存身份。`dispose()` 幂等，取消请求、移除自身 guards/afterEach/动态注册并释放页面状态，不销毁宿主 router。

## 实际缓存与交互

页签 id 默认是 router 解析后的 fullPath；缓存身份是 route id 加 cacheKey(route,item)，默认 fullPath。可设置 `cacheKey: route => String(route.name)` 将同名路由不同参数共享实例，或 `route => route.path` 忽略 query。同一身份的多个页签共享页面状态与刷新生命周期，最后一个关联页签关闭后销毁。组件显示名、数组下标与随机数不参与缓存身份。

NavigationPage 使用真实 RouterView + KeepAlive，每个身份一个容器，停用时组件从 KeepAlive 活动树移出。关闭、刷新和 LRU 淘汰均卸载目标容器；其他容器不换 key。默认最多保留10个页面身份（maxCache 正整数可配置），超预算淘汰最久未激活实例，页签仍可重开并重新挂载。cache=false 的页面只保留当前活动期间。include/exclude 按显式 item.cache 决策，不依赖组件名。跨 id 或不同控制器从不共享缓存。示例输入与滚动位置可检查；测量预算是本能力10个本地轻页面，不声称全库性能。

页签支持浏览器原生拖放、Alt+左右箭头移动、Enter/Space 激活及独立关闭按钮。所有按钮可 Tab 到达；tablist/aria-selected/status 提供选择和变更信息。固定页不可拖移；过期拖动的 id 已被关闭或菜单移除时 move 无操作。窄屏页签横向滚动、动作换行。布局继承已验 AsamAdminLayout 四尺寸 small/default/big/large 与主题，不替换业务子树。

## 嵌入与全屏

EmbedPage props：src、policy、title?；status 事件反馈；公开 open(input)、toggleFullscreen()。policy 必需 resolve/allow；只接受绝对 HTTP(S) URL，拒绝凭据 URL、脚本协议、非法地址和策略拒绝。sandbox 默认空（最严格），permissions 默认空，referrerPolicy 默认 no-referrer。宿主按来源最小授予权限；同时授予同源与脚本需宿主自行评估可信内容。

更换地址销毁旧 iframe，旧代 load/error 回调不能更新新实例。load 只说明文档事件，不能证明远端应用成功。跨源 DOM、远端认证、拒绝嵌入站点能力不由模板绕过；浏览器可能不提供可信 error，状态明确保留未知。模板不提供 postMessage 总线、不自动信任或广播任何消息。需要协作时由宿主建立独立来源/window/会话协议。

原生全屏由用户按钮调用 requestFullscreen/exitFullscreen；pending 防重，fullscreenchange 校准状态，拒绝或不支持给出恢复反馈。只退出本实例持有的全屏，卸载待完成请求也回收。模块导入不访问 DOM；挂载和原生全屏依赖浏览器，完整 SSR/hydration 不承诺。

## 开发、升级与验证

保持模板和 UI/Pro 来源分别可追踪。升级时先 diff Types/Navigation/三个 SFC，再对 route id、cacheKey、fallback、allowlist 和 EmbedPolicy 逐项迁移；不把旧缓存身份直接迁入新的业务 scope。scope 更新若需清空身份，应在宿主数据 id 中带 scope 或先卸载旧控制器再创建。不要把菜单隐藏当授权，不把 URL 中放 token 当认证实现。

`tests/v2/navigation/prepare.mjs` 接受新的 NAV_CONSUMER 绝对路径及 NAV_UI_TAR/NAV_PRO_TAR，复制可修改源码并生成普通 Vite 应用。consumer 独立安装、typecheck/build/dev；不使用源码 alias 或其他角色 node_modules。修改菜单标题、人员路由参数、StatePage 正文后重新编译、生产构建并操作输入/刷新确认开发效果。源码测试与浏览器测试见同目录测试配方；实际结果、未测与首失败只以 DELIVERY/外置回执为准。

## 语言接入与迁移

从 `@asam-ui/pro/i18n` 创建或读取当前应用的语言作用域，并将同一个 `i18n` 显式传给 `createNavigation({ i18n, router, components, load, fallback })`。组件树通过 `AsamApplicationProvider` 的 `config.base.i18n` 接入同一作用域；控制器不会修改宿主语言或持久化。

菜单及页签的业务标题仍由宿主字典提供；语言变化时以稳定 id 更新显示标题，不改变 path、resource、cacheKey 或当前页面实例。`examples/Texts.ts` 的宿主示例字典与组件消息分开；`EmbeddedExample.vue` 仍用公开按钮打开独立同源标签，不在官网生成 iframe。

旧项目未传 i18n 时保留历史行为。逐步迁移时先创建作用域，再连接 Provider 和控制器，最后接入业务标题；完整快速开始、组件外消息及隔离示例见[语言与区域](https://asam-ui.github.io/pro/i18n.html)。
