<template>
	<div>
		<AsamAdminLayout :size="size">
			<template #header>
				<slot name="header">{{ i18n.t('app.navigation.title') }}</slot>
				<NavigationToolbar
					v-if="headerTabs"
					ref="toolbar"
					:controller="controller"
					in-header
				/>
			</template>
			<template #sidebar>
				<AsamMenu
					class="navigation-menu"
					:default-active="activeRoute"
					background-color="var(--asam-color-surface)"
					text-color="var(--asam-color-text-primary)"
					active-text-color="var(--asam-semantic-primary-foreground)"
					@select="selectMenu"
				>
					<NavigationMenuItems :items="controller.visibleMenu.value" />
				</AsamMenu>
			</template>
			<NavigationToolbar v-if="!headerTabs" ref="toolbar" :controller="controller" />
			<AsamPageContainer :title="activeTitle">
				<NavigationView :controller="controller" />
			</AsamPageContainer>
		</AsamAdminLayout>
	</div>
</template>
<script setup lang="ts">
import { computed, onBeforeUnmount, useTemplateRef } from 'vue';
import { useAsamProI18n } from '../../i18n/index.js';
import type { VNode } from 'vue';
import { AsamAdminLayout, AsamPageContainer } from '../../layout/Index.js';
import { AsamMenu } from '@asam-ui/ui';
import type { AsamControlSize } from '@asam-ui/ui';
import type { NavigationController } from './Navigation.js';
import NavigationToolbar from './NavigationToolbar.vue';
import NavigationView from './NavigationView.vue';
import NavigationMenuItems from './NavigationMenuItems.vue';

const props = defineProps<{
	controller: NavigationController;
	size?: AsamControlSize;
	headerTabs?: boolean;
}>();
defineSlots<{ header?: () => VNode[] }>();
const i18n = useAsamProI18n();
const toolbar = useTemplateRef('toolbar');
const activeTab = computed(() =>
	props.controller.tabs.value.find((tab) => tab.id === props.controller.active.value)
);
const activeRoute = computed(() => JSON.stringify(['item', activeTab.value?.routeId ?? '']));
const activeTitle = computed(() => activeTab.value?.title ?? i18n.t('app.navigation.page'));

function selectMenu(id: string) {
	const item = props.controller.menu.value.find(
		(entry) => JSON.stringify(['item', entry.id]) === id
	);
	if (item) void props.controller.navigate(item.location ?? item.path);
}

// This shell owns its module, never the host router.
onBeforeUnmount(() => props.controller.dispose());
defineExpose({
	focusActive: async () => {
		await toolbar.value?.focusActive();
	}
});
</script>
<style scoped>
.navigation-menu :deep(:is(.el-menu-item, .el-sub-menu__title)) {
	--el-menu-hover-bg-color: var(--asam-semantic-primary-soft);
	--el-menu-hover-text-color: var(--asam-semantic-primary-foreground);
}
</style>
