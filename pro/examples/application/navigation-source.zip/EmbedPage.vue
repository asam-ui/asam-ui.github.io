<template>
	<section ref="container" class="navigation-embed" :aria-label="i18n.t('app.embed.region')">
		<AsamBaseForm class="navigation-embed-controls" @submit.prevent="open(address)">
			<!-- prettier-ignore -->
			<AsamFormItem :label="i18n.t('app.embed.address')">
				<AsamInput
					v-model="address"
					type="url"
					:aria-label="i18n.t('app.embed.address')"
				/>
			</AsamFormItem>
			<AsamButton native-type="submit">{{ i18n.t('app.embed.open') }}</AsamButton>
			<AsamButton native-type="button" :disabled="pending" @click="toggleFullscreen">
				{{
					fullscreen ? i18n.t('app.embed.exitFullscreen') : i18n.t('app.embed.fullscreen')
				}}
			</AsamButton>
		</AsamBaseForm>
		<p role="status" aria-live="polite">{{ status }}</p>
		<iframe
			v-if="session"
			:key="session.id"
			:src="session.url"
			:data-navigation-session="session.id"
			:title="title ?? i18n.t('app.embed.content')"
			:sandbox="policy.sandbox ?? ''"
			:allow="policy.permissions ?? ''"
			:referrerpolicy="policy.referrerPolicy ?? 'no-referrer'"
			@load="onLoad"
			@error="onError"
		/>
	</section>
</template>
<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue';
import { useAsamProI18n } from '../../i18n/index.js';
import { resolveApplicationText } from '../../i18n/application/Resolve.js';
import type { ApplicationTextKey } from '../../i18n/application/Resolve.js';
import { AsamBaseForm, AsamButton, AsamFormItem, AsamInput } from '@asam-ui/ui';
import type { EmbedPolicy } from './Types.js';
const props = defineProps<{ src: string; policy: EmbedPolicy; title?: string }>();
const i18n = useAsamProI18n();
const emit = defineEmits<{ (event: 'status', status: string): void }>();
const address = ref(props.src);
const statusCode = ref<ApplicationTextKey>('app.embed.idle');
const status = computed(() => resolveApplicationText(i18n, statusCode.value));
const container = ref<HTMLElement>();
const pending = ref(false);
const fullscreen = ref(false);
let generation = 0;
let disposed = false;
const session = shallowRef<{ id: number; url: string }>();
function belongsToCurrent(event: Event) {
	return (
		!disposed &&
		event.currentTarget instanceof HTMLIFrameElement &&
		event.currentTarget.dataset.navigationSession === String(generation)
	);
}
function onLoad(event: Event) {
	if (belongsToCurrent(event)) report('app.embed.loaded');
}
function onError(event: Event) {
	if (belongsToCurrent(event)) report('app.embed.failed');
}
function report(key: ApplicationTextKey) {
	if (!disposed) {
		statusCode.value = key;
		emit('status', status.value);
	}
}
function open(input: string) {
	const id = ++generation;
	session.value = undefined;
	try {
		const url = new URL(props.policy.resolve(input));
		if (
			!['http:', 'https:'].includes(url.protocol) ||
			url.username ||
			url.password ||
			!props.policy.allow(url)
		)
			throw new Error();
		report('app.embed.loading');
		session.value = { id, url: url.href };
	} catch {
		report('app.embed.rejected');
	}
}
function syncFullscreen() {
	fullscreen.value = document.fullscreenElement === container.value;
}
async function toggleFullscreen() {
	if (pending.value || disposed) return;
	const element = container.value;
	if (!element?.requestFullscreen || !document.fullscreenEnabled) {
		report('app.embed.fullscreenUnavailable');
		return;
	}
	pending.value = true;
	try {
		if (document.fullscreenElement === element) await document.exitFullscreen();
		else await element.requestFullscreen();
		if (disposed && document.fullscreenElement === element) await document.exitFullscreen();
	} catch {
		report('app.embed.fullscreenRejected');
	} finally {
		pending.value = false;
		if (!disposed) syncFullscreen();
	}
}
onMounted(() => {
	document.addEventListener('fullscreenchange', syncFullscreen);
	open(props.src);
});
watch(
	() => [props.src, props.policy] as const,
	() => {
		address.value = props.src;
		open(props.src);
	}
);
onBeforeUnmount(() => {
	disposed = true;
	generation++;
	session.value = undefined;
	document.removeEventListener('fullscreenchange', syncFullscreen);
	if (document.fullscreenElement === container.value)
		void document.exitFullscreen().catch(() => {});
});
defineExpose({ open, toggleFullscreen });
</script>
<style scoped>
.navigation-embed {
	background: var(--el-bg-color);
	color: var(--el-text-color-primary);
	padding: 12px;
}
.navigation-embed-controls {
	display: flex;
	gap: 8px;
	flex-wrap: wrap;
}
iframe {
	width: 100%;
	height: 60vh;
	border: 1px solid var(--el-border-color);
}
</style>
