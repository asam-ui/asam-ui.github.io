<template>
	<NavigationPage
		v-for="page in controller.pages.value"
		:key="`${page.cacheKey}:${page.epoch}`"
		:controller="controller"
		:tab="page"
		:active="page.id === controller.active.value"
	/>
	<RouterView v-if="!controller.active.value" />
</template>

<script setup lang="ts">
import { RouterView } from 'vue-router';
import type { NavigationController } from './Navigation.js';
import NavigationPage from './NavigationPage.vue';

/** 自定义布局的公开页面出口；缓存身份与释放仍由同一导航控制器维护。 */
defineProps<{ controller: NavigationController }>();
</script>
