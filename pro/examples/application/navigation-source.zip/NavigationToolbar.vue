<template>
	<div class="navigation-toolbar" :class="{ 'navigation-toolbar-header': inHeader }">
		<div
			ref="tabs"
			class="navigation-tabs"
			role="tablist"
			:aria-label="i18n.t('app.navigation.tabs')"
		>
			<AsamTag
				v-for="tab in controller.tabs.value"
				:key="tab.id"
				class="navigation-tab"
				:type="tab.id === controller.active.value ? 'primary' : 'info'"
				:effect="tab.id === controller.active.value ? 'light' : 'plain'"
				:closable="!tab.pinned"
				disable-transitions
				:draggable="!tab.pinned"
				@dragstart="startDrag($event, tab.id)"
				@dragend="dragging = ''"
				@dragover.prevent
				@drop.prevent="drop(tab.id)"
				@click="controller.navigate(tab.fullPath)"
				@close="close(tab.id)"
			>
				<span
					class="navigation-tab-title"
					role="tab"
					:aria-selected="tab.id === controller.active.value"
					:tabindex="
						tab.id === (controller.active.value || controller.tabs.value[0]?.id)
							? 0
							: -1
					"
					:data-tab="tab.id"
					@keydown="keyTab($event, tab.id, tab.fullPath)"
				>
					{{ tab.pinned ? i18n.t('app.navigation.pinned') : '' }}{{ tab.title }}
				</span>
			</AsamTag>
		</div>
		<div class="navigation-actions">
			<AsamButton
				native-type="button"
				:type="inHeader ? 'primary' : 'default'"
				@click="controller.refresh()"
			>
				{{ i18n.t('app.navigation.refresh') }}
			</AsamButton>
			<AsamButton native-type="button" type="default" plain @click="controller.closeOthers()">
				{{ i18n.t('app.navigation.closeOthers') }}
			</AsamButton>
			<AsamButton native-type="button" type="danger" plain @click="controller.closeAll()">
				{{ i18n.t('app.navigation.closeAll') }}
			</AsamButton>
			<AsamButton
				native-type="button"
				:type="inHeader ? 'secondary' : 'default'"
				:disabled="controller.loading.value"
				@click="controller.reload()"
			>
				{{ i18n.t('app.navigation.reload') }}
			</AsamButton>
		</div>
		<p class="navigation-status" role="status" aria-live="polite">{{ status }}</p>
	</div>
</template>

<script setup lang="ts">
import { computed, nextTick, shallowRef, useTemplateRef } from 'vue';
import { AsamButton, AsamTag } from '@asam-ui/ui';
import { useAsamProI18n } from '../../i18n/index.js';
import { resolveApplicationText } from '../../i18n/application/Resolve.js';
import type { NavigationController } from './Navigation.js';

const props = defineProps<{ controller: NavigationController; inHeader?: boolean }>();
const i18n = useAsamProI18n();
const tabsElement = useTemplateRef('tabs');
const dragging = shallowRef('');
const announcement = shallowRef<'app.navigation.reordered' | 'app.navigation.closed'>();
const status = computed(() => {
	if (props.controller.loading.value) return i18n.t('app.navigation.loading');
	const errorCode = props.controller.errorCode?.value;
	const problem = errorCode
		? resolveApplicationText(i18n, errorCode)
		: props.controller.error.value;
	return problem || (announcement.value ? i18n.t(announcement.value) : '');
});

function startDrag(event: DragEvent, id: string) {
	dragging.value = id;
	event.dataTransfer?.setData('text/plain', id);
}

function drop(id: string) {
	if (dragging.value) {
		props.controller.move(dragging.value, id);
		announcement.value = 'app.navigation.reordered';
	}
	dragging.value = '';
}

async function keyTab(event: KeyboardEvent, id: string, path: string) {
	if (!event.altKey && ['Enter', ' '].includes(event.key)) {
		event.preventDefault();
		await props.controller.navigate(path);
		return;
	}
	if (!event.altKey && ['ArrowLeft', 'ArrowRight', 'Home', 'End', 'Delete'].includes(event.key)) {
		event.preventDefault();
		if (event.key === 'Delete') {
			await close(id);
			return;
		}
		const tabs = props.controller.tabs.value;
		const index = tabs.findIndex((tab) => tab.id === id);
		const targetIndex =
			event.key === 'Home'
				? 0
				: event.key === 'End'
					? tabs.length - 1
					: (index + (event.key === 'ArrowLeft' ? -1 : 1) + tabs.length) % tabs.length;
		const target = tabs[targetIndex];
		if (target && (await props.controller.navigate(target.fullPath))) await focusActive();
		return;
	}
	if (!event.altKey || !['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
	event.preventDefault();
	const movable = props.controller.tabs.value.filter((tab) => !tab.pinned);
	const index = movable.findIndex((tab) => tab.id === id);
	const target = index >= 0 ? movable[index + (event.key === 'ArrowLeft' ? -1 : 1)] : undefined;
	if (target) {
		props.controller.move(id, target.id);
		announcement.value = 'app.navigation.reordered';
	}
}

async function close(id: string) {
	if (await props.controller.close([id])) {
		announcement.value = 'app.navigation.closed';
		await focusActive();
	}
}

async function focusActive() {
	await nextTick();
	const titles = tabsElement.value?.querySelectorAll<HTMLElement>('[data-tab]') ?? [];
	[...titles].find((title) => title.dataset.tab === props.controller.active.value)?.focus();
}

defineExpose({ focusActive });
</script>

<style scoped>
.navigation-toolbar {
	min-width: 0;
}

.navigation-toolbar-header {
	display: flex;
	flex: 1 1 min(36rem, 100%);
	flex-wrap: wrap;
	align-items: center;
	gap: var(--asam-space-sm, 8px);
}

.navigation-tabs {
	display: flex;
	flex: 1 1 14rem;
	gap: var(--asam-space-sm, 8px);
	min-width: 0;
	overflow-x: auto;
	padding: var(--asam-space-xs, 4px);
}

.navigation-tab {
	flex: 0 0 auto;
	cursor: pointer;
}

.navigation-tab-title:focus-visible {
	border-radius: var(--asam-radius-sm, 4px);
	outline: 2px solid var(--asam-semantic-focus);
	outline-offset: 1px;
}

.navigation-actions {
	display: flex;
	flex-wrap: wrap;
	gap: var(--asam-space-sm, 8px);
}

.navigation-toolbar-header .navigation-actions {
	justify-content: flex-end;
	margin-inline-start: auto;
}

.navigation-actions :deep(.asam-button + .asam-button) {
	margin-inline-start: 0;
}

.navigation-status {
	flex-basis: 100%;
	margin: 0;
}

.navigation-status:empty {
	position: absolute;
}
</style>
