# 请求与错误反馈

宿主注入HTTP供应商、认证、一次解包、数据校验与反馈。没有默认fetch/Axios、自动重试或真实业务后端；dispose取消本实例活跃请求。

## 导入

同一个Pro包同时支持分类访问与精确叶子导入，无需复制实现目录：

```ts
import {
	createRequestClient,
	createLatestRequest,
	createTransportProvider
} from '@asam-ui/pro/application/transport';
import { Application } from '@asam-ui/pro';
// Application.transport与叶子入口共享同一实现。
```

类型从同一叶子路径使用import type；分类类型从@asam-ui/pro/types访问。自动导入使用@asam-ui/pro/resolver的asamProAutoImports({ abilities: ['transport'] })，或按名称白名单启用。能力公开组件使用AsamProResolver；不默认全量注入全局。

## 最小与完整示例

examples/MinimalExample.vue展示本能力的核心配置和释放；examples/内完整场景保留路由、provider及本地fixture。官网提供逐文件复制/下载、能力源码与完整可运行ZIP。ZIP已包含main.ts、Vite配置、配套正常UI/Pro包及可移植pnpm锁文件；解压后运行pnpm install --frozen-lockfile、pnpm run dev、pnpm run typecheck、pnpm run build，无需手写网站宿主。

当前配套Vue3.5.34、EP2.14.7、UI/Pro0.1.0-alpha.1；导航与完整路由示例使用Vue Router4.6.3。展示组件需按element-plus/dist/index.css、@asam-ui/ui/style.css、@asam-ui/pro/style.css顺序引入样式。应用拥有router、provider、会话、业务接口与资源，能力不得反向依赖examples或网站。

## 公共 API 与默认值

| API / 选项                                   | 默认与覆盖                  | 边界                                                                        |
| -------------------------------------------- | --------------------------- | --------------------------------------------------------------------------- |
| `transport(input, context)`                  | 必填应用注入                | 返回 raw 或 data 判别联合；无隐式 fetch / Axios / 重试                      |
| `auth(signal)`                               | 无认证；每次读取，可异步    | 必须响应 signal，更新认证不改实例；headers 仅交供应商                       |
| `online()`                                   | 未配置则尝试传输            | 不访问 navigator，应用可注入离线状态                                        |
| `timeoutMs`                                  | 15000ms；每次可覆盖；0 禁用 | 有限非负，最大 2147483647；涵盖认证、transport、异步解包                    |
| `request(input, { decode, unwrap, signal })` | decode 必填；无自动解包     | raw 成功状态仅 unwrap 一次；data 直接 decode；decode 同步校验/映射          |
| `present(error)`                             | 默认无反馈                  | 安全分类、固定文案、内部编号；每个错误最多调用一次，不等待 callback 完成    |
| `log(event)`                                 | 默认无日志                  | 仅 traceId/outcome/durationMs；不传 URL/headers/params/body/异常/服务端消息 |
| `dispose()`                                  | 终止所有活跃请求            | 幂等；之后请求取消，不重新激活，重挂须创建新实例                            |
| `createLatestRequest(client, commit)`        | 一个消费容器一个实例        | 新 load 取消旧 load，只有当前结果 commit；cancel/dispose 不呈现取消反馈     |
| `createTransportProvider(client, unwrap)`    | 复用 ASAM 数据协议          | provider 输出业务 data，组件 transform 只做选项/分页映射                    |

`TransportResponse` 的 `mode:'raw'` 指 HTTP status/body；`mode:'data'` 指供应商已解包的业务值，即使有名为 data 的属性也不会再次解包。raw 401/403 归 auth，其他非 2xx 归 business。供应商以 `TransportFault('network')` 报网络故障；无法可靠识别的抛出归 unknown，避免把所有 TypeError 猜为网络。取消原因和原始异常被丢弃，`RequestFailure` 不含 cause。服务端追踪字段默认不采纳；本实例 request-N 为本地顺序编号，应用应以实例日志容器区分多个实例。

## 应用使用配方

```ts
import {
	createRequestClient,
	createTransportProvider,
	TransportFault
} from '@asam-ui/pro/application/transport';
import { provideAsamData } from '@asam-ui/ui';

const client = createRequestClient({
	transport: applicationTransport,
	auth: applicationAuthentication,
	present: (error) => applicationErrorContainer.show(error),
	log: (event) => localSafeDiagnostics.append(event)
});
provideAsamData(
	app,
	createTransportProvider(client, (body) => {
		if (!body || typeof body !== 'object' || !('data' in body))
			throw new TransportFault('business');
		return body.data;
	})
);
// applicationTransport / Authentication / ErrorContainer 是应用实现的注入点。
// 真实的可执行实现见 examples/application.ts 与 mock.ts。
```

一次错误 callback 中由应用决定显示 toast、错误页或导航；模板不直接操作路由。组件使用 `isErrorNotified` 和 `onError` 去重；组件自己的 transform 失败仅产生固定 unknown 提示。不要把不可信错误消息直接渲染或调用 console.error(cause)。应用注入的 transport/auth/decoder 自身仍须避免记录秘密，本模块不可能约束宿主自行外传。

认证变更后应用若有组件缓存，应按现有 `setAsamDataScope` / `invalidateAsamData` 协议切 scope 或清缓存；请求层不代管登录态或字典缓存。示例更新模拟认证后用强制 reload 重新请求。

## Agent 发现与正确使用

能力入口为 `capability.json`；需求自然语言“请求认证/一次解包/错误联动/取消超时”映射本目录，API 依据 Types 与 README，运行案例为 examples。顺序：确认供应商返回 raw/data → 注入认证和安全反馈 → provider 对接组件 → 确认 transform 不再解包 → 为独立容器创建 latest → 卸载取消 → 执行 tests。不得猜 CL 账号/API，不生成默认登录路由，不把本能力当发布完成的包。

## 迁移

既有 UI/provider/Yudao API 无破坏修改。应用原本在 Axios 解包的，应返回 `mode:'data'`；尚未解包的返回 raw 并注入 unwrap。避免同时启用 Yudao 的解包适配器，否则会再次解包，应在应用选择单一责任层。本能力 provider 输出已解包数据；选项与分页组件继续现有格式映射。旧 toast 与模板 present 二选其一，模板接管时移除原 transport 的 toast。旧无界 retry 移除，用户显式再次请求；不内建任何自动重试，尤其 POST/PUT/DELETE。

## 验证与适用范围

测试源码包含成功/空、认证更新与实例隔离、一次解包、相反完成顺序、认证/请求/解包阶段取消、超时晚到、HTTP 错误分类、异常捕捉/反馈去重、离线、脱敏、卸载与重挂、1000 请求耗时预算。Node SSR 请求可用（无 window/navigator），SFC 为客户端演示；未宣称 SSR hydration 验证。浏览器和性能实测结果查同目录 DELIVERY；预算为开发机 1000 本地顺序请求小于 1500ms，非远端服务 SLA。

真实后台权限、账号、CL、其他浏览器、完整 SSR 页面及所有宿主安全测试未执行；Chrome 本地示例和确定性 Mock 不替代上述验证。DEV 自测不代替独立 OCR → QA → ACC。日志、截图、构建与测试中间产物各自放本轮输出/证据目录，不提交 Git；原 DEV-R1 原件只保留为历史来源，后续不能覆盖或当作自己运行结果。

## 组件外消息与语言迁移

`createRequestClient({ transport, i18n, ... })` 读取显式应用作用域；它不依赖组件 setup，也不创建全局语言单例。组件 Provider 与客户端应接收同一 i18n，SSR 每个请求单独创建和释放。未传 i18n 的旧项目保留历史行为。

`present` 接收本能力约定的安全反馈。展示已生成的本能力错误时用 `i18n.formatError(error)` 读取当前语言，保留原始错误对象、诊断码、traceId 和 message；不把服务端原始文本或任意 Error.message 识别成资源 key。语言变化不重发请求、不重新解包，也不改变原有取消和结果提交语义。

更多组件外消息、业务字典边界及独立工程见[语言与区域](https://asam-ui.github.io/pro/i18n.html)。
