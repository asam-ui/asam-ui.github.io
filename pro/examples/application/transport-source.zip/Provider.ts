import type { AsamDataProvider } from '@asam-ui/ui';
import type { RequestClient } from './Types.js';
import { RequestFailure } from './Client.js';

/** request 返回业务 data。组件 transform 只映射选项/分页，不再解 HTTP/业务包。 */
export function createTransportProvider(
	client: RequestClient,
	unwrap?: (body: unknown) => unknown
): AsamDataProvider {
	return {
		request: (input, context) =>
			client.request(input, {
				signal: context.signal,
				unwrap,
				decode: (data) => data
			}),
		isErrorNotified: (error) => client.isErrorNotified(error),
		onError: (error) => {
			if (client.isErrorNotified(error.cause)) return;
			if (error.cause instanceof RequestFailure && error.cause.kind === 'cancelled') return;
			client.presentComponentError(error);
		}
	};
}
