import type { AsamI18n } from '@asam-ui/ui/i18n';
import { resolveApplicationText } from '../../i18n/application/Resolve.js';
import type {
	ClientOptions,
	ErrorKind,
	RequestClient,
	RequestInput,
	RequestOptions,
	SafeError
} from './Types.js';

const messages: Record<ErrorKind, string> = {
	cancelled: '请求已取消',
	timeout: '请求超时，请重试',
	offline: '当前离线，请检查网络',
	network: '网络请求失败，请重试',
	auth: '认证失效，请重新登录',
	business: '请求未能完成',
	unknown: '发生未知错误，请重试'
};

/** 应用适配器用有限分类报告错误，不接受原始业务消息或 cause。 */
export class TransportFault extends Error {
	readonly kind: ErrorKind;
	constructor(kind: ErrorKind) {
		if (!Object.hasOwn(messages, kind)) throw new TypeError('Unsupported transport error kind');
		super(messages[kind]);
		this.name = 'TransportFault';
		this.kind = kind;
		Object.freeze(this);
	}
}

export class RequestFailure extends Error implements SafeError {
	readonly kind: ErrorKind;
	readonly traceId: string;
	constructor(kind: ErrorKind, traceId: string) {
		super(messages[kind]);
		this.name = 'RequestFailure';
		this.kind = kind;
		this.traceId = traceId;
		Object.freeze(this);
	}
}

/** Translate only known local error classes. Host and server messages are never interpreted. */
export function formatRequestFailure(
	error: { readonly message: string },
	scope?: AsamI18n
): string {
	return error instanceof RequestFailure || error instanceof TransportFault
		? resolveApplicationText(scope, `app.transport.${error.kind}`)
		: error.message;
}

function safely(callback: () => unknown): void {
	try {
		void Promise.resolve(callback()).catch(() => undefined);
	} catch {
		/* 应用反馈失败不覆盖请求结果，也不记录原始异常。 */
	}
}

function timeout(value: number): number {
	if (!Number.isFinite(value) || value < 0 || value > 2147483647)
		throw new TypeError('timeoutMs must be finite and between 0 and 2147483647');
	return value;
}

export function createRequestClient(options: ClientOptions): RequestClient {
	const defaultTimeout = timeout(options.timeoutMs ?? 15000);
	const controllers = new Set<AbortController>();
	const notified = new WeakSet<object>();
	let sequence = 0;
	let disposed = false;
	const trace = () => `request-${++sequence}`;
	const present = (error: RequestFailure) => {
		if (error.kind === 'cancelled' || notified.has(error) || !options.present) return;
		notified.add(error);
		const safe = Object.freeze({
			kind: error.kind,
			get message() {
				return formatRequestFailure(error, options.i18n);
			},
			traceId: error.traceId
		});
		safely(() => options.present?.(safe));
	};
	return {
		async request<T>(input: RequestInput, request: RequestOptions<T>): Promise<T> {
			const budget = timeout(request.timeoutMs ?? defaultTimeout);
			const traceId = trace();
			const start = performance.now();
			const controller = new AbortController();
			controllers.add(controller);
			let outcome: 'success' | ErrorKind = 'success';
			let timer: ReturnType<typeof setTimeout> | undefined;
			const cancel = () => controller.abort(new TransportFault('cancelled'));
			request.signal?.addEventListener('abort', cancel, { once: true });
			if (disposed || request.signal?.aborted) cancel();
			if (budget > 0)
				timer = setTimeout(() => controller.abort(new TransportFault('timeout')), budget);
			let rejectAbort: () => void = () => undefined;
			const aborted = new Promise<never>((_, reject) => {
				rejectAbort = () => reject(controller.signal.reason);
				controller.signal.addEventListener('abort', rejectAbort, { once: true });
				if (controller.signal.aborted) rejectAbort();
			});
			const run = async () => {
				controller.signal.throwIfAborted();
				if (options.online?.() === false) throw new TransportFault('offline');
				const headers = Object.freeze({ ...(await options.auth?.(controller.signal)) });
				controller.signal.throwIfAborted();
				const response = await options.transport(input, {
					signal: controller.signal,
					headers,
					traceId
				});
				controller.signal.throwIfAborted();
				let data: unknown;
				if (response.mode === 'data') data = response.data;
				else if (response.mode === 'raw') {
					if (response.status === 401 || response.status === 403)
						throw new TransportFault('auth');
					if (
						!Number.isInteger(response.status) ||
						response.status < 200 ||
						response.status >= 300
					)
						throw new TransportFault('business');
					data = request.unwrap ? await request.unwrap(response.body) : response.body;
				} else throw new TransportFault('unknown');
				controller.signal.throwIfAborted();
				return request.decode(data);
			};
			try {
				return await Promise.race([run(), aborted]);
			} catch (cause) {
				const reason = controller.signal.aborted ? controller.signal.reason : cause;
				const kind =
					reason instanceof TransportFault && Object.hasOwn(messages, reason.kind)
						? reason.kind
						: 'unknown';
				outcome = kind;
				const error = new RequestFailure(kind, traceId);
				present(error);
				throw error;
			} finally {
				if (timer !== undefined) clearTimeout(timer);
				request.signal?.removeEventListener('abort', cancel);
				controller.signal.removeEventListener('abort', rejectAbort);
				controllers.delete(controller);
				const event = Object.freeze({
					traceId,
					outcome,
					durationMs: Math.max(0, performance.now() - start)
				});
				safely(() => options.log?.(event));
			}
		},
		isErrorNotified(error) {
			return typeof error === 'object' && error !== null && notified.has(error);
		},
		presentComponentError(error) {
			if (!options.present) return;
			if (disposed || (typeof error === 'object' && error !== null && notified.has(error)))
				return;
			if (error instanceof RequestFailure && error.kind === 'cancelled') return;
			if (typeof error === 'object' && error !== null) notified.add(error);
			present(new RequestFailure('unknown', trace()));
		},
		dispose() {
			disposed = true;
			for (const controller of controllers) controller.abort(new TransportFault('cancelled'));
		}
	};
}
