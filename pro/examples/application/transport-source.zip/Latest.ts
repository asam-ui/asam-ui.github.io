import type { RequestClient, RequestInput, RequestOptions } from './Types.js';

/** 每个消费容器独立创建。旧响应不能写当前 UI，卸载 dispose 后不可复用。 */
export function createLatestRequest<T>(client: RequestClient, commit: (data: T) => void) {
	let current: AbortController | undefined;
	let revision = 0;
	let disposed = false;
	return {
		async load(input: RequestInput, options: RequestOptions<T>): Promise<T> {
			current?.abort();
			const controller = new AbortController();
			current = controller;
			const version = ++revision;
			const abort = () => controller.abort();
			options.signal?.addEventListener('abort', abort, { once: true });
			if (disposed || options.signal?.aborted) abort();
			try {
				const result = await client.request(input, {
					...options,
					signal: controller.signal
				});
				if (!disposed && version === revision && !controller.signal.aborted) commit(result);
				return result;
			} finally {
				options.signal?.removeEventListener('abort', abort);
				if (current === controller) current = undefined;
			}
		},
		cancel() {
			++revision;
			current?.abort();
		},
		dispose() {
			disposed = true;
			++revision;
			current?.abort();
		}
	};
}
