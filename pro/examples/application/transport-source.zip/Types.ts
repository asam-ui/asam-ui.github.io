import type { AsamI18n } from '@asam-ui/ui/i18n';
export type ErrorKind =
	'cancelled' | 'timeout' | 'offline' | 'network' | 'auth' | 'business' | 'unknown';

/** HTTP 包装与已适配业务值必须显式区别，绝不根据 data 属性猜形状。 */
export type TransportResponse =
	| { readonly mode: 'raw'; readonly status: number; readonly body: unknown }
	| { readonly mode: 'data'; readonly data: unknown };

export interface RequestInput {
	readonly url: string;
	readonly method?: 'get' | 'post' | 'put' | 'delete';
	readonly params?: Readonly<Record<string, unknown>>;
	readonly data?: unknown;
}

export interface TransportContext {
	readonly signal: AbortSignal;
	readonly headers: Readonly<Record<string, string>>;
	/** 本实例生成的非业务编号；不采用服务端可能含秘密的追踪字段。 */
	readonly traceId: string;
}

export interface SafeError {
	readonly kind: ErrorKind;
	readonly message: string;
	readonly traceId: string;
}

/** 固定白名单日志。不提供 URL、headers、body、token、原始异常或业务消息。 */
export interface RequestLog {
	readonly traceId: string;
	readonly outcome: 'success' | ErrorKind;
	readonly durationMs: number;
}

export interface ClientOptions {
	/** Explicit language owner for safe feedback; transport diagnostics remain unchanged. */
	readonly i18n?: AsamI18n;
	readonly transport: (
		input: RequestInput,
		context: TransportContext
	) => Promise<TransportResponse>;
	/** 每次请求读取最新认证；异步认证也受取消和超时保护。 */
	readonly auth?: (
		signal: AbortSignal
	) => Readonly<Record<string, string>> | Promise<Readonly<Record<string, string>>>;
	readonly online?: () => boolean;
	/** 一个 callback 中由应用决定反馈、错误页或导航；不会自动重试。 */
	readonly present?: (error: SafeError) => void | Promise<void>;
	readonly log?: (event: RequestLog) => void | Promise<void>;
	readonly timeoutMs?: number;
}

export interface RequestOptions<T> {
	readonly signal?: AbortSignal;
	readonly timeoutMs?: number;
	/** 仅 raw 的 body 调用一次；data 分支要求供应商已经适配。两分支均经 decode 校验。 */
	readonly unwrap?: (body: unknown) => unknown | Promise<unknown>;
	readonly decode: (data: unknown) => T;
}

export interface RequestClient {
	request<T>(input: RequestInput, options: RequestOptions<T>): Promise<T>;
	isErrorNotified(error: unknown): boolean;
	/** 未经本 client 呈现的组件错误，仅以安全的 unknown 分类呈现。 */
	presentComponentError(error: unknown): void;
	dispose(): void;
}
