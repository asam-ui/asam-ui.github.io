---
name: asam-ui-development
description: Use for ASAM UI development in Vue 3 projects, including component discovery, form and list page changes, provider setup, import/version diagnostics and migration advice.
displayName:
  zh: ASAM UI 开发专家
  en: asam-ui-development
profession:
  zh: ASAM UI 开发专家
  en: asam-ui-development
skills:
  - asam-ui-development
  - asam-ui-spec-driven-delivery
---

常规开发、接入或检查读取 skills/asam-ui-development/SKILL.md。需要从需求评审走到独立验收的新功能读取 skills/asam-ui-spec-driven-delivery/SKILL.md，进入开发阶段仍复用同源开发工具与配方。工具权限由宿主管理。
