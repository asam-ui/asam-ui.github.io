import {
	existsSync,
	lstatSync,
	readFileSync,
	readdirSync,
	mkdirSync,
	rmdirSync,
	unlinkSync,
	writeFileSync,
	realpathSync
} from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { randomUUID } from 'node:crypto';
import { assertNoLinks, sha } from './files.mjs';
import { verify } from './lifecycle.mjs';

const pluginId = 'asam-ui-development@my-experts';
const object = (value) => value && typeof value === 'object' && !Array.isArray(value);
const versionSegment = (value) =>
	typeof value === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9._+-]{0,99}$/.test(value);
const cacheVersion = (value) => value.replaceAll('+', '-');

// A marketplace update does not advance WorkBuddy's installed runtime snapshot.
// Plan only the existing user installation owned by this package. Other scopes
// and plugin registrations remain under the host's control.
export function planWorkBuddyCache({ source, configRoot, readOnly = false }) {
	const path = join(configRoot, 'plugins/installed_plugins.json');
	assertNoLinks(path);
	if (!existsSync(path)) return null;
	const before = readFileSync(path);
	const registry = JSON.parse(before.toString('utf8').replace(/^\uFEFF/, ''));
	if (!object(registry) || !object(registry.plugins))
		throw Error('WORKBUDDY_CACHE_REGISTRY_CONFLICT');
	const records = registry.plugins[pluginId];
	if (records === undefined) return null;
	if (!Array.isArray(records) || records.some((record) => !object(record)))
		throw Error('WORKBUDDY_CACHE_REGISTRY_CONFLICT');
	if (records.length === 0) return null;
	const users = records.filter((record) => record.scope === 'user');
	if (users.length !== 1 || records.some((record) => record.scope === 'managed'))
		throw Error('WORKBUDDY_CACHE_SCOPE_CONFLICT');
	const record = users[0];
	const metadata = JSON.parse(readFileSync(join(source, '.codebuddy-plugin/plugin.json')));
	if (metadata.name !== 'asam-ui-development' || !versionSegment(metadata.version))
		throw Error('WORKBUDDY_CACHE_VERSION_CONFLICT');
	const root = join(configRoot, 'plugins/cache/my-experts/asam-ui-development');
	if (
		!versionSegment(record.version) ||
		typeof record.installPath !== 'string' ||
		resolve(record.installPath) !== join(root, cacheVersion(record.version))
	)
		throw Error('WORKBUDDY_CACHE_PATH_CONFLICT');
	const previous = join(root, cacheVersion(record.version));
	const target = join(root, cacheVersion(metadata.version));
	const snapshots = [];
	for (const slot of new Set([previous, target])) {
		assertNoLinks(slot);
		if (!existsSync(slot)) continue;
		if (!readOnly) assertCacheIdle(slot);
		if (verify(slot, { allowWorkBuddyUsageMarkers: readOnly }).host !== 'workbuddy')
			throw Error('WORKBUDDY_CACHE_OWNER_CONFLICT');
		const installed = JSON.parse(readFileSync(join(slot, '.codebuddy-plugin/plugin.json')));
		if (
			installed.name !== metadata.name ||
			!versionSegment(installed.version) ||
			join(root, cacheVersion(installed.version)) !== slot
		)
			throw Error('WORKBUDDY_CACHE_VERSION_CONFLICT');
		snapshots.push({
			path: slot,
			ownershipSHA256: sha(readFileSync(join(slot, 'ownership.json')))
		});
	}
	const same =
		existsSync(target) &&
		readFileSync(join(target, 'ownership.json')).equals(
			readFileSync(join(source, 'ownership.json'))
		);
	// Preserve scope metadata, unrelated plugins and user enablement settings.
	const updated = { ...record, installPath: target, version: metadata.version };
	if (Object.hasOwn(record, 'resolvedVersion')) updated.resolvedVersion = metadata.version;
	registry.plugins[pluginId] = records.map((item) => (item === record ? updated : item));
	const unchanged = JSON.stringify(record) === JSON.stringify(updated);
	return {
		path,
		before,
		after: unchanged ? before : Buffer.from(JSON.stringify(registry, null, '\t') + '\n'),
		target,
		previous,
		root: join(configRoot, 'plugins/cache'),
		same,
		snapshots
	};
}

export function assertWorkBuddyCacheUnchanged(cache) {
	assertNoLinks(cache.path);
	if (!readFileSync(cache.path).equals(cache.before)) throw Error('EXPERT_REGISTRY_CHANGED');
	for (const snapshot of cache.snapshots) {
		assertNoLinks(snapshot.path);
		assertCacheIdle(snapshot.path);
		verify(snapshot.path);
		if (sha(readFileSync(join(snapshot.path, 'ownership.json'))) !== snapshot.ownershipSHA256)
			throw Error('EXPERT_SOURCE_CHANGED');
	}
	if (!cache.snapshots.some((entry) => entry.path === cache.target) && existsSync(cache.target))
		throw Error('EXPERT_SOURCE_CHANGED');
}

function assertCacheIdle(slot) {
	const markers = join(slot, '.in_use');
	assertNoLinks(markers);
	if (!existsSync(markers)) return;
	const entries = readdirSync(markers);
	if (!entries.length) return;
	const groups = { active: [], stale: [], unknown: 0 };
	for (const entry of entries) {
		const status = workBuddyUsageStatus(markers, entry);
		if (status === 'unknown') groups.unknown++;
		else groups[status].push(entry);
	}
	const detail = [
		groups.active.length && `活跃 PID ${groups.active.join(', ')}`,
		groups.stale.length && `PID 已不存在 ${groups.stale.join(', ')}`,
		groups.unknown && `无法核实 ${groups.unknown} 个标记`
	].filter(Boolean).join('；');
	throw Error(`WORKBUDDY_CACHE_IN_USE: ${detail}`);
}

// PID probes describe the host state only. A recycled PID still protects the slot.
function workBuddyUsageStatus(markers, entry) {
	if (!/^[1-9][0-9]{0,9}$/.test(entry)) return 'unknown';
	const pid = Number(entry);
	if (pid > 0x7fffffff) return 'unknown';
	try {
		const path = join(markers, entry);
		const stat = lstatSync(path);
		if (!stat.isFile() || stat.size > 1024) return 'unknown';
		if (JSON.parse(readFileSync(path, 'utf8')).pid !== pid) return 'unknown';
	} catch {
		return 'unknown';
	}
	try {
		process.kill(pid, 0);
		return 'active';
	} catch (error) {
		return error.code === 'ESRCH' ? 'stale' : 'unknown';
	}
}

// Coordinate with WorkBuddy 5.11's cache and registry lock-file contract.
// An existing lock or usage marker is left for the native owner to release.
export function lockWorkBuddyCache(cache) {
	const locks = [];
	const release = () => {
		for (const { path, token } of locks.reverse()) {
			const record = join(path, 'lock.json');
			assertNoLinks(record);
			if (JSON.parse(readFileSync(record)).lockId !== token)
				throw Error('WORKBUDDY_CACHE_LOCK_CHANGED');
			unlinkSync(record);
			rmdirSync(path);
		}
	};
	try {
		const names = [...new Set([cache.root, cache.target])]
			.sort()
			.map((path) => `kylin-plugin-cache-${sha(resolve(path)).slice(0, 16)}`);
		names.push(`installed-plugins-registry-${sha(resolve(cache.path)).slice(0, 16)}`);
		for (const name of names) {
			const path = join(realpathSync(tmpdir()), `${name}.lock`);
			assertNoLinks(path);
			try {
				mkdirSync(path);
			} catch (error) {
				if (error.code === 'EEXIST') throw Error('WORKBUDDY_CACHE_BUSY');
				throw error;
			}
			const token = randomUUID();
			try {
				writeFileSync(
					join(path, 'lock.json'),
					JSON.stringify({ lockId: token, pid: process.pid, timestamp: Date.now() }),
					{ flag: 'wx', mode: 0o600 }
				);
			} catch (error) {
				rmdirSync(path);
				throw error;
			}
			locks.push({ path, token });
		}
		return release;
	} catch (error) {
		release();
		throw error;
	}
}
