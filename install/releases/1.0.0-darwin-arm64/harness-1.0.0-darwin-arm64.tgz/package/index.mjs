import { readFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { isAbsolute, join, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import * as mcpClient from '@deepseek-ai/dsh-mcp-client';
import { BUNDLED_SKILL_RANK } from '@deepseek-ai/dsh-skill';
import { createUserMessage } from '@deepseek-ai/dsh-llm';

export const name = 'asam-ui-development';
export const inject = ['skills'];

// Only this adapter runs in the Harness process. The fixed ASAM runtime remains
// a separate Node 22 process, including the bridge's protocol negotiation probe.
export function apply(ctx, config = {}) {
	const [hostMajor, hostMinor] = process.versions.node.split('.').map(Number);
	if (hostMajor < 24 || (hostMajor === 24 && hostMinor < 9))
		throw Error('HARNESS_HOST_NODE24_9_OR_LATER_REQUIRED');
	const root = fileURLToPath(new URL('./', import.meta.url));
	const node = config.node;
	if (typeof node !== 'string' || !isAbsolute(node))
		throw Error('ASAM_NODE22_ABSOLUTE_PATH_REQUIRED');
	const probe = spawnSync(node, ['--version'], {
		encoding: 'utf8',
		timeout: 10000,
		windowsHide: true
	});
	const [major, minor] = String(probe.stdout ?? '')
		.trim()
		.replace(/^v/, '')
		.split('.')
		.map(Number);
	if (probe.error || probe.status !== 0 || major !== 22 || minor < 19)
		throw Error('ASAM_NODE22_19_OR_LATER_REQUIRED');
	const skills = [
		[name, '在 Vue 3 工程中开发 ASAM UI 页面、只检查规范，或按授权检查并修复。'],
		[
			'asam-ui-spec-driven-delivery',
			'ASAM UI 规范驱动交付。用于澄清需求，把评审结论写成规格，按规格开发、检查并准备独立验收。'
		]
	].map(([skillName, description]) => {
		const directory = join(root, 'skills', skillName);
		return {
			locator: join(directory, 'SKILL.md'),
			summary: {
				name: skillName,
				description,
				invocation: { modelInvocable: true, userInvocable: true },
				provider: name,
				source: 'bundled',
				rank: BUNDLED_SKILL_RANK,
				resourceBase: { kind: 'directory', path: directory.split(sep).join('/') }
			}
		};
	});
	ctx.skills.registerProvider(() => ({
		name,
		list: async () => skills.map(({ summary, locator }) => ({ ...summary, locator })),
		async get(candidate, options) {
			const skill = skills.find(
				({ summary, locator }) => candidate.name === summary.name && candidate.locator === locator
			);
			if (!skill) throw Error('ASAM_SKILL_NOT_FOUND');
			const { locator, summary } = skill;
			const raw = await readFile(locator, { encoding: 'utf8', signal: options.signal });
			const content = raw.replace(/^---\r?\n[\s\S]*?\r?\n---(?:\r?\n|$)/, '').trim();
			if (summary.name !== name) return { ...summary, content };
			return {
				...summary,
				content:
					content +
					'\n\n## 当前 Harness 运行入口\n\n所有 ASAM CLI 命令使用以下独立 Node 22 可执行文件；不可使用 Harness Host 的 Node 或 Electron 运行时。三模式、规则和修复预算仍使用上述共享核心。\n\n' +
					JSON.stringify(
						{ node, agent: join(root, 'skills', name, 'scripts/agent.mjs') },
						null,
						2
					)
			};
		}
	}));
	// Commands are optional on older Harness hosts. Keep the same two Skills;
	// expose the shared quick prompts through the host's native slash menu.
	ctx.inject(['commands'], (commandContext) => {
		const prompts = JSON.parse(readFileSync(join(root, 'quick-prompts.json'), 'utf8'));
		for (const [index, command] of ['asam-button', 'asam-monitor', 'asam-requirements'].entries()) {
			const prompt = prompts[index].zh;
			commandContext.commands.register({
				name: command,
				description: prompt,
				handler({ agent, signal }) {
					signal.throwIfAborted();
					agent.followup(createUserMessage({
						content: [{ type: 'text', text: prompt }],
						source: { kind: 'user' }
					}));
					return { kind: 'success', text: prompt };
				}
			});
		}
	});
	ctx.plugin(mcpClient, {
		serverName: 'asam-ui',
		transport: 'stdio',
		command: node,
		args: [join(root, 'runtime/packages/mcp/src/server.mjs')],
		cwd: root,
		env: {
			ASAM_AGENT_BUNDLE: join(root, 'bundle'),
			ASAM_AGENT_VALIDATION: '1'
		},
		failOnStartupError: true
	});
}
