# ASAM UI 开发专家 1.0.0

在 Vue 项目里查组件用法、类型和示例源码，获取 Pro 页面模板的完整工程。开发新功能时，专家可帮你澄清需求，把评审结论写成规格，再按规格开发、检查并准备独立验收所需的材料。

## asam-ui-development

Look up component usage, types, and example source in Vue projects, and get complete projects for Pro page templates. For new features, clarify requirements, turn review decisions into a specification, then implement and check against it and prepare materials for independent acceptance.
