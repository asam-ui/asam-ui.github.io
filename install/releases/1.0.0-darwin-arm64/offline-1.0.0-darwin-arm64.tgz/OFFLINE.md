# ASAM UI 开发专家离线包

解压后保留全部文件，使用 Node.js >=22.19 <23 运行：

```sh
node installer.mjs --offline-dir . --public-key-file release-public.pem
```

选择 Agent 工具后，未安装则安装；已有安装显示已装版本和目标版本，可选择升级、取消或卸载。无法识别的版本显示“未知”。自动化可显式指定 --host codex|workbuddy|harness 与 --action install|update|uninstall|cancel，check保留作只读校验。离线模式仍校验发行清单签名与所选包摘要。首次信任公钥以官网公布的指纹和取得包的可信来源为准。DeepSeek Harness 通过其自带的 pnpm 安装依赖。首次准备依赖可能需要联网。

安装器下载的文件和阶段日志默认保留在当前用户系统 Downloads/ASAM-UI。macOS 的默认路径是 ~/Downloads/ASAM-UI。Windows 使用系统指定的 Downloads 目录，阶段日志位于其中 ASAM-UI/logs。旧下载保留原位。安装包名称带版本、平台及SHA256末尾16位；完整大小/摘要一致即复用，同名不符则另用唯一名称并保留原文件。解压文件和安装记录与实际插件分开存放；用户删除下载文件不影响已安装插件或OCR运行。已有有效工具优先复用，不为更改下载默认值重新安装，不改全局pnpm或开发缓存。
