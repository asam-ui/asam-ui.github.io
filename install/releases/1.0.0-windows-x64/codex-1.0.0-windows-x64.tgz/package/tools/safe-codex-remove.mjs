import {
	existsSync,
	lstatSync,
	mkdirSync,
	readFileSync,
	readdirSync,
	writeFileSync
} from 'node:fs';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { createHash } from 'node:crypto';
import { loggedSpawnSync as spawnSync } from './installer-log.mjs';
import { fileURLToPath } from 'node:url';

const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
function noLinks(path) {
	for (let p = path; ; p = dirname(p)) {
		try {
			if (lstatSync(p).isSymbolicLink()) throw Error('SYMLINK_NOT_ALLOWED');
		} catch (error) {
			if (error.code !== 'ENOENT') throw error;
		}
		if (dirname(p) === p) break;
	}
}
function files(root, prefix = '') {
	return readdirSync(join(root, prefix), { withFileTypes: true })
		.flatMap((entry) => {
			const path = [prefix, entry.name].filter(Boolean).join('/');
			if (entry.isSymbolicLink()) throw Error('SYMLINK_NOT_ALLOWED');
			if (entry.isDirectory()) return files(root, path);
			if (!entry.isFile()) throw Error('SPECIAL_FILE_NOT_ALLOWED');
			return [{ path, sha256: hash(readFileSync(join(root, path))) }];
		})
		.sort((a, b) => a.path.localeCompare(b.path));
}
const json = (path) => JSON.parse(readFileSync(path, 'utf8'));
const outside = (parent, child) => {
	const rel = relative(parent, child);
	return rel === '..' || rel.startsWith(`..${sep}`) || isAbsolute(rel);
};

export function codexCacheInUse(native) {
	return (
		process.platform === 'win32' &&
		native?.status !== 0 &&
		/\bos error 32\b/i.test(native?.stderr ?? '')
	);
}

function verifiedRetryBackup(root, { installed, pluginId, ownership, expected }) {
	if (!existsSync(root)) return;
	for (const entry of readdirSync(root, { withFileTypes: true })) {
		if (!entry.isDirectory() || !/^remove-[a-f0-9-]{36}$/i.test(entry.name)) continue;
		const candidate = join(root, entry.name);
		try {
			const receiptPath = join(candidate, 'receipt.json');
			const cache = join(candidate, 'cache');
			noLinks(receiptPath);
			noLinks(cache);
			const receipt = json(receiptPath);
			if (
				receipt.status === 'native-failed-preserved' &&
				receipt.nativeInvoked === true &&
				codexCacheInUse(receipt.native) &&
				isAbsolute(receipt.installed ?? '') &&
				relative(receipt.installed, installed) === '' &&
				receipt.pluginId === pluginId &&
				receipt.baselineOwnershipSHA256 === ownership &&
				JSON.stringify(receipt.snapshot) === JSON.stringify(expected) &&
				JSON.stringify(files(cache)) === JSON.stringify(expected)
			)
				return candidate;
		} catch {
			// Only a complete, independently verified snapshot can authorize retry.
		}
	}
}

// Run from a trusted extracted release, not from the mutable installed cache.
// Native Codex remove does not preserve edits. We block edits and independently
// snapshot even a clean cache before delegating to the unmodified native CLI.
export function safeCodexRemove({
	codexHome,
	baseline,
	marketplace,
	backup,
	binary,
	execute = false,
	retryPartial = false
}) {
	if (typeof execute !== 'boolean') throw Error('EXECUTE_BOOLEAN_REQUIRED');
	for (const path of [codexHome, baseline, backup]) {
		if (!isAbsolute(path)) throw Error('ABSOLUTE_PATH_REQUIRED');
		noLinks(resolve(path));
	}
	if (!/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/.test(marketplace)) throw Error('MARKETPLACE_REQUIRED');
	const meta = json(join(baseline, '.codex-plugin/plugin.json'));
	if (
		meta.name !== 'asam-ui-development' ||
		!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(meta.version)
	)
		throw Error('BASELINE_IDENTITY');
	const expected = files(baseline);
	const owner = json(join(baseline, 'ownership.json'));
	if (
		owner.owner !== meta.name ||
		owner.host !== 'codex' ||
		owner.schemaVersion !== 1 ||
		JSON.stringify(expected.filter((f) => f.path !== 'ownership.json')) !==
			JSON.stringify(owner.files)
	)
		throw Error('BASELINE_INTEGRITY');
	const pluginRoot = join(codexHome, 'plugins/cache', marketplace, meta.name);
	const installed = join(pluginRoot, meta.version);
	noLinks(installed);
	if (!outside(codexHome, backup) || !outside(baseline, backup) || !outside(backup, baseline))
		throw Error('INDEPENDENT_BACKUP_REQUIRED');
	if (existsSync(backup)) throw Error('BACKUP_EXISTS');
	const present = existsSync(installed);
	if (!present && !retryPartial) throw Error('CACHE_NOT_FOUND');
	const versions = existsSync(pluginRoot) ? readdirSync(pluginRoot) : [];
	if (versions.some((version) => version !== meta.version) || versions.length > 1)
		throw Error('MULTIPLE_CACHE_VERSIONS_REVIEW_REQUIRED');
	const actual = present ? files(installed) : [];
	const before = new Map(expected.map((f) => [f.path, f.sha256]));
	const after = new Map(actual.map((f) => [f.path, f.sha256]));
	const changed = [...new Set([...before.keys(), ...after.keys()])]
		.sort()
		.filter((path) => before.get(path) !== after.get(path))
		.map((path) => ({
			path,
			kind: !before.has(path) ? 'added' : !after.has(path) ? 'missing' : 'modified',
			baselineSHA256: before.get(path) ?? null,
			installedSHA256: after.get(path) ?? null
		}));
	const pluginId = `${meta.name}@${marketplace}`;
	const ownership = hash(readFileSync(join(baseline, 'ownership.json')));
	const retryOf =
		process.platform === 'win32' &&
		retryPartial &&
		execute &&
		changed.length > 0 &&
		changed.every((change) => change.kind === 'missing')
			? verifiedRetryBackup(dirname(backup), { installed, pluginId, ownership, expected })
			: undefined;
	if (!present && !retryOf) throw Error('CACHE_NOT_FOUND');
	mkdirSync(backup, { recursive: true });
	if (!retryOf) {
		mkdirSync(join(backup, 'cache'));
		for (const file of actual) {
			const target = join(backup, 'cache', file.path);
			mkdirSync(dirname(target), { recursive: true });
			writeFileSync(target, readFileSync(join(installed, file.path)));
		}
		if (JSON.stringify(files(join(backup, 'cache'))) !== JSON.stringify(actual))
			throw Error('SNAPSHOT_CHANGED_RETRY_WITH_NEW_BACKUP');
	}
	const current = () => (existsSync(installed) ? files(installed) : []);
	if (JSON.stringify(current()) !== JSON.stringify(actual))
		throw Error('SNAPSHOT_CHANGED_RETRY_WITH_NEW_BACKUP');
	const receipt = {
		status: changed.length && !retryOf ? 'blocked-modified' : 'preserved-ready',
		pluginId,
		installed,
		backup,
		baselineOwnershipSHA256: ownership,
		preservedPaths: (retryOf ? expected : actual).map((f) => f.path),
		changes: changed,
		snapshot: retryOf ? expected : actual,
		...(retryOf ? { retryOf } : {}),
		nativeInvoked: false,
		nextStep:
			changed.length && !retryOf
				? 'Keep the installed cache and this full backup. Review each changes path, merge wanted edits into maintained source, and only after resolving them run again with a new backup. Do not run native plugin remove or delete files to bypass this check.'
				: 'Full cache backup verified. Execute through this guard with a new backup to remove; keep this backup for recovery.'
	};
	const save = () =>
		writeFileSync(join(backup, 'receipt.json'), JSON.stringify(receipt, null, '\t') + '\n');
	save();
	if ((changed.length && !retryOf) || !execute) return receipt;
	if (!isAbsolute(binary) || !existsSync(binary)) throw Error('EXPLICIT_CODEX_BINARY_REQUIRED');
	// Final check narrows a concurrent-edit race; the full independent snapshot
	// remains available even if the native command fails or changes its behavior.
	if (JSON.stringify(current()) !== JSON.stringify(actual))
		throw Error('CACHE_CHANGED_REMOVE_ABORTED');
	const result = spawnSync(binary, ['plugin', 'remove', receipt.pluginId, '--json'], {
		cwd: codexHome,
		env: { ...process.env, CODEX_HOME: codexHome },
		encoding: 'utf8',
		windowsHide: true,
		timeout: 30000
	});
	receipt.nativeInvoked = true;
	receipt.native = {
		status: result.status,
		stdout: result.stdout,
		stderr: result.stderr,
		error: result.error?.message
	};
	receipt.status =
		result.status === 0 && !existsSync(installed)
			? 'removed-preserved'
			: 'native-failed-preserved';
	receipt.nextStep =
		'Retain backup/cache and receipt. Restore edits manually into maintained source; do not restore or overwrite Codex registries from this snapshot.';
	save();
	return receipt;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		const result = safeCodexRemove(json(process.argv[2]));
		console.log(JSON.stringify(result));
		if (!['removed-preserved', 'preserved-ready'].includes(result.status)) process.exitCode = 2;
	} catch (error) {
		console.error(
			JSON.stringify({ status: 'fail', code: error.message, nativeRemovalNotAssumed: true })
		);
		process.exitCode = 1;
	}
}
