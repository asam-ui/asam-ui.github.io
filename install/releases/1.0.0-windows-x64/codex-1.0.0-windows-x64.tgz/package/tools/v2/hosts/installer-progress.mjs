import { writeFileSync, renameSync, existsSync, unlinkSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { channel } from 'node:diagnostics_channel';
import { assertNoLinks } from './files.mjs';

export const installerProgressEvents = channel('asam-ui.installer.progress');
const settledPhases = new Set(['complete', 'failed', 'reused', 'tool-ready']);
const maxPendingOutputBytes = 64 * 1024;

export function formatInstallerElapsed(milliseconds) {
	return milliseconds < 1000
		? `${Math.floor(milliseconds)}ms`
		: `${(Math.floor((milliseconds + 50) / 100) / 10).toFixed(1)}s`;
}

// File receipts and redirected terminals receive the same real stage/byte data.
// A spinner indicates waiting, never fabricated completion percentages.
export function installerProgress({
	report = {},
	file,
	stream = process.stderr,
	intervalMs = 3000
}) {
	const relay = file && installerProgressEvents.hasSubscribers;
	let started, timer;
	let closed = false,
		tick = 0,
		row = false;
	const openOutputLines = new Set();
	const pendingOutput = new Map();
	const deferredLines = [];
	const elapsedAt = (at) => Math.max(0, at - started);
	const clearRow = () => {
		if (row) stream.write('\r\x1b[2K');
		row = false;
	};
	const writeStatus = (line) => {
		if (openOutputLines.size) deferredLines.push(line);
		else {
			clearRow();
			stream.write(line + '\n');
		}
	};
	const flushStatus = () => {
		for (const line of deferredLines.splice(0)) stream.write(line + '\n');
	};
	const persist = () => {
		if (!file) return;
		assertNoLinks(file);
		const incoming = `${file}.progress-${randomUUID()}`;
		writeFileSync(incoming, JSON.stringify(report, null, '\t') + '\n', {
			flag: 'wx',
			mode: 0o600
		});
		try {
			renameSync(incoming, file);
		} finally {
			if (existsSync(incoming)) unlinkSync(incoming);
		}
	};
	const render = (at, { heartbeat = false, final = false } = {}) => {
		const event = report.progress;
		if (!event) return;
		const active = !settledPhases.has(event.phase);
		const elapsed = active
			? `（${final ? '耗时' : '已用时'} ${formatInstallerElapsed(elapsedAt(at))}）`
			: '';
		let bytes = '';
		if (event.phase !== 'connecting' && Number.isFinite(event.receivedBytes)) {
			bytes = `（已下载 ${event.receivedBytes.toLocaleString('zh-CN')} 字节）`;
			if (event.totalBytes > 0)
				bytes = ` ${Math.min(100, Math.floor((event.receivedBytes * 100) / event.totalBytes))}%（${event.receivedBytes.toLocaleString('zh-CN')} / ${event.totalBytes.toLocaleString('zh-CN')} 字节）`;
		}
		const line = `${heartbeat ? ['|', '/', '-', '\\'][tick++ % 4] + ' ' : ''}${event.message}${bytes}${elapsed}`;
		if (openOutputLines.size) {
			// Repaint only after native output completes its logical line. Keep final
			// rows and their measured end times even if the phase changes meanwhile.
			if (final || !active) writeStatus(line);
			return;
		}
		clearRow();
		const activeRow = stream.isTTY && active && !final;
		stream.write(line + (activeRow ? '' : '\n'));
		row = Boolean(activeRow);
	};
	const refresh = () => {
		try {
			const now = Date.now();
			report.progress.elapsedSeconds = Math.floor(elapsedAt(now) / 1000);
			report.updatedAt = new Date(now).toISOString();
			persist();
			if (!relay) render(now, { heartbeat: true });
		} catch (error) {
			// Timer callbacks must never crash a running install or leak its lock.
			writeStatus(`进度日志更新失败，请保留现场：${error.code || error.message}`);
			clearInterval(timer);
		}
	};
	const finish = (at) => {
		clearInterval(timer);
		if (!report.progress || settledPhases.has(report.progress.phase)) return;
		report.progress.elapsedSeconds = Math.floor(elapsedAt(at) / 1000);
		if (!relay) render(at, { final: true });
	};
	const update = (event) => {
		if (closed) return;
		const now = Date.now();
		const time = new Date(now).toISOString();
		if (report.progress?.phase !== event.phase) {
			finish(event.startedAt ?? now);
			started = event.startedAt ?? now;
			if (!settledPhases.has(event.phase)) {
				timer = setInterval(refresh, intervalMs);
				timer.unref();
			}
			report.stages ||= [];
			report.stages.push({
				phase: event.phase,
				message: event.message,
				startedAt: new Date(started).toISOString()
			});
		}
		report.progress = {
			...event,
			updatedAt: time,
			elapsedSeconds: Math.floor(elapsedAt(now) / 1000)
		};
		report.updatedAt = time;
		persist();
		if (relay) installerProgressEvents.publish({ ...event, startedAt: started });
		else if (stream.isTTY || settledPhases.has(event.phase)) render(now);
	};
	const writeOutput = (output, chunk) => {
		if (!stream.isTTY || !output.isTTY || !chunk.length) {
			output.write(chunk);
			return;
		}
		const lastNewline = chunk.lastIndexOf(10);
		let pending = pendingOutput.get(output);
		if (lastNewline >= 0) {
			clearRow();
			if (pending) output.write(Buffer.concat(pending.chunks, pending.bytes));
			output.write(chunk.subarray(0, lastNewline + 1));
			openOutputLines.delete(output);
			pendingOutput.delete(output);
			pending = undefined;
		}
		const tail = chunk.subarray(lastNewline + 1);
		if (tail.length) {
			pending ??= { chunks: [], bytes: 0 };
			if (
				!openOutputLines.has(output) &&
				pending.bytes + tail.length <= maxPendingOutputBytes
			) {
				// Copy the suffix so a small tail cannot retain a much larger input chunk.
				pending.chunks.push(Buffer.from(tail));
				pending.bytes += tail.length;
				pendingOutput.set(output, pending);
			} else {
				// Oversized lines stream as received. Leave the cursor alone until LF.
				clearRow();
				if (pending.bytes) output.write(Buffer.concat(pending.chunks, pending.bytes));
				output.write(tail);
				pendingOutput.delete(output);
				openOutputLines.add(output);
			}
		}
		if (lastNewline >= 0 && !openOutputLines.size) {
			flushStatus();
			if (report.progress && !settledPhases.has(report.progress.phase)) render(Date.now());
		}
	};
	const endOutputLine = () => {
		if (openOutputLines.size) stream.write('\n');
		openOutputLines.clear();
		for (const [output, pending] of pendingOutput) {
			clearRow();
			output.write(Buffer.concat(pending.chunks, pending.bytes));
			output.write('\n');
		}
		pendingOutput.clear();
		flushStatus();
	};
	return {
		update,
		writeOutput,
		writeStatus,
		endOutputLine,
		clear(at = Date.now()) {
			finish(at);
			delete report.progress;
		},
		close() {
			if (closed) return;
			closed = true;
			const now = Date.now();
			endOutputLine();
			finish(now);
			if (relay && report.progress) installerProgressEvents.publish({ endedAt: now });
			persist();
		}
	};
}
