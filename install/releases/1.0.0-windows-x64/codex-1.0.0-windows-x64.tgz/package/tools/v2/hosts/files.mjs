import { mkdirSync, readFileSync, readdirSync, writeFileSync, lstatSync } from 'node:fs';
import { dirname, join, isAbsolute, resolve } from 'node:path';
import { createHash } from 'node:crypto';

export const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
export const json = (file) => JSON.parse(readFileSync(file, 'utf8'));
// Standalone installer file checks must not load a package's OCR configuration.
export function assertNoLinks(path) {
	if (!isAbsolute(path)) throw Error('ABSOLUTE_PATH_REQUIRED');
	for (let current = resolve(path); ; current = dirname(current)) {
		try {
			if (lstatSync(current).isSymbolicLink()) throw Error('SYMLINK_NOT_ALLOWED');
		} catch (error) {
			if (error.code !== 'ENOENT') throw error;
		}
		if (current === dirname(current)) break;
	}
}
export function write(file, data) {
	mkdirSync(dirname(file), { recursive: true });
	writeFileSync(
		file,
		typeof data === 'string' || Buffer.isBuffer(data)
			? data
			: JSON.stringify(data, null, '\t') + '\n'
	);
}
export function inventory(directory, prefix = '') {
	return readdirSync(join(directory, prefix), { withFileTypes: true })
		.flatMap((entry) => {
			const path = [prefix, entry.name].filter(Boolean).join('/');
			if (entry.isSymbolicLink()) throw new Error('SYMLINK_NOT_ALLOWED');
			return entry.isDirectory()
				? inventory(directory, path)
				: [{ path, sha256: sha(readFileSync(join(directory, path))) }];
		})
		.sort((a, b) => a.path.localeCompare(b.path));
}
