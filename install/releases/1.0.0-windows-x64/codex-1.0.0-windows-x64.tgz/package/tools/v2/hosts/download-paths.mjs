import {
	constants,
	copyFileSync,
	linkSync,
	lstatSync,
	mkdirSync,
	mkdtempSync,
	readFileSync,
	readdirSync,
	rmSync
} from 'node:fs';
import { join, win32, posix, extname, isAbsolute, basename, normalize, dirname } from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { spawnSync } from 'node:child_process';

// Known Folder resolution honors the current user's redirected Downloads.
// Never fall back to USERPROFILE/Downloads when the Windows lookup fails.
export const windowsDownloadsScript = [
	"$ErrorActionPreference = 'Stop'",
	'[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)',
	"if (-not ('ASAM.DownloadFolders' -as [type])) { $asamDeclaration = '[DllImport(' + [char]34 + 'shell32.dll' + [char]34 + ')] public static extern int SHGetKnownFolderPath(ref System.Guid id, uint flags, System.IntPtr token, out System.IntPtr path);'; Add-Type -MemberDefinition $asamDeclaration -Name DownloadFolders -Namespace ASAM }",
	"$asamFolderId = [Guid]'374DE290-123F-4565-9164-39C4925E467B'",
	'$asamFolderPath = [IntPtr]::Zero',
	'try { $asamFolderResult = [ASAM.DownloadFolders]::SHGetKnownFolderPath([ref]$asamFolderId, 0, [IntPtr]::Zero, [ref]$asamFolderPath); [Runtime.InteropServices.Marshal]::ThrowExceptionForHR($asamFolderResult); [Runtime.InteropServices.Marshal]::PtrToStringUni($asamFolderPath) } finally { if ($asamFolderPath -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::FreeCoTaskMem($asamFolderPath) } }'
].join('; ');

let resolvedWindowsDownloads;
function windowsDownloads() {
	if (resolvedWindowsDownloads) return resolvedWindowsDownloads;
	const result = spawnSync(
		'powershell.exe',
		['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', windowsDownloadsScript],
		{ encoding: 'utf8', windowsHide: true, timeout: 30000 }
	);
	if (result.status !== 0) throw Error('SYSTEM_DOWNLOADS_RESOLUTION_FAILED');
	resolvedWindowsDownloads = result.stdout.trim();
	return resolvedWindowsDownloads;
}

export function systemDownloads({
	platform = process.platform,
	home = homedir(),
	resolveWindows = windowsDownloads
} = {}) {
	if (!['win32', 'darwin'].includes(platform)) throw Error('DOWNLOADS_PLATFORM_UNSUPPORTED');
	const paths = platform === 'win32' ? win32 : posix;
	const directory = platform === 'win32' ? resolveWindows() : paths.join(home, 'Downloads');
	if (!paths.isAbsolute(directory) || directory.includes('${') || /[\r\n\0]/.test(directory))
		throw Error('SYSTEM_DOWNLOADS_RESOLUTION_FAILED');
	return directory;
}

export function installerDownloads(root = normalize(systemDownloads())) {
	const name = basename(root);
	const alreadyScoped =
		process.platform === 'win32' ? name.toUpperCase() === 'ASAM-UI' : name === 'ASAM-UI';
	const directory = alreadyScoped ? root : join(root, 'ASAM-UI');
	if (!alreadyScoped) {
		try {
			mkdirSync(directory, { recursive: true, mode: 0o700 });
			if (!lstatSync(directory).isDirectory())
				throw Error('ASAM_DOWNLOAD_DIRECTORY_CONFLICT');
		} catch (cause) {
			throw Error(
				`无法使用安装器下载目录：${directory}。请检查同名文件、目录链接和写入权限。`,
				{ cause }
			);
		}
	}
	return directory;
}

export function createDownloadStage(kind, { downloads = installerDownloads() } = {}) {
	assertDownloadRoot(downloads);
	if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/.test(kind)) throw Error('DOWNLOAD_CATEGORY_INVALID');
	mkdirSync(downloads, { recursive: true, mode: 0o700 });
	// Incoming and transaction files stay private until verification succeeds.
	return mkdtempSync(join(downloads, `.asam-${kind}-`));
}

export function createInstallerLogStage(downloads = installerDownloads()) {
	if (process.platform !== 'win32') return createDownloadStage('installer', { downloads });
	const logs = join(downloads, 'logs');
	try {
		mkdirSync(logs, { recursive: true, mode: 0o700 });
		if (!lstatSync(logs).isDirectory()) throw Error('ASAM_DOWNLOAD_DIRECTORY_CONFLICT');
		return createDownloadStage('installer', { downloads: logs });
	} catch (cause) {
		throw Error(`无法使用安装日志目录：${logs}。请检查同名文件、目录链接和写入权限。`, {
			cause
		});
	}
}

const downloadDirectoryScan = [
	"const fs = require('node:fs');",
	'try {',
	'  process.stdout.write(JSON.stringify({ entries: fs.readdirSync(process.argv[1]) }));',
	'} catch (error) {',
	"  process.stdout.write(JSON.stringify({ code: error.code || 'UNKNOWN' }));",
	'  process.exitCode = 2;',
	'}'
].join('\n');

function downloadDirectoryEntries(directory) {
	if (process.platform !== 'darwin') return readdirSync(directory);
	// A blocked macOS directory read must not leave the installer waiting forever.
	// The child only enumerates names. Verification and publication stay in this process.
	const result = spawnSync(process.execPath, ['-e', downloadDirectoryScan, directory], {
		encoding: 'utf8',
		timeout: 10000,
		killSignal: 'SIGKILL',
		maxBuffer: 2 * 1024 * 1024,
		windowsHide: true
	});
	if (result.error?.code === 'ETIMEDOUT')
		throw Error('DOWNLOAD_CACHE_SCAN_TIMEOUT: 读取安装缓存目录超时，原文件已保留，请反馈安装日志。');
	if (result.error) throw result.error;
	let response;
	try {
		response = JSON.parse(result.stdout);
	} catch (cause) {
		throw Error('DOWNLOAD_CACHE_SCAN_FAILED', { cause });
	}
	if (result.status !== 0)
		throw Error(`DOWNLOAD_CACHE_SCAN_FAILED: ${response.code || 'UNKNOWN'}`);
	if (!Array.isArray(response.entries) || response.entries.some((name) => typeof name !== 'string'))
		throw Error('DOWNLOAD_CACHE_SCAN_FAILED');
	return response.entries;
}

export function downloadFilePath(name, { downloads, sha256, bytes, reuseByContent = false } = {}) {
	const systemRoot = downloads === undefined ? normalize(systemDownloads()) : undefined;
	if (systemRoot !== undefined) downloads = installerDownloads(systemRoot);
	assertDownloadRoot(downloads);
	if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,180}$/.test(name)) throw Error('DOWNLOAD_FILENAME_INVALID');
	mkdirSync(downloads, { recursive: true, mode: 0o700 });
	const extension = extname(name),
		stem = name.slice(0, name.length - extension.length);
	if (sha256 !== undefined || bytes !== undefined) {
		if (!/^[a-f0-9]{64}$/.test(sha256 || '') || !Number.isSafeInteger(bytes) || bytes < 1)
			throw Error('DOWNLOAD_PIN_INVALID');
		const hashTail = sha256.slice(-16);
		const pinnedStem = `${stem}-${hashTail}`;
		const pinned = join(downloads, pinnedStem + extension);
		if (matchesDownload(pinned, sha256, bytes)) return pinned;
		const suffix = new RegExp(`-${hashTail}(?:-[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12})?$`);
		const previous = downloadDirectoryEntries(downloads)
			.filter((entry) => {
				if (entry === pinnedStem + extension) return false;
				if (reuseByContent) return true;
				if (extname(entry) !== extension) return false;
				const candidate = basename(entry, extension);
				return candidate.startsWith(pinnedStem + '-') && suffix.test(candidate);
			})
			.map((entry) => join(downloads, entry));
		const verified = [pinned, ...previous].find((candidate) =>
			matchesDownload(candidate, sha256, bytes)
		);
		if (verified) return verified;
		if (!downloadOccupied(pinned)) {
			if (systemRoot && systemRoot === dirname(downloads))
				reuseLegacyDownload(join(systemRoot, basename(pinned)), pinned, { sha256, bytes });
			if (!downloadOccupied(pinned) || matchesDownload(pinned, sha256, bytes)) return pinned;
		}
	}
	for (let attempt = 0; attempt < 4; attempt++) {
		const file = join(
			downloads,
			`${stem}-${sha256 ? `${sha256.slice(-16)}-` : ''}${randomUUID()}${extension}`
		);
		if (!downloadOccupied(file)) return file;
	}
	throw Error('DOWNLOAD_FILENAME_COLLISION');
}

function reuseLegacyDownload(legacy, destination, { sha256, bytes }) {
	if (!matchesDownload(legacy, sha256, bytes)) return;
	const stage = createDownloadStage('reuse', { downloads: dirname(destination) });
	const incoming = join(stage, 'verified.download');
	try {
		copyFileSync(legacy, incoming, constants.COPYFILE_EXCL);
		if (matchesDownload(incoming, sha256, bytes))
			publishVerifiedDownload(incoming, destination, { sha256, bytes });
	} catch (error) {
		if (!['ENOENT', 'EEXIST', 'EACCES', 'EPERM'].includes(error.code)) throw error;
	} finally {
		rmSync(stage, { recursive: true, force: true });
	}
}

export function retainVerifiedDownload(name, staged, { downloads, sha256, bytes }) {
	for (let attempt = 0; attempt < 4; attempt++) {
		const path = downloadFilePath(name, { downloads, sha256, bytes });
		try {
			publishVerifiedDownload(staged, path, { sha256, bytes });
			return path;
		} catch (error) {
			if (error.code !== 'EEXIST') throw error;
		}
	}
	throw Error('DOWNLOAD_FILENAME_COLLISION');
}

function publishExclusive(staged, destination) {
	try {
		linkSync(staged, destination);
	} catch (error) {
		const unsupported = ['ENOTSUP', 'EOPNOTSUPP', 'ENOSYS', 'EPERM', 'EXDEV', 'EMLINK'];
		// Windows also maps ERROR_INVALID_FUNCTION from a volume to EISDIR.
		if (
			!unsupported.includes(error.code) &&
			!(process.platform === 'win32' && error.code === 'EISDIR')
		)
			throw error;
		copyFileSync(staged, destination, constants.COPYFILE_EXCL);
	}
}

// Only verified files reach this boundary. Both publication paths preserve any
// entry that another run has already created.
export function publishVerifiedDownload(staged, destination, { sha256, bytes }) {
	try {
		publishExclusive(staged, destination);
	} catch (error) {
		if (error.code !== 'EEXIST' || !matchesDownload(destination, sha256, bytes)) throw error;
	}
}

function matchesDownload(path, sha256, bytes) {
	try {
		const stat = lstatSync(path);
		return (
			stat.isFile() &&
			stat.size === bytes &&
			createHash('sha256').update(readFileSync(path)).digest('hex') === sha256
		);
	} catch (error) {
		if (!['ENOENT', 'EACCES', 'EPERM'].includes(error.code)) throw error;
		return false;
	}
}

function downloadOccupied(path) {
	try {
		lstatSync(path);
		return true;
	} catch (error) {
		if (error.code === 'ENOENT') return false;
		if (['EACCES', 'EPERM'].includes(error.code)) return true;
		throw error;
	}
}

function assertDownloadRoot(directory) {
	if (
		typeof directory !== 'string' ||
		!isAbsolute(directory) ||
		directory.includes('${') ||
		/[\r\n\0]/.test(directory)
	)
		throw Error('SYSTEM_DOWNLOADS_RESOLUTION_FAILED');
}
