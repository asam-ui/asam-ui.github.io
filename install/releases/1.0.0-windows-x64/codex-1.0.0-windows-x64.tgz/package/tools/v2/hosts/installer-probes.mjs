import { execFile, spawn, spawnSync } from 'node:child_process';
import { nativeLog } from './installer-log.mjs';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { json, write } from './files.mjs';

// The supervisor joins an unnamed, non-inheritable Windows job before starting
// the probe. Windows retains the entire tree even after the original child exits.
// Killing the supervisor closes its only job handle, so cleanup never looks up a PID.
const windowsOcrJob = String.raw`
$ErrorActionPreference = 'Stop'
$job = [IntPtr]::Zero
$joined = $false
try {
    # Define the imports in memory. Starting a compiler before joining the job
    # would itself create an unmanaged child during cancellation.
    $assembly = [AppDomain]::CurrentDomain.DefineDynamicAssembly(
        [Reflection.AssemblyName]::new('AsamOcrJob'), 'Run')
    $type = $assembly.DefineDynamicModule('Native').DefineType('AsamOcrJob.Native', 'Public')
    function Add-Native([string]$name, [type]$result, [type[]]$parameters) {
        $method = $type.DefinePInvokeMethod($name, 'kernel32.dll',
            'Public,Static,PinvokeImpl', 'Standard', $result, $parameters, 'Winapi', 'Unicode')
        $method.SetImplementationFlags($method.GetMethodImplementationFlags() -bor
            [Reflection.MethodImplAttributes]::PreserveSig)
    }
    Add-Native 'CreateJobObjectW' ([IntPtr]) @([IntPtr], [IntPtr])
    Add-Native 'SetInformationJobObject' ([bool]) @([IntPtr], [int], [IntPtr], [uint32])
    Add-Native 'AssignProcessToJobObject' ([bool]) @([IntPtr], [IntPtr])
    Add-Native 'QueryInformationJobObject' ([bool]) @([IntPtr], [int], [IntPtr], [uint32], [IntPtr])
    Add-Native 'CloseHandle' ([bool]) @([IntPtr])
    $native = $type.CreateType()
    $job = $native::CreateJobObjectW([IntPtr]::Zero, [IntPtr]::Zero)
    if ($job -eq [IntPtr]::Zero) { throw 'OCR_JOB_CREATE_FAILED' }

    # JOBOBJECT_EXTENDED_LIMIT_INFORMATION: LimitFlags is a DWORD at offset 16.
    $size = if ([IntPtr]::Size -eq 8) { 144 } else { 112 }
    $limits = [byte[]]::new($size)
    [BitConverter]::GetBytes([uint32]0x2000).CopyTo($limits, 16) # KILL_ON_JOB_CLOSE
    $buffer = [Runtime.InteropServices.Marshal]::AllocHGlobal($size)
    try {
        [Runtime.InteropServices.Marshal]::Copy($limits, 0, $buffer, $size)
        if (-not $native::SetInformationJobObject($job, 9, $buffer, $size)) {
            throw 'OCR_JOB_LIMIT_FAILED'
        }
        $self = [Diagnostics.Process]::GetCurrentProcess()
        $joined = $native::AssignProcessToJobObject($job, $self.Handle)
        $self.Dispose()
        if (-not $joined) { throw 'OCR_JOB_ASSIGN_FAILED' }

        $start = [Diagnostics.ProcessStartInfo]::new(
            $env:ASAM_OCR_JOB_COMMAND, $env:ASAM_OCR_JOB_ARGUMENTS)
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.RedirectStandardInput = $true
        $process = [Diagnostics.Process]::Start($start)
        try {
            $process.StandardInput.Close()
            $process.WaitForExit()
            $exitCode = $process.ExitCode
        } finally { $process.Dispose() }
        do {
            # JOBOBJECT_BASIC_ACCOUNTING_INFORMATION: ActiveProcesses at offset 40.
            if (-not $native::QueryInformationJobObject($job, 1, $buffer, 48, [IntPtr]::Zero)) {
                throw 'OCR_JOB_QUERY_FAILED'
            }
            $active = [Runtime.InteropServices.Marshal]::ReadInt32($buffer, 40)
            if ($active -gt 1) { [Threading.Thread]::Sleep(25) }
        } while ($active -gt 1)
    } finally { [Runtime.InteropServices.Marshal]::FreeHGlobal($buffer) }
    exit $exitCode
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
} finally {
    # Once joined, only process exit may close this handle, including on cancellation.
    if (-not $joined -and $job -ne [IntPtr]::Zero) { $null = $native::CloseHandle($job) }
}
`;

function quoteWindowsArgument(value) {
	return '"' + value.replace(/(\\*)"/g, '$1$1\\"').replace(/\\+$/, '$&$&') + '"';
}

function stopProbe(child) {
	if (!child.pid || child.exitCode !== null || child.signalCode !== null) return;
	if (process.platform === 'win32') {
		// A probe can start Git. Limit cleanup to this invocation's PID and descendants.
		const taskkill = join(process.env.SystemRoot || 'C:/Windows', 'System32/taskkill.exe');
		const stopped = spawnSync(taskkill, ['/PID', String(child.pid), '/T', '/F'], {
			windowsHide: true,
			timeout: 3000
		});
		if (stopped.status === 0) return;
	}
	child.kill();
}

export function expectedExpertMcpTools(source, { validation = true } = {}) {
	const names = [
		'list_components',
		'get_component_api',
		'get_component_example',
		'get_guide',
		'agent_discover',
		'agent_read',
		'agent_inspect',
		'agent_diagnose',
		'agent_migration'
	];
	// Published bundles declare the packages verified against npm in the
	// snapshot manifest. Historical bundles store Pro candidate metadata separately.
	const manifest = source && json(join(source, 'bundle/manifest.json'));
	if (manifest?.packages?.['@asam-ui/pro']) names.push('get_pro_api');
	if (manifest?.discoverySHA256) names.push('discover_docs','get_docs','get_type_dictionary');
	if (validation) names.push('agent_validation_plan');
	return names;
}

// A protocol probe of the installed service, not host trust or selected-model
// execution. Uses bundled runtime and Node only; no package install is needed.
export async function probeMcp(
	server,
	{ source, cwd = homedir(), timeoutMs = 15000, signal } = {}
) {
	signal?.throwIfAborted();
	const expected = expectedExpertMcpTools(source);
	const finishLog = nativeLog(server.command, server.args);
	const child = spawn(server.command, server.args, {
		cwd,
		env: { ...process.env, ...server.env },
		windowsHide: true,
		stdio: ['pipe', 'pipe', 'pipe']
	});
	let captured = '';
	const closed = new Promise((resolve) => child.once('close', resolve));
	const pending = new Map();
	let sequence = 0,
		buffer = '',
		stderr = '',
		outputBytes = 0;
	const fail = (error) => {
		for (const item of pending.values()) {
			clearTimeout(item.timer);
			item.reject(error);
		}
		pending.clear();
	};
	let nativeError;
	child.on('error', (error) => {
		nativeError = error;
		fail(error);
	});
	child.on('exit', () => fail(Error('MCP_PROCESS_EXITED')));
	child.stdin.on('error', fail);
	child.stderr.on('data', (bytes) => {
		stderr = (stderr + bytes).slice(-32768);
	});
	child.stdout.on('data', (bytes) => {
		outputBytes += bytes.length;
		if (outputBytes <= 1024 * 1024) captured += bytes;
		if (outputBytes > 1024 * 1024) {
			fail(Error('MCP_OUTPUT_LIMIT'));
			child.kill();
			return;
		}
		buffer += bytes;
		for (let end; (end = buffer.indexOf('\n')) >= 0;) {
			const line = buffer.slice(0, end);
			buffer = buffer.slice(end + 1);
			if (!line.trim()) continue;
			try {
				const message = JSON.parse(line),
					item = pending.get(message.id);
				if (!item) continue;
				pending.delete(message.id);
				clearTimeout(item.timer);
				if (message.error) item.reject(Error(`MCP_RPC_${message.error.code}`));
				else item.resolve(message.result);
			} catch {
				fail(Error('MCP_INVALID_JSON'));
			}
		}
	});
	const request = (method, params) =>
		new Promise((resolveResult, reject) => {
			signal?.throwIfAborted();
			const id = ++sequence;
			const timer = setTimeout(() => {
				pending.delete(id);
				reject(Error('MCP_PROBE_TIMEOUT'));
			}, timeoutMs);
			pending.set(id, { resolve: resolveResult, reject, timer });
			child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
		});
	const abort = () => fail(signal.reason);
	signal?.addEventListener('abort', abort, { once: true });
	try {
		await request('initialize', {
			protocolVersion: '2024-11-05',
			capabilities: {},
			clientInfo: { name: 'asam-ui-installer', version: '1' }
		});
		signal?.throwIfAborted();
		child.stdin.write(
			JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n'
		);
		const listed = await request('tools/list', {});
		const names = listed.tools?.map((tool) => tool.name) || [];
		if (names.length !== expected.length || expected.some((name) => !names.includes(name)))
			throw Error('MCP_TOOL_SET_MISMATCH');
		for (const [name, args] of [
			['agent_discover', { query: '按钮', limit: 1 }],
			['agent_read', { id: 'ui.button', section: 'recipe' }]
		]) {
			const result = await request('tools/call', { name, arguments: args });
			if (result.isError || JSON.parse(result.content?.[0]?.text || '{}').status !== 'pass')
				throw Error('MCP_TOOL_CALL_FAILED');
		}
		signal?.throwIfAborted();
		return { status: 'pass', tools: names, discover: 'pass', read: 'pass', stderr };
	} finally {
		signal?.removeEventListener('abort', abort);
		fail(Error('MCP_PROBE_CLOSED'));
		child.stdin.end();
		if (signal?.aborted) stopProbe(child);
		else if (child.exitCode === null) child.kill();
		let timer;
		try {
			await Promise.race([
				closed,
				new Promise((resolve) => {
					timer = setTimeout(resolve, 3000);
				})
			]);
		} finally {
			clearTimeout(timer);
			finishLog({
				status: child.exitCode,
				signal: child.signalCode,
				stdout: captured,
				stderr,
				error: signal?.aborted ? signal.reason : nativeError,
				stopRequested: true
			});
		}
	}
}

function runOcrCommand(command, args, cwd, signal) {
	signal?.throwIfAborted();
	const finishLog = nativeLog(command, args);
	const supervised = process.platform === 'win32';
	const executable = supervised
		? join(
				process.env.SystemRoot || 'C:/Windows',
				'System32/WindowsPowerShell/v1.0/powershell.exe'
			)
		: command;
	const argv = supervised
		? [
				'-NoProfile',
				'-NonInteractive',
				'-EncodedCommand',
				Buffer.from(windowsOcrJob, 'utf16le').toString('base64')
			]
		: args;
	const env = { ...process.env, OCR_NO_UPDATE: '1' };
	if (supervised) {
		env.ASAM_OCR_JOB_COMMAND = command;
		env.ASAM_OCR_JOB_ARGUMENTS = args.map(quoteWindowsArgument).join(' ');
	}
	return new Promise((resolve) => {
		let stopReason;
		const stop = (reason) => {
			if (stopReason || child.exitCode !== null || child.signalCode !== null) return;
			stopReason = reason;
			child.kill();
		};
		const abort = () => stop(signal.reason);
		const child = execFile(
			executable,
			argv,
			{
				cwd,
				encoding: 'utf8',
				maxBuffer: 1024 * 1024,
				windowsHide: true,
				env
			},
			(error, stdout, stderr) => {
				clearTimeout(timeout);
				signal?.removeEventListener('abort', abort);
				const result = {
					status: child.exitCode,
					signal: child.signalCode,
					stdout,
					stderr,
					error: stopReason ?? (child.exitCode === null ? error : undefined),
					stopRequested: Boolean(stopReason)
				};
				finishLog(result);
				resolve(result);
			}
		);
		const timeout = setTimeout(
			() =>
				stop(Object.assign(Error('OCR_NATIVE_TIMEOUT: ETIMEDOUT'), { code: 'ETIMEDOUT' })),
			30000
		);
		child.stdin?.end();
		signal?.addEventListener('abort', abort, { once: true });
	});
}

export async function ocrProbe(binary, output, onProgress, { signal } = {}) {
	signal?.throwIfAborted();
	const project = join(output, 'ocr-project');
	mkdirSync(project, { recursive: true });
	write(join(project, 'probe.mjs'), 'export const value = 1;\n');
	const git = await runOcrCommand(
		'git',
		['-c', 'init.templateDir=', 'init', '-q'],
		project,
		signal
	);
	signal?.throwIfAborted();
	if (git.error || git.status !== 0)
		return {
			status: 'partial',
			code: 'OCR_PROBE_REQUIRES_GIT',
			action: '安装或启用 Git 后重新双击同一入口'
		};
	for (const [name, args] of [
		['preview', ['delegate', 'preview', '--format', 'json', '--repo', project]],
		['rules', ['delegate', 'rule', '--format', 'json', '--repo', project, 'probe.mjs']]
	]) {
		signal?.throwIfAborted();
		onProgress?.({
			phase: `ocr-probe-${name}`,
			message: name === 'preview' ? '正在执行 OCR 选文件自检…' : '正在执行 OCR 规则解析自检…'
		});
		const result = await runOcrCommand(binary, args, project, signal);
		write(join(output, `ocr-${name}.json`), result.stdout || '{}');
		signal?.throwIfAborted();
		if (result.error || result.status !== 0)
			return {
				status: 'partial',
				code: 'OCR_RULE_PROBE_FAILED',
				action: '核对安装日志和 Git，重试同一入口'
			};
		const value = JSON.parse(result.stdout);
		if (
			name === 'preview' &&
			!value.reviewable_files?.some((item) => item.path === 'probe.mjs')
		)
			throw Error('OCR_PREVIEW_INCOMPLETE');
		if (name === 'rules' && !value.groups?.some((group) => group.files.includes('probe.mjs')))
			throw Error('OCR_RULES_INCOMPLETE');
	}
	return {
		status: 'pass',
		preview: 'pass',
		rules: 'pass',
		semanticReview: 'requires-selected-model'
	};
}
