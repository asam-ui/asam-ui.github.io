import { AsyncLocalStorage } from 'node:async_hooks';
import { channel } from 'node:diagnostics_channel';
import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { appendFileSync, writeFileSync, lstatSync } from 'node:fs';
import { basename, join } from 'node:path';
import { homedir } from 'node:os';
import { captureSync } from './process-capture.mjs';

// Signed host adapters may be loaded from a package. A named channel keeps their
// observations in the calling install without replacing any process built-ins.
const native = channel('asam-ui.installer.native');
const active = new AsyncLocalStorage();

export function nativeLog(command, args) {
	if (!native.hasSubscribers) return () => {};
	const startedAt = new Date().toISOString();
	const started = Date.now();
	let finished = false;
	return (result) => {
		if (finished) return;
		finished = true;
		native.publish({
			phase: 'native',
			command,
			args,
			startedAt,
			finishedAt: new Date().toISOString(),
			durationMs: Date.now() - started,
			exitCode: result.status ?? null,
			signal: result.signal ?? null,
			stopRequested: result.stopRequested || undefined,
			stdout: result.stdout?.toString() || '',
			stderr: result.stderr?.toString() || '',
			error: result.error?.stack || null
		});
	};
}

function loggedCall(invoke, command, args, options) {
	const finish = nativeLog(command, args);
	try {
		const result = invoke(command, args, options);
		finish(result);
		return result;
	} catch (error) {
		finish({ error });
		throw error;
	}
}

export const loggedSpawnSync = (command, args, options) =>
	loggedCall(spawnSync, command, args, options);
export const loggedCaptureSync = (command, args, options) =>
	loggedCall(captureSync, command, args, options);

export function installationLog(directory) {
	const runId = randomUUID();
	const bootstrapRunId = /^[a-f0-9]{32}$/.test(process.env.ASAM_INSTALL_BOOTSTRAP_RUN_ID || '')
		? process.env.ASAM_INSTALL_BOOTSTRAP_RUN_ID
		: undefined;
	const started = Date.now();
	const file = join(directory, 'EXECUTION.jsonl');
	const aliases = new Map([[homedir(), '<home>']]);
	let sequence = 0;
	let warning;
	const text = (value) => {
		let result = String(value);
		for (const [value, label] of [...aliases].sort((a, b) => b[0].length - a[0].length))
			result = result.split(value).join(label).split(value.replaceAll('\\', '/')).join(label);
		return result
			.replace(
				/-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?-----END [^-]*PRIVATE KEY-----/g,
				'<redacted>'
			)
			.replace(/\b(?:Bearer|Basic)\s+[A-Za-z0-9+/_.=:-]+/gi, '<redacted>')
			.replace(
				/(\b(?:set[-_]?cookie|cookie)["']?\s*[:=]\s*)(?:"(?:\\.|[^"\\])*"|'[^']*'|[^\r\n]*)/gi,
				'$1<redacted>'
			)
			.replace(
				/(["']?(?:[\w.-]*(?:token|password|passwd|secret|authorization|api[_-]?key|auth[_-]?key|_auth)[\w.-]*)["']?\s*[:=]\s*)(?:"(?:\\.|[^"\\])*"|'[^']*'|[^\s,;}]+)/gi,
				'$1"<redacted>"'
			)
			.replace(/https?:\/\/[^\s"'<>]+/g, (url) => {
				try {
					const parsed = new URL(url);
					return `${parsed.origin}${parsed.pathname}${parsed.search ? '?<redacted>' : ''}`;
				} catch {
					return '<url>';
				}
			})
			.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '<email>');
	};
	const clean = (value, key = '') => {
		if (
			/token|password|passwd|secret|authorization|cookie|api[_-]?key|^env$|^config(?:uration)?$|credentials/i.test(
				key
			)
		)
			return '<redacted>';
		if (typeof value === 'string') {
			if (value === runId) return value;
			// Native structured responses get recursive key filtering as well as text filtering.
			try {
				return JSON.stringify(clean(JSON.parse(value)));
			} catch {
				return text(value);
			}
		}
		if (Array.isArray(value)) return value.map((item) => clean(item));
		if (value && typeof value === 'object')
			return Object.fromEntries(
				Object.entries(value).map(([name, item]) => [name, clean(item, name)])
			);
		return value;
	};
	const record = (event) => {
		try {
			appendFileSync(
				file,
				JSON.stringify({
					runId,
					sequence: ++sequence,
					at: new Date().toISOString(),
					...clean(event)
				}) + '\n',
				{ mode: 0o600 }
			);
		} catch (error) {
			warning ||= error.code || 'INSTALL_LOG_WRITE_FAILED';
		}
	};
	const listen = (event) => {
		if (active.getStore() !== runId) return;
		// Do not copy command scripts or unrelated config listings into diagnostics.
		const args = event.args.map((arg, index) =>
			index && ['-e', '-Command'].includes(event.args[index - 1]) ? '<script>' : arg
		);
		let stdout =
			event.args.includes('config') && event.args.includes('list')
				? '<configuration listing omitted>'
				: event.stdout;
		if (event.args.includes('plugin') && event.args.includes('list')) {
			try {
				const listed = JSON.parse(event.stdout);
				stdout = JSON.stringify({
					marketplaces: listed.marketplaces?.filter(
						(item) => item.name === 'asam-ui-local'
					),
					installed: listed.installed?.filter(
						(item) => item.pluginId === 'asam-ui-development@asam-ui-local'
					)
				});
			} catch {
				stdout =
					'<unrelated plugin listing omitted>\n' +
					event.stdout
						.split(/\r?\n/)
						.filter((line) => /@asam-ui\/dsh-development/.test(line))
						.join('\n');
			}
		}
		record({
			...event,
			command: basename(event.command),
			args,
			stdout,
			stdoutBytes: Buffer.byteLength(event.stdout),
			stderrBytes: Buffer.byteLength(event.stderr)
		});
	};
	return {
		runId,
		file,
		clean,
		record,
		alias(value, label) {
			if (value && typeof value === 'string') aliases.set(value, `<${label}>`);
		},
		async run(callback) {
			native.subscribe(listen);
			try {
				return await active.run(runId, callback);
			} finally {
				native.unsubscribe(listen);
			}
		},
		async step(phase, callback) {
			const started = Date.now();
			record({ phase, status: 'started' });
			try {
				const value = await callback();
				record({ phase, status: 'completed', durationMs: Date.now() - started });
				return value;
			} catch (error) {
				record({
					phase,
					status: 'failed',
					durationMs: Date.now() - started,
					error: error.stack,
					...(error.preserved ? { preserved: error.preserved } : {})
				});
				throw error;
			}
		},
		snapshot(paths) {
			return Object.fromEntries(
				Object.entries(paths).map(([name, path]) => {
					try {
						const info = lstatSync(path);
						return [
							name,
							{
								exists: true,
								symlink: info.isSymbolicLink(),
								bytes: info.size,
								modifiedAt: info.mtime.toISOString()
							}
						];
					} catch (error) {
						return [
							name,
							error.code === 'ENOENT'
								? { exists: false }
								: { observationError: error.code }
						];
					}
				})
			);
		},
		writeReceipt(receipt) {
			writeFileSync(
				join(directory, 'INSTALLATION.json'),
				JSON.stringify(
					clean({
						...receipt,
						bootstrapRunId,
						runId,
						executionLog: file,
						logWarning: warning,
						finishedAt: new Date().toISOString(),
						durationMs: Date.now() - started
					}),
					null,
					2
				) + '\n',
				{ mode: 0o600 }
			);
		}
	};
}
