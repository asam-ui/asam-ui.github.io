import { accessSync, constants, existsSync, statSync } from 'node:fs';
import { isAbsolute, join } from 'node:path';
import { spawnSync } from 'node:child_process';

export function macAppExecutable(
	app,
	{
		readExecutable = (plist) => {
			const result = spawnSync(
				'/usr/libexec/PlistBuddy',
				['-c', 'Print :CFBundleExecutable', plist],
				{ encoding: 'utf8', timeout: 10000 }
			);
			if (result.error || result.status !== 0) throw Error('WORKBUDDY_APP_METADATA_INVALID');
			return result.stdout.replace(/\r?\n$/, '');
		}
	} = {}
) {
	if (typeof app !== 'string' || !isAbsolute(app) || !app.endsWith('.app'))
		throw Error('WORKBUDDY_APP_INVALID');
	const plist = join(app, 'Contents/Info.plist');
	if (!existsSync(plist) || !statSync(plist).isFile())
		throw Error(`WORKBUDDY_APP_METADATA_MISSING: ${plist}`);
	const name = readExecutable(plist);
	if (typeof name !== 'string' || !name || ['.', '..'].includes(name) || /[/\\\r\n\0]/.test(name))
		throw Error('WORKBUDDY_APP_METADATA_INVALID');
	const executable = join(app, 'Contents/MacOS', name);
	if (!existsSync(executable) || !statSync(executable).isFile())
		throw Error(`WORKBUDDY_APP_EXECUTABLE_MISSING: ${executable}`);
	accessSync(executable, constants.X_OK);
	return executable;
}

export function macProcessPattern(app) {
	if (
		typeof app !== 'string' ||
		!isAbsolute(app) ||
		!app.endsWith('.app') ||
		/[\r\n\0]/.test(app)
	)
		throw Error('WORKBUDDY_APP_INVALID');
	return '^' + app.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/Contents/';
}
export function macWorkBuddyRunning(app, { run = spawnSync } = {}) {
	const result = run('/usr/bin/pgrep', ['-f', macProcessPattern(app)], {
		encoding: 'utf8',
		timeout: 10000
	});
	if (result.error || ![0, 1].includes(result.status))
		throw Error('WORKBUDDY_PROCESS_CHECK_FAILED');
	return result.status === 0;
}
