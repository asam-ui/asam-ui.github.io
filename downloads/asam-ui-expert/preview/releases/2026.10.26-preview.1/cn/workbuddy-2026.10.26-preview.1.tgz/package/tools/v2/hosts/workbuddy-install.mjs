import {
	existsSync,
	readFileSync,
	mkdirSync,
	renameSync,
	openSync,
	closeSync,
	unlinkSync,
	writeFileSync
} from 'node:fs';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { verify } from './lifecycle.mjs';
import { noLinks } from './ocr-tool.mjs';
import { inventory, json, sha, write } from './files.mjs';
import { installMcp } from './workbuddy-mcp.mjs';

const id = 'asam-ui-development';
const outside = (root, path) => {
	const rel = relative(root, path);
	return isAbsolute(rel) || rel === '..' || rel.startsWith('..\\') || rel.startsWith('../');
};
const object = (value) => value && typeof value === 'object' && !Array.isArray(value);
function copy(source, target) {
	for (const file of inventory(source))
		write(join(target, file.path), readFileSync(join(source, file.path)));
	verify(target);
}

function replaceRegistry(path, bytes) {
	noLinks(path);
	mkdirSync(dirname(path), { recursive: true });
	const temporary = `${path}.asam-incoming-${randomUUID()}`;
	writeFileSync(temporary, bytes, { flag: 'wx', mode: 0o600 });
	try {
		renameSync(temporary, path);
	} finally {
		if (existsSync(temporary)) unlinkSync(temporary);
	}
}

// Same custom-expert files as the observed vendor registration path. This is
// our explicit local deployment adapter, not a vendor UI/IPC or trust bypass.
export function installExpert({
	source,
	configRoot = process.env.WORKBUDDY_CONFIG_DIR || join(homedir(), '.workbuddy'),
	userId,
	apply = false
} = {}) {
	if (
		!isAbsolute(source) ||
		!isAbsolute(configRoot) ||
		typeof apply !== 'boolean' ||
		!/^[-a-zA-Z0-9_]{1,100}$/.test(userId || '')
	)
		throw Error('EXPLICIT_INSTALL_INPUT_REQUIRED');
	source = resolve(source);
	configRoot = resolve(configRoot);
	noLinks(source);
	noLinks(configRoot);
	if (!outside(source, configRoot) || !outside(configRoot, source))
		throw Error('SEPARATE_SOURCE_REQUIRED');
	if (verify(source).host !== 'workbuddy') throw Error('WORKBUDDY_PACKAGE_REQUIRED');
	const target = join(configRoot, 'plugins/marketplaces/my-experts/plugins', id);
	const marketPath = join(
		configRoot,
		'plugins/marketplaces/my-experts/.codebuddy-plugin/marketplace.json'
	);
	const listPath = join(configRoot, 'experts/custom', userId, 'experts.json');
	for (const path of [target, marketPath, listPath]) noLinks(path);
	const oldBytes = [marketPath, listPath].map((path) =>
		existsSync(path) ? readFileSync(path) : null
	);
	const market = oldBytes[0]
		? JSON.parse(oldBytes[0].toString('utf8').replace(/^\uFEFF/, ''))
		: { name: 'my-experts', plugins: [] };
	const list = oldBytes[1] ? JSON.parse(oldBytes[1].toString('utf8').replace(/^\uFEFF/, '')) : [];
	if (
		!object(market) ||
		market.name !== 'my-experts' ||
		!Array.isArray(market.plugins) ||
		!Array.isArray(list) ||
		list.some((entry) => typeof entry !== 'string') ||
		market.plugins.some((entry) => !object(entry)) ||
		market.plugins.filter((entry) => entry.name === id).length > 1
	)
		throw Error('EXPERT_REGISTRY_CONFLICT');
	const sourceHash = sha(readFileSync(join(source, 'ownership.json')));
	let same = false;
	if (existsSync(target)) {
		verify(target);
		same = sha(readFileSync(join(target, 'ownership.json'))) === sourceHash;
	}
	const entry = {
		name: id,
		source: `./plugins/${id}`,
		description: json(join(source, '.codebuddy-plugin/plugin.json')).description
	};
	const previousEntry = market.plugins.find((item) => item.name === id);
	if (previousEntry && previousEntry.source !== entry.source)
		throw Error('EXPERT_SOURCE_CONFLICT');
	if (previousEntry) Object.assign(previousEntry, entry);
	else market.plugins.push(entry);
	if (!list.includes(id)) list.push(id);
	const plan = {
		status: 'planned',
		source,
		target,
		configRoot,
		userId,
		operation: same ? 'reuse' : 'install',
		ownershipSHA256: sourceHash,
		hostObservation: 'pending'
	};
	if (!same && existsSync(target)) plan.operation = 'update';
	if (!apply) return plan;
	const incoming = join(configRoot, 'installation-staging', id);
	noLinks(incoming);
	if (existsSync(incoming)) throw Error('EXPERT_RECOVERY_REQUIRED');
	mkdirSync(configRoot, { recursive: true });
	const lock = join(configRoot, 'asam-expert-install.lock');
	noLinks(lock);
	const backup = join(configRoot, 'installation-backups', id, randomUUID());
	noLinks(backup);
	const transaction = join(backup, 'transaction.json');
	const fd = openSync(lock, 'wx');
	let movedOld = false,
		movedNew = false;
	const writtenMetadata = [];
	try {
		for (let n = 0; n < oldBytes.length; n++) {
			const path = [marketPath, listPath][n];
			const current = existsSync(path) ? readFileSync(path) : null;
			if (
				oldBytes[n] === null
					? current !== null
					: current === null || !oldBytes[n].equals(current)
			)
				throw Error('EXPERT_REGISTRY_CHANGED');
		}
		if (!same) {
			write(transaction, { ...plan, phase: 'copying', incoming, backup });
			copy(source, incoming);
			if (sha(readFileSync(join(incoming, 'ownership.json'))) !== sourceHash)
				throw Error('EXPERT_SOURCE_CHANGED');
			if (existsSync(target)) {
				verify(target);
				mkdirSync(backup, { recursive: true });
				renameSync(target, join(backup, 'expert'));
				movedOld = true;
			}
			mkdirSync(dirname(target), { recursive: true });
			renameSync(incoming, target);
			movedNew = true;
		}
		for (const [n, path, value] of [
			[0, marketPath, market],
			[1, listPath, list]
		]) {
			const encoded = JSON.stringify(value, null, '\t') + '\n';
			if (oldBytes[n] && oldBytes[n].toString('utf8') === encoded) continue;
			const current = existsSync(path) ? readFileSync(path) : null;
			if (
				oldBytes[n] === null
					? current !== null
					: current === null || !oldBytes[n].equals(current)
			)
				throw Error('EXPERT_REGISTRY_CHANGED');
			if (oldBytes[n]) write(join(backup, `registry-${n}.json`), oldBytes[n]);
			replaceRegistry(path, encoded);
			writtenMetadata.push(n);
		}
		const mcp = installMcp({ base: target, configRoot, apply: true });
		if (existsSync(transaction))
			write(transaction, { ...plan, phase: 'completed', incoming, backup, mcp });
		return {
			...plan,
			status:
				same && writtenMetadata.length === 0 && mcp.status === 'unchanged'
					? 'unchanged'
					: 'installed',
			backup: existsSync(backup) ? backup : null,
			mcp,
			restartRequired: true
		};
	} catch (error) {
		// Roll back only this adapter's known writes; preserve every candidate and
		// backup outside the watcher tree for diagnosis/recovery.
		for (const n of writtenMetadata) {
			const path = [marketPath, listPath][n];
			if (oldBytes[n]) replaceRegistry(path, oldBytes[n]);
			else unlinkSync(path);
		}
		if (movedNew) {
			mkdirSync(backup, { recursive: true });
			renameSync(target, join(backup, 'failed-candidate'));
		}
		if (movedOld) renameSync(join(backup, 'expert'), target);
		if (existsSync(transaction))
			write(transaction, {
				...plan,
				phase: 'failed-preserved',
				incoming,
				backup,
				code: error.code || error.message
			});
		throw error;
	} finally {
		closeSync(fd);
		unlinkSync(lock);
	}
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		const [configRoot, userId, action] = process.argv.slice(2);
		if (action !== undefined && action !== '--apply') throw Error('EXPECTED_APPLY_FLAG');
		console.log(
			JSON.stringify(
				installExpert({
					source: resolve(dirname(fileURLToPath(import.meta.url)), '../../..'),
					configRoot,
					userId,
					apply: action === '--apply'
				})
			)
		);
	} catch (error) {
		console.log(
			JSON.stringify({
				status: 'partial',
				code: error.code || error.message,
				action: '保留现场；确认 WorkBuddy 已退出、完整包和用户 ID 后重试'
			})
		);
		process.exitCode = 2;
	}
}
