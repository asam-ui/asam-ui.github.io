import { readFileSync, realpathSync, statSync } from 'node:fs';
import { isAbsolute, join, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

// This function is embedded verbatim in MCP args. It does not require the host
// to expand strings when an expert dependency is copied into the user provider.
async function bootstrapMain(expectedSHA256) {
	const fs = await import('node:fs');
	const path = await import('node:path');
	const { homedir } = await import('node:os');
	const { createHash } = await import('node:crypto');
	const { pathToFileURL } = await import('node:url');
	const explicit = process.env.ASAM_UI_EXPERT_ROOT;
	let root;
	// Keep placeholder tokens out of inline JS: plugin providers may substitute
	// every config string, and a Windows path must never become JavaScript source.
	if (explicit && explicit !== '$' + '{CODEBUDDY_PLUGIN_ROOT}') {
		if (!path.isAbsolute(explicit) || explicit.includes('$' + '{'))
			throw Error('ASAM_EXPERT_ROOT_UNRESOLVED');
		root = explicit;
	} else {
		const configRoot = process.env.WORKBUDDY_CONFIG_DIR || path.join(homedir(), '.workbuddy');
		if (!path.isAbsolute(configRoot) || configRoot.includes('$' + '{'))
			throw Error('ASAM_EXPERT_CONFIG_ROOT_UNRESOLVED');
		root = path.join(configRoot, 'plugins/marketplaces/my-experts/plugins/asam-ui-development');
	}
	const launcher = path.join(root, 'runtime/workbuddy-launcher.mjs');
	if (!fs.existsSync(launcher))
		throw Error(
			'ASAM_EXPERT_NOT_INSTALLED: install the complete expert at the declared WorkBuddy root'
		);
	if (
		fs.statSync(launcher).size > 64 * 1024 ||
		createHash('sha256').update(fs.readFileSync(launcher)).digest('hex') !== expectedSHA256
	)
		throw Error('ASAM_EXPERT_LAUNCHER_HASH: restore the matching complete package');
	await (await import(pathToFileURL(launcher).href)).launch(root);
}

export function workBuddyBootstrap(expectedSHA256) {
	if (!/^[a-f0-9]{64}$/.test(expectedSHA256)) throw Error('LAUNCHER_HASH_REQUIRED');
	return `(${bootstrapMain.toString()})('${expectedSHA256}').catch(error => { process.stderr.write('ASAM expert startup failed: ' + error.message + '\\n'); process.exitCode = 1; });`;
}

export async function launch(directory) {
	const root = realpathSync(directory);
	const read = (name, maxBytes = 32 * 1024 * 1024) => {
		if (isAbsolute(name) || name.split(/[\\/]/).some((part) => part === '..' || !part))
			throw Error('ASAM_EXPERT_PATH_BOUNDARY');
		const file = realpathSync(join(root, name));
		const rel = relative(root, file);
		if (isAbsolute(rel) || rel.split(/[\\/]/).includes('..'))
			throw Error('ASAM_EXPERT_PATH_BOUNDARY');
		if (!statSync(file).isFile() || statSync(file).size > maxBytes)
			throw Error('ASAM_EXPERT_FILE_LIMIT');
		return readFileSync(file);
	};
	const metadata = JSON.parse(read('.codebuddy-plugin/plugin.json', 128 * 1024));
	const ownership = JSON.parse(read('ownership.json', 1024 * 1024));
	if (
		metadata.name !== 'asam-ui-development' ||
		metadata.agentName !== 'asam-ui-development' ||
		ownership.schemaVersion !== 1 ||
		ownership.owner !== 'asam-ui-development' ||
		ownership.host !== 'workbuddy' ||
		!Array.isArray(ownership.files) ||
		ownership.files.length > 10000
	)
		throw Error('ASAM_EXPERT_IDENTITY');
	const required = ['runtime/packages/mcp/src/server.mjs', 'bundle/manifest.json'];
	const paths = new Set();
	for (const file of ownership.files) {
		if (paths.has(file.path)) throw Error('ASAM_EXPERT_DUPLICATE_FILE');
		paths.add(file.path);
		// Preserve custom display text and unrelated old files. Only the owned runtime
		// and paired data are executable/readable inputs for this service.
		if (!file.path.startsWith('runtime/') && !file.path.startsWith('bundle/')) continue;
		if (createHash('sha256').update(read(file.path)).digest('hex') !== file.sha256)
			throw Error(`ASAM_EXPERT_RUNTIME_HASH: ${file.path}`);
	}
	if (required.some((name) => !paths.has(name))) throw Error('ASAM_EXPERT_INCOMPLETE');
	process.env.ASAM_AGENT_BUNDLE = join(root, 'bundle');
	await import(pathToFileURL(join(root, required[0])).href);
}
