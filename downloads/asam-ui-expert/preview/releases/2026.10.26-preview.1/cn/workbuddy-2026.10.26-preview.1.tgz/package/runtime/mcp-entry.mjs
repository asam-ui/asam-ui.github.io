import { readFileSync, realpathSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const root = dirname(dirname(realpathSync(fileURLToPath(import.meta.url))));
try {
 const launcher = join(root, 'runtime/workbuddy-launcher.mjs');
 if (createHash('sha256').update(readFileSync(launcher)).digest('hex') !== '772666df5f37ac5573ba520ab2fc524fa907fd7c3e2ec07400bdddccea3ca29d') throw Error('ASAM_EXPERT_LAUNCHER_HASH');
 await (await import(pathToFileURL(launcher).href)).launch(root);
} catch (error) { process.stderr.write('ASAM expert startup failed: ' + error.message + '\n'); process.exitCode = 1; }
