import {
	existsSync,
	readFileSync,
	readdirSync,
	mkdirSync,
	renameSync,
	openSync,
	closeSync,
	unlinkSync,
	writeFileSync
} from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { noLinks } from './ocr-tool.mjs';
import { verify } from './lifecycle.mjs';
import { sha, write } from './files.mjs';
import { mcpOwnership, mcpConfiguration } from './workbuddy-mcp.mjs';

const id = 'asam-ui-development';
const object = (value) => value && typeof value === 'object' && !Array.isArray(value);
const bytesAt = (path) => (existsSync(path) ? readFileSync(path) : null);
const same = (left, right) =>
	left === null ? right === null : right !== null && left.equals(right);
function read(path, fallback) {
	const bytes = bytesAt(path);
	return {
		path,
		before: bytes,
		value: bytes ? JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, '')) : fallback
	};
}
function replace(path, bytes) {
	noLinks(path);
	mkdirSync(dirname(path), { recursive: true });
	const incoming = `${path}.asam-uninstall-${randomUUID()}`;
	writeFileSync(incoming, bytes, { flag: 'wx', mode: 0o600 });
	try {
		renameSync(incoming, path);
	} finally {
		if (existsSync(incoming)) unlinkSync(incoming);
	}
}

// Removes only this expert's verified slot and exact registrations. Shared
// runtimes, OCR caches, tool settings, trust records and history are retained.
export function uninstallExpert({ configRoot, userId, apply = false } = {}) {
	if (
		!isAbsolute(configRoot) ||
		!/^[-a-zA-Z0-9_]{1,100}$/.test(userId || '') ||
		typeof apply !== 'boolean'
	)
		throw Error('EXPLICIT_UNINSTALL_INPUT_REQUIRED');
	configRoot = resolve(configRoot);
	noLinks(configRoot);
	const target = join(configRoot, 'plugins/marketplaces/my-experts/plugins', id);
	const paths = [
		join(configRoot, 'plugins/marketplaces/my-experts/.codebuddy-plugin/marketplace.json'),
		join(configRoot, 'experts/custom', userId, 'experts.json'),
		join(configRoot, 'mcp.json')
	];
	for (const path of [target, ...paths]) noLinks(path);
	const owner = existsSync(target) ? verify(target) : null;
	if (owner && owner.host !== 'workbuddy') throw Error('WORKBUDDY_PACKAGE_REQUIRED');
	const ownership = owner ? sha(readFileSync(join(target, 'ownership.json'))) : null;
	const items = [
		read(paths[0], { name: 'my-experts', plugins: [] }),
		read(paths[1], []),
		read(paths[2], {})
	];
	const [market, list, mcp] = items.map((item) => item.value);
	if (
		!object(market) ||
		market.name !== 'my-experts' ||
		!Array.isArray(market.plugins) ||
		market.plugins.some((item) => !object(item)) ||
		market.plugins.filter((item) => item.name === id).length > 1 ||
		!Array.isArray(list) ||
		list.some((item) => typeof item !== 'string')
	)
		throw Error('EXPERT_REGISTRY_CONFLICT');
	const entry = market.plugins.find((item) => item.name === id);
	if (entry && entry.source !== `./plugins/${id}`) throw Error('EXPERT_SOURCE_CONFLICT');
	if (!object(mcp) || (mcp.mcpServers !== undefined && !object(mcp.mcpServers)))
		throw Error('INVALID_MCP_CONFIG');
	const service = mcp.mcpServers?.['asam-ui'];
	const mcpOwner = mcpOwnership(configRoot, service);
	if (
		service !== undefined &&
		!mcpOwner.value &&
		(!owner || !isDeepStrictEqual(service, mcpConfiguration(target)))
	)
		throw Error('ASAM_MCP_ENTRY_CONFLICT');
	const normalized = (path) =>
		process.platform === 'win32' ? resolve(path).toLowerCase() : resolve(path);
	if (
		service !== undefined &&
		(!object(service) ||
			!isAbsolute(service.command || '') ||
			!Array.isArray(service.args) ||
			service.args.length !== 1 ||
			typeof service.args[0] !== 'string' ||
			!isAbsolute(service.args[0]) ||
			normalized(service.args[0]) !== normalized(join(target, 'runtime/mcp-entry.mjs')) ||
			JSON.stringify(service.env) !== JSON.stringify({ ASAM_AGENT_VALIDATION: '1' }) ||
			Object.keys(service).some((key) => !['command', 'args', 'env'].includes(key)))
	)
		throw Error('ASAM_MCP_ENTRY_CONFLICT');
	// The expert directory and MCP are shared across this config root. Never
	// remove resources still referenced by another account.
	const references = [];
	references.push({ path: mcpOwner.path, before: mcpOwner.before });
	const custom = join(configRoot, 'experts/custom');
	noLinks(custom);
	if (existsSync(custom))
		for (const account of readdirSync(custom, { withFileTypes: true })) {
			if (account.name === userId) continue;
			if (account.isSymbolicLink()) throw Error('SYMLINK_NOT_ALLOWED');
			if (!account.isDirectory()) continue;
			const path = join(custom, account.name, 'experts.json');
			noLinks(path);
			const other = read(path, []);
			if (
				!Array.isArray(other.value) ||
				other.value.some((value) => typeof value !== 'string')
			)
				throw Error('EXPERT_REGISTRY_CONFLICT');
			if (other.value.includes(id)) throw Error('EXPERT_USED_BY_ANOTHER_ACCOUNT');
			references.push(other);
		}
	const changes = [Boolean(entry), list.includes(id), service !== undefined];
	market.plugins = market.plugins.filter((item) => item.name !== id);
	items[1].value = list.filter((item) => item !== id);
	if (service !== undefined) delete mcp.mcpServers['asam-ui'];
	for (let n = 0; n < items.length; n++)
		items[n].after = changes[n]
			? Buffer.from(JSON.stringify(items[n].value, null, '\t') + '\n')
			: items[n].before;
	const plan = {
		status: 'planned',
		operation: owner || changes.some(Boolean) ? 'remove' : 'absent',
		target,
		configRoot,
		userId,
		removesMcp: service !== undefined,
		preservesSharedTools: true
	};
	if (!apply) return plan;
	const locks = ['asam-expert-install.lock', 'mcp.json.asam-install.lock'].map((name) =>
		join(configRoot, name)
	);
	for (const path of [...locks, join(configRoot, 'installation-staging', id)]) {
		noLinks(path);
		if (existsSync(path)) throw Error('PREVIOUS_INSTALLATION_REQUIRES_RECOVERY');
	}
	if (plan.operation === 'absent') return { ...plan, status: 'absent', backup: null };
	const backup = join(configRoot, 'installation-backups', id, `uninstall-${randomUUID()}`);
	noLinks(backup);
	const transaction = join(backup, 'transaction.json');
	const acquired = [],
		written = [];
	let moved = false;
	try {
		for (const path of locks) acquired.push({ path, fd: openSync(path, 'wx') });
		for (const item of [...items, ...references])
			if (!same(item.before, bytesAt(item.path))) throw Error('UNINSTALL_CONFIG_CHANGED');
		if (owner) {
			verify(target);
			if (sha(readFileSync(join(target, 'ownership.json'))) !== ownership)
				throw Error('UNINSTALL_EXPERT_CHANGED');
		} else if (existsSync(target)) throw Error('UNINSTALL_EXPERT_CHANGED');
		mkdirSync(backup, { recursive: true });
		for (const [n, item] of items.entries())
			if (item.before)
				writeFileSync(join(backup, `registry-${n}.json`), item.before, {
					flag: 'wx',
					mode: 0o600
				});
		write(transaction, { ...plan, phase: 'prepared', backup });
		if (owner) {
			renameSync(target, join(backup, 'expert'));
			moved = true;
		}
		for (const item of items) {
			if (same(item.before, item.after)) continue;
			if (!same(item.before, bytesAt(item.path))) throw Error('UNINSTALL_CONFIG_CHANGED');
			replace(item.path, item.after);
			written.push(item);
		}
		write(transaction, { ...plan, phase: 'completed', backup });
		return { ...plan, status: 'removed', backup, restartRequired: true };
	} catch (error) {
		let recoveryRequired = false;
		for (const item of written.reverse()) {
			if (!same(item.after, bytesAt(item.path))) {
				recoveryRequired = true;
				continue;
			}
			try {
				if (item.before) replace(item.path, item.before);
				else unlinkSync(item.path);
			} catch {
				recoveryRequired = true;
			}
		}
		if (moved) {
			if (existsSync(target)) recoveryRequired = true;
			else
				try {
					renameSync(join(backup, 'expert'), target);
				} catch {
					recoveryRequired = true;
				}
		}
		if (existsSync(transaction))
			write(transaction, {
				...plan,
				phase: 'failed-preserved',
				backup,
				recoveryRequired,
				code: error.code || error.message
			});
		throw error;
	} finally {
		for (const lock of acquired.reverse()) {
			closeSync(lock.fd);
			unlinkSync(lock.path);
		}
	}
}
