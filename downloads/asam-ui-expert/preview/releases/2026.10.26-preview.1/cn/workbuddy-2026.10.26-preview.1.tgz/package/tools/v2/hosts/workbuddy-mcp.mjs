import {
	existsSync,
	readFileSync,
	realpathSync,
	mkdirSync,
	openSync,
	closeSync,
	writeFileSync,
	renameSync,
	unlinkSync
} from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { noLinks } from './ocr-tool.mjs';
import { verify } from './lifecycle.mjs';
import { json, sha } from './files.mjs';

const record = (value) => value && typeof value === 'object' && !Array.isArray(value);
const bytesAt = (path) => (existsSync(path) ? readFileSync(path) : null);
const sameBytes = (left, right) =>
	left === null ? right === null : right !== null && left.equals(right);

// This receipt is an installation baseline, not authority supplied by an args
// keyword. All command/args/env fields must still match the recorded service.
export function mcpOwnership(configRoot, previous) {
	const path = join(configRoot, 'mcp.json.asam-ui-owner.json');
	noLinks(path);
	const before = bytesAt(path);
	let value = null;
	try {
		value = before ? JSON.parse(before.toString('utf8')) : null;
	} catch {
		throw Error('ASAM_MCP_ENTRY_CONFLICT');
	}
	if (before && !record(value)) throw Error('ASAM_MCP_ENTRY_CONFLICT');
	if (
		value &&
		(value.schema !== 'asam-ui/mcp-owner@1' ||
			!isAbsolute(value.base || '') ||
			!/^[a-f0-9]{64}$/.test(value.ownershipSHA256 || '') ||
			!record(value.server) ||
			!isAbsolute(value.server.command || '') ||
			!isDeepStrictEqual(value.server.args, [join(value.base, 'runtime/mcp-entry.mjs')]) ||
			!isDeepStrictEqual(value.server.env, { ASAM_AGENT_VALIDATION: '1' }) ||
			Object.keys(value.server).some((key) => !['command', 'args', 'env'].includes(key)) ||
			(previous !== undefined && !isDeepStrictEqual(previous, value.server)))
	)
		throw Error('ASAM_MCP_ENTRY_CONFLICT');
	return { path, before, value };
}
export function mcpConfiguration(base, command = process.execPath) {
	if (!isAbsolute(base) || !isAbsolute(command)) throw Error('ABSOLUTE_PATH_REQUIRED');
	noLinks(base);
	// Node installations may expose a managed junction (for example NVM).
	// Store its resolved executable, never a shim or mutable junction spelling.
	command = realpathSync(command);
	noLinks(command);
	if (verify(base).host !== 'workbuddy') throw Error('WORKBUDDY_PACKAGE_REQUIRED');
	const descriptor = json(join(base, 'mcpServer.json'));
	if (
		descriptor.schema !== 'asam-ui/mcp-install@1' ||
		descriptor.serverName !== 'asam-ui' ||
		descriptor.transport.command !== 'node' ||
		JSON.stringify(descriptor.transport.args) !==
			JSON.stringify(['{{EXPERT_ROOT}}/runtime/mcp-entry.mjs']) ||
		JSON.stringify(descriptor.transport.env) !== JSON.stringify({ ASAM_AGENT_VALIDATION: '1' })
	)
		throw Error('MCP_DESCRIPTOR_MISMATCH');
	return {
		command,
		args: [join(resolve(base), 'runtime/mcp-entry.mjs')],
		env: { ASAM_AGENT_VALIDATION: '1' }
	};
}

// Explicit install action only. Never runs on MCP startup, changes trust, scans
// other profiles, or replaces another service. Dry-run is the command default.
export function installMcp({
	base,
	configRoot = process.env.WORKBUDDY_CONFIG_DIR || join(homedir(), '.workbuddy'),
	command = process.execPath,
	apply = false
} = {}) {
	if (!isAbsolute(configRoot) || typeof apply !== 'boolean') throw Error('INVALID_INSTALL_INPUT');
	const server = mcpConfiguration(base, command);
	const target = join(configRoot, 'mcp.json');
	noLinks(target);
	const before = existsSync(target) ? readFileSync(target) : null;
	const value = before ? JSON.parse(before.toString('utf8').replace(/^\uFEFF/, '')) : {};
	if (!record(value) || (value.mcpServers !== undefined && !record(value.mcpServers)))
		throw Error('INVALID_MCP_CONFIG');
	const previous = value.mcpServers?.['asam-ui'];
	const ownership = mcpOwnership(configRoot, previous);
	const installedBase = join(
		configRoot,
		'plugins/marketplaces/my-experts/plugins/asam-ui-development'
	);
	const managedBases = [resolve(base), resolve(installedBase)];
	let managed = isDeepStrictEqual(previous, server);
	if (previous !== undefined && !managed) {
		if (ownership.value && managedBases.includes(ownership.value.base)) {
			verify(ownership.value.base);
			managed = true;
		} else if (existsSync(installedBase)) {
			managed = isDeepStrictEqual(previous, mcpConfiguration(installedBase, command));
		}
		if (!managed) throw Error('ASAM_MCP_ENTRY_CONFLICT');
	}
	const unchanged = isDeepStrictEqual(previous, server);
	const owner = {
		schema: 'asam-ui/mcp-owner@1',
		base: resolve(base),
		ownershipSHA256: sha(readFileSync(join(base, 'ownership.json'))),
		server
	};
	const ownerBytes = Buffer.from(JSON.stringify(owner, null, '\t') + '\n');
	if (unchanged && (!apply || sameBytes(ownership.before, ownerBytes)))
		return { status: 'unchanged', target };
	const plan = {
		status: 'planned',
		target,
		service: 'asam-ui',
		operation: previous === undefined ? 'add' : 'update',
		server,
		trust: 'user-action-required-if-host-requests'
	};
	if (!apply) return plan;
	mkdirSync(configRoot, { recursive: true });
	const lock = `${target}.asam-install.lock`;
	noLinks(lock);
	const fd = openSync(lock, 'wx');
	const suffix = randomUUID();
	const temporary = `${target}.asam-incoming-${suffix}`;
	const ownerTemporary = `${ownership.path}.asam-incoming-${suffix}`;
	const backup = before ? `${target}.asam-backup-${suffix}` : null;
	const ownerBackup = ownership.before ? `${ownership.path}.asam-backup-${suffix}` : null;
	let written = false;
	let encoded;
	try {
		const current = existsSync(target) ? readFileSync(target) : null;
		if (before === null ? current !== null : current === null || !before.equals(current))
			throw Error('MCP_CONFIG_CHANGED');
		if (!sameBytes(ownership.before, bytesAt(ownership.path)))
			throw Error('MCP_CONFIG_CHANGED');
		if (backup) writeFileSync(backup, before, { flag: 'wx', mode: 0o600 });
		if (ownerBackup) writeFileSync(ownerBackup, ownership.before, { flag: 'wx', mode: 0o600 });
		value.mcpServers ??= {};
		value.mcpServers['asam-ui'] = server;
		encoded = unchanged ? before : Buffer.from(JSON.stringify(value, null, '\t') + '\n');
		writeFileSync(temporary, encoded, {
			flag: 'wx',
			mode: 0o600
		});
		writeFileSync(ownerTemporary, ownerBytes, { flag: 'wx', mode: 0o600 });
		const latest = existsSync(target) ? readFileSync(target) : null;
		if (before === null ? latest !== null : latest === null || !before.equals(latest))
			throw Error('MCP_CONFIG_CHANGED');
		if (!sameBytes(ownership.before, bytesAt(ownership.path)))
			throw Error('MCP_CONFIG_CHANGED');
		if (!unchanged) {
			renameSync(temporary, target);
			written = true;
		}
		renameSync(ownerTemporary, ownership.path);
		return {
			...plan,
			status: unchanged ? 'unchanged' : 'installed',
			backup,
			ownerBackup,
			previousSHA256: before && sha(before),
			restartRequired: true
		};
	} catch (error) {
		if (written && sameBytes(encoded, bytesAt(target))) {
			if (before) {
				writeFileSync(temporary, before, { flag: 'wx', mode: 0o600 });
				renameSync(temporary, target);
			} else unlinkSync(target);
		}
		throw error;
	} finally {
		if (existsSync(temporary)) unlinkSync(temporary);
		if (existsSync(ownerTemporary)) unlinkSync(ownerTemporary);
		closeSync(fd);
		unlinkSync(lock);
	}
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		const [configRoot, action] = process.argv.slice(2);
		if (action !== undefined && action !== '--apply') throw Error('EXPECTED_APPLY_FLAG');
		console.log(
			JSON.stringify(
				installMcp({
					base: resolve(dirname(fileURLToPath(import.meta.url)), '../../..'),
					configRoot,
					apply: action === '--apply'
				})
			)
		);
	} catch (error) {
		console.log(
			JSON.stringify({
				status: 'partial',
				code: error.code || error.message,
				action: '保留原配置，核对明确安装目录和冲突后重试'
			})
		);
		process.exitCode = 2;
	}
}
