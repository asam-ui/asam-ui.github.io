import {
	existsSync,
	readFileSync,
	readdirSync,
	mkdirSync,
	writeFileSync,
	renameSync
} from 'node:fs';
import { accessSync, constants, statfsSync, statSync } from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { homedir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { createInterface } from 'node:readline/promises';
import { installExpert } from './workbuddy-install.mjs';
import { installMcp } from './workbuddy-mcp.mjs';
import { uninstallExpert } from './workbuddy-uninstall.mjs';
import { macAppExecutable, macWorkBuddyRunning } from './workbuddy-app.mjs';
import { noLinks, hostToolDefaults, prepareTool } from './ocr-tool.mjs';
import { assertHostRuntime } from './host-runtime.mjs';
import { installerMessage, ocrDownloadMessage } from './installer-message.mjs';
import { installerProgress } from './installer-progress.mjs';
import { inventory, json, write } from './files.mjs';
import { verify } from './lifecycle.mjs';
import { probeMcp, ocrProbe } from './installer-probes.mjs';
export { probeMcp } from './installer-probes.mjs';

const uuid = '[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}';
const validId = new RegExp(`^${uuid}$`);
export function detectUserIds(configRoot) {
	noLinks(configRoot);
	const ids = new Set();
	const custom = join(configRoot, 'experts/custom');
	noLinks(custom);
	for (const root of [configRoot, custom]) {
		if (!existsSync(root)) continue;
		for (const entry of readdirSync(root, { withFileTypes: true })) {
			if (!entry.isDirectory() || entry.isSymbolicLink()) continue;
			if (validId.test(entry.name)) ids.add(entry.name);
			const user = new RegExp(`^user-(${uuid})-(?:personal|enterprise|team)$`).exec(
				entry.name
			);
			if (root === configRoot && user) ids.add(user[1]);
		}
	}
	return [...ids].sort();
}
export function chooseUserId(ids, requested) {
	if (requested) {
		if (!validId.test(requested) || !ids.includes(requested))
			throw Error('WORKBUDDY_ACCOUNT_UNKNOWN');
		return requested;
	}
	if (ids.length === 0)
		throw Error('WORKBUDDY_ACCOUNT_REQUIRED: open WorkBuddy and sign in once');
	if (ids.length !== 1) throw Error('WORKBUDDY_ACCOUNT_SELECTION_REQUIRED');
	return ids[0];
}

export function workBuddyRunning(app = process.env.ASAM_WORKBUDDY_APP) {
	if (process.platform === 'win32') {
		const result = spawnSync(
			'tasklist.exe',
			['/FI', 'IMAGENAME eq WorkBuddy.exe', '/FO', 'CSV', '/NH'],
			{ encoding: 'utf8', windowsHide: true }
		);
		if (result.error || result.status !== 0) throw Error('WORKBUDDY_PROCESS_CHECK_FAILED');
		return /^"WorkBuddy\.exe"/im.test(result.stdout);
	}
	if (process.platform === 'darwin') {
		return macWorkBuddyRunning(app);
	}
	throw Error('ONECLICK_PLATFORM_UNSUPPORTED');
}

export function preflight({
	base,
	configRoot,
	userId,
	app = process.env.ASAM_WORKBUDDY_APP,
	action = 'install'
} = {}) {
	if (!['install', 'uninstall'].includes(action)) throw Error('INVALID_INSTALL_ACTION');
	assertHostRuntime('workbuddy');
	if (!isAbsolute(base) || !isAbsolute(configRoot)) throw Error('ABSOLUTE_PATH_REQUIRED');
	const [major, minor] = process.versions.node.split('.').map(Number);
	if (major !== 22 || minor < 19) throw Error('NODE_22_19_OR_LATER_REQUIRED');
	if (!app || !isAbsolute(app)) throw Error('WORKBUDDY_NOT_INSTALLED');
	let executable = app;
	if (process.platform === 'darwin') executable = macAppExecutable(app);
	if (!existsSync(executable) || !statSync(executable).isFile())
		throw Error('WORKBUDDY_NOT_INSTALLED');
	if (workBuddyRunning(app))
		throw Error('WORKBUDDY_RUNNING: fully exit WorkBuddy including its tray');
	verify(base);
	noLinks(configRoot);
	userId = chooseUserId(detectUserIds(configRoot), userId);
	accessSync(configRoot, constants.R_OK | constants.W_OK);
	for (const path of [
		'asam-expert-install.lock',
		'mcp.json.asam-install.lock',
		'installation-staging/asam-ui-development'
	]) {
		noLinks(join(configRoot, path));
		if (existsSync(join(configRoot, path)))
			throw Error('PREVIOUS_INSTALLATION_REQUIRES_RECOVERY');
	}
	if (action === 'uninstall') {
		const plan = uninstallExpert({ configRoot, userId });
		return {
			status: 'pass',
			action,
			workBuddy: executable,
			node: process.version,
			arch: process.arch,
			userId,
			configWritable: true,
			operation: plan.operation
		};
	}
	const expert = installExpert({ source: base, configRoot, userId });
	const mcp = installMcp({ base, configRoot });
	const fs = statfsSync(configRoot);
	const required =
		inventory(base).reduce((size, item) => size + statSync(join(base, item.path)).size, 0) * 2 +
		16 * 1024 * 1024;
	if (fs.bavail * fs.bsize < required) throw Error('INSTALL_DISK_SPACE_REQUIRED');
	const git = spawnSync('git', ['--version'], {
		encoding: 'utf8',
		timeout: 10000,
		windowsHide: true
	});
	if (git.error || git.status !== 0 || !/^git version /m.test(git.stdout))
		throw Error('GIT_REQUIRED_FOR_OCR: install or enable Git, then run the same entry again');
	return {
		status: 'pass',
		workBuddy: executable,
		node: process.version,
		arch: process.arch,
		userId,
		configWritable: true,
		availableBytes: fs.bavail * fs.bsize,
		requiredBytes: required,
		existingExpert: expert.operation,
		mcp: mcp.operation || mcp.status,
		git: git.stdout.trim(),
		network: 'downloaded only when pinned resources are missing'
	};
}

function saveToolSettings(configRoot, previousBytes, value) {
	const target = join(configRoot, 'asam-ui-tools.json');
	noLinks(target);
	const encoded = JSON.stringify(value, null, '\t') + '\n';
	if (previousBytes?.toString('utf8') === encoded) return;
	const current = existsSync(target) ? readFileSync(target) : null;
	if (
		previousBytes === null
			? current !== null
			: current === null || !previousBytes.equals(current)
	)
		throw Error('HOST_TOOL_SETTINGS_CHANGED');
	const token = randomUUID();
	if (previousBytes)
		writeFileSync(`${target}.backup-${token}`, previousBytes, { flag: 'wx', mode: 0o600 });
	const incoming = `${target}.incoming-${token}`;
	writeFileSync(incoming, encoded, { flag: 'wx', mode: 0o600 });
	renameSync(incoming, target);
}

export async function runOneClick({
	base,
	configRoot = process.env.WORKBUDDY_CONFIG_DIR || join(homedir(), '.workbuddy'),
	userId,
	allowDownload = true
} = {}) {
	const checked = preflight({ base, configRoot, userId });
	userId = checked.userId;
	const beforeSettings = join(configRoot, 'asam-ui-tools.json');
	noLinks(beforeSettings);
	const settingsBytes = existsSync(beforeSettings) ? readFileSync(beforeSettings) : null;
	const settings = settingsBytes
		? JSON.parse(settingsBytes.toString('utf8').replace(/^\uFEFF/, ''))
		: {};
	if (
		!settings ||
		typeof settings !== 'object' ||
		Array.isArray(settings) ||
		Object.keys(settings).some(
			(key) => !['cacheRoot', 'binary', 'downloadTimeoutMs'].includes(key)
		)
	)
		throw Error('INVALID_HOST_TOOL_SETTINGS');
	const defaults = hostToolDefaults(
		'workbuddy',
		{ ...process.env, WORKBUDDY_CONFIG_DIR: configRoot },
		settings
	);
	const output = join(
		configRoot,
		'installation-receipts/asam-ui',
		new Date().toISOString().replace(/[:.]/g, '-') + '-' + randomUUID()
	);
	noLinks(output);
	mkdirSync(output, { recursive: true });
	const report = {
		schemaVersion: 1,
		installedAt: new Date().toISOString(),
		platform: process.platform,
		arch: process.arch,
		expertVersion: json(join(base, '.codebuddy-plugin/plugin.json')).version,
		preflight: checked,
		hostUi: 'pending',
		modelSkillRead: 'pending',
		hostMcpTrust: 'user-action-if-requested',
		output
	};
	report.status = 'running';
	const progress = installerProgress({ report, file: join(output, 'INSTALLATION.json') });
	try {
		progress.update({ phase: 'prerequisites', message: '前置检查通过，正在准备 OCR…' });
		report.ocr = await prepareTool({ ...defaults, allowDownload, onProgress: progress.update });
		if (report.ocr.status === 'pass') {
			if (workBuddyRunning()) throw Error('WORKBUDDY_RESTARTED_DURING_PREPARATION');
			progress.update({ phase: 'deploying', message: '正在备份并安装专家与 MCP 配置…' });
			report.install = installExpert({ source: base, configRoot, userId, apply: true });
			saveToolSettings(configRoot, settingsBytes, {
				cacheRoot: defaults.cacheRoot,
				binary: report.ocr.binary,
				downloadTimeoutMs: defaults.downloadTimeoutMs
			});
			progress.update({
				phase: 'mcp-probe',
				message: '专家与 MCP 配置已安装，正在连接 MCP 并执行工具调用…'
			});
			const service = json(join(configRoot, 'mcp.json')).mcpServers['asam-ui'];
			report.mcp = await probeMcp(service);
			progress.update({ phase: 'ocr-probe', message: '正在执行 OCR 选文件与规则解析自检…' });
			report.ocrProbe = ocrProbe(report.ocr.binary, output);
		}
		report.status =
			report.mcp?.status === 'pass' &&
			report.ocr.status === 'pass' &&
			report.ocrProbe?.status === 'pass'
				? 'pass'
				: 'partial';
		progress.update({
			phase: report.status === 'pass' ? 'complete' : 'failed',
			message:
				report.status === 'pass'
					? '专家安装及 MCP/OCR 自检全部完成。'
					: '工具准备或自检未通过，具体原因已保存到日志。'
		});
	} catch (error) {
		report.status = 'partial';
		report.code = error.code || error.message;
		progress.update({
			phase: 'failed',
			message: '操作未完成，具体原因及当前阶段已保存到日志。'
		});
	} finally {
		progress.close();
	}
	return report;
}

export function runUninstall({
	base,
	configRoot = process.env.WORKBUDDY_CONFIG_DIR || join(homedir(), '.workbuddy'),
	userId
} = {}) {
	const checked = preflight({ base, configRoot, userId, action: 'uninstall' });
	const output = join(
		configRoot,
		'installation-receipts/asam-ui',
		new Date().toISOString().replace(/[:.]/g, '-') + '-' + randomUUID()
	);
	noLinks(output);
	mkdirSync(output, { recursive: true });
	const report = {
		schemaVersion: 1,
		action: 'uninstall',
		startedAt: new Date().toISOString(),
		preflight: checked,
		output
	};
	write(join(output, 'UNINSTALLATION.json'), report);
	try {
		if (workBuddyRunning()) throw Error('WORKBUDDY_RESTARTED_DURING_PREPARATION');
		report.uninstall = uninstallExpert({ configRoot, userId: checked.userId, apply: true });
		const mcpPath = join(configRoot, 'mcp.json');
		if (
			existsSync(report.uninstall.target) ||
			(existsSync(mcpPath) && json(mcpPath).mcpServers?.['asam-ui'] !== undefined)
		)
			throw Error('UNINSTALL_VERIFICATION_FAILED');
		report.status = 'pass';
	} catch (error) {
		report.status = 'partial';
		report.code = error.code || error.message;
	}
	write(join(output, 'UNINSTALLATION.json'), report);
	return report;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		const configRoot = process.env.WORKBUDDY_CONFIG_DIR || join(homedir(), '.workbuddy');
		const ids = detectUserIds(configRoot);
		let requested = process.env.ASAM_WORKBUDDY_USER_ID;
		if (!requested && ids.length > 1 && process.env.ASAM_INSTALL_NONINTERACTIVE !== '1') {
			console.log('检测到多个 WorkBuddy 用户，请选择当前账号：');
			ids.forEach((id, index) => console.log(`${index + 1}. ${id}`));
			const prompt = createInterface({ input: process.stdin, output: process.stdout });
			try {
				requested = ids[Number(await prompt.question('账号编号：')) - 1];
				if (!requested) throw Error('INVALID_ACCOUNT_SELECTION');
			} finally {
				prompt.close();
			}
		}
		const action = process.env.ASAM_INSTALL_ACTION || 'install';
		if (!['install', 'uninstall'].includes(action)) throw Error('INVALID_INSTALL_ACTION');
		const input = {
			base: resolve(dirname(fileURLToPath(import.meta.url)), '../../..'),
			configRoot,
			userId: requested,
			allowDownload: process.env.ASAM_INSTALL_ALLOW_DOWNLOAD !== '0'
		};
		if (action === 'uninstall') {
			const report = runUninstall(input);
			console.log(
				report.status === 'pass'
					? '专家及对应 MCP 已卸载；备份、共享运行时和 OCR 缓存已保留。可再次运行本入口选择 1 重新安装。'
					: '卸载未完成，请查看日志并保留现场。'
			);
			console.log(`结果：${join(report.output, 'UNINSTALLATION.json')}`);
			if (report.status !== 'pass')
				console.error(
					installerMessage(
						report.code || report.uninstall?.code || 'UNINSTALL_VERIFICATION_FAILED'
					)
				);
			process.exitCode = report.status === 'pass' ? 0 : 2;
		} else {
			const report = await runOneClick(input);
			let message = '前置准备或自检存在待处理项，查看日志后重新双击同一入口即可重试。';
			if (report.install)
				message = '专家已部署，但自检存在待处理项。查看日志后重新双击同一入口即可重试。';
			if (report.status === 'pass')
				message = '安装与 MCP/OCR 自检完成。现在可打开 WorkBuddy；如提示信任，请本人确认。';
			console.log(message);
			if (report.status !== 'pass' && report.ocr?.download)
				console.error(ocrDownloadMessage(report.ocr));
			if (report.status !== 'pass')
				console.error(
					installerMessage(report.code || report.ocr?.code || 'OCR_SELF_TEST_FAILED')
				);
			console.log(`结果：${join(report.output, 'INSTALLATION.json')}`);
			process.exitCode = report.status === 'pass' ? 0 : 2;
		}
	} catch (error) {
		console.error(installerMessage(error));
		process.exitCode = 2;
	}
}
