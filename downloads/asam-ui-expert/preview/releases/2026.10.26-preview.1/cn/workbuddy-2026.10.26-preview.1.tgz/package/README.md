# ASAM UI 开发专家 0.1.0-alpha.19

本次修复专家安装包装，配对 ASAM 组件及共享核心仍为原 b92d / 0.1.0-alpha.1。修复固定盘符、OCR 准备配置、分发资料本机路径及 MCP 安装入口。真实 WorkBuddy UI/Skill 加载仍需现场验证。

## 对外唯一安装入口

下载对应系统的安装包并完整解压。Windows 双击 install.bat，macOS 双击 install.command；每个平台的包只有这一个对外入口，内部文件保持完整。先安装并登录过 WorkBuddy，然后完全退出（含托盘）。入口优先使用 WorkBuddy 自带 Node，其次使用 PATH 中的系统 Node（22.19+、22.x）；不调用其他应用私有 Node，缺少时提示安装，不自动下载，随后识别账号、备份更新专家与 MCP、准备固定 OCR 并执行实际自检。多账号时选择当前用户；不改信任、不停止其他进程、不使用管理员权限或修改系统环境。详细结果保存在 WorkBuddy 配置根 installation-receipts。

入口菜单提供 1 安装/更新、2 卸载、0 退出。卸载将已核对归属的专家移出加载目录并保存在 installation-backups，移除本专家的市场、当前账号和对应 MCP 登记；保留其他配置、共享 Node/OCR、工具配置、历史与信任记录。卸载不要求 Git 或 OCR 可用；修改过的专家、未知同名服务及其他账号引用会停止。卸载后再选择 1 可验证完整重装。自动化可设置 ASAM_INSTALL_ACTION=install 或 uninstall，并设置 ASAM_INSTALL_NONINTERACTIVE=1；未指定 action 的非交互调用兼容默认安装。

重复双击同一入口选择 1 即可重试/更新；有用户修改或冲突时停止并保留原件。OCR 公网下载失败、缺 Git 等自检失败明确报告 partial，不冒安装全通过。Windows 已实测；macOS Intel/Apple Silicon 的兼容实现与固定文件已提供，真机验证待补，不宣称已通过。下载的脚本仍遵守系统本身的打开/授权机制，不自动移除隔离标记。

## 直接本地安装（无需自然语言创建）

先完全退出 WorkBuddy。保持解压包完整，使用实际 Node.js 22（已测 22.19.0 与 WorkBuddy 自带 22.22.2）。用该 Node 运行 tools/v2/hosts/workbuddy-install.mjs，依次传入 WorkBuddy 绝对配置根、当前用户 ID；默认预览，再加 --apply 执行。

安装器会部署自定义专家、更新 my-experts 市场及对应用户列表，并安装 asam-ui MCP；不登记为普通插件、不改其他专家/服务、不改信任。旧专家和登记备份在配置根 installation-backups；MCP 原配置以 mcp.json.asam-backup-* 原字节保存。已有修改、链接、同名未知服务或遗留安装现场会停止。先核备份和错误再恢复，不强制覆盖。更新时重复同一流程，相同包幂等。

## 使用 WorkBuddy 导入入口

也可通过实际界面导入本 ZIP。导入成功后，需从实际安装目录运行 tools/v2/hosts/workbuddy-mcp.mjs，传入绝对配置根，先预览，再 --apply。mcpServer.json 是描述文件，不是可以原样复制的用户配置；包不再携带会被宿主误复制的 .mcp.json/mcp.json。

完成后打开/重启 WorkBuddy；如要求信任，由用户本人授权。专家出现、Skill 实际读取、MCP 列出 10 工具及真实调用分别验，不以隔离握手冒界面通过。MCP 未连接时使用 skills/asam-ui-development/scripts/agent.mjs 的同源 CLI，先 discover 再 read。开发/verify/verify-fix 与共享验证契约见 Skill。

## OCR 准备

ASAM_OCR_CACHE_ROOT 指定共享缓存根；ASAM_OCR_BINARY 指定已有 1.13.1 固定原生工具，都会核绝对路径、字节哈希和运行版本。按机器既有存储规则设置，先复用；不依赖 E 盘，不搜索任意 PATH 程序。默认优先 WORKBUDDY_CONFIG_DIR/tools/open-code-review，再用用户缓存。ASAM_OCR_DOWNLOAD_TIMEOUT_MS 默认十分钟，可设一秒到三十分钟；仍支持取消，下载失败保留现场，不执行半包。网络受限时配置已有工具，不将延长超时当成联网成功。

可在明确配置根的 asam-ui-tools.json 持久保存 cacheRoot、binary、downloadTimeoutMs 三项，环境变量优先。配置根由 WORKBUDDY_CONFIG_DIR 指定，默认用户主目录下 .workbuddy；不改系统环境或其他应用配置。

## 资料与许可

运行依赖已随 runtime 打包，无需包内安装依赖。Node 与消费工程依赖由宿主管理，工程统一 pnpm。bundle/manifest.json 和 provenance.json 明确记录资料脱敏投影和原输入摘要；原始证据文件、来源哈希、组件契约和验收状态保留，非原 bundle 字节。不得混用其他版本 runtime/bundle 或伪改 ownership.json。卸载不删除业务工程。

ASAM UI Documentation Tool Use License 1.0 为自定义受限许可，见 LICENSE；第三方许可见 runtime/licenses 与 THIRD_PARTY_NOTICES.json。

## 专家包测试

新对话中的工具调用、只读审查、页面开发及芋道接入测试见 [TESTING.md](./TESTING.md)。
