import { writeFileSync, renameSync, existsSync, unlinkSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { noLinks } from './ocr-tool.mjs';

// File receipts and redirected terminals receive the same real stage/byte data.
// A spinner indicates waiting, never fabricated completion percentages.
export function installerProgress({ report, file, stream = process.stderr, intervalMs = 5000 }) {
	const started = Date.now();
	let closed = false,
		tick = 0,
		row = false;
	const persist = () => {
		noLinks(file);
		const incoming = `${file}.progress-${randomUUID()}`;
		writeFileSync(incoming, JSON.stringify(report, null, '\t') + '\n', {
			flag: 'wx',
			mode: 0o600
		});
		try {
			renameSync(incoming, file);
		} finally {
			if (existsSync(incoming)) unlinkSync(incoming);
		}
	};
	const render = (heartbeat = false) => {
		const event = report.progress;
		if (!event) return;
		const elapsed = Math.floor((Date.now() - started) / 1000);
		let bytes = '';
		if (event.phase !== 'connecting' && Number.isFinite(event.receivedBytes)) {
			bytes = `（已下载 ${(event.receivedBytes / 1048576).toFixed(1)} MB）`;
			if (event.totalBytes > 0)
				bytes = ` ${Math.min(100, Math.floor((event.receivedBytes * 100) / event.totalBytes))}%（${(event.receivedBytes / 1048576).toFixed(1)} / ${(event.totalBytes / 1048576).toFixed(1)} MB）`;
		}
		const line = `${heartbeat ? ['|', '/', '-', '\\'][tick++ % 4] + ' ' : ''}${event.message}${bytes}（已用时 ${elapsed} 秒）`;
		if (row) stream.write('\r\x1b[2K');
		const activeRow =
			stream.isTTY && (heartbeat || ['connecting', 'downloading'].includes(event.phase));
		stream.write(line + (activeRow ? '' : '\n'));
		row = Boolean(activeRow);
	};
	const update = (event) => {
		if (closed) return;
		const time = new Date().toISOString();
		if (report.progress?.phase !== event.phase) {
			report.stages ||= [];
			report.stages.push({ phase: event.phase, message: event.message, startedAt: time });
		}
		report.progress = {
			...event,
			updatedAt: time,
			elapsedSeconds: Math.floor((Date.now() - started) / 1000)
		};
		report.updatedAt = time;
		persist();
		render();
	};
	const timer = setInterval(() => {
		if (closed || !report.progress) return;
		try {
			report.progress.elapsedSeconds = Math.floor((Date.now() - started) / 1000);
			report.updatedAt = new Date().toISOString();
			persist();
			render(true);
		} catch (error) {
			// Timer callbacks must never crash a running install or leak its lock.
			stream.write(`\n进度日志更新失败，请保留现场：${error.code || error.message}\n`);
			clearInterval(timer);
		}
	}, intervalMs);
	timer.unref();
	return {
		update,
		close() {
			if (closed) return;
			closed = true;
			clearInterval(timer);
			if (row) stream.write('\n');
			persist();
		}
	};
}
