import {
	cpSync,
	existsSync,
	lstatSync,
	mkdirSync,
	readFileSync,
	renameSync,
	rmSync
} from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { inventory, json, sha } from './files.mjs';

// Operates only on a caller-selected staging slot, not host registries or business projects.
function entryStat(path) {
	try {
		return lstatSync(path);
	} catch (error) {
		if (error.code === 'ENOENT') return null;
		throw error;
	}
}
export function verify(directory) {
	if (entryStat(directory)?.isSymbolicLink()) throw new Error('SYMLINK_NOT_ALLOWED');
	const receipt = json(join(directory, 'ownership.json'));
	if (
		receipt.schemaVersion !== 1 ||
		receipt.owner !== 'asam-ui-development' ||
		!['codex', 'workbuddy'].includes(receipt.host)
	)
		throw new Error('UNKNOWN_OWNER');
	const expected = receipt.files;
	const actual = inventory(directory).filter((f) => f.path !== 'ownership.json');
	if (!Array.isArray(expected)) throw new Error('UNKNOWN_OWNER');
	const before = new Map(expected.map((file) => [file.path, file.sha256]));
	if (
		expected.length > 10000 ||
		before.size !== expected.length ||
		expected.some(
			(file) =>
				typeof file.path !== 'string' ||
				!file.path ||
				isAbsolute(file.path) ||
				file.path.includes('\\') ||
				file.path.split('/').some((part) => !part || part === '..' || part === '.') ||
				file.path === 'ownership.json' ||
				!/^[a-f0-9]{64}$/.test(file.sha256)
		)
	)
		throw new Error('UNKNOWN_OWNER');
	const after = new Map(actual.map((file) => [file.path, file.sha256]));
	const paths = [...new Set([...before.keys(), ...after.keys()])]
		.filter((path) => before.get(path) !== after.get(path))
		.sort();
	if (paths.length) {
		const error = new Error('MODIFIED_CONTENT');
		error.paths = paths;
		throw error;
	}
	return receipt;
}
function checkSlot(slot) {
	if (
		!isAbsolute(slot) ||
		!['codex', 'workbuddy'].includes(slot.split(/[\\/]/).at(-2)) ||
		slot.split(/[\\/]/).at(-1) !== 'asam-ui-development'
	)
		throw new Error('EXPLICIT_HOST_SLOT_REQUIRED');
	// Refuse junctions in all existing ancestors; a lexical path alone is insufficient.
	for (let p = slot; ; p = dirname(p)) {
		if (entryStat(p)?.isSymbolicLink()) throw new Error('SYMLINK_NOT_ALLOWED');
		if (p === dirname(p)) break;
	}
}
export function install(source, slot) {
	if (!isAbsolute(slot)) throw new Error('EXPLICIT_HOST_SLOT_REQUIRED');
	slot = resolve(slot);
	checkSlot(slot);
	if (entryStat(`${slot}.disabled`)) throw new Error('DISABLED_SLOT_EXISTS');
	const sourceOwnershipSHA256 = sha(readFileSync(join(source, 'ownership.json')));
	const incoming = verify(source);
	if (entryStat(`${slot}.incoming`)) throw new Error('RECOVERY_REQUIRED');
	if (slot.split(/[\\/]/).at(-2) !== incoming.host) throw new Error('HOST_MISMATCH');
	if (existsSync(slot)) {
		const old = verify(slot);
		if (old.host !== incoming.host) throw new Error('HOST_MISMATCH');
		if (
			sha(readFileSync(join(source, 'ownership.json'))) ===
			sha(readFileSync(join(slot, 'ownership.json')))
		)
			return { status: 'unchanged' };
	}
	const stage = `${slot}.incoming`;
	const backup = `${slot}.previous`;
	if (entryStat(stage) || entryStat(backup)) throw new Error('RECOVERY_REQUIRED');
	mkdirSync(dirname(slot), { recursive: true });
	cpSync(source, stage, { recursive: true });
	verify(stage);
	if (sha(readFileSync(join(stage, 'ownership.json'))) !== sourceOwnershipSHA256)
		throw new Error('SOURCE_CHANGED');
	const hadPrevious = existsSync(slot);
	if (hadPrevious) renameSync(slot, backup);
	try {
		renameSync(stage, slot);
	} catch (error) {
		if (hadPrevious) renameSync(backup, slot);
		throw error;
	}
	return { status: 'installed', backup: hadPrevious ? backup : null };
}
export function uninstall(slot) {
	if (!isAbsolute(slot)) throw new Error('EXPLICIT_HOST_SLOT_REQUIRED');
	slot = resolve(slot);
	checkSlot(slot);
	if (entryStat(`${slot}.disabled`)) throw new Error('ENABLE_OR_PRESERVE_DISABLED_SLOT');
	if (!existsSync(slot)) return { status: 'absent' };
	const receipt = verify(slot); // Ambiguous/user-modified content is preserved in full.
	if (receipt.host !== slot.split(/[\\/]/).at(-2)) throw new Error('HOST_MISMATCH');
	rmSync(slot, { recursive: true });
	return { status: 'removed' };
}
export function rollback(slot) {
	if (!isAbsolute(slot)) throw new Error('EXPLICIT_HOST_SLOT_REQUIRED');
	slot = resolve(slot);
	checkSlot(slot);
	const current = verify(slot);
	if (!entryStat(`${slot}.previous`) && entryStat(`${slot}.rolled-back`)) {
		const preserved = verify(`${slot}.rolled-back`);
		if (current.host !== slot.split(/[\\/]/).at(-2) || preserved.host !== current.host)
			throw new Error('HOST_MISMATCH');
		return { status: 'unchanged', preserved: `${slot}.rolled-back` };
	}
	const previous = verify(`${slot}.previous`);
	if (current.host !== slot.split(/[\\/]/).at(-2) || previous.host !== current.host)
		throw new Error('HOST_MISMATCH');
	if (entryStat(`${slot}.rolled-back`)) throw new Error('RECOVERY_REQUIRED');
	renameSync(slot, `${slot}.rolled-back`);
	renameSync(`${slot}.previous`, slot);
	return { status: 'restored', preserved: `${slot}.rolled-back` };
}

// These operations rename only verified content. They never register a WorkBuddy expert
// or change Codex settings; disabling a staging slot is not a host UI disable receipt.
export function setEnabled(slot, enabled) {
	if (!isAbsolute(slot)) throw new Error('EXPLICIT_HOST_SLOT_REQUIRED');
	slot = resolve(slot);
	checkSlot(slot);
	const disabled = `${slot}.disabled`;
	const from = enabled ? disabled : slot;
	const to = enabled ? slot : disabled;
	if (entryStat(to)) {
		if (entryStat(from)) throw new Error('RECOVERY_REQUIRED');
		const receipt = verify(to);
		if (receipt.host !== slot.split(/[\\/]/).at(-2)) throw new Error('HOST_MISMATCH');
		return { status: 'unchanged' };
	}
	const receipt = verify(from);
	if (receipt.host !== slot.split(/[\\/]/).at(-2)) throw new Error('HOST_MISMATCH');
	renameSync(from, to);
	return { status: enabled ? 'enabled' : 'disabled', path: to };
}

// A cancelled/interrupted install is inspectable and recoverable without deleting old input.
// resume commits a fully verified incoming directory; cancel preserves it under .cancelled.
export function recover(slot, action) {
	if (!isAbsolute(slot)) throw new Error('EXPLICIT_HOST_SLOT_REQUIRED');
	slot = resolve(slot);
	checkSlot(slot);
	if (!['resume', 'cancel'].includes(action)) throw new Error('ACTION_UNSUPPORTED');
	if (entryStat(`${slot}.disabled`)) throw new Error('DISABLED_SLOT_EXISTS');
	const incoming = `${slot}.incoming`;
	const previous = `${slot}.previous`;
	const cancelled = `${slot}.cancelled`;
	const receipt = (path) => {
		const value = verify(path);
		if (value.host !== slot.split(/[\\/]/).at(-2)) throw new Error('HOST_MISMATCH');
	};
	// Verify every source before the first mutation, including recovery points.
	for (const path of [slot, incoming, previous, ...(action === 'cancel' ? [cancelled] : [])])
		if (entryStat(path)) receipt(path);
	if (action === 'cancel') {
		if (entryStat(incoming)) {
			if (entryStat(cancelled)) throw new Error('RECOVERY_REQUIRED');
			renameSync(incoming, cancelled);
		}
		if (!entryStat(slot) && entryStat(previous)) renameSync(previous, slot);
		return { status: 'cancelled', preserved: entryStat(cancelled) ? cancelled : null };
	}
	if (entryStat(incoming)) {
		if (entryStat(slot)) {
			if (entryStat(previous)) throw new Error('RECOVERY_REQUIRED');
			renameSync(slot, previous);
		}
		renameSync(incoming, slot);
		return { status: 'resumed', backup: entryStat(previous) ? previous : null };
	}
	if (!entryStat(slot) && entryStat(previous)) {
		renameSync(previous, slot);
		return { status: 'restored' };
	}
	if (!entryStat(slot)) throw new Error('RECOVERY_INPUT_MISSING');
	return { status: 'unchanged' };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		const [action, slot, source] = process.argv.slice(2);
		const operations = {
			install: () => install(source, slot),
			uninstall: () => uninstall(slot),
			rollback: () => rollback(slot),
			disable: () => setEnabled(slot, false),
			enable: () => setEnabled(slot, true),
			resume: () => recover(slot, 'resume'),
			cancel: () => recover(slot, 'cancel')
		};
		if (!operations[action]) throw new Error('ACTION_UNSUPPORTED');
		console.log(JSON.stringify(operations[action]()));
	} catch (error) {
		console.error(
			JSON.stringify({
				status: 'fail',
				code: error.message,
				slot: process.argv[3],
				preservedPaths: error.paths
			})
		);
		process.exitCode = 1;
	}
}
