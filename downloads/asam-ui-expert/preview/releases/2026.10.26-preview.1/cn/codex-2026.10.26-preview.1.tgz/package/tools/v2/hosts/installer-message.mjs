// Chinese UI text; retain stable codes and upstream diagnostics for support.
export function installerMessage(error) {
	const detail = String(error?.code || error?.message || error);
	const code = detail.match(/^[A-Z][A-Z0-9_]+/)?.[0];
	const messages = [
		[
			/NODE_FOREIGN_APPLICATION/,
			'不能使用其他应用的私有 Node，请使用当前平台自带 Node 或 PATH 中的系统 Node。'
		],
		[
			/NODE_22|NODE_RUNTIME/,
			'需要 Node.js 22.19 或以上的 22.x 版本，请安装后加入 PATH，再重新运行。'
		],
		[
			/WORKBUDDY_NOT_INSTALLED|WORKBUDDY_APP_/,
			'未找到有效的 WorkBuddy 应用，请检查安装位置并先登录一次。'
		],
		[
			/WORKBUDDY_ACCOUNT_UNKNOWN|INVALID_ACCOUNT_SELECTION/,
			'账号选择无效，请重新运行并选择当前已登录的账号。'
		],
		[/WORKBUDDY_ACCOUNT_REQUIRED/, '请先打开 WorkBuddy 并登录一次，完全退出后再运行安装器。'],
		[/WORKBUDDY_ACCOUNT_SELECTION_REQUIRED/, '检测到多个账号，请重新运行并选择当前账号。'],
		[/WORKBUDDY_RUNNING|WORKBUDDY_RESTARTED/, '请完全退出 WorkBuddy（包括托盘），然后重试。'],
		[/PROCESS_CHECK_FAILED/, '无法确认应用是否已退出，请检查进程状态后重试。'],
		[
			/CODEX_CONFIG_INCOMPATIBLE/,
			'当前 Codex CLI 无法读取现有 config.toml，请核对 CLI 与桌面版本及下方配置错误位置。安装器未修改该配置。'
		],
		[
			/CODEX_CLI_REQUIRED|CODEX_CLI_RESPONSE_UNSUPPORTED/,
			'未找到支持插件安装命令的 Codex CLI，请检查 Codex 安装及版本。'
		],
		[/CODEX_NATIVE_FAILED/, 'Codex 原生命令执行失败，请查看下方诊断。'],
		[/GIT_REQUIRED/, '未找到 Git，请安装并加入 PATH 后重新运行。'],
		[
			/MODIFIED_CONTENT|MANAGED_SOURCE_CHANGED|INSTALLED_SOURCE_CONFLICT/,
			'检测到已安装文件被修改，已停止操作并保留原件，请先核对修改。'
		],
		[
			/CONFLICT|UNMANAGED_INSTALLATION|MULTIPLE_INSTALLATIONS/,
			'检测到现有安装或配置冲突，已保留原件，请先核对归属。'
		],
		[
			/STATE_INVALID|PLUGIN_IDENTITY|PACKAGE_REQUIRED|MISMATCH|INCOMPLETE|OUTPUT_EXISTS/,
			'安装包或安装记录校验未通过，请保留现场并使用完整、匹配的安装包。'
		],
		[
			/SYMLINK|ABSOLUTE_PATH|INDEPENDENT_BACKUP|INVALID_/,
			'路径或参数无效，请检查绝对路径、链接和安装参数。'
		],
		[/DISK_SPACE/, '安装目录剩余空间不足，请释放空间后重试。'],
		[
			/PREVIOUS_INSTALLATION|BUSY|EEXIST/,
			'检测到未结束的安装现场或正在执行的任务，请保留日志并核对后重试。'
		],
		[/CHANGED/, '操作期间文件或配置发生变化，已停止操作，请核对后重试。'],
		[/OCR_|TOOL_/, 'OCR 工具准备或规则自检未通过，请检查网络、工具路径及日志后重试。'],
		[/EACCES|EPERM/, '没有访问所需文件的权限，请检查目录权限后重试。']
	];
	const message =
		messages.find(([pattern]) => pattern.test(detail))?.[1] ||
		'操作未完成，已保留现场，请查看日志中的具体原因后重试。';
	return `${message}${code ? `（${code}）` : ''}\n原始诊断：${detail}`;
}

export function ocrDownloadMessage(result) {
	if (!result?.download) return '';
	const { url, error } = result.download;
	const reasons = [];
	const visit = (value) => {
		if (!value) return;
		if (value.code) reasons.push(value.code);
		if (value.message) reasons.push(value.message);
		if (value.status) reasons.push(`HTTP ${value.status}`);
		visit(value.cause);
		for (const item of value.errors || []) visit(item);
	};
	visit(error);
	const detail = reasons.join('；');
	let message = 'OCR 下载或校验未完成，请查看下方诊断后重试。';
	if (/TOOL_DOWNLOAD_HASH|TOOL_DOWNLOAD_SIZE/.test(result.code))
		message = 'OCR 文件大小或摘要校验不通过，已保留现场，不会执行该文件。';
	else if (/TIMEOUT|timed?\s?out|Timeout/i.test(detail))
		message = '连接或下载 OCR 超时，请检查网络及代理设置后重试。';
	else if (/ENOTFOUND|EAI_AGAIN/.test(detail))
		message = '无法解析 OCR 下载服务器域名，请检查 DNS 和网络连接。';
	else if (/CERT|TLS|SSL|SELF_SIGNED|UNABLE_TO_VERIFY/i.test(detail))
		message = 'OCR 下载连接的证书或 TLS 校验失败，请检查系统时间、证书及代理设置。';
	else if (/HTTP \d+/.test(detail))
		message = 'OCR 下载服务器返回异常状态，请稍后重试或检查网络访问限制。';
	const mirror = result.download.mirrorFailure;
	return `${message}\n下载地址：${url}\n下载诊断：${detail}${mirror ? `\n国内镜像诊断：${mirror.url}；${mirror.code || mirror.message}` : ''}`;
}
