# ASAM UI 开发专家

用于 Vue 3 工程的 ASAM UI 组件查询、页面修改、接入与版本诊断。当前专家包装版本 0.1.0-alpha.19，配对核心/UI 仍为 0.1.0-alpha.1。维护者：ASAM UI <zwq8299174@126.com>。

## 开始使用

1. 安装可在 PATH 中运行的 Node.js 22.19.x。目标 Vue 工程使用 pnpm 管理自己的依赖。
2. 保持解压目录完整，通过Codex 支持的本地插件入口加载本包。请勿只复制 Agent 文本或移动 runtime/bundle 子目录。
3. 打开目标工程，对专家说：“检查这个 Vue 工程，查找适用的 ASAM UI 表单组件，先给出修改建议。”也可以说：“为当前列表页增加筛选，保留我已有的改动。”
4. 在宿主中确认本地 asam-ui MCP 服务可用，再查询组件配方。实际界面中的服务发现仍需现场确认；专家可见不等于工具已经连接。

## 工具连接与回退

MCP 声明位于根 .mcp.json。Codex CLI 将显式 cwd: . 绑定到已安装插件根，启动文件及资料使用相对该根的路径；不依赖 MCP 对插件变量做替换。Node22.19.x 必须可运行。CLI 原生加载与桌面界面结果分别记录。

运行依赖已打包在 runtime 中，无需安装包内依赖或联网下载；Node.js 仍是前置条件。这不代表模型或业务工程可离线工作。MCP 暂不可用时，可在 PowerShell 使用同源只读 CLI：

```powershell
$expert = 'E:/你的解压目录/asam-ui-development'
pnpm --config.verify-deps-before-run=error exec node "$expert/skills/asam-ui-development/scripts/agent.mjs" discover '{"query":"按钮","version":"0.1.0-alpha.1"}'
pnpm --config.verify-deps-before-run=error exec node "$expert/skills/asam-ui-development/scripts/agent.mjs" read '{"id":"ui.button","section":"recipe","version":"0.1.0-alpha.1"}'
```

inspect/diagnose 需明确的工程路径；migration 需明确的 from/to 版本对。工具只读检查，不执行业务源码或配置。资料缺失、版本不匹配或无能力匹配会明确返回失败/未支持；请恢复完整配套包，不混用其他候选。当前能力和已知限制见 Skill，详细配方按需 read；精确版本、来源和摘要见 provenance.json 与 bundle/manifest.json。

## 更新、卸载与许可

Codex 原生命令 plugin remove 会删除安装缓存中的用户修改；不要直接用该命令或桌面卸载来处理可能改过的缓存。受支持的流程是从可信解压包运行 tools/safe-codex-remove.mjs，传入JSON计划文件：codexHome为实际绝对配置根、baseline为本可信解压包目录、marketplace为实际市场名、backup为配置根和包目录之外不存在的新备份目录、binary为明确codex可执行文件、execute为false先预检。脚本保存完整缓存及receipt.json，精确列出modified/added/missing路径；有任何差异就停止，不调用原生卸载。审核并在维护源码中合并所需修改后，用新备份目录和execute:true重新执行；即使无差异也先验证完整备份再委托原生remove。不要删除修改或伪改清单来绕过检查。保留备份，不自动回写宿主注册；有多个缓存版本、链接或未知归属时停止并人工核实。操作期间停止修改该缓存，脚本不提供跨进程文件锁。卸载不删除业务工程或依赖。若更新失败，保留原件并核对恢复步骤。

本包使用 ASAM UI Documentation Tool Use License 1.0（自定义受限许可，见 LICENSE），并非 MIT/Apache 或通用开源授权。第三方组件按其各自许可分发；runtime/licenses 和 runtime/THIRD_PARTY_NOTICES.json 保留对应声明及来源。

## 当前验证入口

本包包含固定051共享核心及同源profile，安装准备仍不代表真实宿主任务通过。自然语言任务按Skill自动进入三模式流程；具体契约见bundle/validation-contract.md。独立检查保持产品只读。

同源CLI包装：scripts/agent.mjs的参数为操作、JSON对象、明确绝对工程或检查点路径（脚本完整位置为skills/asam-ui-development/scripts/agent.mjs）。validation-ocr只需output附件目录，包装自动准备固定工具descriptor，不接收用户手填descriptor。编程式宿主适配从tools/v2/hosts/agent-entry.mjs导入loadValidationCore，再消费共享核心；宿主提供真实检查/模型审查/候选修复及权限。

MCP配置为本包启用ASAM_AGENT_VALIDATION=1，只增加只读agent_validation_plan；未设置该开关的原生服务保持原工具集合。MCP不暴露命令执行、产品写入或任意shell。宿主权限和用户取消优先；缺能力/必需结果仍partial。

## 专家包测试

新对话中的工具调用、只读审查、页面开发及芋道接入测试见 [TESTING.md](./TESTING.md)。
