await (await import('../../../tools/v2/hosts/agent-entry.mjs')).main();
