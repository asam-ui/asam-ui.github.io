import { spawn, spawnSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { write } from './files.mjs';

// A protocol probe of the installed service, not host trust or selected-model
// execution. Uses bundled runtime and Node only; no package install is needed.
export async function probeMcp(server, { cwd = homedir(), timeoutMs = 15000 } = {}) {
	const child = spawn(server.command, server.args, {
		cwd,
		env: { ...process.env, ...server.env },
		windowsHide: true,
		stdio: ['pipe', 'pipe', 'pipe']
	});
	const pending = new Map();
	let sequence = 0,
		buffer = '',
		stderr = '',
		outputBytes = 0;
	const fail = (error) => {
		for (const item of pending.values()) {
			clearTimeout(item.timer);
			item.reject(error);
		}
		pending.clear();
	};
	child.on('error', fail);
	child.on('exit', () => fail(Error('MCP_PROCESS_EXITED')));
	child.stdin.on('error', fail);
	child.stderr.on('data', (bytes) => {
		stderr = (stderr + bytes).slice(-32768);
	});
	child.stdout.on('data', (bytes) => {
		outputBytes += bytes.length;
		if (outputBytes > 1024 * 1024) {
			fail(Error('MCP_OUTPUT_LIMIT'));
			child.kill();
			return;
		}
		buffer += bytes;
		for (let end; (end = buffer.indexOf('\n')) >= 0;) {
			const line = buffer.slice(0, end);
			buffer = buffer.slice(end + 1);
			if (!line.trim()) continue;
			try {
				const message = JSON.parse(line),
					item = pending.get(message.id);
				if (!item) continue;
				pending.delete(message.id);
				clearTimeout(item.timer);
				if (message.error) item.reject(Error(`MCP_RPC_${message.error.code}`));
				else item.resolve(message.result);
			} catch {
				fail(Error('MCP_INVALID_JSON'));
			}
		}
	});
	const request = (method, params) =>
		new Promise((resolveResult, reject) => {
			const id = ++sequence;
			const timer = setTimeout(() => {
				pending.delete(id);
				reject(Error('MCP_PROBE_TIMEOUT'));
			}, timeoutMs);
			pending.set(id, { resolve: resolveResult, reject, timer });
			child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
		});
	try {
		await request('initialize', {
			protocolVersion: '2024-11-05',
			capabilities: {},
			clientInfo: { name: 'asam-ui-installer', version: '1' }
		});
		child.stdin.write(
			JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n'
		);
		const listed = await request('tools/list', {});
		const names = listed.tools?.map((tool) => tool.name) || [];
		if (names.length !== 10 || !names.includes('agent_validation_plan'))
			throw Error('MCP_TOOL_SET_MISMATCH');
		for (const [name, args] of [
			['agent_discover', { query: '按钮', limit: 1 }],
			['agent_read', { id: 'ui.button', section: 'recipe' }]
		]) {
			const result = await request('tools/call', { name, arguments: args });
			if (result.isError || JSON.parse(result.content?.[0]?.text || '{}').status !== 'pass')
				throw Error('MCP_TOOL_CALL_FAILED');
		}
		return { status: 'pass', tools: names, discover: 'pass', read: 'pass', stderr };
	} finally {
		fail(Error('MCP_PROBE_CLOSED'));
		child.stdin.end();
		if (child.exitCode === null) child.kill();
	}
}

export function ocrProbe(binary, output) {
	const project = join(output, 'ocr-project');
	mkdirSync(project, { recursive: true });
	write(join(project, 'probe.mjs'), 'export const value = 1;\n');
	const run = (command, args) =>
		spawnSync(command, args, {
			cwd: project,
			encoding: 'utf8',
			timeout: 30000,
			windowsHide: true,
			env: { ...process.env, OCR_NO_UPDATE: '1' }
		});
	const git = run('git', ['-c', 'init.templateDir=', 'init', '-q']);
	if (git.error || git.status !== 0)
		return {
			status: 'partial',
			code: 'OCR_PROBE_REQUIRES_GIT',
			action: '安装或启用 Git 后重新双击同一入口'
		};
	for (const [name, args] of [
		['preview', ['delegate', 'preview', '--format', 'json', '--repo', project]],
		['rules', ['delegate', 'rule', '--format', 'json', '--repo', project, 'probe.mjs']]
	]) {
		const result = run(binary, args);
		write(join(output, `ocr-${name}.json`), result.stdout || '{}');
		if (result.error || result.status !== 0)
			return {
				status: 'partial',
				code: 'OCR_RULE_PROBE_FAILED',
				action: '核对安装日志和 Git，重试同一入口'
			};
		const value = JSON.parse(result.stdout);
		if (
			name === 'preview' &&
			!value.reviewable_files?.some((item) => item.path === 'probe.mjs')
		)
			throw Error('OCR_PREVIEW_INCOMPLETE');
		if (name === 'rules' && !value.groups?.some((group) => group.files.includes('probe.mjs')))
			throw Error('OCR_RULES_INCOMPLETE');
	}
	return {
		status: 'pass',
		preview: 'pass',
		rules: 'pass',
		semanticReview: 'requires-selected-model'
	};
}
