import { existsSync, readFileSync, realpathSync } from 'node:fs';
import { dirname, isAbsolute, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { noLinks, toolchain } from './ocr-tool.mjs';

// This observes only the current process and explicitly selected binaries, never user homes/profiles.
export function environment({ host, hostVersion, hostShape, pnpmCLI } = {}) {
	const issues = [];
	const [major, minor] = process.versions.node.split('.').map(Number);
	if (major !== 22 || minor < 19)
		issues.push({ code: 'NODE_VERSION', action: '使用 Node >=22.19.0 <23 的运行环境' });
	if (toolchain.platforms[`${process.platform}-${process.arch}`]?.preparation !== 'supported')
		issues.push({ code: 'PLATFORM_NOT_VALIDATED', action: '使用支持矩阵中已验证的平台' });
	if (!['codex', 'workbuddy'].includes(host))
		issues.push({ code: 'HOST_UNSUPPORTED', action: '选择 Codex 或 WorkBuddy 支持范围' });
	if (!hostVersion || !hostShape)
		issues.push({
			code: 'HOST_OBSERVATION_REQUIRED',
			action: '由实际宿主界面或原生命令确认版本与形态'
		});
	let pnpm = { status: 'partial', code: 'PNPM_PATH_REQUIRED' };
	if (!pnpmCLI) {
		const root = dirname(realpathSync(process.execPath));
		pnpmCLI = ['mjs', 'cjs']
			.map((ext) => join(root, `node_modules/pnpm/bin/pnpm.${ext}`))
			.find(existsSync);
	}
	if (pnpmCLI) {
		try {
			noLinks(pnpmCLI);
			// Resolve the known pnpm distribution CLI, not a shell shim or an arbitrary project script.
			if (!isAbsolute(pnpmCLI)) throw Error('PNPM_PATH_REQUIRED');
			const root = dirname(dirname(realpathSync(pnpmCLI)));
			const metadata = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
			if (
				metadata.name !== 'pnpm' ||
				metadata.version !== '11.9.0' ||
				!/[\\/]bin[\\/]pnpm\.(?:cjs|mjs)$/.test(pnpmCLI)
			)
				throw Error('PNPM_VERSION');
			const result = spawnSync(process.execPath, [pnpmCLI, '--version'], {
				encoding: 'utf8',
				timeout: 10000,
				windowsHide: true,
				env: { ...process.env, pnpm_config_verify_deps_before_run: 'error' }
			});
			if (result.error || result.status !== 0 || result.stdout.trim() !== '11.9.0')
				throw Error('PNPM_NOT_EXECUTABLE');
			const policy = spawnSync(
				process.execPath,
				[
					pnpmCLI,
					'--config.verify-deps-before-run=error',
					'config',
					'get',
					'verify-deps-before-run'
				],
				{
					encoding: 'utf8',
					timeout: 10000,
					windowsHide: true,
					env: { ...process.env, pnpm_config_verify_deps_before_run: 'error' }
				}
			);
			if (policy.error || policy.status !== 0 || policy.stdout.trim() !== 'error')
				throw Error('PNPM_VERIFICATION_POLICY');
			pnpm = {
				status: 'pass',
				version: metadata.version,
				cli: realpathSync(pnpmCLI),
				verifyDepsBeforeRun: 'error'
			};
		} catch (error) {
			pnpm = { status: 'partial', code: error.code ?? error.message };
		}
	}
	if (pnpm.status !== 'pass')
		issues.push({
			code: pnpm.code,
			action: '使用锁定的 pnpm 11.9.0 安装，再从原准备检查点继续'
		});
	return {
		status: issues.length ? 'partial' : 'pass',
		platform: process.platform,
		arch: process.arch,
		node: { version: process.version, executable: realpathSync(process.execPath) },
		pnpm,
		temporaryDirectory: tmpdir(),
		host: {
			name: host ?? null,
			version: hostVersion ?? null,
			shape: hostShape ?? null,
			evidence: 'caller-observation; not host execution proof'
		},
		issues
	};
}
