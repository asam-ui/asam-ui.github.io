import {
	existsSync,
	mkdirSync,
	readFileSync,
	realpathSync,
	writeFileSync,
	renameSync,
	openSync,
	closeSync,
	unlinkSync
} from 'node:fs';
import { dirname, isAbsolute, join, resolve, relative, sep } from 'node:path';
import { homedir } from 'node:os';
import { randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { noLinks, hostToolDefaults, prepareTool } from './ocr-tool.mjs';
import { assertHostRuntime } from './host-runtime.mjs';
import { installerMessage, ocrDownloadMessage } from './installer-message.mjs';
import { installerProgress } from './installer-progress.mjs';
import { verify } from './lifecycle.mjs';
import { inventory, json, sha, write } from './files.mjs';
import { probeMcp, ocrProbe } from './installer-probes.mjs';
import { safeCodexRemove } from './safe-codex-remove.mjs';

const name = 'asam-ui-development',
	marketplace = 'asam-ui-local',
	pluginId = `${name}@${marketplace}`;
const pathKey = (path) => {
	const value = resolve(path.replace(/^\\\\\?\\/, ''));
	return process.platform === 'win32' ? value.toLowerCase() : value;
};
const hashFile = (path) => sha(readFileSync(path));
function atomic(path, value, previous) {
	noLinks(path);
	const current = existsSync(path) ? readFileSync(path) : null;
	if (previous === null ? current !== null : current === null || !current.equals(previous))
		throw Error('CODEX_INSTALLER_CONFIG_CHANGED');
	const incoming = `${path}.incoming-${randomUUID()}`;
	writeFileSync(incoming, JSON.stringify(value, null, '\t') + '\n', { flag: 'wx', mode: 0o600 });
	try {
		renameSync(incoming, path);
	} finally {
		if (existsSync(incoming)) unlinkSync(incoming);
	}
}
function copy(source, target) {
	for (const file of inventory(source))
		write(join(target, file.path), readFileSync(join(source, file.path)));
	verify(target);
}
function native(binary, codexHome, args) {
	const result = spawnSync(binary, args, {
		cwd: codexHome,
		env: { ...process.env, CODEX_HOME: codexHome },
		encoding: 'utf8',
		windowsHide: true,
		timeout: 60000,
		maxBuffer: 2 * 1024 * 1024
	});
	if (result.error || result.status !== 0) {
		const detail = result.error?.message || result.stderr || result.stdout;
		if (/failed to load configuration|invalid type:.*expected a boolean/.test(detail))
			throw Error(
				`CODEX_CONFIG_INCOMPATIBLE: 当前 Codex CLI 无法读取现有配置，请核对 CLI 与桌面版本及 config.toml 指定位置；安装器未修改该配置。CLI：${binary}\n原始诊断：${detail}`
			);
		throw Error(
			`CODEX_NATIVE_FAILED: Codex 原生命令执行失败（${args.slice(0, 3).join(' ')}）。\n原始诊断：${detail}`
		);
	}
	return JSON.parse(result.stdout);
}
function observation(binary, codexHome) {
	const markets = native(binary, codexHome, [
		'plugin',
		'marketplace',
		'list',
		'--json'
	]).marketplaces;
	const plugins = native(binary, codexHome, [
		'plugin',
		'list',
		'--marketplace',
		marketplace,
		'--json'
	]).installed;
	if (!Array.isArray(markets) || !Array.isArray(plugins))
		throw Error('CODEX_CLI_RESPONSE_UNSUPPORTED');
	const selected = markets.filter((item) => item.name === marketplace);
	if (selected.length > 1 || plugins.some((item) => item.pluginId !== pluginId))
		throw Error('CODEX_MARKETPLACE_CONFLICT');
	if (plugins.length > 1) throw Error('CODEX_MULTIPLE_INSTALLATIONS');
	return { market: selected[0], installed: plugins[0] };
}
function validateState(state, codexHome, observed) {
	if (!state) {
		if (observed.market || observed.installed)
			throw Error(
				'CODEX_UNMANAGED_INSTALLATION: preserve existing installation and review its source'
			);
		return;
	}
	if (
		state.schemaVersion !== 1 ||
		state.owner !== name ||
		typeof state.root !== 'string' ||
		!isAbsolute(state.root) ||
		!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(state.version || '')
	)
		throw Error('CODEX_INSTALLER_STATE_INVALID');
	const rel = relative(join(codexHome, 'asam-ui', 'marketplaces'), resolve(state.root));
	if (!rel || isAbsolute(rel) || rel === '..' || rel.startsWith(`..${sep}`))
		throw Error('CODEX_INSTALLER_STATE_INVALID');
	noLinks(state.root);
	const base = join(state.root, 'codex', name);
	if (
		verify(base).host !== 'codex' ||
		json(join(base, '.codex-plugin/plugin.json')).version !== state.version ||
		hashFile(join(base, 'ownership.json')) !== state.ownershipSHA256 ||
		hashFile(join(state.root, '.agents/plugins/marketplace.json')) !== state.catalogSHA256
	)
		throw Error('CODEX_MANAGED_SOURCE_CHANGED');
	if (observed.market && pathKey(observed.market.root) !== pathKey(state.root))
		throw Error('CODEX_MARKETPLACE_CONFLICT');
	if (observed.installed) {
		if (observed.installed.version !== state.version || observed.installed.enabled !== true)
			throw Error('CODEX_INSTALLED_STATE_CONFLICT');
		const installed = join(codexHome, 'plugins/cache', marketplace, name, state.version);
		noLinks(installed);
		verify(installed);
		if (hashFile(join(installed, 'ownership.json')) !== state.ownershipSHA256)
			throw Error('CODEX_INSTALLED_SOURCE_CONFLICT');
	}
}
function removeOwned(binary, codexHome, state, backupRoot, report) {
	const backup = join(backupRoot, `remove-${randomUUID()}`);
	const result = safeCodexRemove({
		codexHome,
		baseline: join(state.root, 'codex', name),
		marketplace,
		backup,
		binary,
		execute: true
	});
	report.backups.push(backup);
	if (result.status !== 'removed-preserved') throw Error(`CODEX_REMOVE_${result.status}`);
}

export async function runCodexOneClick({
	source,
	binary,
	codexHome = process.env.CODEX_HOME || join(homedir(), '.codex'),
	backupRoot = process.env.ASAM_CODEX_BACKUP_ROOT || join(homedir(), '.asam-ui-backups/codex'),
	action = 'install',
	allowDownload = true
} = {}) {
	if (!['install', 'uninstall'].includes(action)) throw Error('INVALID_INSTALL_ACTION');
	assertHostRuntime('codex');
	if (typeof binary !== 'string' || !isAbsolute(binary)) throw Error('CODEX_CLI_REQUIRED');
	binary = realpathSync(binary);
	for (const path of [source, binary, codexHome, backupRoot]) {
		if (typeof path !== 'string' || !isAbsolute(path)) throw Error('ABSOLUTE_PATH_REQUIRED');
		noLinks(path);
	}
	source = resolve(source);
	codexHome = resolve(codexHome);
	backupRoot = resolve(backupRoot);
	for (const parent of [source, codexHome]) {
		const rel = relative(parent, backupRoot);
		if (!rel || (!isAbsolute(rel) && rel !== '..' && !rel.startsWith(`..${sep}`)))
			throw Error('INDEPENDENT_BACKUP_REQUIRED');
	}
	binary = realpathSync(binary);
	if (verify(source).host !== 'codex') throw Error('CODEX_PACKAGE_REQUIRED');
	const [major, minor] = process.versions.node.split('.').map(Number);
	if (major !== 22 || minor < 19) throw Error('NODE_22_19_OR_LATER_REQUIRED');
	const metadata = json(join(source, '.codex-plugin/plugin.json'));
	const version = metadata.version;
	if (
		metadata.name !== name ||
		!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(version || '')
	)
		throw Error('CODEX_PLUGIN_IDENTITY');
	const executable = spawnSync(binary, ['--version'], {
		encoding: 'utf8',
		timeout: 10000,
		windowsHide: true
	});
	if (executable.error || executable.status !== 0 || !/^codex-cli \d+\./m.test(executable.stdout))
		throw Error('CODEX_CLI_REQUIRED');
	mkdirSync(codexHome, { recursive: true });
	const manager = join(codexHome, 'asam-ui');
	noLinks(manager);
	mkdirSync(manager, { recursive: true });
	const lock = join(manager, 'installer.lock');
	noLinks(lock);
	const statePath = join(manager, 'installer-state.json');
	noLinks(statePath);
	const output = join(manager, 'receipts', randomUUID());
	noLinks(output);
	mkdirSync(output, { recursive: true });
	const report = {
		schemaVersion: 1,
		action,
		version,
		codexVersion: executable.stdout.trim(),
		codexBinary: binary,
		node: realpathSync(process.execPath),
		codexHome,
		output,
		backups: [],
		hostUi: 'pending',
		selectedModelSkill: 'pending',
		hostTrust: 'user-action-if-requested'
	};
	const fd = openSync(lock, 'wx');
	report.status = 'running';
	const progress = installerProgress({ report, file: join(output, 'INSTALLATION.json') });
	try {
		progress.update({
			phase: 'host-registration',
			message: '正在读取 Codex 插件登记；每条宿主命令最长等待 60 秒…'
		});
		let stateBytes = existsSync(statePath) ? readFileSync(statePath) : null;
		let state = stateBytes ? JSON.parse(stateBytes.toString('utf8')) : null;
		let observed = observation(binary, codexHome);
		validateState(state, codexHome, observed);
		if (action === 'uninstall') {
			progress.update({
				phase: 'uninstall',
				message: '正在检查并备份已有插件，然后卸载本插件…'
			});
			if (observed.installed) removeOwned(binary, codexHome, state, backupRoot, report);
			if (observed.market)
				native(binary, codexHome, [
					'plugin',
					'marketplace',
					'remove',
					marketplace,
					'--json'
				]);
			observed = observation(binary, codexHome);
			if (observed.installed || observed.market)
				throw Error('CODEX_UNINSTALL_VERIFICATION_FAILED');
			report.operation = state && report.backups.length ? 'removed' : 'absent';
		} else {
			progress.update({ phase: 'prerequisites', message: '正在检查 Git 和工具配置…' });
			const git = spawnSync('git', ['--version'], {
				encoding: 'utf8',
				timeout: 10000,
				windowsHide: true
			});
			if (git.error || git.status !== 0) throw Error('GIT_REQUIRED_FOR_OCR');
			const settingsPath = join(codexHome, 'asam-ui-tools.json');
			noLinks(settingsPath);
			const settingsBytes = existsSync(settingsPath) ? readFileSync(settingsPath) : null;
			const settings = settingsBytes ? JSON.parse(settingsBytes.toString('utf8')) : {};
			if (
				!settings ||
				typeof settings !== 'object' ||
				Array.isArray(settings) ||
				Object.keys(settings).some(
					(key) => !['cacheRoot', 'binary', 'downloadTimeoutMs'].includes(key)
				)
			)
				throw Error('INVALID_HOST_TOOL_SETTINGS');
			const defaults = hostToolDefaults('codex', process.env, settings);
			report.ocr = await prepareTool({
				...defaults,
				allowDownload,
				onProgress: progress.update
			});
			if (report.ocr.status !== 'pass')
				throw Error(`OCR_PREPARATION_${report.ocr.code || report.ocr.status}`);
			progress.update({ phase: 'deploying', message: '正在校验并部署插件文件…' });
			const node = realpathSync(process.execPath);
			const reusable =
				state &&
				state.inputOwnershipSHA256 === hashFile(join(source, 'ownership.json')) &&
				state.node === node &&
				state.ocrBinary === report.ocr.binary;
			if (!reusable) {
				const root = join(manager, 'marketplaces', `${version}-${randomUUID()}`);
				noLinks(root);
				const base = join(root, 'codex', name);
				copy(source, base);
				const mcpPath = join(base, '.mcp.json'),
					mcp = json(mcpPath);
				if (
					mcp.mcpServers?.['asam-ui']?.command !== 'node' ||
					mcp.mcpServers['asam-ui'].cwd !== '.'
				)
					throw Error('CODEX_MCP_DESCRIPTOR_MISMATCH');
				mcp.mcpServers['asam-ui'].command = node;
				mcp.mcpServers['asam-ui'].env = {
					...mcp.mcpServers['asam-ui'].env,
					ASAM_TOOLS_CONFIG_DIR: codexHome,
					ASAM_OCR_CACHE_ROOT: defaults.cacheRoot,
					ASAM_OCR_BINARY: report.ocr.binary
				};
				write(mcpPath, mcp);
				const owner = json(join(base, 'ownership.json'));
				owner.files = inventory(base).filter((item) => item.path !== 'ownership.json');
				write(join(base, 'ownership.json'), owner);
				verify(base);
				write(join(root, '.agents/plugins/marketplace.json'), {
					name: marketplace,
					interface: { displayName: 'ASAM UI' },
					plugins: [
						{
							name,
							source: { source: 'local', path: `./codex/${name}` },
							policy: { installation: 'AVAILABLE', authentication: 'ON_INSTALL' },
							category: 'Developer Tools'
						}
					]
				});
				if (observed.installed) removeOwned(binary, codexHome, state, backupRoot, report);
				if (observed.market)
					native(binary, codexHome, [
						'plugin',
						'marketplace',
						'remove',
						marketplace,
						'--json'
					]);
				state = {
					schemaVersion: 1,
					owner: name,
					root,
					version,
					node,
					ocrBinary: report.ocr.binary,
					inputOwnershipSHA256: hashFile(join(source, 'ownership.json')),
					ownershipSHA256: hashFile(join(base, 'ownership.json')),
					catalogSHA256: hashFile(join(root, '.agents/plugins/marketplace.json'))
				};
				atomic(statePath, state, stateBytes);
				stateBytes = readFileSync(statePath);
				observed = observation(binary, codexHome);
			}
			progress.update({
				phase: 'registering',
				message: '正在更新 Codex 本地市场及插件登记；每条宿主命令最长等待 60 秒…'
			});
			if (!observed.market)
				native(binary, codexHome, ['plugin', 'marketplace', 'add', state.root, '--json']);
			if (!observed.installed)
				native(binary, codexHome, ['plugin', 'add', pluginId, '--json']);
			atomic(statePath, state, stateBytes);
			const settingsValue = {
				cacheRoot: defaults.cacheRoot,
				binary: report.ocr.binary,
				downloadTimeoutMs: defaults.downloadTimeoutMs
			};
			if (
				settingsBytes &&
				settingsBytes.toString('utf8') !== JSON.stringify(settingsValue, null, '\t') + '\n'
			) {
				const backup = join(backupRoot, `settings-${randomUUID()}.json`);
				noLinks(backup);
				mkdirSync(dirname(backup), { recursive: true });
				writeFileSync(backup, settingsBytes, { flag: 'wx', mode: 0o600 });
				report.backups.push(backup);
			}
			atomic(settingsPath, settingsValue, settingsBytes);
			observed = observation(binary, codexHome);
			validateState(state, codexHome, observed);
			if (!observed.installed) throw Error('CODEX_PLUGIN_NOT_INSTALLED');
			const installed = join(codexHome, 'plugins/cache', marketplace, name, state.version);
			const service = json(join(installed, '.mcp.json')).mcpServers['asam-ui'];
			progress.update({
				phase: 'mcp-probe',
				message: '正在连接 MCP、列出工具并调用 discover/read…'
			});
			report.mcp = await probeMcp(service, { cwd: installed });
			progress.update({ phase: 'ocr-probe', message: '正在执行 OCR 选文件与规则解析自检…' });
			report.ocrProbe = ocrProbe(report.ocr.binary, output);
			if (report.ocrProbe.status !== 'pass') throw Error('OCR_RULE_PROBE_FAILED');
			report.operation =
				reusable && report.backups.length === 0 ? 'unchanged-or-restored' : 'installed';
			report.installed = installed;
		}
		report.status = 'pass';
		progress.update({
			phase: 'complete',
			message: action === 'uninstall' ? '插件卸载完成。' : '插件安装及 MCP/OCR 自检全部完成。'
		});
	} catch (error) {
		report.status = 'partial';
		report.code = error.code || error.message;
		progress.update({
			phase: 'failed',
			message: '操作未完成，具体原因及当前阶段已保存到日志。'
		});
	} finally {
		try {
			progress.close();
		} finally {
			closeSync(fd);
			unlinkSync(lock);
		}
	}
	return report;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		const report = await runCodexOneClick({
			source: resolve(dirname(fileURLToPath(import.meta.url)), '../../..'),
			binary: process.env.ASAM_CODEX_BINARY,
			action: process.env.ASAM_INSTALL_ACTION || 'install',
			allowDownload: process.env.ASAM_INSTALL_ALLOW_DOWNLOAD !== '0'
		});
		console.log(
			report.status === 'pass'
				? report.action === 'uninstall'
					? 'Codex 插件已卸载，共享工具及备份保留。'
					: 'Codex 插件安装与 MCP/OCR 自检通过。请重新打开 Codex 并新建对话测试。'
				: installerMessage(report.code)
		);
		console.log(`结果：${join(report.output, 'INSTALLATION.json')}`);
		if (report.status !== 'pass' && report.ocr?.download)
			console.error(ocrDownloadMessage(report.ocr));
		process.exitCode = report.status === 'pass' ? 0 : 2;
	} catch (error) {
		console.error(installerMessage(error));
		process.exitCode = 2;
	}
}
