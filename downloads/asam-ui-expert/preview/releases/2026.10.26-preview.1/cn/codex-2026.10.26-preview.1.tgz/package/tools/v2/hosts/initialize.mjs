import { readFileSync, realpathSync } from 'node:fs';
import { isAbsolute, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { environment } from './environment.mjs';
import { prepareTool } from './ocr-tool.mjs';
import { install, verify } from './lifecycle.mjs';
import { installedValidation } from './validation-payload.mjs';

// This prepares an explicit isolated package slot. Host registration/permissions remain
// with the actual host UI. Shared validation rules, model calls and task state belong to 051.
export async function initialize({
	source,
	slot,
	hostObservation = {},
	pnpmCLI,
	tool = {},
	signal
} = {}) {
	const pending = (code, action, results = {}) => ({
		status: 'partial',
		code,
		action,
		...results
	});
	if (signal?.aborted) return pending('CANCELLED', '从同一安装输入继续');
	if (
		typeof source !== 'string' ||
		typeof slot !== 'string' ||
		!isAbsolute(source) ||
		!isAbsolute(slot)
	)
		return pending('EXPLICIT_HOST_SLOT_REQUIRED', '选择完整套件和独立绝对安装目录');
	try {
		const receipt = verify(source);
		const inside = (parent, child) => {
			const path = relative(parent, child);
			return (
				path === '' || (!isAbsolute(path) && path !== '..' && !path.startsWith(`..${sep}`))
			);
		};
		if (
			inside(realpathSync(source), resolve(slot)) ||
			inside(resolve(slot), realpathSync(source))
		)
			return pending('SEPARATE_HOST_SLOT_REQUIRED', '选择与分发源完全分离的安装目录');
		const observed = environment({ ...hostObservation, host: receipt.host, pnpmCLI });
		if (observed.status !== 'pass')
			return pending('ENVIRONMENT_INCOMPLETE', '完成列明的最小环境动作后继续', {
				environment: observed
			});
		const prepared = await prepareTool({ ...tool, signal });
		if (prepared.status !== 'pass')
			return { ...prepared, environment: observed, installed: false };
		if (signal?.aborted)
			return pending('CANCELLED', '从同一安装输入继续，已核工具可复用', { tool: prepared });
		const installed = install(source, slot);
		const validation = installedValidation(slot);
		// A core handoff must explicitly bind validation content to its fixed package manifest.
		// 006 packages are valid inputs for environment work but cannot satisfy the new loop gate.
		return pending(
			validation ? 'HOST_VALIDATION_NOT_RUN' : 'FIXED_VALIDATION_INPUT_REQUIRED',
			validation
				? '安装准备就绪；在当前宿主授权下按同源流程执行真实任务'
				: '消费051冻结候选并核同版本资料后执行真实宿主任务',
			{
				environment: observed,
				tool: prepared,
				installed,
				ready: Boolean(validation),
				validationProfile: validation
					? {
							id: validation.profile,
							version: validation.version,
							fingerprint: validation.fingerprint
						}
					: null,
				ocrDescriptor: {
					executable: prepared.binary,
					version: prepared.version,
					sha256: prepared.sha256,
					platform: process.platform,
					arch: process.arch
				},
				hostRegistration: 'NOT_RUN',
				validation: 'NOT_RUN',
				source,
				slot
			}
		);
	} catch (error) {
		return pending(error.code ?? error.message, '保留原件，核明确路径或恢复点后继续', {
			preservedPaths: error.paths ?? []
		});
	}
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	const result = await initialize(JSON.parse(readFileSync(process.argv[2], 'utf8')));
	console.log(JSON.stringify(result));
	process.exitCode = result.status === 'pass' ? 0 : 1;
}
