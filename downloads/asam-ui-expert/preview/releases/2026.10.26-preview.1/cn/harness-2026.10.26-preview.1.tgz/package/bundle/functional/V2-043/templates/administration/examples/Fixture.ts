import { reactive } from 'vue';
import type { AsamCrudServices, AsamCrudCodec } from '@asam-ui/pro';
import type {
	AdministrationServices,
	Entity,
	GrantNode,
	GrantOperation,
	GrantResult,
	GrantSnapshot,
	Id,
	MenuRow,
	Query,
	RoleRow,
	UserRow
} from '../Types.js';
import { directoryUser, catalogUser } from '../Codecs.js';
import { validateTree } from '../Tree.js';

export type Outcome = 'success' | 'failure' | 'conflict' | 'unknown-applied' | 'unknown-unapplied';
/** Fully local synthetic service. No endpoint, credentials or real account writes. */
export function createSyntheticServices(format: 'directory' | 'catalog' = 'directory') {
	const controls = reactive({
		delay: 100,
		readError: false,
		refreshError: false,
		outcome: 'success' as Outcome,
		verifyUnknown: false,
		malformedTree: false,
		partial: false,
		label: '合成用户',
		unknownRoles: 'preserve' as 'preserve' | 'reject'
	});
	const metrics = reactive({
		pending: 0,
		reads: 0,
		creates: 0,
		updates: 0,
		removes: 0,
		grants: 0,
		verifies: 0,
		events: [] as {
			name: string;
			start: number;
			end: number;
			scope: string;
			operationId?: string;
		}[]
	});
	let next = 1000;
	const stores = new Map<
		string,
		{ users: Map<Id, UserRow>; roles: Map<Id, RoleRow>; menus: Map<Id, MenuRow> }
	>();
	const writeResults = new Map<string, boolean>(),
		removeResults = new Map<string, boolean>();
	const grantStores = new Map<string, { version: number; direct: Id[] }>(),
		grantResults = new Map<string, GrantResult>();
	const identity = (...parts: unknown[]) => JSON.stringify(parts);
	const idAt = (i: number): Id => (i === 1 ? '0' : i);
	function store(scope: string) {
		let data = stores.get(scope);
		if (!data) {
			data = {
				users: new Map(
					Array.from({ length: 100 }, (_, i) => {
						// Both actual DTO adapters participate in ordinary service list/load/write.
						const m = {
							name: `${controls.label}${i}`,
							account: `member-${i}`,
							status: i % 3 ? '启用' : '停用',
							roleIds: [idAt(i % 30)],
							context: '示例空间',
							note: '可替换的合成资料',
							version: 1
						};
						const row =
							format === 'directory'
								? directoryUser.from({ uid: idAt(i), ...directoryUser.to(m) })
								: catalogUser.from({ key: idAt(i), ...catalogUser.to(m) });
						return [row.id, row];
					})
				),
				roles: new Map(
					Array.from({ length: 30 }, (_, i) => [
						idAt(i),
						{
							id: idAt(i),
							name: `协作角色${i}`,
							code: `role-${i}`,
							enabled: '启用',
							members: `${i + 2} 项合成引用（后端最终裁决）`,
							note: '仅前端展示关联',
							context: '示例空间',
							version: 1
						}
					])
				),
				menus: new Map(
					Array.from({ length: 50 }, (_, i) => [
						idAt(i),
						{
							id: idAt(i),
							parentId: i === 0 ? null : idAt(Math.floor((i - 1) / 3)),
							title: `权限节点${i}`,
							kind: i < 17 ? '结构' : '操作',
							permissionCode: `sample:${i}`,
							enabled: i % 9 === 0 ? '停用' : '启用',
							grantable: i < 17 ? '否' : '是',
							version: 1
						}
					])
				)
			};
			stores.set(scope, data);
		}
		return data;
	}
	async function wait(name: string, scope: string, operationId?: string) {
		metrics.pending++;
		const event = { name, scope, operationId, start: performance.now(), end: 0 };
		await new Promise((r) => setTimeout(r, controls.delay));
		metrics.pending--;
		event.end = performance.now();
		metrics.events.push(event);
	}
	function nodes(scope: string): GrantNode[] {
		return [...store(scope).menus.values()].map((n) => ({
			...n,
			enabled: n.enabled === '启用',
			grantable: n.grantable === '是'
		}));
	}
	function generic<Row extends { id: Id; version: number }, Edit extends { version: number }>(
		entity: Entity,
		rows: (scope: string) => Map<Id, Row>,
		defaults: () => Edit,
		normalize?: (edit: Readonly<Edit>, id: Id) => Row
	): AsamCrudServices<Row, Query, Edit, Id> {
		async function save(model: Readonly<Edit>, scope: string, operationId: string, id?: Id) {
			const mode = controls.outcome,
				key = id ?? ++next;
			await wait(`${entity}:${id === undefined ? 'create' : 'update'}`, scope, operationId);
			const previous = rows(scope).get(key);
			if (mode === 'failure')
				return {
					status: 'failure' as const,
					message: '服务确认拒绝，未应用',
					issues: [
						{ key: entity === 'menus' ? 'title' : 'name', message: '请检查输入名称' }
					]
				};
			if (
				mode === 'conflict' ||
				(id !== undefined && (!previous || previous.version !== model.version))
			)
				return { status: 'failure' as const, message: '版本冲突，确认未应用；请重新加载' };
			if (entity === 'users') {
				const m = model as unknown as UserRow;
				if (
					controls.unknownRoles === 'reject' &&
					m.roleIds.some((k) => !store(scope).roles.has(k))
				)
					return { status: 'failure' as const, message: '服务策略拒绝未知角色，未应用' };
			}
			let row: Row;
			try {
				row = normalize ? normalize(model, key) : ({ ...model, id: key } as unknown as Row);
			} catch {
				return { status: 'failure' as const, message: '字段映射无效，确认未应用' };
			}
			row.version = (previous?.version ?? 0) + 1;
			if (entity === 'menus') {
				try {
					const all = new Map(store(scope).menus);
					all.set(key, row as unknown as MenuRow);
					validateTree(
						[...all.values()].map((n) => ({
							...n,
							enabled: n.enabled === '启用',
							grantable: n.grantable === '是'
						}))
					);
				} catch {
					return { status: 'failure' as const, message: '菜单结构无效，确认未应用' };
				}
			}
			const applied = mode !== 'unknown-unapplied';
			if (applied) rows(scope).set(key, structuredClone(row));
			writeResults.set(identity(scope, operationId), applied);
			if (controls.refreshError) controls.readError = true;
			return mode.startsWith('unknown')
				? { status: 'unknown' as const, message: '响应未知，请核实原操作' }
				: { status: 'success' as const, data: { id: key } };
		}
		return {
			async list(q, c) {
				metrics.reads++;
				const snapshot = [...rows(c.scope).values()].map((r) => structuredClone(r));
				await wait(`${entity}:list`, c.scope);
				if (controls.readError) throw new Error('模拟读取失败');
				const result = snapshot.filter((r) => {
					const m = r as unknown as Record<string, unknown>;
					return (
						(!q.query.keyword ||
							String(m.name ?? m.title).includes(q.query.keyword) ||
							String(m.account ?? m.code ?? '').includes(q.query.keyword)) &&
						(!q.query.status || String(m.status ?? m.enabled) === q.query.status) &&
						(q.query.role === null ||
							(Array.isArray(m.roleIds) && m.roleIds.includes(q.query.role))) &&
						(!q.query.context || String(m.context ?? '').includes(q.query.context))
					);
				});
				return {
					list: result.slice(
						(q.currentPage - 1) * q.pageSize,
						q.currentPage * q.pageSize
					),
					total: result.length
				};
			},
			async defaults(c) {
				await wait(`${entity}:defaults`, c.scope);
				return defaults();
			},
			async load(k, c) {
				await wait(`${entity}:load`, c.scope);
				if (controls.readError) throw new Error('模拟加载失败');
				const row = rows(c.scope).get(k);
				if (!row) throw new Error('记录不存在');
				const { id: _id, ...edit } = row;
				return structuredClone(edit) as unknown as Edit;
			},
			create(m, o, c) {
				metrics.creates++;
				return save(m, c.scope, o.target.operationId);
			},
			update(k, m, o, c) {
				metrics.updates++;
				return save(m, c.scope, o.target.operationId, k);
			},
			async verify(o) {
				metrics.verifies++;
				await wait(`${entity}:verify`, o.scope, o.target.operationId);
				return controls.verifyUnknown
					? { status: 'unknown' }
					: writeResults.get(identity(o.scope, o.target.operationId))
						? { status: 'success' }
						: { status: 'not-applied' };
			},
			async resolve(keys, c) {
				return keys.map((key) => {
					const r = rows(c.scope).get(key);
					return r
						? {
								key,
								target: {
									key,
									version: String(r.version),
									payload: { id: key, version: r.version }
								}
							}
						: { key, reason: '记录不存在' };
				});
			},
			async remove(t, s) {
				metrics.removes++;
				const mode = controls.partial && t.key === '0' ? 'failure' : controls.outcome;
				await wait(`${entity}:remove`, s.context.scope, s.operationId);
				const r = rows(s.context.scope).get(t.key);
				if (
					mode === 'failure' ||
					mode === 'conflict' ||
					!r ||
					String(r.version) !== t.version ||
					(entity === 'menus' &&
						[...store(s.context.scope).menus.values()].some((n) =>
							Object.is(n.parentId, t.key)
						))
				)
					return {
						key: t.key,
						status: 'failure',
						message: '拒绝、被引用或版本冲突，确认未应用'
					};
				const applied = mode !== 'unknown-unapplied';
				if (applied) rows(s.context.scope).delete(t.key);
				removeResults.set(identity(s.context.scope, s.operationId, t.key), applied);
				return { key: t.key, status: mode.startsWith('unknown') ? 'unknown' : 'success' };
			},
			async verifyRemove(t, s) {
				metrics.verifies++;
				await wait(`${entity}:verifyRemove`, s.context.scope, s.operationId);
				return {
					key: t.key,
					status: controls.verifyUnknown
						? 'unknown'
						: removeResults.get(identity(s.context.scope, s.operationId, t.key))
							? 'success'
							: 'unsent'
				};
			}
		};
	}
	const users = generic<UserRow, Omit<UserRow, 'id'>>(
		'users',
		(s) => store(s).users,
		() => ({
			name: '',
			account: '',
			status: '启用',
			roleIds: [],
			context: '示例空间',
			note: '',
			version: 0
		}),
		(m, id) =>
			format === 'directory'
				? directoryUser.from({ uid: id, ...directoryUser.to(m) })
				: catalogUser.from({ key: id, ...catalogUser.to(m) })
	);
	const roles = generic<RoleRow, Omit<RoleRow, 'id'>>(
		'roles',
		(s) => store(s).roles,
		() => ({
			name: '',
			code: '',
			enabled: '启用',
			members: '尚无合成引用',
			note: '',
			context: '示例空间',
			version: 0
		})
	);
	const menus = generic<MenuRow, Omit<MenuRow, 'id'>>(
		'menus',
		(s) => store(s).menus,
		() => ({
			parentId: null,
			title: '',
			kind: '操作',
			permissionCode: '',
			enabled: '启用',
			grantable: '是',
			version: 0
		})
	);
	function grantRecord(scope: string, subject: Id) {
		const key = identity(scope, subject);
		let record = grantStores.get(key);
		if (!record) {
			record = { version: 1, direct: [18, 27, 'legacy'] };
			grantStores.set(key, record);
		}
		return record;
	}
	/** Directory stores full assignments; catalog host applies an explicit set delta. */
	function applyGrant(op: GrantOperation, record: { version: number; direct: Id[] }) {
		if (format === 'directory') record.direct = [...op.direct];
		else {
			const removed = record.direct.filter((id) => !op.direct.includes(id)),
				added = op.direct.filter((id) => !record.direct.includes(id));
			record.direct = record.direct.filter((id) => !removed.includes(id)).concat(added);
		}
		record.version++;
	}
	const services: AdministrationServices = {
		version: `${format}-1`,
		users: { crud: users },
		roles: { crud: roles },
		menus: { crud: menus },
		async roleOptions(r) {
			await wait('roles:options', r.scope);
			if (controls.readError) throw new Error('模拟读取失败');
			return [...store(r.scope).roles.values()].map((n) => ({
				id: n.id,
				name: n.name,
				enabled: n.enabled === '启用'
			}));
		},
		async menuNodes(r) {
			await wait('menus:tree', r.scope);
			if (controls.readError) throw new Error('模拟读取失败');
			const all = nodes(r.scope);
			return controls.malformedTree ? [...all, all[0]!] : all;
		},
		grants: {
			async load(subject, r): Promise<GrantSnapshot> {
				const record = grantRecord(r.scope, subject),
					direct = [...record.direct],
					v = record.version;
				await wait('grant:load', r.scope);
				if (controls.readError) throw new Error('模拟读取失败');
				return {
					subject,
					scope: r.scope,
					version: String(v),
					direct,
					nodes: controls.malformedTree
						? [...nodes(r.scope), nodes(r.scope)[0]!]
						: nodes(r.scope),
					unavailable: 'preserve'
				};
			},
			async save(op, r) {
				metrics.grants++;
				const mode = controls.outcome;
				await wait('grant:save', r.scope, op.operationId);
				const record = grantRecord(op.scope, op.subject);
				if (mode === 'failure') return { status: 'failure', reason: 'denied' };
				if (mode === 'conflict' || String(record.version) !== op.version)
					return { status: 'failure', reason: 'conflict' };
				const previous = record.direct.filter(
					(id) =>
						!nodes(op.scope).some(
							(n) => Object.is(n.id, id) && n.enabled && n.grantable
						)
				);
				if (
					previous.some((id) => !op.direct.includes(id)) ||
					op.direct.some(
						(id) =>
							!record.direct.includes(id) &&
							!nodes(op.scope).some(
								(n) => Object.is(n.id, id) && n.enabled && n.grantable
							)
					)
				)
					return { status: 'failure', reason: 'validation' };
				if (mode !== 'unknown-unapplied') applyGrant(op, record);
				const result: GrantResult =
					mode === 'unknown-unapplied'
						? { status: 'failure', reason: 'validation' }
						: { status: 'success', version: String(record.version) };
				grantResults.set(op.operationId, result);
				return mode.startsWith('unknown') ? { status: 'unknown' } : result;
			},
			async verify(op, r) {
				metrics.verifies++;
				await wait('grant:verify', r.scope, op.operationId);
				return controls.verifyUnknown
					? { status: 'unknown' }
					: (grantResults.get(op.operationId) ?? { status: 'unknown' });
			}
		}
	};
	return { services, controls, metrics };
}
