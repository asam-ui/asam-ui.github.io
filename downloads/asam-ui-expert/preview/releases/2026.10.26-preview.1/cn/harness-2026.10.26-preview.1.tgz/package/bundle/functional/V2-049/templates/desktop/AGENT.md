# Agent：新增或修改浏览器桌面

1. 确认当前模板来源SHA、UI/Pro 0.1.0-alpha.1及Vue/EP版本；先读本目录capability→API，再按需读Desktop与一个族SFC。停用工具套件不改变应用运行依赖。
2. 将业务意图拆为本地panel id/标题/权限/状态/slot内容与宿主请求。已有菜单继续交032导航；029页面状态容器承接loading/empty/error。只把布局交034 cache；不要把theme/locale与任意业务字段混写。
3. 普通配置修改入口examples/config.ts。替换一个面板时更新typed allowlist和ExamplePanel/SFC，不把URL/远端字符串变成组件；业务服务由宿主注入，AbortController在内容卸载时取消。新增面板不要求新增MCP或Skill。
4. 选择一个族修改布局与文案，保ASAM token、四尺寸、业务控件语义及只读/权限。检查模板与types同步。三族各自可编辑，公共Stage变更需三族回归。
5. 精确保存normal源、实际file tar/锁/安装metadata/生产dist；实际修改title、notes标题、初始坐标和示例正文，重新typecheck/build后在真实生产页面核显示、拖缩放、草稿与键盘/窄屏；冻结modified后从normal原字节还原并再验证。不要只改测试oracle或静态截图。
6. 按tests/v2/desktop配方跑正常包、类型正反、状态/权限、双身份/双实例、坏存储、迟到回调、销毁与预算；记录首FAIL/未测，不能重采first追绿。发现工具/版本/网络/数据失败分别定位。没有独立QA/ACC不得把DEV自测称整卡验收。
7. 新旧接口迁移时diff Types/Desktop/Stage，明确旧schema默认/重置与宿主数据边界。重复执行接入只更新自己目录，保留用户现有布局/规范/配置；共享出口/官网/Agent索引提精确proposal给原owner。

可判错误：把Preferences写成任意layout字段；用字符串拼接混淆owner 0与'0'；将隐藏面板当后端鉴权；把窄屏尺寸覆写宽屏rect；最小化通过v-if销毁内容；不用同版CSS或alias作者源码；异步save后直接写当前新scope。报告具体文件/方法、后果、预期与回归用例。

本卡普通Agent修改任务只读本地资料和源码，不调用在线模型/账户/付费或上传源码。Codex/WorkBuddy实际安装和双宿主全量结果属于052，本卡仅交同源方法与普通工程修改证据，不冒跨宿主通过。
