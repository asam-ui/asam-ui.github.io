import type {
	SocialAuthor,
	SocialComment,
	SocialId,
	SocialOutcome,
	SocialPage,
	SocialPost
} from './Types.js';
import type { SocialWrite } from './Types.js';
export const idKey = (id: SocialId) => JSON.stringify([typeof id, id]);
const validId = (id: unknown) =>
	(typeof id === 'number' && Number.isFinite(id)) || (typeof id === 'string' && !!id.trim());
const count = (n: unknown) => typeof n === 'number' && Number.isSafeInteger(n) && n >= 0;
const optionalText = (s: unknown) => s === undefined || typeof s === 'string';
export function validWrite(action: SocialWrite) {
	if (!action || !validId(action.postId)) return false;
	if (action.kind === 'like' || action.kind === 'bookmark')
		return typeof action.desired === 'boolean' && count(action.version);
	if (action.kind === 'comment')
		return (
			typeof action.body === 'string' && !!action.body.trim() && action.body.length <= 10000
		);
	return action.kind === 'delete' && validId(action.commentId);
}
function image(image: { src: string; alt: string } | undefined) {
	if (
		image !== undefined &&
		(!image ||
			typeof image.src !== 'string' ||
			!/^\.?\.?\//.test(image.src) ||
			image.src.startsWith('//') ||
			/[\\\u0000-\u0020\u007f]/.test(image.src) ||
			typeof image.alt !== 'string')
	)
		throw Error('图片必须是本地资源及替代文本');
}
function author(a: SocialAuthor) {
	if (!a || !validId(a.id) || !optionalText(a.name)) throw Error('作者数据无效');
	image(a.avatar);
}
export function post(p: SocialPost): SocialPost {
	if (
		!p ||
		!validId(p.id) ||
		typeof p.body !== 'string' ||
		!optionalText(p.time) ||
		typeof p.liked !== 'boolean' ||
		typeof p.bookmarked !== 'boolean' ||
		!count(p.likes) ||
		!count(p.comments) ||
		!count(p.version)
	)
		throw Error('帖子数据无效');
	author(p.author);
	image(p.cover);
	return structuredClone(p);
}
export function comment(c: SocialComment, postId: SocialId): SocialComment {
	if (
		!c ||
		!validId(c.id) ||
		c.postId !== postId ||
		typeof c.body !== 'string' ||
		!optionalText(c.time) ||
		typeof c.canDelete !== 'boolean'
	)
		throw Error('评论数据无效');
	author(c.author);
	return structuredClone(c);
}
export function page<T extends { id: SocialId }>(
	value: SocialPage<T>,
	validate: (row: T) => T
): SocialPage<T> {
	if (
		!value ||
		!Array.isArray(value.list) ||
		!count(value.total) ||
		value.total < value.list.length
	)
		throw Error('分页数据无效');
	const rows = value.list.map(validate),
		keys = rows.map((r) => idKey(r.id));
	if (new Set(keys).size !== keys.length) throw Error('标识重复');
	return { list: rows, total: value.total };
}
export function outcome(value: SocialOutcome, postId: SocialId): SocialOutcome {
	if (!value || !['success', 'failed', 'unknown'].includes(value.status))
		throw Error('操作结果无效');
	if (value.status === 'success') {
		const row = post(value.post);
		if (row.id !== postId) throw Error('操作对象不匹配');
		return { status: 'success', post: row };
	}
	if (value.status === 'failed') {
		const message = value.message;
		if (typeof message !== 'string') throw Error('失败结果无效');
		return { status: 'failed', message };
	}
	return { status: 'unknown' };
}
