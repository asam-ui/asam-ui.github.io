<template>
	<section ref="container" class="navigation-embed" aria-label="内嵌页面">
		<form @submit.prevent="open(address)">
			<label>嵌入地址 <input v-model="address" type="url"></label>
			<button type="submit">打开地址</button>
			<button type="button" :disabled="pending" @click="toggleFullscreen">
				{{ fullscreen ? '退出全屏' : '全屏' }}
			</button>
		</form>
		<p role="status" aria-live="polite">{{ status }}</p>
		<iframe
			v-if="session"
			:key="session.id"
			:src="session.url"
			:data-navigation-session="session.id"
			:title="title ?? '内嵌内容'"
			:sandbox="policy.sandbox ?? ''"
			:allow="policy.permissions ?? ''"
			:referrerpolicy="policy.referrerPolicy ?? 'no-referrer'"
			@load="onLoad"
			@error="onError"
		/>
	</section>
</template>
<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue';
import type { EmbedPolicy } from './Types.js';
const props = defineProps<{ src: string; policy: EmbedPolicy; title?: string }>();
const emit = defineEmits<{ (event: 'status', status: string): void }>();
const address = ref(props.src);
const status = ref('未加载');
const container = ref<HTMLElement>();
const pending = ref(false);
const fullscreen = ref(false);
let generation = 0;
let disposed = false;
const session = shallowRef<{ id: number; url: string }>();
function belongsToCurrent(event: Event) {
	return (
		!disposed &&
		event.currentTarget instanceof HTMLIFrameElement &&
		event.currentTarget.dataset.navigationSession === String(generation)
	);
}
function onLoad(event: Event) {
	if (belongsToCurrent(event)) report('文档 load 已发生；远端应用状态未知');
}
function onError(event: Event) {
	if (belongsToCurrent(event)) report('嵌入加载失败，请检查地址或站点策略');
}
function report(message: string) {
	if (!disposed) {
		status.value = message;
		emit('status', message);
	}
}
function open(input: string) {
	const id = ++generation;
	session.value = undefined;
	try {
		const url = new URL(props.policy.resolve(input));
		if (
			!['http:', 'https:'].includes(url.protocol) ||
			url.username ||
			url.password ||
			!props.policy.allow(url)
		)
			throw new Error();
		report('正在加载嵌入文档');
		session.value = { id, url: url.href };
	} catch {
		report('地址无效或宿主策略拒绝，可修改地址重试');
	}
}
function syncFullscreen() {
	fullscreen.value = document.fullscreenElement === container.value;
}
async function toggleFullscreen() {
	if (pending.value || disposed) return;
	const element = container.value;
	if (!element?.requestFullscreen || !document.fullscreenEnabled) {
		report('当前环境不支持全屏或未授予权限');
		return;
	}
	pending.value = true;
	try {
		if (document.fullscreenElement === element) await document.exitFullscreen();
		else await element.requestFullscreen();
		if (disposed && document.fullscreenElement === element) await document.exitFullscreen();
	} catch {
		report('全屏请求被拒绝，请由用户再次操作或检查嵌入权限');
	} finally {
		pending.value = false;
		if (!disposed) syncFullscreen();
	}
}
onMounted(() => {
	document.addEventListener('fullscreenchange', syncFullscreen);
	open(props.src);
});
watch(
	() => [props.src, props.policy] as const,
	() => {
		address.value = props.src;
		open(props.src);
	}
);
onBeforeUnmount(() => {
	disposed = true;
	generation++;
	session.value = undefined;
	document.removeEventListener('fullscreenchange', syncFullscreen);
	if (document.fullscreenElement === container.value)
		void document.exitFullscreen().catch(() => {});
});
defineExpose({ open, toggleFullscreen });
</script>
<style scoped>
.navigation-embed {
	background: var(--el-bg-color);
	color: var(--el-text-color-primary);
	padding: 12px;
}
form {
	display: flex;
	gap: 8px;
	flex-wrap: wrap;
}
iframe {
	width: 100%;
	height: 60vh;
	border: 1px solid var(--el-border-color);
}
</style>
