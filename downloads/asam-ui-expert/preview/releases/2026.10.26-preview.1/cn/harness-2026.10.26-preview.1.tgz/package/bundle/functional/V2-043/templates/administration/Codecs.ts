import type { AsamCrudCodec, AsamFieldDefinition, AsamFieldModel } from '@asam-ui/pro';
import type { UserEdit, RoleEdit, MenuEdit, Id } from './Types.js';
import { fields, stringField as text, versionValue, denseArray } from './Validation.js';
import { isId } from './Tree.js';
const ids = (v: unknown): Id[] => {
	denseArray(v);
	if (!v.every(isId) || new Set(v).size !== v.length) throw new Error('角色集合无效');
	return [...v];
};
const version = (m: Readonly<Record<string, unknown>>) => versionValue(m.version);
const userKeys = ['name', 'account', 'status', 'roleIds', 'context', 'note', 'version'];
const roleKeys = ['name', 'code', 'enabled', 'members', 'note', 'context', 'version'];
const menuKeys = ['parentId', 'title', 'kind', 'permissionCode', 'enabled', 'grantable', 'version'];
export const versionField: AsamFieldDefinition = {
	key: 'version',
	label: '版本',
	kind: 'text',
	modes: { edit: { hidden: true } },
	submitHidden: true,
	submit: (value) => {
		if (typeof value !== 'string' || !/^(0|[1-9]\d*)$/.test(value))
			throw new Error('版本输入无效');
		return versionValue(Number(value));
	}
};
export const userCodec: AsamCrudCodec<UserEdit> = {
	encode: (m) => {
		fields(m, userKeys);
		const valid = userCodec.decode(m);
		return { ...valid, roleIds: [...valid.roleIds], version: String(valid.version) };
	},
	decode: (m) => {
		fields(m, userKeys);
		return {
			name: text(m, 'name'),
			account: text(m, 'account'),
			status: text(m, 'status'),
			roleIds: ids(m.roleIds),
			context: text(m, 'context'),
			note: text(m, 'note'),
			version: version(m)
		};
	}
};
export const roleCodec: AsamCrudCodec<RoleEdit> = {
	encode: (m) => {
		fields(m, roleKeys);
		const valid = roleCodec.decode(m);
		return { ...valid, version: String(valid.version) };
	},
	decode: (m) => {
		fields(m, roleKeys);
		return {
			name: text(m, 'name'),
			code: text(m, 'code'),
			enabled: text(m, 'enabled'),
			members: text(m, 'members'),
			note: text(m, 'note'),
			context: text(m, 'context'),
			version: version(m)
		};
	}
};
export const menuCodec: AsamCrudCodec<MenuEdit> = {
	encode: (m) => {
		fields(m, menuKeys);
		const valid = menuCodec.decode(m);
		return { ...valid, version: String(valid.version) };
	},
	decode: (m) => {
		fields(m, menuKeys);
		const p = m.parentId;
		if (p !== null && !isId(p)) throw new Error('父节点无效');
		return {
			parentId: p,
			title: text(m, 'title'),
			kind: text(m, 'kind'),
			permissionCode: text(m, 'permissionCode'),
			enabled: text(m, 'enabled'),
			grantable: text(m, 'grantable'),
			version: version(m)
		};
	}
};
/** Explicit alternate host DTOs; IDs retain their original number/string type. */
export interface DirectoryUserDTO {
	uid: Id;
	display: string;
	login: string;
	active: boolean;
	associations: Id[];
	area: string;
	memo: string;
	revision: number;
}
export interface CatalogUserDTO {
	key: Id;
	profile: { title: string; handle: string };
	state: 'open' | 'closed';
	groups: Id[];
	zone: string;
	annotation: string;
	etag: number;
}
export const directoryUser = {
	from: (d: DirectoryUserDTO) => {
		fields(d, [
			'uid',
			'display',
			'login',
			'active',
			'associations',
			'area',
			'memo',
			'revision'
		]);
		if (!isId(d.uid) || typeof d.active !== 'boolean') throw new Error('目录用户字段无效');
		return {
			id: d.uid,
			name: text(d, 'display'),
			account: text(d, 'login'),
			status: d.active ? '启用' : '停用',
			roleIds: ids(d.associations),
			context: text(d, 'area'),
			note: text(d, 'memo'),
			version: versionValue(d.revision)
		};
	},
	to: (m: Readonly<UserEdit>): Omit<DirectoryUserDTO, 'uid'> => {
		fields(m, userKeys);
		userCodec.decode(m);
		if (!['启用', '停用'].includes(m.status)) throw new Error('目录状态映射无效');
		return {
			display: m.name,
			login: m.account,
			active: m.status === '启用',
			associations: [...m.roleIds],
			area: m.context,
			memo: m.note,
			revision: m.version
		};
	}
};
export const catalogUser = {
	from: (d: CatalogUserDTO) => {
		fields(d, ['key', 'profile', 'state', 'groups', 'zone', 'annotation', 'etag']);
		fields(d.profile, ['title', 'handle']);
		if (!isId(d.key) || !['open', 'closed'].includes(d.state))
			throw new Error('目录用户字段无效');
		return {
			id: d.key,
			name: text(d.profile, 'title'),
			account: text(d.profile, 'handle'),
			status: d.state === 'open' ? '启用' : '停用',
			roleIds: ids(d.groups),
			context: text(d, 'zone'),
			note: text(d, 'annotation'),
			version: versionValue(d.etag)
		};
	},
	to: (m: Readonly<UserEdit>): Omit<CatalogUserDTO, 'key'> => {
		fields(m, userKeys);
		userCodec.decode(m);
		if (!['启用', '停用'].includes(m.status)) throw new Error('目录状态映射无效');
		return {
			profile: { title: m.name, handle: m.account },
			state: m.status === '启用' ? 'open' : 'closed',
			groups: [...m.roleIds],
			zone: m.context,
			annotation: m.note,
			etag: m.version
		};
	}
};
export function decodeUserPayload(model: Readonly<AsamFieldModel>) {
	return userCodec.decode(model);
}
