# Agent 配方

发现入口：capability.json；公开类型：Types.ts；API.md 和 README.md 同版。

1. 明确 app、owner typed tuple、业务 scope 和 storage 的所有权；禁止认证数据缓存。
2. 配完整字典与 fallbackLocale、可选 initial/force、系统媒体；传有效 colorMode 与显式 EP locale 给真实 Provider。
3. 复制完整 examples 与 navigation，安装真实双包和 Vue Router；不要修改共享控制器或把 title 翻译当路由标识。
4. 变更 home/title 字典和初始偏好/TTL，类型正负用例、正常/修改生产构建及浏览器操作后恢复原件并比 hash。
5. 验证坏/未来/迁移/抛错、scope/TTL/clear 晚到、业务清理保偏好、双实例/系统监听、四尺寸/窄屏/焦点。
6. 只把固定候选与证据交独立 QA；OCR delegate 由 QA 执行，再独立 ACC。不得自行宣称验收。

限制及迁移精确见 README.md；完整模板 recipe 不要求 CL 或 033 认证模块。

整改配方：偏好成功/缓存失败、偏好失败/缓存成功、双方失败须分别验证中英归属及切语言；按 namespace 注入独立故障，先核失败不落盘，再核真实成功写入恢复及 foreign/草稿保持。status-browser.mjs 在生产包执行这些正负对照；verify.ps1 -Freeze 在修改恢复前保存完整阶段。
