# V2-053 完整DEV送测报告

2026-10-19（Asia/Shanghai）。**完整DEV候选自测通过；F053-01、F053-02、F053-02b均关闭，自有剩余缺口0。** 独立OCR/QA/ACC、codex/v2集入与资源收尾尚未执行，由原TC接续；没有新增角色、子代理或心跳。

## 固定来源与职责

- 原始base：3f07c7582c6be38ee22ef86783b7022adf31e316。首次两次实际HEAD相同，开工干净。本地分支codex/v2-053-dev-r1；最终完整送测HEAD固定于本报告提交后生成的delta-plain/FINAL-DEV-DELIVERY.json。
- 原DEV产品08fe9219f50598c8ce7e92a6b92c4a67bec12c5c仅修Tour声明。完整正常UI JS/声明源为2f8ecc78fb48d694222e5d0d0991d6edb9fb5105。
- root共享6623d292817fa3dc1cf1f6c7c5d5593568c6721a在本分支精确择取为43352fe9eefbd8c06820ddb7322864c065aa7ef4，只含tokens、样式、包README。root CSS d5c81504700c699a71c7c0391bf78b99c8d3c413择取为51810e4d1de3dc5c5504e517c4405e7e7cb760ac，仅plain两项前景specificity。没有择取其他治理提交、并写共享源或改031产品。
- 实际chat01a1543f-0b42-7092-a5fd-c66abc68e351、f604项目、独立E:/worktree-tmp/5aaf/asam-ui；native turn_context实核Sol/high、danger-full-access/never及成功工程工具，app项目已回读。native-preflight/project-environment保留，不用提示词冒配置。
- 无.codegraph，使用rg未初始化索引。29原始输入逐固定Git字节核对，授权共享差额另按root hash/Git blob配对。001/031仅继承精简报告/固定小回执，不访问、恢复、重扫旧归档角色、安装、raw或保护残留。

## 实现与闭环

F053-01：正常包Tour组件声明原props为{}，独立AsamTourProps完整却仍使真实$props.modelValue报TS2339。改为既有明确类型defineProps<AsamTourProps>()，继续raw vnode委托；正常包15原生props、两个slots及实例清单一致，正反类型及真实打开/键盘关闭/模型/slot通过。首失败包和日志保留。

F053-02：合法暗色surface使实心foreground变rgb(20,20,20)。root新增可选color.onSolid，默认既有白色，与surface分工；六实心真实为primary/success/warning/danger/info/gradient，accent为tonal未改。正常新UI在light、仅surface变暗、dark、显式onSolid的六类型均通过；完整旧theme省略新字段并移除旧显式前景后，恢复默认白色且inline旧字段已移除。33项观察完整保留，其中首轮两plain失败单列。

F053-02b：正常EP高specificity覆盖plain显式onSolid hover/active，仍白色。root仅把两项文字变量移入.asam-button.is-plain，其他plain优先级不变。最终新CSS正常包定点：hover/active均rgb(245,230,99)，各自背景严格等于首轮实测值，移出后静态前景恢复品牌rgb(122,49,92)，pageerror=0。等待真实有限CSS过渡结束采样；初帧假PASS、稳定首FAIL和plain首FAIL都保留。

## BASE及共同Q完整范围

完整入口/来源/职责映射见CONTRACTS.md，迁移见MIGRATION.md，Agent方法见AGENT.md。142深入口、146 JS出口、207根运行符号、1285声明仅是索引；结论来自真实正常导入、完整契约解析、26直接原生alias所有options引用身份、职责分支、同字节有效接受与实际差额，不用数量或attrs代替行为。

| 要求           | 最终DEV结果及证据                                                                                                                                                          |
| -------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| BASE-01 / Q-01 | PASS适用完整范围；source-audit/public-contracts逐入口/公开类型/原生身份及职责拆分，Tour正常包补差；未变能力按有效接受和原生限制继承                                        |
| BASE-02 / Q-04 | PASS；40/36/32/28高度、16/14/14/12字号、20/18/16/14 Button padding、图标/非单行例外、组件→Group→Form→Provider/031桥、嵌套/动态/清空回退、partial/null/light-dark及前景差额 |
| BASE-03 / Q-08 | PASS；原生/ASAM扩展/Pro可辨，正常包TS/JS完整SFC、同版本Agent方法；UI不引Agent                                                                                              |
| BASE-04 / Q-09 | PASS；Tour类型恢复、onSolid行为来源/理由/替代/迁移与前后消费；旧完整主题可省略字段，无扩大删除接口                                                                         |
| Q-02           | PASS适用加载/禁用/只读/空错/卸载恢复；无新权限业务，031只继承原边界                                                                                                        |
| Q-03           | PASS本地模型/事件/slot/键盘点击一致；新请求时序/真实业务提交/后端不适用                                                                                                    |
| Q-05           | PASS名称、键盘、focus/clear、禁用阻断及受影响文字表现；真实读屏未测                                                                                                        |
| Q-06           | PASS props/slot、局部尺寸/主题扩展、显式onSolid交互与旧对象回退                                                                                                            |
| Q-07           | PASS固定代表：50次主题切换含点击/Vue/style观测2308.3738ms，预算15000ms；不推断通用稳定/FPS。服务DOM、卸载恢复、runner finally关闭                                          |
| Q-10           | 适用边界PASS；theme污染反例/默认对象不变；无新增后端鉴权、富文本/资源上传处理，既有协议保持                                                                                |
| Q-11           | PASS本卡普通Vue/Chrome可核；其他浏览器/宿主/真实CL未测，不借052代签                                                                                                        |
| Q-12           | PASS独立安装/正常exports、完整SFC修改→HMR效果→原字节恢复、固定输入与无关dirty保护                                                                                          |

## 正常包与差额验证

实际Node22.19.0/x64、pnpm11.9.0、EP2.14.7、Vue3.5.34、TS6.0.3、Chrome155.0.8059.82。每进程加载E入口后D pnpm；store/cache/state在唯一D根，其余新profile/temp/产物E。复用系统Node、宿主Playwright、Chrome，未下载runtime/browser。父子verifyDepsBeforeRun=error、frozen/offline；只用自己hoisted/copy安装与内部UI junction，未触canonical partial或他人node_modules。

初始正常UI/Pro与Tour后继完整build/pack/install、完整SFC、JS/TS缺符号/私有路径反例、纯ASAM skipLibCheck=false通过。onSolid正常完整UI后继及可选字段/错误类型反例通过，1408声明同字节，仅tokens/index.d.ts变化。最终仅CSS差额正常build:style/pack/增量安装后做plain定点：1721个非style dist保持字节；没有重建/改称新JS声明，没有重跑旧全矩阵。脚本既有消费SFC typecheck/生产构建实际执行。

最终UI tar SHA256 e12f10b272d2a4607910cdacaa60c245f3c6f386b45774048a7053c2b411adbd；JS/声明源2f8、CSS源51810分别绑定。Pro tar 117b9190fc85031f4956d43a2128a7094c6432a2169fc58ee788add041ec72be复用，182个dist同字节，未冒新Pro build。正常安装UI1722/Pro182文件逐一配对。根锁6c70b50cc9b729badfb57b746457a5aa08a4f029dcaf42632a1b4fd932c9c2a7及补丁c1fea5923b0d78c0155c213ee186b0417e3790a0de3fdbe646e1aa5c9a1332c4不变。

Chrome1280×900和390×844截图实际查看。首fixture漏EP基础CSS的视觉FAIL已保存，补正常element-plus/dist/index.css后图标/密度断言与图像通过。原pnpm配置、Pro链接、TS6参数、测试URL/标签、选项raw/分支、generic Upload、Table非runtime context和格式失败均保留；未改全局配置/依赖追绿。性能起终点/预算事先固定，完整观测成本保留；foreground等有限过渡结束测量。

## 保全与送测

外置根E:/DevCache/artifacts/asam-ui/v2-053/dev-r1/；阶段为原根、delta-tour、delta-on-solid、delta-plain。可变consumer更新前保存输入/锁/不可变tar映射；旧receipt可变路径须按supersession恢复，不能冒旧字节仍在。首FAIL、初帧假PASS未覆盖，包/依赖/log/截图不入Git。最终HEAD、变更清单、索引SHA在FINAL-DEV-DELIVERY.json。

真实读屏、其他浏览器/宿主、CL/后端、全库内部组合和公开部署未测/不适用，不加成本卡隐藏门槛；既有原生不支持/失败按原资格保留。没有访问/清理031、OPT、保护残留或共享缓存，没有main/CL/canonical/云/push/deploy/npm写入。本角色/空间保留给原链整改，不自行归档。TC按固定base→完整HEAD实际OCR委托源码/文本审查及适用QA后独立ACC，主控再有限集入/回归/保全收尾；DEV不代签。
