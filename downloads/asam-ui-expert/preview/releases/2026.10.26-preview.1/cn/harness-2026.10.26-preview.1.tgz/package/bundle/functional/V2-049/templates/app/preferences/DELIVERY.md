# V2-034 完整开发交付

唯一事件：V2-034-FIRST-DEV-FULL-A06-A07-A14。产品 base：14f2dc76078452d82b5cc3ef36752c1b1ea03f12。候选仅包含 templates/app/preferences 与 tests/v2/preferences；无共享源码补丁，无根台账/云/CL/main 修改，无推送、部署、发布或新角色。

实现 A06 应用字典、可配置语言/回退、普通文本插值与 Intl、双语完整菜单/页签/页面/操作/空错状态、显式 EP locale 桥接；A07 会话/持久/初始/安全优先级与独立 force、system 与有效色彩分离、真实媒体监听和幂等销毁、局部 Provider 隔离；A14 typed owner/scope namespace、可注入同步存储、schema 校验与 v1 迁移/未来保护、业务 snapshot TTL、scope/clear/reset/dispose 对晚到异步恢复的失效。

完整普通应用采用已验 031 Provider、032 createNavigation 和 NavigationPage，两个业务页保留合法草稿。公开控制器组合足够实现翻译菜单/页签，不修改 NavigationShell/MenuItems 或控制器算法；布局的 menuLabel/sidebarLabel 直接用已有公开参数。四尺寸、亮暗、390 窄屏、焦点及页签键盘导航均有真实浏览器操作。README/API/Types/capability/AGENT 和完整 recipe 同版。

正常 UI 对象 7a810ec019fde1a00bcc3449b1fc608ef9fcfb82fa5b6854c5efd38e1d3fc009（711659B），Pro 对象 018978986a6fed4b1279db119fb51f753e51d027fa6bf67eb020dfdda930b1c0（92125B），复用 032 永久保全。保持真实 6588 构建/3a710 未变源 provenance，未冒称 14f2 或新模板 HEAD 重建。PACKAGE-SOURCE-READROUTES.json SHA 152fc2a7c28a5153508a76119b9d0374a14c16f46075bcc64d413394b9cb1a8a；本角色逐件验证 1504 正常来源与固定 14f2，116 精确 LF→CRLF；1836 个正常包载荷与自有 consumer 安装结果全字节相同。无包源码影响，未重建全库或手补产物。

外置原件根：E:/DevCache/artifacts/asam-ui/v2-034/dev-r1。自有消费根：E:/DevCache/temp/asam-ui/v2-034-dev-r1/consumer。SOURCE-PAYLOAD-RECEIPT.json 含逐件来源与安装 hashes；ENVIRONMENT.json、turn-context.json、session-meta.json 含实际配置/路径证据。后者实核 gpt-6.1-sol/high、danger-full-access/never；真实 f604 项目关联由应用 list_threads 回读。Node 22.19.0、pnpm11.9.0、统一 D:/.pnpm-store 与 E 缓存；复用宿主管理 Playwright 和现有 Chrome。

验证结果及准确文件 SHA 以外置 FINAL-MANIFEST.json 与 HANDOFF.json 为准：普通最终与修改最终各含正负类型、13 核心测试、正常 Vite 生产构建及真实 Chrome 完整交互。修改消费实际改整份 App.vue 的 initial/TTL 与完整字典的页面/菜单文案，VARIANT-modify/restore.json 保存 before/modified/restored 整文件 hash；原件外置保存，恢复后与源文件逐字节核对。关键宽/窄/亮暗图经开发亲看。

过程首错原件保留：首次离线安装缺无必要 tsx 元数据，已去掉 tsx 改用当前 TypeScript 转译+Node runner；首轮浏览器定位 data-size 同时匹配 Provider 与 select，脚本改为 select[data-size]；亲看早期截图发现漏 EP 样式和菜单默认中文，已补正式样式与公开 label 输入，并重跑当前候选。修改态首次标题断言还遇到多个 h1，已限定应用主标题并重跑；暗色菜单显式传入 ASAM 语义色变量。早期日志/截图不作为最终候选通过依据。

限制：普通示例静态导入完整 UI/Pro，生产构建存在 chunk >500k 提示；不构成构建失败。无完整 SSR hydration、跨标签同步、任意历史迁移、自动过期订阅或同代次请求取消承诺；snapshot TTL、同步原子存储适配器边界详见 README。UI 中存储机器状态码为诊断输出，状态说明随语言切换。无 033/真实 CL 依赖，不冒 042 最终设计页面。

本交付为 DEV 自测候选，不声明独立 QA/ACC PASS。独立 QA 应固定完整 base/head，对所有本卡文件用 OCR delegate 逐件取规则并亲审，再结合完整消费验证；完整 QA 后送独立 ACC。只由开发主控串行集入 codex/v2、有限回归及后续资源闭环。
