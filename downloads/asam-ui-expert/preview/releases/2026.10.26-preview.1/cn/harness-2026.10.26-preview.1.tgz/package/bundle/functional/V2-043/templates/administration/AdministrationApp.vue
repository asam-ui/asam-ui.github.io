<template>
	<AsamApplicationProvider
		:config="{
			size: host.size.value,
			colorMode: mode,
			permission: { check: host.security.permission }
		}"
	>
		<div class="administration" :data-family="family" :data-mode="mode">
			<a class="skip" href="#administration-content">跳到管理内容</a>
			<aside class="brand" aria-label="应用品牌">
				<span class="brand-mark">A /</span>
				<div>
					<p>ASAM WORKSPACE</p>
					<h1>
						{{
							family === 'minimal'
								? '管理目录'
								: family === 'brand'
									? '协作管理中心'
									: '权限控制台'
						}}
					</h1>
					<p>用户 · 角色 · 菜单</p>
				</div>
				<p class="brand-note">
					{{
						family === 'brand'
							? '清晰分工，让每次变更有据可查。'
							: family === 'technology'
								? 'ADMINISTRATION / DIRECT GRANTS'
								: 'Administration'
					}}
				</p>
			</aside>
			<header class="topbar">
				<span>{{ host.security.state.value.subject?.name ?? '公开安全页' }}</span
				><span>{{ host.security.state.value.status }}</span
				><slot name="controls" /><AsamButton :size="host.size.value" @click="router.back()"
					>返回</AsamButton
				>
			</header>
			<nav v-if="navigation" aria-label="管理页面">
				<AsamButton
					v-for="item in navigation.visibleMenu.value"
					:key="item.id"
					:size="host.size.value"
					:aria-current="
						router.currentRoute.value.path === item.path ? 'page' : undefined
					"
					@click="navigation.navigate(item.path)"
					>{{ item.title }}</AsamButton
				>
			</nav>
			<main id="administration-content" ref="content" tabindex="-1">
				<RouterView
					v-if="navigation && router.currentRoute.value.path !== '/safe'"
					:key="
						JSON.stringify([
							host.security.state.value.epoch,
							serviceGeneration,
							host.services.value.version,
							router.currentRoute.value.path
						])
					"
				/>
				<section v-else class="safe" aria-label="公开安全页">
					<h2>安全页</h2>
					<p>当前页面需要明确的读取权限。会话、权限待定或失效时请由宿主恢复。</p>
					<slot name="recovery" />
				</section>
			</main>
			<footer>ASAM / 可编辑管理模板 <span>服务与授权策略由宿主提供</span></footer>
		</div>
	</AsamApplicationProvider>
</template>
<script setup lang="ts">
import { nextTick, onBeforeUnmount, provide, ref, watch } from 'vue';
import { RouterView, useRouter } from 'vue-router';
import { AsamButton } from '@asam-ui/ui';
import { AsamApplicationProvider } from '@asam-ui/pro';
import { createSecurityNavigation } from '../app/security/index.js';
import { administrationKey } from './Types.js';
import type { AdministrationHost } from './Types.js';
import UsersPage from './UsersPage.vue';
import RolesPage from './RolesPage.vue';
import MenusPage from './MenusPage.vue';
import './styles.css';
const props = withDefaults(
	defineProps<{
		host: AdministrationHost;
		family?: 'minimal' | 'brand' | 'technology';
		mode?: 'light' | 'dark';
	}>(),
	{ family: 'minimal', mode: 'light' }
);
const router = useRouter(),
	content = ref<HTMLElement>(),
	leaves = new Set<() => Promise<boolean>>();
const serviceGeneration = ref(0);
provide(administrationKey, { ...props.host, leaves });
// Router START_LOCATION is '/' even when a normal host is beginning a deep-link navigation.
const initialLocation = router.options.history.location || router.currentRoute.value.fullPath;
const bridge = createSecurityNavigation({
	security: props.host.security,
	router,
	components: { users: UsersPage, roles: RolesPage, menus: MenusPage },
	items: [
		{ id: 'users', title: '用户管理', path: '/users', resource: 'users', cache: false },
		{ id: 'roles', title: '角色管理', path: '/roles', resource: 'roles', cache: false },
		{ id: 'menus', title: '菜单权限', path: '/menus', resource: 'menus', cache: false }
	],
	rules: {
		'/users': { permission: 'users:read' },
		'/roles': { permission: 'roles:read' },
		'/menus': { permission: 'menus:read' }
	},
	publicPaths: ['/', '/safe'],
	safePage: '/safe'
});
const navigation = bridge.navigation;
bridge.resume(router.resolve(initialLocation).path === '/' ? '/users' : initialLocation);
const guard = router.beforeEach(async (to, from) => {
	if (
		to.path === from.path ||
		to.path === '/safe' ||
		props.host.security.state.value.status !== 'authenticated'
	)
		return true;
	const epoch = props.host.security.state.value.epoch;
	for (const leave of leaves)
		if (!(await leave()) || epoch !== props.host.security.state.value.epoch) return false;
	return true;
});
const after = router.afterEach(async () => {
	await nextTick();
	content.value?.focus({ preventScroll: true });
});
const unsubscribe = props.host.security.onInvalidate(() => {
	void nextTick(() => content.value?.focus());
});
const stop = watch(
	() => props.host.services.value,
	() => {
		serviceGeneration.value++;
		leaves.clear();
	},
	{ flush: 'sync' }
);
onBeforeUnmount(() => {
	guard();
	after();
	unsubscribe();
	stop();
	bridge.dispose();
});
defineExpose({ navigation, resume: bridge.resume });
</script>
