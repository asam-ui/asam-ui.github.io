import { computed, effectScope, readonly, ref, shallowRef, watch } from 'vue';
import { createAsamDataRuntime } from '@asam-ui/ui';
import { useAsamListController } from '@asam-ui/pro';
import { scopeKey } from '../app/security/Security.js';
import { comment, idKey, outcome, page, post, validWrite } from './Validation.js';
import { socialPermission } from './Types.js';
import type {
	SocialComment,
	SocialHost,
	SocialId,
	SocialOperation,
	SocialPost,
	SocialRequest,
	SocialWrite
} from './Types.js';

/** Owns only this page's runtime, reads, drafts and operation. Borrowed hosts are never disposed. */
export function createSocial(getHost: () => SocialHost) {
	const scope = effectScope();
	let disposed = false,
		epoch = 0,
		selection = 0,
		commentRun = 0;
	const aborts = new Set<AbortController>();
	const clearing = ref(false);
	const authoritative = new Map<string, SocialPost>();
	const revision = ref(0);
	const runtime = createAsamDataRuntime({ scope: 'social-page' });
	const selected = shallowRef<SocialPost | null>(null);
	const comments = shallowRef<readonly SocialComment[]>([]);
	const commentPage = ref(1),
		commentTotal = ref(0),
		commentsLoading = ref(false);
	const commentsError = ref(''),
		writeError = ref(''),
		feedback = ref(''),
		draft = ref('');
	const pending = shallowRef<SocialOperation | null>(null);
	const writeStatus = ref<'idle' | 'pending' | 'success' | 'failed' | 'unknown'>('idle');
	let stopSecurity = () => {};
	const allowed = (kind: keyof typeof socialPermission) => {
		if (disposed || clearing.value) return false;
		const h = getHost();
		return (
			!disposed &&
			!h.disabled &&
			(!(kind !== 'read' && kind !== 'comments') || !h.readonly) &&
			h.security.check({
				permission: socialPermission[kind],
				write: kind !== 'read' && kind !== 'comments'
			}) === 'allowed'
		);
	};
	const draftInput = computed({
		get: () => draft.value,
		set: (value: string) => {
			if (typeof value === 'string' && selected.value && allowed('comment'))
				draft.value = value;
		}
	});
	function request(kind: keyof typeof socialPermission, signal?: AbortSignal, object?: SocialId) {
		const h = getHost(),
			g = epoch,
			s = selection;
		const subject = h.security.state.value.subject;
		if (!subject || !allowed(kind)) throw Error('当前会话无权操作');
		const key = scopeKey(subject),
			controller = new AbortController();
		aborts.add(controller);
		const cancel = () => controller.abort();
		signal?.addEventListener('abort', cancel, { once: true });
		if (signal?.aborted) cancel();
		const current = () => {
			const latest = getHost();
			return (
				!disposed &&
				epoch === g &&
				latest.security === h.security &&
				latest.service === h.service &&
				!controller.signal.aborted &&
				allowed(kind) &&
				latest.security.state.value.subject !== null &&
				scopeKey(latest.security.state.value.subject!) === key &&
				(object === undefined || (selection === s && selected.value?.id === object))
			);
		};
		const input: SocialRequest = { subject, signal: controller.signal, isCurrent: current };
		return {
			host: h,
			input,
			current,
			release: () => {
				signal?.removeEventListener('abort', cancel);
				aborts.delete(controller);
			}
		};
	}
	function accept(row: SocialPost) {
		const key = idKey(row.id),
			known = authoritative.get(key);
		if (!known || known.version <= row.version) {
			authoritative.set(key, row);
			revision.value++;
		}
		return authoritative.get(key)!;
	}
	const list = scope.run(() =>
		useAsamListController<SocialPost>({
			fields: [
				{ key: 'keyword', label: '关键词', kind: 'text' },
				{ key: 'author', label: '作者', kind: 'single' },
				{ key: 'bookmarked', label: '只看收藏', kind: 'single' }
			],
			initial: { keyword: '', author: '', bookmarked: false },
			queryKeys: ['keyword', 'author', 'bookmarked'],
			rowKey: (row) => idKey(row.id),
			pageSize: 20,
			immediate: false,
			runtime,
			api: async (query, context) => {
				const r = request('read', context.signal);
				try {
					if (!r.current()) throw Error('读取失效');
					const response = await r.host.service.feed(query, r.input);
					if (!r.current()) throw Error('读取失效');
					const result = page(response, post);
					if (!r.current()) throw Error('读取失效');
					if (result.list.length > query.pageSize) throw Error('信息流超过请求页长');
					const rows: SocialPost[] = [];
					for (const row of result.list) {
						const value = accept(row);
						if (!r.current()) throw Error('读取失效');
						rows.push(value);
					}
					return { ...result, list: rows };
				} finally {
					r.release();
				}
			}
		})
	)!;
	const rows = computed(() => {
		revision.value;
		return list.page.data.value.list.map((row) => authoritative.get(idKey(row.id)) ?? row);
	});
	function clear() {
		// Nested host/security notifications belong to this same cleanup. The outer host
		// watcher resumes the latest host after cleanup; a nested watcher must not reopen it.
		if (clearing.value) return;
		clearing.value = true;
		++epoch;
		++selection;
		++commentRun;
		const old = [...aborts];
		aborts.clear();
		try {
			// Revoke the old result before any local ref notifies synchronous observers.
			runtime.invalidate();
			authoritative.clear();
			selected.value = null;
			comments.value = [];
			draft.value = '';
			pending.value = null;
			writeStatus.value = 'idle';
			commentsError.value = '';
			writeError.value = '';
			feedback.value = '';
			commentsLoading.value = false;
			commentTotal.value = 0;
			commentPage.value = 1;
		} finally {
			try {
				old.forEach((c) => c.abort());
			} finally {
				clearing.value = false;
			}
		}
	}
	async function loadComments(targetPage = commentPage.value) {
		if (!Number.isSafeInteger(targetPage) || targetPage < 1) return;
		const row = selected.value;
		if (!row || !allowed('comments')) return;
		const run = ++commentRun,
			r = request('comments', undefined, row.id);
		commentsLoading.value = true;
		commentsError.value = '';
		try {
			if (!r.current() || run !== commentRun) return;
			const value = await r.host.service.comments(row.id, targetPage, 20, r.input);
			if (!r.current() || run !== commentRun) return;
			const result = page(value, (c) => comment(c, row.id));
			if (!r.current() || run !== commentRun) return;
			if (result.list.length > 20) throw Error('评论超过请求页长');
			comments.value = result.list;
			if (!r.current() || run !== commentRun) return;
			commentTotal.value = result.total;
			if (!r.current() || run !== commentRun) return;
			commentPage.value = targetPage;
		} catch {
			if (r.current() && run === commentRun)
				commentsError.value = '评论读取失败，保留原结果，可重试';
		} finally {
			if (r.current() && run === commentRun) commentsLoading.value = false;
			r.release();
		}
	}
	function close() {
		if (disposed || clearing.value) return;
		const token = ++selection;
		++commentRun;
		selected.value = null;
		if (selection !== token) return;
		comments.value = [];
		if (selection !== token) return;
		draft.value = '';
		if (selection !== token) return;
		commentsLoading.value = false;
		if (selection !== token) return;
		commentsError.value = '';
		if (selection !== token) return;
		writeError.value = '';
		if (selection !== token) return;
		commentTotal.value = 0;
		// A submitted operation remains unresolved until explicit lookup, preventing accidental resend.
		if (pending.value) writeStatus.value = 'unknown';
	}
	async function open(row: SocialPost) {
		if (!allowed('read') || !list.resultReady.value || !rows.value.some((p) => p.id === row.id))
			return;
		const token = selection + 1;
		close();
		if (selection !== token || !allowed('read') || !list.resultReady.value) return;
		const currentRow = rows.value.find((p) => p.id === row.id);
		if (!currentRow) return;
		// A delayed UI closure may retain an earlier service's row with the same ID.
		// Only the current result is authoritative; opening never imports caller row data.
		selected.value = post(currentRow);
		if (selection !== token || !allowed('read')) return;
		commentPage.value = 1;
		await loadComments(1);
	}
	async function write(action: SocialWrite, resolving = false) {
		if (!validWrite(action)) return;
		if ((!resolving && pending.value) || writeStatus.value === 'pending') return;
		const kind = action.kind;
		const row =
			rows.value.find((p) => p.id === action.postId) ??
			(selected.value?.id === action.postId ? selected.value : null);
		if ((!resolving && !row) || !allowed(kind) || (!resolving && !list.resultReady.value))
			return;
		if (
			!resolving &&
			kind === 'comment' &&
			(!action.body.trim() ||
				action.body.length > 10000 ||
				selected.value?.id !== action.postId)
		)
			return;
		if (
			!resolving &&
			kind === 'delete' &&
			(!comments.value.some((c) => c.id === action.commentId && c.canDelete) ||
				selected.value?.id !== action.postId)
		)
			return;
		const operation = resolving
			? pending.value
			: { id: crypto.randomUUID(), action: structuredClone(action) };
		if (!operation || operation.action.postId !== action.postId) return;
		const r = request(
			kind,
			undefined,
			selected.value?.id === action.postId ? action.postId : undefined
		);
		const g = epoch,
			oldDraft = draft.value;
		const current = () => r.current() && pending.value === operation;
		try {
			pending.value = operation;
			if (!current()) return;
			writeError.value = '';
			if (!current()) return;
			writeStatus.value = 'pending';
			if (!current()) return;
			feedback.value = resolving ? '正在核实原操作' : '正在提交';
			if (!current()) return;
			const raw = resolving
				? await r.host.service.resolve(operation.id, r.input)
				: await r.host.service.write(operation, r.input);
			if (!current()) return;
			const result = outcome(raw, action.postId);
			if (!current()) return;
			writeStatus.value = result.status;
			if (!current()) return;
			if (result.status === 'success') {
				const accepted = accept(result.post);
				if (!current()) return;
				if (selected.value?.id === accepted.id) selected.value = accepted;
				if (!current()) return;
				feedback.value = '已保存服务权威结果';
				if (!current()) return;
				if (kind === 'comment' && draft.value === oldDraft && oldDraft === action.body)
					draft.value = '';
				if (!current()) return;
				if (
					(kind === 'comment' || kind === 'delete') &&
					selected.value?.id === action.postId
				)
					await loadComments(1);
				if (current()) pending.value = null;
			} else if (result.status === 'failed') {
				writeError.value = result.message;
				if (!current()) return;
				feedback.value = '操作未完成，草稿保留，可重试';
				if (current()) pending.value = null;
			} else feedback.value = '结果未知，请核实原操作；不会自动重发';
		} catch {
			if (current()) {
				writeStatus.value = 'unknown';
				if (current()) feedback.value = '结果未知，请核实原操作';
			}
		} finally {
			if (
				!disposed &&
				g === epoch &&
				pending.value === operation &&
				writeStatus.value === 'pending'
			)
				writeStatus.value = 'unknown';
			r.release();
		}
	}
	scope.run(() => {
		watch(
			() => [
				getHost().security,
				getHost().service,
				getHost().security.state.value.epoch,
				getHost().security.state.value.status,
				getHost().security.state.value.subject,
				!!getHost().disabled,
				!!getHost().readonly
			],
			() => {
				const g = epoch + 1,
					previous = stopSecurity;
				stopSecurity = () => {};
				previous();
				clear();
				if (epoch !== g || disposed) return;
				const stop = getHost().security.onInvalidate(clear);
				if (epoch !== g || disposed) {
					stop();
					return;
				}
				stopSecurity = stop;
				if (allowed('read') && epoch === g) {
					list.resumeScope({ keyword: '', author: '', bookmarked: false });
					if (epoch === g && allowed('read')) void list.submit();
				}
			},
			{ immediate: true, flush: 'sync' }
		);
	});
	function dispose() {
		if (disposed) return;
		disposed = true;
		stopSecurity();
		clear();
		scope.stop();
	}
	return {
		list,
		rows,
		selected: readonly(selected),
		comments: readonly(comments),
		commentPage: readonly(commentPage),
		commentTotal: readonly(commentTotal),
		commentsLoading: readonly(commentsLoading),
		commentsError: readonly(commentsError),
		writeError: readonly(writeError),
		draft: draftInput,
		feedback: readonly(feedback),
		writeStatus: readonly(writeStatus),
		pending: readonly(pending),
		allowed,
		open,
		close,
		loadComments,
		write,
		shown: (row: SocialPost) => rows.value.find((p) => p.id === row.id) ?? row,
		resolve: () => (pending.value ? write(pending.value.action, true) : Promise.resolve()),
		cancelDraft: () => {
			if (!disposed && !clearing.value) feedback.value = '已取消编辑，草稿已保留';
		},
		dispose
	};
}
export type SocialController = ReturnType<typeof createSocial>;
