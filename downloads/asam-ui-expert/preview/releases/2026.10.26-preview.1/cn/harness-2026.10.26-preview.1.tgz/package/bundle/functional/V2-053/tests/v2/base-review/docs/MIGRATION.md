# 基础接口与迁移边界

本卡产品输入固定 `3f07c7582c6be38ee22ef86783b7022adf31e316`。本轮原DEV产品差额是修复
AsamTour 正常包组件声明遗漏原生 props：SFC 用既有完整 AsamTourProps 定义输入，继续由
suppliedNativeProps 按实际提供值委托原生组件。它恢复已有能力的类型可见性，不删除接口；
原有运行调用无需迁移，也不再需要错误的类型绕过。后继由根唯一共享写者新增可选
`color.onSolid?: string`，将六个实心类型（第六为gradient，accent不改）及plain填充交互态的
前景从页面surface分离。root源6623d292在本分支精确择取为43352fe9，修改tokens/styles及包说明；
没有改版本、依赖、锁、补丁、聚合出口或031产品。旧完整主题对象可省略此字段，默认白色；
需要自定义实心前景时才显式传onSolid；仅换页面背景的既有调用无需迁移，有意借surface设置
实心文字颜色的调用应改为显式onSolid保留目标色。root另以d5c81504修plain两项前景specificity，
本分支51810e4d精确承接。真实前后验证见Foreground.vue、plain-point.mjs和正常包后继回执。
正常包修复前的 TS2339 失败与修复后的同一属性消费分别保全。
以下是固定版本已经存在的差异；不能把历史差异写成本卡新破坏项。

| 来源与差异                                    | 理由及替代                                                                                | 消费迁移与验证                                                                                                           |
| --------------------------------------------- | ----------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| Button 已删除 `variant`                       | 2026-10-02 已确认语义统一；用 `type`，省略为 secondary；ASAM gradient/accent/ghost 等保留 | 将 `variant="primary"` 改为 `type="primary"`；types.ts 对旧字段要求报错，正常 SFC 以 type/省略两种消费                   |
| Input 不接受 password/textarea 模式           | 同一已确认职责拆分；AsamPassword、AsamTextarea 承接                                       | 保留模型/适用事件，改组件名；rows/autosize 仅传 Textarea；types.ts 拒绝旧 Input 模式，Baseline.vue 正常运行三个入口      |
| 控件尺寸为四档                                | ASAM big=36px；仅传入 EP 的桥接值使用三档                                                 | 传 ASAM size，不复制 Symbol/context key；显式、Group、Form、Provider 与031应用桥的回退已纳入浏览器测试                   |
| 图形和容器 `size` 语义独立                    | Icon/Avatar 图形尺寸、Space 间距、Dialog/Drawer 容器尺寸不是单行控件高度                  | 按该入口 Types.ts 使用原语义；不将 Dialog mini 等错误替换为四档控件尺寸                                                  |
| 原生 DatePicker/TimePicker 无默认 valueFormat | UI-039 已接受原生值协议；无格式时保留 Date；上游空值与工厂结果不被归一                    | 字符串应用显式提供 valueFormat；高级 DateTimeRange 的完整端点协议另用专用入口；本轮不改变已有调用方                      |
| Select/Hierarchy 原生和高级值协议分离         | value/object、array/string 与 Remote/Dict 为 ASAM 自有协议；原生分支由 EP 处理            | 需要原生类型用 `valueMode="native"` 与原生 options/slots；需要数据转换用对应高级类型，不混合解释 slot 的 raw/node/option |
| AsamBaseForm 与 AsamForm 分工                 | 前者原生公开表单；后者 Schema/fields、自有模型与数据组合                                  | 普通表单用 BaseForm；Schema 用 Form/createAsamSchema，不以完整替换 EP 内部算法为目标                                     |
| 031 应用配置桥可选                            | 基础 AsamConfigProvider 保持；ApplicationProvider 额外提供局部主题与权限原语              | 现有基础消费者无需迁移；需要局部主题才加入 Pro 与两包 CSS；theme:null 重置，undefined 继承；不改原031产品                |

同版本完整资料：`packages/ui/src/components/*/Types.ts`、局部 `Index.ts`、正常包 `.d.ts`、
`packages/pro/src/configuration/README.md`。正常编译运行只用公开包导入；源码路径用于阅读
合同，不能成为运行 alias。所有当前已知 SFC 由本卡新增 examples 覆盖，不擅自修改 CL
或其他 owner 样例。真正建议修改公共出口/补丁/依赖时，应另给开发主控精确 proposal。

原生限制继续成立：UI-034 lazy 未解析模型等、UI-039 原生不支持模型/日期边界、
原生声明有限兼容问题不得在 wrapper 中接管算法或用 skip/结果归一抹去。历史失败与
未测保持其原资格，本卡正常案例 PASS 不表示这些原生场景修复。
