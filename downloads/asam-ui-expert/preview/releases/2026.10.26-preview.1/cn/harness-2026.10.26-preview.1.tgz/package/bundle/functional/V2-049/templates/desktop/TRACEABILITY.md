# V2-049 范围追溯

本卡P30仅浏览器桌面。状态指本DEV事实，独立QA/OCR/ACC尚未发生；性能预算明确FAIL，不将下表当整卡PASS。

| 本卡功能                           | 实现与资料                                                     | 实际验证                                                               |
| ---------------------------------- | -------------------------------------------------------------- | ---------------------------------------------------------------------- |
| 快捷入口/任务栏/三个可替换面板     | DesktopStage、Types、examples/config、panel slot               | 三族宽窄功能序列                                                       |
| 开/激活/关/最小化/最大化/还原/顺序 | Desktop、Stage                                                 | 生命周期逻辑、真实UI和稳定实例                                         |
| 拖/缩放/键盘等价                   | Stage两手柄与8/32px步长                                        | 鼠标/触控/方向键、最大化与还原                                         |
| 取消/逃逸/视口/滚动                | pointer capture、Escape/blur/scroll/RO、finish实际尺寸复核     | 首resize FAIL保留→R2通过；真实touchCancel与嵌套滚动                    |
| 焦点/内容所有权                    | focusRevision/contextRevision、id+context key、内容卸载清理    | 草稿保持、关闭焦点、身份切换销毁、子任务abort                          |
| 版本化偏好                         | 034 createBusinessCache、typed Scope/StorageAdapter            | 坏JSON/schema/链接/旧版/未来/TTL、精确reset                            |
| 时序/权限/隔离                     | epoch与写前复核、allowlist、conflict                           | 双实例/双owner、回调重入、迟到save/restore、跨页storage事件            |
| 窄屏/恢复                          | logical rect与projection分离                                   | 单面板、断点草稿与rect、所有状态恢复                                   |
| 三族/主题/尺寸/状态                | 三个完整SFC、Desktop.css、同版Provider/PageContainer           | 各族明暗/28/32/36/40、loading/empty/error/readonly/disabled/permission |
| 轻CSS与减少动态                    | 180ms opacity、prefers-reduced-motion                          | 各族实际animation对象和reduce=none                                     |
| Agent修改与普通消费                | API/AGENT/capability、可编辑App/SFC                            | normal→modified→restored真实build/browser/source/dist/包身份           |
| 资源/性能                          | scope cache dispose、Stage清监听/observer、内容abort、预算plan | 销毁通过；首次完整双钟预算FAIL，余预算NOT_RUN                          |

42横向要求按本卡实际边界承接：

| 要求    | 本卡承接与验证边界                                                 |
| ------- | ------------------------------------------------------------------ |
| BASE-01 | 消费已验029公开布局/032导航/034存储，不重建原生EP能力              |
| BASE-02 | ASAM tokens/Provider与四尺寸，逐族明暗/尺寸实测                    |
| BASE-03 | 库组件、应用源码模板与宿主业务职责在README/API可辨                 |
| BASE-04 | 新增模板无旧桌面破坏项；自有布局迁移路径见README                   |
| AI-01   | capability与README给定位、版本、边界                               |
| AI-02   | prepare/README给普通工程首次接入，独立consumer实际安装             |
| AI-03   | capability.intent按浏览器桌面/多面板等意图发现                     |
| AI-04   | Types/API/版本与同版file包固定，精确来源封套                       |
| AI-05   | DESIGN与本卡正式输入形成结构/交互/范围，不猜CL设计                 |
| AI-06   | README/AGENT明确host、layout、034 cache与导航改动                  |
| AI-07   | 三族真实页面/各适用状态，而非只存在底层组件                        |
| AI-08   | typed panels/slots，宿主服务/权限/请求留宿主，示例非CL             |
| AI-09   | 实际配置/SFC修改与还原，保原库和无关路径                           |
| AI-10   | 本表关联P30→源码→具名检查与来源SHA                                 |
| AI-11   | AGENT列错误用法；类型反例、schema拒绝与权限/竞态反例               |
| AI-12   | 类型/逻辑/生产/真实浏览器分别留证，预算失败单列                    |
| AI-13   | pnpm配置/首类型/resize首失败与修复保留，不冒工具成功               |
| AI-14   | capability→API→所需单族SFC渐进读取                                 |
| AI-15   | 使用可用本机Chrome；无设计截图不伪造；无跨宿主安装声明             |
| AI-16   | 普通Vue/包消费，与Agent运行时无依赖                                |
| AI-17   | README按Types/Stage/schema差异给迁移验证，未作无来源自动迁移       |
| AI-18   | prepare拒覆已有consumer；复制本卡路径，不重写公共配置              |
| AI-19   | 权限实时allowlist，布局不含正文/凭据，无外发/真实数据              |
| AI-20   | DELIVERY区分功能通过/预算FAIL/QA与ACC待执行                        |
| HOST-01 | 052负责Codex安装生命周期；本卡交同源能力/配方，不冒新宿主安装      |
| HOST-02 | 052负责WorkBuddy真实入口；本卡未测该宿主                           |
| HOST-03 | 同一Types/API/方法；未新增桌面专用MCP/Skill                        |
| HOST-04 | 普通应用卸载/资源已测；插件安装更新卸载非本卡运行内容              |
| HOST-05 | 固定Vue/EP/UI/Pro版本，宿主矩阵不冒通过                            |
| HOST-06 | README/AGENT本地源码分发，050/052聚合提案，不承诺市场发表          |
| Q-01    | Types/props/slots/retry/expose与API，同版类型正反通过              |
| Q-02    | 正常/加载/空/错/禁用/只读/权限、坏存储恢复均有实际用例             |
| Q-03    | epoch、冲突/回调重入、操作一致与迟到结果实测                       |
| Q-04    | 三族设计Skill取舍、实际截图；品牌侧栏对比已修并实测                |
| Q-05    | 有名称的真实按钮/手柄/状态区、方向键、焦点回落/窄屏切换            |
| Q-06    | typed controller/panels及panel/navigation/footer slots，不绑定业务 |
| Q-07    | 监听/observer/内容任务清理通过；首次完整性能预算未通过             |
| Q-08    | 同版资料/锁/包/生产产物/阶段对象分别绑定                           |
| Q-09    | 可编辑SFC/普通项目真实修改还原，迁移路径完整                       |
| Q-10    | 当前allowlist不替后端鉴权，内容本地SFC不执行远端字符串             |
| Q-11    | 本机Chrome真实结果；双宿主扩展052，不拿本卡代其PASS                |
| Q-12    | 仅本卡owner路径，库/其他卡/canonical/现网不写                      |
