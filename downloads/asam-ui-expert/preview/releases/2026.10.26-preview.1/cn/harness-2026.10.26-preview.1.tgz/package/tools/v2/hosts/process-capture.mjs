import { spawnSync } from 'node:child_process';
import {
	closeSync,
	mkdtempSync,
	openSync,
	readFileSync,
	rmdirSync,
	statSync,
	unlinkSync
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

// Windows workspace sandboxes can execute a child while rejecting its anonymous
// output pipes. Use the host's existing task TEMP; never change its permissions.
export function captureSync(file, args, options = {}) {
	if (process.platform !== 'win32') return spawnSync(file, args, options);
	const directory = mkdtempSync(join(tmpdir(), 'asam-capture-'));
	const paths = ['stdout', 'stderr'].map((name) => join(directory, name));
	const descriptors = [];
	try {
		for (const path of paths) descriptors.push(openSync(path, 'wx', 0o600));
		const result = spawnSync(file, args, {
			...options,
			stdio: ['ignore', ...descriptors]
		});
		for (const fd of descriptors.splice(0)) closeSync(fd);
		const limit = options.maxBuffer ?? 1024 * 1024;
		if (paths.some((path) => statSync(path).size > limit)) {
			result.error ??= Object.assign(new Error('Captured output exceeded maxBuffer'), {
				code: 'ENOBUFS'
			});
			result.stdout = result.stderr = options.encoding ? '' : Buffer.alloc(0);
		} else {
			[result.stdout, result.stderr] = paths.map((path) =>
				readFileSync(path, options.encoding || undefined)
			);
		}
		result.output = [null, result.stdout, result.stderr];
		return result;
	} finally {
		for (const fd of descriptors) closeSync(fd);
		for (const path of paths) {
			try {
				unlinkSync(path);
			} catch (error) {
				if (error.code !== 'ENOENT') throw error;
			}
		}
		rmdirSync(directory);
	}
}

export function captureTextSync(file, args, options = {}) {
	const result = captureSync(file, args, { ...options, encoding: 'utf8' });
	if (result.error) throw result.error;
	if (result.status !== 0)
		throw Object.assign(new Error('Child process failed'), {
			status: result.status,
			signal: result.signal,
			stdout: result.stdout,
			stderr: result.stderr
		});
	return result.stdout;
}
