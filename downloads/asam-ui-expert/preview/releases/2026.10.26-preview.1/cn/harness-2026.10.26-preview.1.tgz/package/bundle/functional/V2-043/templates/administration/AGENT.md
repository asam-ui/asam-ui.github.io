# Agent 修改配方

先从 README 确定普通 consumer 与公开依赖版本，读 Types/API，再按功能文件修改。

新增业务字段时同步维护 Types、Codecs.ts 对应白名单/读写映射与宿主 DTO；额外或缺失字段不会被静默接受。仅表单版本字符串到数字使用显式受校验转换。pnpm11 必须在普通 consumer 的 pnpm-workspace.yaml 设置 `verifyDepsBeforeRun: error` 并实际回读 error，不能以 .npmrc 文本或根目录 undefined 冒生效。
无需为这个模板创建 MCP、Skill 服务或等待文档聚合任务。

| 要修改什么            | 同版入口                                                                         | 实际验证                                               |
| --------------------- | -------------------------------------------------------------------------------- | ------------------------------------------------------ |
| 用户字段/列           | UsersPage.vue fields/columns，Codecs.ts userCodec，Types.ts UserEdit             | 新建/编辑/详情、原 version、列与实际保存 DTO           |
| 角色候选/未知角色策略 | UsersPage source、AdministrationHost.unknownRoles、宿主 roleOptions 与写 adapter | 0/'0'，未知旧角色保留或明确拒绝，禁用候选不能新增      |
| 角色资料/引用反馈     | RolesPage.vue、roleCodec 与宿主 roles.crud                                       | 完整 CRUD 与引用/冲突恢复                              |
| 菜单树/可授标记       | MenusPage.vue、menuCodec、menuNodes、GrantNode                                   | 重复/孤儿/循环/非法 ID 整次拒绝，过滤不丢已选          |
| 授权后端策略          | GrantService；参照 Fixture.ts full/delta 两例                                    | direct 集合、不可授保留、unknown 同操作核实、旧树晚到  |
| 三族外壳              | AdministrationApp.vue、styles.css、examples/App.vue                              | 各族三路由、390、明暗、键盘、减少动态                  |
| 宿主配置              | examples/App.vue 的 security/runtime/服务引用/size                               | 权限失效立即清理、只读、跨 scope/service、双实例所有权 |

自主修改验证：在独立普通 consumer 中修改字段、列、候选或授权策略、adapter 与外壳，
每阶段 **命令前** 冻结源/config/tools/有效锁/安装metadata/正常完整包。构建运行修改版后封 CAS，
另一个实际读路从封存源码/产物复放，再按原字节恢复、构建运行核恢复。
记录首错与后继修复窗口；不得用最终源伪造早期证据，不把模型测试替代 UI。

本卡测试脚本位于 tests/v2/administration，env.ps1 使用最新 E 缓存、D 唯一 pnpm 配置。
不执行根 partial install；运行普通 consumer 的 typecheck/test/build，独立 QA 仍须 OCR 实际审查。
