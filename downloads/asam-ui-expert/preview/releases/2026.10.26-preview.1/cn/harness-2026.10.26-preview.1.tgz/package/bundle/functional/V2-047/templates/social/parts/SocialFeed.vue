<template>
	<section class="social-feed" aria-label="社交信息流">
		<form class="social-query" @submit.prevent="search">
			<label
				>关键词<input v-model="keyword" name="keyword" :disabled="!c.allowed('read')"
			/></label>
			<label
				>作者<select aria-label="作者" v-model="author" :disabled="!c.allowed('read')">
					<option value="all">全部作者</option>
					<option value="number">林序 · 数字0</option>
					<option value="string">陈知 · 字符串0</option>
				</select></label
			>
			<label class="social-check"
				><input
					v-model="bookmarked"
					type="checkbox"
					:disabled="!c.allowed('read')"
				/>只看收藏</label
			>
			<button type="submit" :disabled="!c.allowed('read')">查询</button>
		</form>
		<AsamProList
			:controller="c.list"
			:content="content"
			label="社区帖子"
			:size="size"
			:disabled="!c.allowed('read')"
			:sorts="sorts"
			:layout="grid ? 'grid' : 'list'"
			:min-width="300"
		>
			<template #title="{ row }"
				><span>{{ row.author.name ?? '作者未知' }}</span></template
			>
			<template #extra="{ row }"
				><span class="social-index">{{ typeof row.id }}:{{ row.id }}</span></template
			>
			<template #content="{ row }">
				<article :data-post="idKey(row.id)">
					<SocialImage class="social-avatar" :image="row.author.avatar" />
					<p
						class="social-body"
						:class="{ 'social-preview': !expanded.has(idKey(row.id)) }"
					>
						{{ row.body }}
					</p>
					<button :aria-expanded="expanded.has(idKey(row.id))" @click="expand(row)">
						{{ expanded.has(idKey(row.id)) ? '收起原文' : '展开全文' }}
					</button>
					<SocialImage :image="row.cover" />
					<small>{{ row.time ?? '时间未知' }}</small>
				</article>
			</template>
			<template #operation="{ row }">
				<button
					:aria-pressed="c.shown(row).liked"
					:disabled="blocked('like')"
					@click="
						c.write({
							kind: 'like',
							postId: row.id,
							desired: !c.shown(row).liked,
							version: c.shown(row).version
						})
					"
				>
					{{ c.shown(row).liked ? '取消点赞' : '点赞' }} · {{ c.shown(row).likes }}
				</button>
				<button
					:aria-pressed="c.shown(row).bookmarked"
					:disabled="blocked('bookmark')"
					@click="
						c.write({
							kind: 'bookmark',
							postId: row.id,
							desired: !c.shown(row).bookmarked,
							version: c.shown(row).version
						})
					"
				>
					{{ c.shown(row).bookmarked ? '取消收藏' : '收藏' }}
				</button>
				<button
					:disabled="!c.allowed('read') || !c.list.resultReady.value"
					@click="open(row)"
				>
					正文与评论 · {{ c.shown(row).comments }}
				</button>
			</template>
			<template #error="{ retry }"
				><p role="alert">
					信息流读取失败，旧结果已过期。<button
						:disabled="!c.allowed('read')"
						@click="retry"
					>
						重试读取
					</button>
				</p></template
			>
		</AsamProList>
		<p role="status" aria-live="polite">{{ c.feedback.value }}</p>
		<p v-if="c.writeError.value" class="social-body" role="alert" data-social-write-error>
			{{ c.writeError.value }}
		</p>
		<button
			v-if="c.pending.value && c.writeStatus.value === 'unknown'"
			:disabled="!c.allowed(c.pending.value.action.kind)"
			@click="c.resolve"
		>
			核实原操作
		</button>
	</section>
</template>
<script setup lang="ts">
import { ref, watch } from 'vue';
import { AsamProList } from '@asam-ui/pro';
import type { AsamListContent, AsamListSort } from '@asam-ui/pro';
import type { AsamControlSize } from '@asam-ui/ui';
import type { SocialController } from '../Social.js';
import type { SocialPost } from '../Types.js';
import { idKey } from '../Validation.js';
import SocialImage from './SocialImage.vue';
const props = defineProps<{ c: SocialController; size?: AsamControlSize; grid?: boolean }>();
const keyword = ref(''),
	author = ref('all'),
	bookmarked = ref(false),
	expanded = ref(new Set<string>());
watch(
	() => props.c.list.session.value,
	() => {
		keyword.value = '';
		author.value = 'all';
		bookmarked.value = false;
		expanded.value = new Set();
	}
);
const sorts: readonly { label: string; value: AsamListSort | null }[] = [
	{ label: '记录顺序', value: null },
	{ label: '点赞最多', value: { field: 'likes', order: 'descending' } }
];
const content = (_row: SocialPost): AsamListContent => ({ title: '' });
function search() {
	if (!props.c.allowed('read')) return;
	props.c.list.setDraft({
		keyword: keyword.value,
		author: author.value === 'number' ? 0 : author.value === 'string' ? '0' : '',
		bookmarked: bookmarked.value
	});
	void props.c.list.submit();
}
function expand(row: SocialPost) {
	const set = new Set(expanded.value),
		key = idKey(row.id);
	if (set.has(key)) set.delete(key);
	else set.add(key);
	expanded.value = set;
}
function blocked(kind: 'like' | 'bookmark') {
	return !props.c.allowed(kind) || !!props.c.pending.value || !props.c.list.resultReady.value;
}
function open(row: SocialPost) {
	Object.assign(props.c, { returnFocus: document.activeElement });
	void props.c.open(row);
}
</script>
