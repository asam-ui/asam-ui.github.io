<template>
	<div class="social-demo" :class="{ dark }">
		<nav class="social-demo-controls" aria-label="示例设置">
			<label
				>页面风格<select aria-label="页面风格" v-model="family">
					<option value="minimal">简约手记</option>
					<option value="brand">品牌社区</option>
					<option value="tech">活动台</option>
				</select></label
			>
			<label
				>尺寸<select aria-label="尺寸" v-model="size">
					<option>large</option>
					<option>big</option>
					<option>default</option>
					<option>small</option>
				</select></label
			>
			<button @click="security.login(0)">登录林序 / 数字0</button
			><button @click="security.login('0')">登录陈知 / 字符串0</button
			><button @click="security.restore">恢复登录</button
			><button @click="security.logout">退出登录</button>
			<button :disabled="!security.state.value.subject" @click="switchContext">
				切换讨论空间
			</button>
			<label><input v-model="readonly" type="checkbox" />只读</label
			><label><input v-model="disabled" type="checkbox" />停用</label
			><label><input v-model="dark" type="checkbox" />父级暗色</label>
			<label>读取失败<input v-model="fixture.control.readFailure" type="checkbox" /></label>
			<label
				>写入情景<select aria-label="写入情景" v-model="fixture.control.writeMode">
					<option value="normal">正常</option>
					<option value="failed">明确失败</option>
					<option value="unknown">结果未知</option>
				</select></label
			>
			<label
				>服务数据<select aria-label="服务数据" v-model="mapped">
					<option :value="false">标准 DTO</option>
					<option :value="true">嵌套编辑 DTO</option>
				</select></label
			>
			<button @click="security.expire">撤回会话权限</button>
		</nav>
		<component :is="pages[family]" :host="host" :size="size" ref="page" />
	</div>
</template>
<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref, shallowRef } from 'vue';
import type { AsamControlSize } from '@asam-ui/ui';
import MinimalSocialPage from '../MinimalSocialPage.vue';
import BrandSocialPage from '../BrandSocialPage.vue';
import TechSocialPage from '../TechSocialPage.vue';
import { createDemoSecurity, createEditorialService, createSyntheticService } from './Fixture.js';
import type { SocialController } from '../Social.js';
const security = createDemoSecurity();
const fixture = createSyntheticService();
fixture.control = reactive(fixture.control);
// The service closes over the same control object; reactive proxy writes reach that object.
const editorial = createEditorialService(fixture.service);
const family = ref<'minimal' | 'brand' | 'tech'>('minimal'),
	size = ref<AsamControlSize>('default');
const readonly = ref(false),
	disabled = ref(false),
	dark = ref(false),
	mapped = ref(false);
const page = shallowRef<{ controller: SocialController }>();
const pages = { minimal: MinimalSocialPage, brand: BrandSocialPage, tech: TechSocialPage };
const host = computed(() => ({
	security,
	service: mapped.value ? editorial : fixture.service,
	readonly: readonly.value,
	disabled: disabled.value
}));
function switchContext() {
	const s = security.state.value.subject;
	if (s)
		void security.switchContext({
			tenant: typeof s.scope.tenant === 'number' ? '0' : 0,
			organization: null
		});
}
onMounted(() => {
	void security.login(0);
});
onBeforeUnmount(security.dispose);
defineExpose({ security, fixture, page, family, size, readonly, disabled, mapped });
</script>
<style>
.social-demo.dark {
	--asam-color-bg-page: #202523;
	--asam-color-surface: #29322c;
	--asam-color-text-primary: #f3f4ef;
	--asam-color-border: #667369;
}
</style>
