import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { json, sha } from './files.mjs';

const dataFiles = [
	'validation-profile.json',
	'validation-contract.md',
	'design-reference-workflow.md'
];

// Validate transport/source pairing only. Rule meaning/fingerprints remain owned by the shared core.
export function validationPayload(manifest, bundle) {
	const value = manifest.validation;
	if (!value) {
		if (
			manifest.sourceFiles.some(
				(file) => file.path === 'packages/agent-core/src/validation.mjs'
			)
		)
			throw Error('VALIDATION_MANIFEST_REQUIRED');
		return null;
	}
	if (
		value.schemaVersion !== 1 ||
		value.coreEntry !== 'packages/agent-core/src/validation.mjs' ||
		!Array.isArray(value.files) ||
		value.files.length !== dataFiles.length ||
		!dataFiles.every((path) => value.files.filter((file) => file.path === path).length === 1) ||
		value.mcp?.tool !== 'agent_validation_plan' ||
		value.mcp.enableEnvironment !== 'ASAM_AGENT_VALIDATION=1' ||
		value.mcp.readOnly !== true ||
		!/^[a-f0-9]{64}$/.test(value.fingerprint)
	)
		throw Error('VALIDATION_MANIFEST_INVALID');
	for (const file of value.files) {
		if (
			!manifest.files.some(
				(entry) => entry.path === file.path && entry.sha256 === file.sha256
			) ||
			!manifest.sourceFiles.some(
				(entry) =>
					entry.path === `agent-content/${file.path}` && entry.sha256 === file.sha256
			) ||
			sha(readFileSync(join(bundle, file.path))) !== file.sha256
		)
			throw Error('VALIDATION_DATA_MISMATCH');
	}
	if (!manifest.sourceFiles.some((file) => file.path === value.coreEntry))
		throw Error('VALIDATION_CORE_MISSING');
	return value;
}

export function installedValidation(base) {
	if (
		!existsSync(join(base, 'provenance.json')) &&
		!existsSync(join(base, 'bundle/manifest.json'))
	)
		return null;
	const provenance = json(join(base, 'provenance.json'));
	const bytes = readFileSync(join(base, 'bundle/manifest.json'));
	if (sha(bytes) !== provenance.inputManifestSHA256) throw Error('VALIDATION_INPUT_MISMATCH');
	const value = validationPayload(JSON.parse(bytes), join(base, 'bundle'));
	if (!value) return null;
	const profile = value.files.find((file) => file.path === 'validation-profile.json');
	if (
		sha(readFileSync(join(base, 'runtime/agent-content/validation-profile.json'))) !==
			profile.sha256 ||
		!existsSync(join(base, 'runtime', value.coreEntry))
	)
		throw Error('VALIDATION_RUNTIME_INCOMPLETE');
	return value;
}
