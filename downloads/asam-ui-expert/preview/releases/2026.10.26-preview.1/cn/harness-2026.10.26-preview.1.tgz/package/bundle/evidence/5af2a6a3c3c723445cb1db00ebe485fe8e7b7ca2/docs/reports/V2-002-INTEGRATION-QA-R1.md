# V2-002 有限集成回归 · QA-R1

2026-10-16（Asia/Shanghai）。**固定集成输入的有限回归 PASS，可交开发主控核验、保全及原三角色收尾。** 本报告独立验证新包，不把旧 QA 包结论挂到新包，也不替代其他卡或官网的独立验收。

## 固定输入与范围

- 完整输入：`1956f2d0e689ec5f2f4e8ce3db0cd91af12b844d`，本 QA 独立 `E:/worktree-tmp/04a4/asam-ui` 精确检出；只提交本报告。
- 原完整 QA：`79c14122c1b80e4be1986b1f8055ad4168130a3b`；原 ACC：`82573a1077a0bf055db4e69c7e18ef239defb1ba`。原 R1 FAIL、上游判界、R2 通过及原件均保留，不重开001或重跑不变23组。
- 字段选取提交 `9097c1690fc683ca254c9af53c43dcf1a21a1ecc` 的实际 diff-tree 为26个变更路径，逐 blob 对已验623/8a输入一致；当前根中 README 与 consumer/verify 两处因本次明确衔接而变化，已单独亲审。当前字段源码、Form、own SSR 与其余字段夹具无未授权漂移。
- main 的共享 Form/SSR 两 blob 已由维护 owner 集成并向上合入；主线独立凭据为 `fd142ff764e57bbe1026e498727e6eff25a13768:docs/reports/MAINT-SHARED-FORM-INTEGRATION-20261016.md`，已按固定 Git 原文读取，仅作适用来源，不代本次新包验证。保留的六行输入计数透明背景样式也在本次实际包浏览器中检查。
- 原角色及权限实际回合 `01a14347-2bbe-7d60-aadd-01dad1a27db4`：gpt-6.1-sol/high、danger-full-access/never，有效工程工具；无 CodeGraph，未初始化。Node22.19.0/pnpm11.9.0，D唯一store/cache/state与E独占temp/profile/output均在执行进程核实。

## OCR 与实际差异

自行执行 OCR v1.13.0 delegate preview/rule 并由本宿主亲审。由于根采用选取集成，工具实际 range 的 merge_base 为 `6141229b21a56efdf210fb845cdabf556bf0cc10`，而非传入的623；完整预览621路径均外置保留。按开发主控指定范围排除 apps/docs/tools，范围预览27可审、594排除；没有以工具总数冒全官网或全树审查通过。

- 5项重新亲审：Pro package.json、vite.config.ts、UI styles/index.css、CSS两分支测试、consumer/verify；使用实际 merge-base→输入的差异和必要上下文读取。
- 22项继承原79c审查，各自当前 Git blob 与623一致，逐项登记继承来源；27项均 reviewed，0 skipped。不是重新执行22项未变源码审查。
- Pro README 与 CSS bridge DEV报告补充人工审查；其他官网、治理和非本卡内容按显式授权边界排除，不签其新结论。`ocr-full-preview.json`、`ocr-scope-preview.json`、`ocr-rules.json`、`ocr-coverage.json`固定实际refs、逐路径及排除清单；字段选取与预期衔接差异 errors=[]。

CSS插件仅在最终 bundle 没有 style.css 时补无规则注释入口，不改变已有真实 CSS；Vue插件、cssFileName、公开 CSS export 与CSS sideEffects对应。十个运行出口、peer/声明/私有路径保护保持；consumer新增真实CSS导入并对pnpm子命令显式使用never。没有发现未处置的本次源码缺陷。

## 实际执行结果

| 检查                      | 本 QA 独立结果                                                                                                                                                                                                   |
| ------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| UI/Pro 严格类型及实际构建 | UI typecheck退出0；新UI完整JS→声明→样式、Pro构建与typecheck退出0，根锁和EP补丁未变。                                                                                                                             |
| CSS无样式与真实SFC分支    | 使用实际字段 src/index.ts，移除补入口插件的对照确实无CSS；加入插件后有注释式style.css且JS逐字节不变。真实scoped SFC保留selector和letter-spacing:7px，未被无规则注释覆盖。                                        |
| 新两包实际消费            | 15步通过：真实pack/安装、类型/生产构建、十运行出口、声明、peers、CSS解析和Vite真实导入；不存在符号/私有路径/坏声明/缺peer按预期失败。坏声明及manifest恢复，后继包类型/载荷比较再次验证恢复。                     |
| 同一字段SFC/type组合      | 源码类型/构建、真实包类型/构建4步通过。包侧标准tsconfig无源alias/根extends；没有重复选项核心全组。                                                                                                               |
| 模型与Form                | 从实际安装包的公开 `@asam-ui/pro` 入口运行9组模型；本轮构建UI运行8项own SSR，全部通过，含原型同名missing/own undefined/null/0/false/空串/显式值。                                                                |
| 实际包guard及CSS          | 独立真实包fixture的12组通过：原11组能力预检/局部目标/异步callback与异常传播/清理/隐藏折叠/恢复/public slot/search零触发，另验证两包CSS导入及input/textarea计数背景为透明。模型、0/false、草稿保持，无pageerror。 |
| 适用原红件                | 新包QA002-01/02两组通过：schema/旧fields控件、slot与native fieldValue一致；长文本/标签/未解析值/错误在1280/390和窄容器无横溢，全文复制保留，截图亲看。                                                           |
| producer→tar→install      | UI1722、Pro8项dist路径集合和原始字节三方全部一致，package.json在tar/安装也一致，errors=[]。实际安装Pro CSS剥离注释后为空，确认当前无规则。                                                                       |

复用本 QA 既有 consumer `E:/DevCache/artifacts/asam-ui/V2-002/qa-r1/r2/consumer/consumer` 和锁定依赖，先把其原manifest/lock、根文件与src保全到本轮 `reused-consumer-before`；原归档包/QA/ACC结果不覆盖。新输出、包与日志全在独立目录。外置consumer驱动仅把fixture与consumer路径路由到上述实际位置，不改消费断言；字段驱动同样只路由路径并省略不变核心全组，由模型9/SSR8/guard承担本轮定向行为验证。适配前仓库脚本与实际驱动均按摘要保存。

计数CSS探针首稿用data属性定位wrapper，但该属性实际透传到原生输入；改用真实组件/计数DOM后12组通过。初稿与失败原件保留，未修改产品或撤销样式断言。Chrome实际155.0.8059.82，各浏览器context/server均finally结束，端口2611/2622及本角色匹配进程回读无残留。

## 新包、源与证据配对

两个包均为0.1.0-alpha.1，来自本QA固定1956输入的完整重建，不能与原R2相同版本的包互换摘要。UI/pro源码、实际生产者、归档和复用consumer的安装位置都记录在索引和receipt。

| 对象          | SHA256 / 路径                                                                                                                                |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| 新 Pro tgz    | `afa0a963eda2d74f514cb46931b95bb5d1f5d4128766f5a865d53533d4a12588`；本轮 `consumer/packs/6c2dc17313cc4fad/asam-ui-pro-0.1.0-alpha.1.tgz`。   |
| 新 UI tgz     | `2fbc5fb5e240d0f737e24f72c8ea65f4f839022374f08f48bdc6003c0090ab12`；本轮 `consumer/packs/ui-d4c9ded9b0427960/asam-ui-ui-0.1.0-alpha.1.tgz`。 |
| 根锁 / EP补丁 | `5efa11b5c7253f021b081851046f6e1f853a8db1f7617d394bae50e8993c81d8` / `c1fea5923b0d78c0155c213ee186b0417e3790a0de3fdbe646e1aa5c9a1332c4`。    |
| 本轮索引      | `evidence-index.json`：14项固定源映射、98项原件，SHA256 `5fcd66ac960806c42f04b1fffaff15b6c1de3bf65cce36c41f41c66cd49a323d`。                 |

外部证据根：`E:/DevCache/artifacts/asam-ui/V2-002/qa-r1/integration-1956`。关键原件为 `actual-turn.json`、OCR三件与coverage、`consumer-main.log`/`consumer/receipt.json`及15步日志、`css-branches/receipt.json`、`ui-typecheck.log`、`fields-verify.log`、`form-own.log`、`model.json`、`guard-browser.json`、原红件浏览器receipt/截图和 `payload-pairing.json`。大原件不入Git；当前报告在提交前执行格式、diff及仓库完整/暂存内容检查。

上游原型名规则仍未被修复，预检只明确拒绝不可靠校验；不签003/004的真实请求、保存、上次结果或定位，不测试未纳入本集成的editor/list。仅本卡有限集成回归通过，无需新建角色或重新全卡QA→ACC。开发主控核本固定报告/索引后同轮组织保全、原三角色归档及资源回收；本QA不提前自归档、不改main/台账，不推送、部署或发布。
