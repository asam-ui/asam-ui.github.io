import { gunzipSync } from 'node:zlib';

// Extract one fixed member in memory. Never unpack paths, run package scripts,
// or trust executable bytes until the existing pinned binary SHA256 is checked.
export function ocrArchive(bytes, expectedBytes) {
	let tar;
	try {
		tar = gunzipSync(bytes, { maxOutputLength: expectedBytes + 1024 * 1024 });
	} catch {
		throw Error('TOOL_ARCHIVE_INVALID');
	}
	let binary;
	for (let offset = 0; offset + 512 <= tar.length;) {
		const header = tar.subarray(offset, offset + 512);
		if (header.every((byte) => byte === 0)) break;
		const name = header.subarray(0, 100).toString('utf8').split('\0')[0];
		const prefix = header.subarray(345, 500).toString('utf8').split('\0')[0];
		const sizeText = header.subarray(124, 136).toString('ascii').replace(/\0.*$/, '').trim();
		if (!/^[0-7]+$/.test(sizeText)) throw Error('TOOL_ARCHIVE_INVALID');
		const size = parseInt(sizeText, 8),
			start = offset + 512;
		if (!Number.isSafeInteger(size) || start + size > tar.length)
			throw Error('TOOL_ARCHIVE_INVALID');
		const path = prefix ? `${prefix}/${name}` : name;
		if (path === 'package/bin/opencodereview' || path === 'package/bin/opencodereview.exe') {
			if (binary || ![0, 48].includes(header[156]) || size !== expectedBytes)
				throw Error('TOOL_ARCHIVE_INVALID');
			binary = tar.subarray(start, start + size);
		}
		offset = start + Math.ceil(size / 512) * 512;
	}
	if (!binary) throw Error('TOOL_ARCHIVE_INVALID');
	return binary;
}
