import { mountAdministration } from '../examples/mount.js';
mountAdministration('minimal');
