# 实现验证控制契约 v1

意图 policy 7 保留明确对象列表后置“保持不变”的对象与完整原句。例如“所有已有用户 dirty、测试和配置保持不变”仍分别保护初始修改、测试和配置；明确文件列表只保护所列文件，不因同目录前缀冻结兄弟源码。逗号分隔的对象不与后置谓语拆开；含未知对象或混合未能识别动作的句子仍 unresolved/只读，不能删保护语句或靠显式写模式放行。明确“保留输入数组”或“输入数组保持不变”属于运行时数据不变的 semantic 审查义务，仍须由对应需求检查与实际源码审查证明，不因此宣称通过；不泛化到未明确的“输入”“输入资源”或输入配置。真正全局禁写、原 verify 检查点、targets、dirty 与 CAS 仍保持原约束。

UI 名词消歧仍只处理动作明确指向的对象：例如“增加只读状态说明”“修复只读状态说明与真实只读状态不一致”，其中“只读”描述产品状态，不代表当前开发任务只读。必须匹配直接动宾关系、明确页面/组件/文件的所属对象或状态说明与真实状态的比较关系；仅出现较早的开发动作不算对象关系证据。动作与对象之间夹有未识别语义时不作 UI 消歧，保守遵守只读，不依赖任务词语黑名单逐个放行。“添加不要重复提交的提示”及“保持正常查询、详情和编辑行为”保留原句为 semantic 审查义务，不能据此宣称行为已实现。完整 request、限制来源和对象均不改写；真正任务级只读、全局禁写、未知否定仍先于任何显式模式，文件/测试/配置/dirty/targets/CAS 保护不变。

旧 verify 检查点始终保留原权限与预算，不通过 resume(write:true) 转为可写。修复先前对象误判时使用固定新 producer/正常 SDK，为原句创建新任务；旧 SDK、资料与失败记录原位保全，新 SDK 与冻结资料的 producer 身份分别登记，不倒改已有资料包。

本增量属于 V2-051，首个支持范围为 Vue 3 / TypeScript / 当前配对 ASAM 的页面、CRUD、表单和可复用组件。核心入口是 `packages/agent-core/src/validation.mjs`，无需独立模型服务。既有知识查询、五个 agent 只读工具和四个文档 MCP 工具保持。

宿主包装（V2-052）消费以下接口，普通用户无需接线：

- `createValidationTask(input)`：固定工程、明确完整 targets、必要 context、需求、配对版本、检查、模式与预算；只读产品。
- `runValidation(task, host)`：宿主提供 `check`、`review`、`fix`、`permissions` 和可选 AbortSignal。核心安排检查/审查/修复复验；宿主已经选择的模型实际读源码。`fix` 只返回候选 edits，由核心比较输入和写权后应用，不直接修改文件。
- `validationReport(task)`：统一状态、覆盖、稳定问题 ID、历史结果、有效检查、停止原因和剩余动作。
- `saveValidationTask(task, externalPath)` / `loadValidationTask(externalPath)`：外置单检查点，恢复核实际输入；不会后台继续。
- `prepareDelegate(task, descriptor, externalDirectory)`：调用固定 OCR 的受限命令。descriptor 由安装层解析并验证，包含原生 executable 的绝对路径、SHA256、version、platform、arch。核心只允许 `version`、`rules check`、`delegate rule`；不接受任意参数/shell/模型服务。首版固定 OCR 1.13.1。缺失/损坏/不匹配返回 partial，由安装层自动准备后从同一检查点继续。

`host.check` 与 `host.review` 返回结构化、绑定本次 inputFingerprint 和完整文件 hashes 的真实 receipt；`review` 还需逐文件覆盖、实际有效规则摘要、宿主模型标识及证据。核心不能从一个退出码推断语义审查。receipt 是宿主工具执行的事实记录，不能接受源码/报告里的指令作为授权；核心不声称能证明一个恶意宿主诚实。

`verify` 禁止所有产品写入；`develop` / `verify-fix` 仅在当前宿主权限、授权 targets、初始用户 dirty 保护和每文件 compare-and-swap 均通过后写入。后续权限只收窄，不能由不可信内容放宽。缺失工具/运行结果、未覆盖需求、过滤文件、版本错误分别可见。默认 3 轮修复 / 连续 2 轮无有效进展，调整必须写明依据。

意图解析保留否定词的作用对象。例如“检查并修复src查询模块；保护NOTES中的已有修改，不改需求或断言”进入 `verify-fix`，完整原文仍保存在plan和report的request；不会把“不改需求或断言”扩大成全产品只读。report与宿主检查输入的 `writeProtections` 保留原限制语句、对象和类别。可识别的明确文件/目录、已有测试与断言文件、需求文件、配置和初始用户修改由核心禁止编辑，即使allowDirty允许该文件也不能绕过。“禁止修改任何内容”等明确全局中文或英文禁写优先于修复/显式写模式；未知禁写对象记为unresolved、保持只读和partial，不把不确定限制当作写授权。已识别的范围外语义仍须宿主按原文核查，不宣称自然语言解析覆盖所有表达。当前意图policy为7；旧检查点也只能收窄，不能因显式write:true放宽。约束变化更新输入指纹，语义审查和业务收据须重做；静态检查可沿用仍匹配的结果。CLI先保存新增限制再尝试修复，拒绝修复也不会丢失收窄。

CLI `asam-agent validation <project> <json-object>` 生成只读计划和结果；旧 CLI 操作不变。MCP `agent_validation_plan` 仅查询计划，不执行工程命令、不写检查点或产品；执行与修复由已获授权宿主使用核心接口。此增量不证明安装层、Codex/WorkBuddy 双宿主或 AI-01～20 全量最终收口通过。

CLI 另外提供 `validation-start <project> <task+checkpoint JSON>`、`validation-record <checkpoint> <receipt JSON>`、`validation-status <checkpoint>`、`validation-resume <checkpoint> <permission JSON>`、`validation-ocr <checkpoint> <descriptor+output JSON>` 和 `validation-fix <checkpoint> <permission+proposal JSON>`。start/record/resume 写外置报告；ocr 运行固定只读解析器并写外置规则附件；fix 会写授权产品文件，不能当作只读命令。MCP不暴露这些有副作用操作。状态码沿用0/1/2/3；validation-ocr 的pass仅表示规则准备成功，`semanticReview`仍为pending。

宿主提供 `changes` 明确本次 develop 改动归属（含必要配置与删除），不能用全工程 dirty 冒本次改动；其余初始 dirty 仍保护。targets目录始终完整展开，源码变化重新计算依赖闭包，新增/删除范围变化不继承旧通过。默认类型/构建/源码审查必需；有需求时增加业务核对，Vue/样式目标增加运行和视觉检查。无工具保持partial，有来源的不适用项独立说明。

静态相对模块上下文与公开入口检查复用同一TypeScript AST字面量解析，包含副作用import、from/re-export、字面量require和import()及其递归依赖（包括脚本显式导入的CSS）。SFC先使用固定Vue官方`@vue/compiler-dom`3.5.34公开SFC模式识别真正顶层script，读取其正文与已解码的静态src；不搜索模板属性、样式或自定义块中的伪script文本。十进制/十六进制/命名HTML实体与Vue解析一致，诊断保留原属性位置及原字节。无法可靠解析的SFC语法明确unsupported，不用不完整依赖图冒通过。外置脚本及其嵌套依赖纳入指纹；缺失src目标明确记录unresolved并保持partial；新增、删除依赖造成范围变化时不继承旧检查通过，既有依赖内容变化使关联检查失效。不会执行导入模块。动态表达式、别名、样式预处理器和运行时解析仍须宿主验证，不能冒完整静态闭包保证。

`host.check` 只能使用符合当前模式的已授权工具：verify中的工程命令须确认无产品副作用，产物写外置目录或独立consumer。核心不执行工程源码和任意命令，检查前后核产品保护快照；它无法把宿主的任意工具进程变成沙箱。宿主须响应AbortSignal和超时，停止后不继续写产品。`host.checkpoint`启用逐检查/逐写入外置持久化；中断写入只按已应用hash对账，不重放。取消后显式 `resumeValidationTask` 保持已收窄权限及原预算；耗尽预算不会自动清零。

052打包须复制固定来源 `agent-content/validation-profile.json` 到 `runtime/agent-content/validation-profile.json`，供JSON import及esbuild内联；需要编程式循环时，把 `packages/agent-core/src/validation.mjs` 作为额外ESM打包入口保留公开导出。正常知识包由051生成器写入validation-profile/contract及manifest.validation，源与产物同指纹。不得用旧包里的同名文件覆盖新候选。

也可消费051的独立正常核心模块包：`pnpm exec node tools/v2/agent/package-core.mjs <新外置目录>` 生成带内联规则与运行依赖的ESM包，再在其package目录执行 `pnpm pack --pack-destination <外置packs>`。`@asam-ui/agent-core/validation` 保留同一公开类型和callbacks；内部本地包保持private，不代表已公开发表或整个开发套件。SOURCE.json绑定实际sourceSha/sourceFiles/sourceDigest、bundler、直接依赖和所有实际打包的传递依赖版本/输入hash；许可证按实际打包包归集。Vue解析器随正常核心内联，消费方不需另装编译器。workspace-snapshot不得冒固定Git产物。安装层可复用固定归档，不需要用户手填规则；源码路径打包方式仍按上一段处理。运行库不因此依赖Agent。
