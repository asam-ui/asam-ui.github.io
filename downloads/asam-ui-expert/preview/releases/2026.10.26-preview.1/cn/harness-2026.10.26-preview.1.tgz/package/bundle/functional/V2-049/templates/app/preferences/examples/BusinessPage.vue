<template>
	<section>
		<h2>{{ preferences.t(page) }}</h2>
		<p>{{ preferences.t('greeting', { name: 'ASAM' }) }}</p>
		<label>{{ preferences.t('draft') }} <input v-model="draft" data-draft /></label>
		<p data-format>
			{{ preferences.number(12345.67) }} ·
			{{
				preferences.date(new Date('2026-10-18T12:00:00Z'), {
					timeZone: 'UTC',
					dateStyle: 'long'
				})
			}}
		</p>
	</section>
</template>
<script setup lang="ts">
import { inject, ref } from 'vue';
import { useRoute } from 'vue-router';
import { preferenceKey } from './context.js';
const preferences = inject(preferenceKey)!;
const page = useRoute().path === '/notes' ? 'notes' : 'home';
const draft = ref('');
</script>
