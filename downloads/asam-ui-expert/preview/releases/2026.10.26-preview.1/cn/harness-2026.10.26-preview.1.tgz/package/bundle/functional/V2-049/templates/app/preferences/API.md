# API

| API                          | 输入/输出                                | 行为                                              |
| ---------------------------- | ---------------------------------------- | ------------------------------------------------- |
| createPreferences            | PreferenceOptions → PreferenceController | owner 固定；实例 dispose 后 choose 返回 false     |
| locale/theme/colorMode       | 只读 computed                            | 应用语言、用户选择、有效颜色                      |
| choose                       | Partial<Preferences> → boolean           | 拒绝非法值；写失败仍保留会话选择                  |
| t                            | key, string/number 插值 → string         | 普通文本；fallback 与 issue 可观察                |
| number/date                  | 标准 Intl options → string               | 使用当前 locale                                   |
| status/issues                | 只读 ref                                 | missing/ok/migrated/invalid/future/unavailable 等 |
| reset/dispose                | 无参数                                   | 当前 owner 重置；监听器幂等清理                   |
| createBusinessCache          | CacheOptions<T> → controller             | 每 scope snapshot TTL，payload 需 validate        |
| read/write                   | name / name,value                        | Result<T> / StorageStatus；验证实际存储           |
| remember                     | name, async loader → Promise<Result<T>>  | 失效代次阻止晚到恢复                              |
| switchScope                  | typed Scope                              | 同步退出旧 scope 显示和异步写入                   |
| clear/reset/invalidate       | 无参数                                   | 当前 scope envelope 删除；使在途任务失效          |
| dispose                      | 无参数                                   | 幂等失效，后续操作不写存储                        |
| storageKey/encodeScope       | app/kind/owner/scope                     | typed tuple 编码，非法 scope 抛错                 |
| browserStorage/memoryStorage | 无参数                                   | 安全发现浏览器存储 / 新建独立内存适配器           |

完整字段与结果类型以同版 Types.ts、Cache.ts、Preferences.ts 为准。status 为最近操作结果；remember 失效返回 stale，不覆盖新的 scope 状态。无全局 clear、无主体推断、无 KeepAlive 重实现。

示例反馈：data-preference-feedback 与 data-cache-feedback 分别对应 preferences.status 与 cache.status；各自覆盖状态的双语说明。恢复必须由相应成功操作产生，切适配器不虚报成功；控制器类型与存储协议未变。
