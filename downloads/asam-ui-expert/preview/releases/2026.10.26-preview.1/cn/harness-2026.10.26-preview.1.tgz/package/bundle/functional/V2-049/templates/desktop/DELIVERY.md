# V2-049 首完整 DEV 候选

当前修订：原QA-R1已对5cc及b0fb实际复审；QA049-01/02关闭，QA049-03同scope基线连续性缺陷的原DEV整改及新固定候选见 [REMEDIATION-R3](./REMEDIATION-R3.md)，上一轮见 [R2](./REMEDIATION-R2.md)。下文保留5cc首候选的原DEV事实，不替代QA当前结论。首次完整性能预算FAIL不变。

2026-10-19。完整浏览器窗口式工作台、三族SFC/Types/API/示例/Agent方法与适用迁移已交。**DEV功能检查通过，首次完整性能预算FAIL；不得标整卡PASS或已完成QA/ACC。** 未拆成小阶段交付，完整独立OCR源码审查→QA→ACC尚待原测试主控安排。

固定base `2d814770fafa3a9268707d7202d31e6b698d4896`，分支 `codex/v2-049-dev-r1`，只写templates/desktop与tests/v2/desktop。最终提交head、全部Git blob/raw字节、方法/配置/锁/包/日志/截图与外置原件哈希在 `E:/DevCache/artifacts/asam-ui/v2-049/dev-r1/CANDIDATE.json`。自引用head在提交后由封套绑定，不在正文伪造。正常各阶段的headAtObservation仍是当时base，不冒最终提交head。

## 复用与完整实现

实核本人f604项目、E独立工作区、原生新回合Sol/high、danger-full-access/never及有效工程；15公开源与三项已验依赖签名通过。仅只读当前固定Git/稳定签名，不访问034保护空间或递归扫历史安装。

消费029的AsamPageContainer与同版Provider/四尺寸，示例导航只用032公开createNavigation。034 Preferences仅locale/theme；布局真实用createBusinessCache，独立app/desktop-layout命名空间、typed owner/scope、version=1、TTL默认30天/now/validate。严格layout schema不存正文/凭据/权限；allowlist实时过滤、scope内容销毁、迟到/重入guard、坏记录与未来版本明确reset、双实例冲突不静默覆写。逻辑rect与视口投影分离。

窗口开/激活/最小化/恢复/最大化/还原/关、pointer/keyboard移动缩放、层级与焦点、窄屏单面板、内容实例与任务所有权完整。三族布局差异见DESIGN，完整追溯与42项适用边界见TRACEABILITY。普通项目源码可继续编辑，不依赖Agent运行时。公共出口/官网/知识索引仅INTEGRATION-PROPOSAL提案。

## 工程与真实结果

| 范围                  | 真实结果                                                                                                                                                |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 公开类型正反、生产SFC | vue-tsc通过；包含必须报错的owner/size/body/permission/readonly反例                                                                                      |
| 逻辑                  | 8具名组通过：三窗生命周期、投影、schema、权限、typed身份/TTL/坏存储/冲突/迟到/回调重入                                                                  |
| 正常生产浏览器        | 三族×1280/390，174断言通过；修复后必要全三族回归另174通过，不把重复次数当覆盖数量                                                                       |
| 边界                  | 首轮resize竞态FAIL保留；提交点实测surface尺寸复核后67断言通过，含实际pointer resize/touchCancel、焦点、坏localStorage/跨页冲突、子任务取消              |
| 动态/滚动/异常        | 11断言通过：各族正常180ms实际CSS动画、reduce=none、真实嵌套滚动取消；浏览器SecurityError通过明确注入模拟，当前会话继续                                  |
| Agent改配             | 实际改title/notes标题/初始x/SFC正文，正常包重新生产构建，三族宽窄30断言通过；modified先冻结再恢复，restored另30通过                                     |
| 二次程序核验          | 324项通过；normal/restored全部78源/config/锁/包/dist/metadata逐字节一致；三阶段1874实际安装载荷同已签包。此为DEV独立程序核验，非独立QA角色              |
| 许可/包               | 正常完整UI/Pro file tar，UI b581a432…/Pro ebe7532e…，来源已验b9；整个UI与所消费Pro layout/configuration同固定base无差异；1874实际载荷含许可文件逐项核验 |

本机Node22.19.0/x64、pnpm11.9.0、实际Chrome155.0.8059.82、Playwright1.58.2。公共运行时直接复用已安装版本，未下载浏览器。pnpm唯一D:/.pnpm-store，其他temp/profile/产物为本卡E目录；独立consumer及子pnpm实际verifyDepsBeforeRun=error，hoisted/copy，不装root partial或借他人node_modules。包/源码/dist/配置/锁/安装metadata各阶段绑定。

## 首失败与明确未通过

首次3,000ms预算方法已在browser前冻结：完整DOM每元素属性/文字/未量化rect/全部computed style/滚动与输入/焦点，完整CSS/fonts/images、无pending rAF/动画，连续两帧精确相同；保留编码/运输/解码/比较/最终browserRPC及host双钟成本。

首minimal-1280初始样本：179元素、每帧140049个computed属性，两帧完整raw 10338896B；browser完整端点9076.89990234375ms，最终browserRPC 13762.300048828125ms，host13766.0417ms，host比较66.40830000000096ms。两帧精确相同但双钟超预算，**FAIL**。首次raw、截图、方法SHA与所有成本保留，后续五场景及后续操作预算NOT_RUN；没有改字段/精度/双钟、扣运输成本、抬预算或重采first追绿。后续功能/视觉修复不冒性能复测通过。此预算缺口须继续诊断和整改，当前不具备完整质量PASS。

首pnpm11忽略.npmrc工程选项、无TTY保护、锁autoInstallPeers配置不符均保留日志；最终实际yaml修复后离线独立安装自然0。首类型错误AsamInput textarea按公开拆分改为AsamTextarea，原失败保留。恢复命令曾返回运行session后构建已派发，原日志保留，不依赖该重叠结果；恢复自然完成后另串行build0并验证全部原字节。首边界resize FAIL与后继R2分别保留，不覆盖。

## 范围与下一步

未测所有OS/浏览器、SSR hydration、真实CL/后端、Codex/WorkBuddy完整安装生命周期；相应跨宿主实施仍由052承担。本地同步StorageAdapter不是跨进程原子CAS，读前/写前检测不能宣称消除最后一次setItem之间的同时写竞争。

送原测试主控的是完整可审源码与全范围结果，性能FAIL仍开；不是独立QA/ACC或整卡完成。QA须固定本base/head执行OCR delegate preview/rules并逐文件实际审查，核本次resize修复、完整适用状态、预算缺口与所有历史FAIL；真实完整QA PASS后才独立ACC。没有创建角色/子代理/心跳、归档或删除角色/工作树、写canonical/云/main、推送/部署/npm发布或现网覆盖。本卡独立consumer的安装结构由pnpm在精确路径核实后重建，原配置/锁/metadata及全部失败日志保留。
