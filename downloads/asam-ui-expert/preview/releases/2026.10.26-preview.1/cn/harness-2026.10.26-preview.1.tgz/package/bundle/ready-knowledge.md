# 已就绪知识与组合迁移

本轮从固定 `f4be97aba0022d1e865c0b4d1378324661d3b7ee` 接续，继承 ba8e 共享核心及原独立 QA/ACC、5ccb 有限回归，不重开原核心全组。051-F 继续实际实施，不等待全部最终输入。

## 当前输入与实际交付

已完成的 V2-008～042、044～046 共38项进入可离线读取的来源知识：capability、README、API、Types、公开入口、Agent配方、现有迁移正文，以及 capability 明确引用且实际存在的完整示例/三族SFC。引用不存在时保留 `unavailableExamples`，不伪造源码；SFC的业务模块闭包仍按其原交付读取，不承诺单文件独立运行。

V2-043、047、048、049、053 共5项保留待最终输入。完整43项依赖、AI-01～20、VAL-S01～18与051-A～F范围均保留；38项来源收录不等于38项运行适配全部验收。

`ready-knowledge.json` 只指定真实任务与目录，不复制组件实现。`ready-knowledge.mjs` 读固定本地台账已完成状态、正文和逐字节来源，生成外置 `source-knowledge.json`；加载时核外层文件、来源指纹及每份嵌入正文，拒绝记录重名、伪装候选及待定任务混入。

保留原9项已配对能力、旧Pro候选与目录原字节。新增ID为 `ready.v2-008` 等，明确 `kind:source-knowledge / runtimePairing:not-checked`，不把新组件冒充旧28ae候选出口。实际安装适配另核正常tar、peer、公开声明、类型、构建与行为；同版本号不能替代候选身份。

## 统一读取与人工迁移

原有 `discover/read/migration` 与 CLI/MCP 共用同一核心，不新增逐组件工具。

```json
{ "query": "AsamCrudPage" }
```

发现 `ready.v2-024` 后按 `read` 的 `section` 读取 `api/examples/recipe/migration/sources`，使用原分页参数，来源正文与哈希一同返回。`symbols` 是来源中的符号引用，标为 `source-reference`，不冒实际安装包的可执行出口。

```json
{ "id": "ready.v2-024", "from": "list-editor-detail", "to": "crud-controller" }
```

上述 `migration` 只返回已提供的人工组合迁移配方，`completed:false`。未知迁移对、自动改写、未提供配方的模块或混入Pro版本对均为 `unsupported`；原固定UI/Pro自身版本迁移语义保持。

`examples/ready-crud` 是本轮新的实际消费适配：40条合成资料、普通查询/编辑/详情组合迁至CRUD，保留同一借入列表、typed key、codec和服务；删除旧保存回调的刷新职责，由CRUD刷新一次；封装公开typed props的 `RecordsPanel.vue`。显式保留dirty/删除确认、readonly、unknown核实、成功与刷新分离，不代表真实CL业务。空查询中被List省略的可选字段由codec明确恢复默认，不能用断言强转业务模型。

实际正常包固定于原CRUD根有限回归的3f0791生产：UI tar `b581a4329280e77aab96419c55d2dad91c4396a87a77dc4c02c904bca50f36da`，Pro tar `4e2fda881b41057084da7478a55e1895d34d0ace1678b7e3db420d8bce8a067f`。此配对只用于本例，不能扩成38项全部运行配对。

## 复现与验证边界

先加载本仓E环境入口和D唯一pnpm入口，核真实配置与资源。用 `tests/v2/agent/ready/prepare-consumer.mjs <新外置路径>` 建立自有consumer；当前reader仅读取 `reproduction-input.json` 指定的哈希签名快照与两份具名immutable tar，原字节复制15项完整输入，不读旧consumer/安装/producer，不重写锁或配置，不执行安装。独立QA随后在自己的新目录离线冻结安装。不使用其他角色mutable node_modules、源码alias或手补声明/dist。

原DEV首次安装用到的相对tar重定位已单独保全：原锁 `a5e862f5…09851` 与实际已验锁 `29b6a5c7…4776`、两类路径11处byte offsets及精确逆映射、183 registry packages/snapshots和peer/patch/integrity相等证明均在签名快照内。来源只取本次DEV自己保留的初轮consumer及已验consumer-r2；原有.npmrc是实际PRESENT，初轮vite配置ABSENT如实记载，未回填历史。最终tsconfig没有额外extends，vite与完整八源也以原已验字节冻结；新reader不再实施这些历史变化。

独立QA的 `QA-READY-EXAMPLES-01` 原八个缺例子FAIL保留。来源收集现承接 `entry/entries/pages/recipe/preview/source` 等既有结构、嵌套对象/数组，以及明确以斜杠结尾的源码目录；保留JSON指针、去重、缺失/外部引用原因，不猜测family标签目录或追踪业务import闭包。新增原八例的正常SDK红→绿及目录/边界检查；该整改只更新知识数据/构建来源与复现reader，不改原核心、正常SDK或八源运行工程，原完整交付封套不覆盖。

用该工程的 `pnpm run typecheck`、`pnpm run build`；`node --experimental-strip-types --test migration.test.mjs` 实际从正常安装包执行组合迁移。`verify-consumer.mjs` 核whole tar所有普通文件与安装字节，并拒绝额外dist；浏览器脚本使用实际Chrome和独占E profile、实际构建产物，截图/trace/日志外置。没有新增性能预算结论。

数据编排页沿ASAM原控件/tokens，不机械套三族设计。视觉按实际1280/390截图、表单错误/焦点、只读详情、未知核实和减少动态检查；不以DOM或模型检查代视觉。原完整模板三族来源可读取，但本次没有重画38项模板或冒充其重新验收。

共享验证方法用于这份真实消费工程，类型/构建、源码审查、运行、视觉和需求结果分别留证；宿主本轮审查标same-context，独立QA→ACC仍由原测试主控组织。052保持停写置顶，不进入其UI/profile/导入或生命周期；未修改根配置/锁、canonical、CL或云端，未发布或推送。

AI-01/03/04/08/14新增38项可读来源；AI-06/07/09/11/12/16落实本例公开消费、复用组件和实际验证；AI-17落实精确人工组合迁移；AI-18/19/20继续保留只读查询、来源与失败、固定候选及未验证边界。其余AI与VAL结果继承原共享核心适用部分，不把此局部增量改标整卡完成。
