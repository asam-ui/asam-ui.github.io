import { readonly, shallowRef } from 'vue';
import type {
	SecurityAdapter,
	SecurityId,
	SecurityRequest,
	SecurityRule,
	SecurityScope,
	SecurityState,
	SecurityStatus,
	SecuritySubject
} from './Types.js';

const id = (value: unknown): value is SecurityId =>
	(typeof value === 'string' && value.trim().length > 0) ||
	(typeof value === 'number' && Number.isFinite(value));
const scopeValid = (scope: SecurityScope) =>
	scope &&
	(scope.tenant === null || id(scope.tenant)) &&
	(scope.organization === null || id(scope.organization));
export const scopeKey = (subject: Pick<SecuritySubject, 'id' | 'scope'>) =>
	JSON.stringify([subject.id, subject.scope.tenant, subject.scope.organization]);
const sameScope = (a: SecurityScope, b: SecurityScope) =>
	a.tenant === b.tenant && a.organization === b.organization;

function normalize(input: SecuritySubject): SecuritySubject {
	const codes = (value: readonly string[]) =>
		Array.isArray(value) && value.every((code) => typeof code === 'string' && !!code.trim());
	if (
		!input ||
		!id(input.id) ||
		typeof input.name !== 'string' ||
		!codes(input.roles) ||
		!codes(input.permissions) ||
		!scopeValid(input.scope) ||
		!Array.isArray(input.contexts) ||
		!input.contexts.every((c) => scopeValid(c) && typeof c.label === 'string') ||
		!Number.isFinite(input.expiresAt) ||
		(input.readOnly !== undefined && typeof input.readOnly !== 'boolean')
	)
		throw new Error('Invalid subject');
	// Explicit allowlist removes accidental host secrets and mutable DTO references.
	return Object.freeze({
		id: input.id,
		name: input.name,
		roles: Object.freeze([...input.roles]),
		permissions: Object.freeze([...input.permissions]),
		scope: Object.freeze({
			tenant: input.scope.tenant,
			organization: input.scope.organization
		}),
		contexts: Object.freeze(
			input.contexts.map((c) =>
				Object.freeze({ tenant: c.tenant, organization: c.organization, label: c.label })
			)
		),
		expiresAt: input.expiresAt,
		readOnly: input.readOnly ?? false
	});
}

/** One controller per application/SSR request. Host adapter owns all credentials. */
export function createSecurity<Credentials>(options: {
	adapter: SecurityAdapter<Credentials>;
	now?: () => number;
}) {
	const now = options.now ?? Date.now;
	const state = shallowRef<SecurityState>({
		status: 'anonymous',
		subject: null,
		error: '',
		epoch: 0
	});
	let generation = 0;
	let disposed = false;
	let abort: AbortController | undefined;
	let timer: ReturnType<typeof setTimeout> | undefined;
	let refreshFlight: { request: SecurityRequest; promise: Promise<boolean> } | undefined;
	const listeners = new Set<() => void>();
	function begin(status: SecurityStatus, started?: (request: SecurityRequest) => void) {
		const token = ++generation;
		const previous = abort;
		const controller = new AbortController();
		let blocked = false;
		const owns = () => token === generation && abort === controller;
		const request: SecurityRequest = {
			signal: controller.signal,
			isCurrent: () => owns() && !disposed && !blocked && !controller.signal.aborted
		};
		// Establish ownership before *any* user-observable synchronous boundary.
		abort = controller;
		clearTimeout(timer);
		timer = undefined;
		refreshFlight = undefined;
		started?.(request);
		let failed = false;
		try {
			state.value = { status, subject: null, error: '', epoch: token };
		} catch {
			failed = true;
		}
		// Always cancel the captured predecessor, never a nested operation's controller.
		previous?.abort();
		if (!owns()) return request;
		for (const listener of [...listeners]) {
			if (!owns()) break;
			try {
				listener();
			} catch {
				failed = true;
			}
		}
		if (failed && owns()) {
			blocked = true;
			try {
				state.value = {
					status: disposed ? 'disposed' : 'error',
					subject: null,
					error: '会话清理失败，请重试',
					epoch: token
				};
			} catch {
				/* A throwing observer cannot reopen this request. */
			}
			controller.abort();
		}
		return request;
	}
	function expire() {
		if (!disposed) begin('expired');
	}
	function accept(input: SecuritySubject, request: SecurityRequest) {
		if (!request.isCurrent()) return false;
		const subject = normalize(input);
		const expired = subject.expiresAt <= now();
		if (!request.isCurrent()) return false;
		if (expired) {
			expire();
			return false;
		}
		state.value = { ...state.value, status: 'authenticated', subject, error: '' };
		if (!request.isCurrent()) return false;
		const schedule = () => {
			if (!request.isCurrent()) return;
			const remaining = subject.expiresAt - now();
			if (!request.isCurrent()) return;
			if (remaining <= 0) expire();
			else timer = setTimeout(schedule, Math.min(remaining, 2147483647));
		};
		schedule();
		return request.isCurrent();
	}
	async function run(
		status: SecurityStatus,
		task: (request: SecurityRequest) => Promise<SecuritySubject | null>,
		started?: (request: SecurityRequest) => void
	) {
		if (disposed) return false;
		const request = begin(status, started);
		if (!request.isCurrent()) return false;
		try {
			const value = await task(request);
			if (!request.isCurrent()) return false;
			if (value === null) {
				state.value = { ...state.value, status: 'anonymous' };
				return false;
			}
			return accept(value, request);
		} catch {
			if (request.isCurrent()) {
				try {
					state.value = {
						...state.value,
						status: 'error',
						subject: null,
						error: '认证或上下文操作失败，请重试'
					};
				} catch {
					/* Observer failures cannot reject or revive an operation. */
				}
			}
			return false;
		}
	}
	function check(rule: SecurityRule): 'allowed' | 'denied' | 'pending' | 'error' {
		const current = state.value;
		if (current.status === 'error') return 'error';
		if (['restoring', 'authenticating', 'refreshing', 'switching'].includes(current.status))
			return 'pending';
		const subject = current.subject;
		if (
			current.status !== 'authenticated' ||
			!subject ||
			subject.expiresAt <= now() ||
			state.value !== current
		)
			return 'denied';
		if (!rule || (!rule.permission && !rule.role)) return 'denied';
		if (
			rule.permission !== undefined &&
			(typeof rule.permission !== 'string' ||
				!rule.permission.trim() ||
				!subject.permissions.includes(rule.permission))
		)
			return 'denied';
		if (
			rule.role !== undefined &&
			(typeof rule.role !== 'string' ||
				!rule.role.trim() ||
				!subject.roles.includes(rule.role))
		)
			return 'denied';
		return rule.write && subject.readOnly ? 'denied' : 'allowed';
	}
	function refresh(): Promise<boolean> {
		if (refreshFlight?.request.isCurrent()) return refreshFlight.promise;
		const subject = state.value.subject;
		if (!subject || disposed) return Promise.resolve(false);
		let complete!: (value: boolean) => void;
		const promise = new Promise<boolean>((resolve) => {
			complete = resolve;
		});
		let slot: typeof refreshFlight;
		const result = run(
			'refreshing',
			async (request) => {
				const value = await options.adapter.refresh(subject, request);
				if (!request.isCurrent()) return null;
				if (scopeKey(value) !== scopeKey(subject))
					throw new Error('Refresh changed identity');
				return value;
			},
			(request) => {
				slot = { request, promise };
				refreshFlight = slot;
			}
		);
		const settle = (value: boolean) => {
			if (refreshFlight === slot) refreshFlight = undefined;
			complete(value);
		};
		void result.then(settle, () => settle(false));
		return promise;
	}
	async function switchContext(scope: SecurityScope) {
		const subject = state.value.subject;
		if (
			!subject ||
			disposed ||
			!scopeValid(scope) ||
			!subject.contexts.some((c) => sameScope(c, scope))
		)
			return false;
		const target = { tenant: scope.tenant, organization: scope.organization };
		return run('switching', async (request) => {
			const value = await options.adapter.switchContext(subject, target, request);
			if (!request.isCurrent()) return null;
			if (value.id !== subject.id || !sameScope(value.scope, target))
				throw new Error('Context mismatch');
			return value;
		});
	}
	async function logout() {
		if (disposed) return false;
		const request = begin('logging-out');
		if (!request.isCurrent()) return false;
		try {
			await options.adapter.logout(request);
			if (!request.isCurrent()) return false;
			state.value = { ...state.value, status: 'anonymous' };
			return request.isCurrent();
		} catch {
			if (request.isCurrent()) {
				try {
					state.value = {
						...state.value,
						status: 'error',
						error: '本地已登出，远端登出失败，请重试'
					};
				} catch {
					/* Keep the local session closed even if an observer throws. */
				}
			}
			return false;
		}
	}
	return {
		state: readonly(state),
		check,
		permission: (permission: string) => check({ permission }),
		login: (credentials: Credentials) =>
			run('authenticating', (request) => options.adapter.login(credentials, request)),
		restore: () => run('restoring', options.adapter.restore),
		refresh,
		switchContext,
		logout,
		expire,
		reset: () => {
			if (!disposed) begin('anonymous');
		},
		onInvalidate: (listener: () => void) => {
			listeners.add(listener);
			return () => listeners.delete(listener);
		},
		dispose: () => {
			if (!disposed) {
				disposed = true;
				begin('disposed');
				abort?.abort();
				listeners.clear();
			}
		}
	};
}
export type SecurityController = ReturnType<typeof createSecurity<unknown>>;

/** Only canonical application-relative paths; never use an untrusted redirect verbatim. */
export function safeReturnPath(input: unknown, fallback = '/safe'): string {
	if (
		typeof input !== 'string' ||
		!input.startsWith('/') ||
		input.startsWith('//') ||
		/[\\\u0000-\u0020\u007f]/.test(input) ||
		/%[0-9a-f]{2}/i.test(input.split(/[?#]/)[0])
	)
		return fallback;
	try {
		const url = new URL(input, 'https://application.invalid');
		return url.origin === 'https://application.invalid' &&
			url.pathname === input.split(/[?#]/)[0]
			? input
			: fallback;
	} catch {
		return fallback;
	}
}
