# V2-047 原 QA-R1 · 471666 整改复验

结论：**四项产品整改通过；整卡仍 FAIL / ACC_NOT_READY**。完整强端点尚未取得
当前候选的通过证据。固定产品为 `47166679eea13a15c697e632d99efbb184e1852f`，
直接父 `8900cdbeffb3cf5c8bbbafdfd7807d3392a8c29e`，原 base
`37b0e6cdee3e6a969194ff39f07e7f9152176b53`。仍是原角色，不是第二次首次 QA。

## 本轮实际结论

| 项目                  | 当前候选独立复验                                                                                                                                                                                        |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| QA047-01 清理同步重入 | PASS。原复现、清理期间动作/草稿回灌、嵌套 host、借入所有权/销毁终态、allowed computed；真实服务切换及合成 composition 后新评论提交、只读 final gate、退出清理通过。首证仍只限定旧候选清理同步返回边界。 |
| QA047-02 四档尺寸     | PASS。三族 × 四尺寸 × button/input/select 共 36 个实际高度均为 40/36/32/28；textarea 多行和 120px 最小高度、完整正文/20 评论保留。390 宽长标签自然换行，未裁剪或横溢。                                  |
| QA047-03 暗色文字     | PASS。三族明暗六场景中 status/sort/refresh 的实际原始文字颜色与页面 ink 接通，前景/背景链留原件。亮度比诊断约 10～15，不作可访问性认证。                                                                |
| QA047-04 失败原因     | PASS。三族 × 1280/390 六场景，444 字服务原因全文纯文本显示、脚本和链接不执行、草稿与恢复提示独立，切帖/服务/身份/新操作清理及迟到失败隔离通过。                                                         |
| 行为、类型与构建      | 66 行为通过：原 53 + 清理 5 + 原因 5 + 原 QA 3。严格公开类型正负、三个 SFC 生产构建通过。                                                                                                               |
| 当前普通 UI           | 九组真实功能流程通过，明确为 functional-only / strongTiming NOT_SAMPLED。                                                                                                                               |
| 完整强端点            | 当前 471 的 normal/detail/write 及改配/恢复强窗口均 NOT_RUN。方法资格核验与预算通过分开；未因换版本重采旧 first。                                                                                       |

19 个差异文件全部宿主审查：OCR delegate 实际 preview/rules 为 16 reviewable，
另 3 文档人工补审，19 reviewed / 0 skipped；实际规则正文、来源、pattern 与 hash
逐路径保留。React 专属规则不套到 Vue。原 27 个未变文件逐签名承接原 38 文件审查。
没有新增未解决的产品源码 finding；完整强门槛仍未关闭。

## 实际输入与消费

只从固定 Git 和声明的不可变原件接收 46 源/19 差异及 DEV 新封套 616 成员；
未读 DEV 活动 consumer/服务。TC 本次声明输入资格与 QA 的接收证明分别保留，
不重扫原 834/1632 历史原件。原生本轮 Sol/high、danger-full-access/never、独立 E
工作区与工程配置已实际核实。

复用自己一次安装且已完整签名核实的正常 consumer；原 UI 1726/Pro 154 正常 tar
成员加 3 CLI shim、15912 物理文件/393 链接和所消费 70 源闭包沿原精确签名承接。
没有新安装、公共库重建、源码 alias 或修改公共产物。实际仍是 EP 官方 CSS → UI → Pro。
当前产品源由固定 Git 复制到自己的 consumer，三族实际 production build，31 个
templates/dist 文件物理只读且写句柄拒绝；正常 CAS 为
`f81934617c36d6b63e6860ffd73d265a8d3a71e1b76893fe8d3b264f46562027`。

每工程加载 E 存储与 D pnpm 入口；实际 Node 22.19/pnpm 11.9，pnpm store/cache/state
为 D 唯一根及子目录，temp/profile/output 隔离在 E。pnpm 命令 child 的 inherited=false
和 runner enforced/error、CLI 实际 readback=error 均保留。方法 oracle 首次在仓库 cwd
触发配置 guard、未启动浏览器或创建窗口，随后仅改用自己的 consumer cwd，未伪造通过。

原 QA 的实际六文件 Agent 改配、物理只读回放和两次真实还原属于原 8900 的已签名历史，
本轮未把这些旧源结果冒作新 471 改配执行。Agent 方法及未变布局源的签名可承接，
当前新增修复通过上述 normal 全流程和定向复验覆盖；当前改配强门槛未测明确保留。

## 必要方法差额

原首完整 raw SHA256
`5b026adfbbe586cff5a803f8a3cf4a19e254ab32dc155a582e1b7289934868d6`
仍为 host 12077.4717ms/browser 12067.90ms 的 FAIL；原详情/写入未测不改写。
既有一次有界诊断的 capture 约 5.25/4.90s，只证明观察成本，不认定唯一产品原因。

后继 `strong-vector.mjs` 固定 SHA256
`ea1d964526f759ae9f0f41e4f14a5eb382cd19ddc9981dc494db1943c744e2e4`，
`codec.mjs` 为 `d50bcae60b2f09f72d67f19ecd35872720ebf421047bf8ab96b8d5d9b89e9b78`。
方法实际源码与资格包在外置 `method-ready-r2/`。TC 已独立实核 1819/0，判定
METHOD FIDELITY QUALIFIED，`allowOneNewMethodWindow=false`：现有单次原生 CSS
成本占去大部分预算，没有足证支持两帧及全部后继观察在 3000ms 内完成，因此本轮不开
新强窗口。这是基于本轮成本证据的调度判断，不冒新 endpoint FAIL 或普适性能下界。
TC 回执 `METHOD-VECTOR-R2-TC-REVIEW.json` 的 SHA256 为
`5976b6d0dd935af476c4f6ad906299f0f56fb249dda409e625c88245156ae5d7`。

- 把同一 CSS 字段的重复 live reread 改为一次完整 native indexed key/getPropertyValue
  读取；所有元素和 before/after 的全部原字段保留。capture 除 CSS 实现和诊断计数名外，
  TypeScript AST 归一后与固定原方法完全相等。
- 原始 CSS 字符串仅做精确字典池，完整展开后比较；无取整、颜色等价或字段裁剪。
  碰撞安全 typed codec 保留 0/字符串 0、undefined/null、-0/NaN/Infinity、保留键对象、
  稀疏数组、Unicode 等；正例和九类负例通过。
- 实际当前 599 元素、1,414,371 CSS 字段与独立完整原生参考逐项零差异，另注入自定义属性、
  fractional transform/opacity；浏览器全源 typed/gzip 回环及 host 独立展开通过。
  vector 2505.9ms/reference 3275.4ms 是方法成本观察，不能推断两帧完整端点 ≤3000ms。
  先前更慢的 named getter 实验与原件保留，未用于后继强方法。
- 所有内部 pair 和解码失败 wire 保留。浏览器对原始完整 source 回环比较，host 独立
  gunzip/解码/全帧比较后，再核独立 CDP checkpoint 并 await 最后 browser RPC。
  该 RPC 先读全部 pending/font/完整动画/image/service 状态并计算 predicate，最后取
  performance.now；完整返回后才取 host end。实际函数 VM 每项模拟 25ms，正例包含
  全部观察，负例拒绝提前结束钟。
- 原 100/20 帖、40/20 评论、真实读写 100ms、3000ms 双独立钟、两真实 RAF、无 warmup
  保持；完整采集/编码/传输/解码/比较/RPC 成本不扣减。原始报告序列化及落盘成本另记。

existing-output guard 已真实非零退出且未打开浏览器。方法准备脚本 R1 因 Windows
路径斜杠 matcher 自身异常未产 READY；保留部分源和 native 后，只修 basename 生成 R2，
未重跑产品功能或预算。源方法资格包不是预算 PASS，也不抹除任何历史 FAIL/UNKNOWN。

## 交付边界

本地 Git 只提交本目录 QA 配方/精简报告；产品工作树仍为原 8900，471 从固定 Git
进入自己的外置 consumer 验证。无公共包、根配置锁、canonical、main、CL 或云写入。
无新角色、子代理、心跳、ACC、推送、部署、发布或自归档；原 DEV/QA 保留后继用途。
自有 preview 61449 已逐命令核属后只停止 PID 56688，自有 Chrome 为 0；实际 native
session33379 返回 exit1/child4294967295，按强制停止记录，不冒正常退出。

完整来源、阶段实际源/有效锁/metadata/工具、执行结果、继承和未测范围位于
`E:/DevCache/artifacts/asam-ui/v2-047/qa-r1/remediation-471/FINAL.json`，
最终只读二次核在同目录 `SECOND-READ.json`。二次原件完整性通过也不代表整卡 QA 通过。
