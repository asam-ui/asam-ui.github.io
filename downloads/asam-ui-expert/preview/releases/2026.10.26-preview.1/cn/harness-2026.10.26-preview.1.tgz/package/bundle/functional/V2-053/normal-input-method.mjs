import assert from 'node:assert/strict';
import { mkdirSync, existsSync, cpSync, readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { root, output, consumer, json, save, hash, run, git } from './lib.mjs';

assert.ok(!existsSync(consumer), '消费安装必须是本角色新目录；不覆盖旧原件');
const packs = join(output, 'packs');
mkdirSync(packs, { recursive: true });
if (existsSync(join(packs, 'ui/pack-receipt.json'))) {
	const receipt = json(join(packs, 'ui/pack-receipt.json'));
	assert.equal(receipt.inputHead, git('rev-parse', 'HEAD'));
	assert.equal(hash(readFileSync(receipt.artifact.path)), receipt.artifact.sha256);
	for (const [path, entry] of Object.entries(receipt.files)) {
		if (path.startsWith('package/dist/'))
			assert.equal(
				hash(readFileSync(join(root, 'packages/ui', path.slice(8)))),
				entry.sha256,
				path
			);
	}
	console.log('复用本角色已固定且逐文件一致的正常 UI 包');
} else {
	run('ui-portable-pack', [
		'exec',
		'node',
		'tools/eng-006/pack-portable-ui.mjs',
		'--stage',
		join(output, 'ui-stage'),
		'--out',
		join(packs, 'ui'),
		'--pnpm-cli',
		process.env.V2_PNPM_ENTRY || process.env.npm_execpath
	]);
}
run('pro-pack', ['pack', '--pack-destination', join(packs, 'pro')], join(root, 'packages/pro'));
const archives = Object.fromEntries(
	['ui', 'pro'].map((name) => {
		const file = join(
			packs,
			name,
			readdirSync(join(packs, name)).find((file) => file.endsWith('.tgz'))
		);
		return [name, { path: file.replaceAll('\\', '/'), sha256: hash(readFileSync(file)) }];
	})
);
mkdirSync(consumer);
const deps = json(join(root, 'tests/v2/consumer/package.json'));
delete deps.scripts;
deps.name = 'asam-v2-053-normal-consumer';
deps.dependencies['@asam-ui/ui'] = `file:${archives.ui.path}`;
deps.dependencies['@asam-ui/pro'] = `file:${archives.pro.path}`;
deps.scripts = { typecheck: 'vue-tsc --noEmit -p tsconfig.json', build: 'vite build' };
save(join(consumer, 'package.json'), deps);
cpSync(join(root, 'patches'), join(consumer, 'patches'), { recursive: true });
writeFileSync(
	join(consumer, 'pnpm-workspace.yaml'),
	readFileSync(join(root, 'pnpm-workspace.yaml'), 'utf8').replace(
		/packages:\s*\n(?:[ \t]+-.*\n)+/,
		'packages: []\n'
	)
);
writeFileSync(
	join(consumer, '.npmrc'),
	'strict-peer-dependencies=true\nauto-install-peers=false\nnode-linker=hoisted\npackage-import-method=copy\nsymlink=false\nenable-global-virtual-store=false\nverify-deps-before-run=error\n'
);
cpSync(join(root, 'tests/v2/base-review/examples'), consumer, { recursive: true });
writeFileSync(
	join(consumer, 'main.ts'),
	`import { createApp, h } from 'vue';
import 'element-plus/dist/index.css';
import '@asam-ui/ui/style.css';
import '@asam-ui/pro/style.css';
import Baseline from './Baseline.vue';
import Plain from './Plain.vue';
createApp({render:()=>h('div', [h(Baseline), h(Plain)])}).mount('#app');\n`
);
writeFileSync(
	join(consumer, 'index.html'),
	'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>V2-053 基础复核</title><div id="app"></div><script type="module" src="/main.ts"></script></html>'
);
writeFileSync(
	join(consumer, 'vite.config.ts'),
	"import {defineConfig} from 'vite';import vue from '@vitejs/plugin-vue';export default defineConfig({plugins:[vue()],server:{host:'127.0.0.1',port:45353,strictPort:true}});\n"
);
save(join(consumer, 'tsconfig.json'), {
	compilerOptions: {
		target: 'ES2022',
		module: 'ESNext',
		moduleResolution: 'Bundler',
		strict: true,
		skipLibCheck: true,
		allowJs: true,
		checkJs: true,
		noEmit: true,
		lib: ['ES2022', 'DOM']
	},
	include: ['*.ts', '*.vue']
});
// 新 fixture 先生成自己的解析锁；实际安装与随后所有运行均 frozen/error。
run('consumer-lock', ['install', '--lockfile-only', '--offline'], consumer);
run('consumer-install', ['install', '--frozen-lockfile', '--offline'], consumer);
const installed = {};
for (const name of ['ui', 'pro']) {
	const dist = join(root, `packages/${name}/dist`);
	const destination = join(consumer, `node_modules/@asam-ui/${name}/dist`);
	const paths = (await import('./lib.mjs')).files(dist);
	installed[name] = paths.map((path) => {
		const suffix = path.slice(dist.length + 1);
		const bytes = readFileSync(path);
		assert.equal(
			hash(readFileSync(join(destination, suffix))),
			hash(bytes),
			`${name}/${suffix}`
		);
		return { path: suffix.replaceAll('\\', '/'), sha256: hash(bytes) };
	});
}
save(join(output, 'normal-package.json'), {
	sourceHead: git('rev-parse', 'HEAD'),
	archives,
	installed,
	lock: hash(readFileSync(join(root, 'pnpm-lock.yaml'))),
	consumerLock: hash(readFileSync(join(consumer, 'pnpm-lock.yaml'))),
	patch: hash(readFileSync(join(root, 'patches/element-plus@2.14.7.patch'))),
	consumer
});
run('consumer-types', ['run', 'typecheck'], consumer);
run('consumer-build', ['run', 'build'], consumer);
