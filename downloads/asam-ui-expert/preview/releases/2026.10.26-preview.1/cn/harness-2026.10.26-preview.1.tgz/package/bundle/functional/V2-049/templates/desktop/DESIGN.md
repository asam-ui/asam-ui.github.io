# 三族参考与实现

参考物为本卡可执行的结构规范与对应SFC，不使用未提供的业务截图推断CL。ASAM tokens和原控件语义优先，未引入外部字体、图片、图标包或动画库。

| 族       | 已阅读技能与取舍                                                                                                                                                                          | 实现位置与结构                                                                           |
| -------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| 克制简约 | `C:/Users/Administrator/.agents/skills/minimalist-ui/SKILL.md`：编辑式层级、细线、衬线大标题、低阴影。桌面任务无需营销页的巨大纵向留白                                                    | MinimalDesktop.vue：顶部编辑刊线、横排介绍与导航、开放点阵桌面、轻窗口                   |
| 品牌分栏 | `C:/Users/Administrator/.agents/skills/high-end-visual-design/SKILL.md`：选择Editorial Split与Soft Structuralism，保留非对称空间和轻反馈；不照搬React/Tailwind、双重嵌套营销卡片或巨型CTA | BrandDesktop.vue：独立品牌侧栏/大字标记、右侧工作区、窄屏压成品牌横栏                    |
| 深色科技 | `C:/Users/Administrator/.agents/skills/industrial-brutalist-ui/SKILL.md`：选择Tactical Telemetry，技术侧索引、刻度网格与直角窗口；ASAM品牌主色替代危险红，不加入噪声/闪烁影响可读性       | TechDesktop.vue：技术顶栏/左编号尺/右工作面、状态式任务栏，示例默认dark，仍支持宿主light |

Desktop.css保三种不同布局/空间/导航。四尺寸由同版ASAM控件消费，标题栏相应40/46/50/54px；有键盘focus和180ms opacity入场，prefers-reduced-motion禁用。主题由034 Preferences→同版AsamApplicationProvider局部作用域生效，不改全局document class。README/API/Agent与能力版本同行维护。

真实预览、逐族宽窄/明暗/状态/焦点验证及正常→修改→还原的具体结果见DELIVERY与外置封套，设计描述不冒截图或浏览器通过。
