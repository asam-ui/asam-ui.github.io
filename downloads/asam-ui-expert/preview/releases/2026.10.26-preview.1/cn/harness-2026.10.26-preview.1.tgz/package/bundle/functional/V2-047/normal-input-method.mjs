import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root = path.resolve(import.meta.dirname, '../../..');
const target = process.argv[2];
if (!target || !path.isAbsolute(target) || !target.replaceAll('\\', '/').startsWith('E:/DevCache/'))
	throw Error('需要独立 E:/DevCache consumer 绝对目录');
if (fs.existsSync(path.join(target, 'package.json')))
	throw Error('consumer已存在，禁止覆盖安装元数据');
const packs = 'E:/DevCache/artifacts/asam-ui/v2-025/dev-r1/qa02501-03-r3b/packs';
const hashes = {
	pro: '340a1a90c824207e4b17a9125d2eaf841f9e8542cc3e11126d2cb335045c99f8',
	ui: '5f1ffb33bc376b7ee12d6e0df7f3375b644b76c5a8e1fa9b71df9393af396b09'
};
const dependencies = { vue: '3.5.34', 'element-plus': '2.14.7' };
for (const [name, hash] of Object.entries(hashes)) {
	const file = `${packs}/${hash}/asam-ui-${name}-0.1.0-alpha.1.tgz`;
	if (crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== hash)
		throw Error('包字节不匹配');
	dependencies[`@asam-ui/${name}`] = `file:${file}`;
}
fs.mkdirSync(target, { recursive: true });
fs.cpSync(path.join(root, 'tests/v2/social'), path.join(target, 'tests/v2/social'), {
	recursive: true
});
fs.cpSync(path.join(root, 'templates/social'), path.join(target, 'templates/social'), {
	recursive: true
});
fs.mkdirSync(path.join(target, 'templates/app/security'), { recursive: true });
for (const [file, expected] of Object.entries({
	'Security.ts': '5340f8080bf2e3a1ed26b331bd6225b09cfb8016ddeff91e7402ff9a3eb6f6ee',
	'Types.ts': '8695acff6342beeb4eba8aa51bb2d358d3ca210ce09aa9f62ac2267d39a2a29a'
})) {
	const raw = execFileSync(
		'git',
		['show', `37b0e6cdee3e6a969194ff39f07e7f9152176b53:templates/app/security/${file}`],
		{ cwd: root }
	);
	if (crypto.createHash('sha256').update(raw).digest('hex') !== expected)
		throw Error('固定033源码不匹配');
	fs.writeFileSync(path.join(target, 'templates/app/security', file), raw);
}
fs.mkdirSync(path.join(target, 'patches'), { recursive: true });
fs.copyFileSync(
	path.join(root, 'patches/element-plus@2.14.7.patch'),
	path.join(target, 'patches/element-plus@2.14.7.patch')
);
fs.writeFileSync(
	path.join(target, 'package.json'),
	JSON.stringify(
		{
			name: 'v2-047-social-consumer',
			private: true,
			type: 'module',
			packageManager: 'pnpm@11.9.0',
			scripts: {
				typecheck: 'node tests/v2/social/command.mjs typecheck',
				build: 'node tests/v2/social/command.mjs build',
				dev: 'node tests/v2/social/command.mjs dev'
			},
			dependencies,
			devDependencies: {
				'@vitejs/plugin-vue': '6.0.9',
				vite: '8.0.10',
				typescript: '6.0.3',
				'vue-tsc': '3.3.11',
				prettier: '3.9.6',
				esbuild: '0.27.4'
			}
		},
		null,
		2
	)
);
fs.writeFileSync(
	path.join(target, 'pnpm-workspace.yaml'),
	"packages: []\nverifyDepsBeforeRun: error\nstrictPeerDependencies: true\nautoInstallPeers: false\nallowBuilds:\n  esbuild: true\noverrides:\n  '@tiptap/vue-3@3.31.3>@tiptap/extension-bubble-menu': 3.31.3\n  '@tiptap/vue-3@3.31.3>@tiptap/extension-floating-menu': 3.31.3\npatchedDependencies:\n  element-plus@2.14.7: patches/element-plus@2.14.7.patch\n"
);
fs.writeFileSync(
	path.join(target, '.npmrc'),
	'node-linker=hoisted\npackage-import-method=copy\nsymlink=false\nenable-global-virtual-store=false\n'
);
fs.writeFileSync(
	path.join(target, 'tsconfig.json'),
	JSON.stringify(
		{
			compilerOptions: {
				target: 'ES2022',
				module: 'ESNext',
				moduleResolution: 'Bundler',
				strict: true,
				skipLibCheck: true,
				lib: ['ES2022', 'DOM', 'DOM.Iterable'],
				types: ['vite/client'],
				noEmit: true
			},
			include: ['templates/**/*.ts', 'templates/**/*.vue']
		},
		null,
		2
	)
);
fs.writeFileSync(
	path.join(target, 'vite.config.ts'),
	"import { defineConfig } from 'vite';\nimport vue from '@vitejs/plugin-vue';\nexport default defineConfig({ plugins: [vue()], build: { target: 'es2022', assetsInlineLimit: 0 } });\n"
);
fs.writeFileSync(
	path.join(target, 'index.html'),
	'<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>公共笔记</title></head><body style="margin:0"><div id="app"></div><script type="module" src="/templates/social/examples/main.ts"></script></body></html>'
);
console.log(JSON.stringify({ target, packages: hashes }));
