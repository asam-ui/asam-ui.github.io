import { createApp, defineComponent, h } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import 'element-plus/dist/index.css';
import '@asam-ui/ui/style.css';
import '@asam-ui/pro/style.css';
import App from './App.vue';
const router = createRouter({
	history: createWebHistory(),
	routes: [
		{ path: '/safe', component: defineComponent(() => () => h('p', '安全页')) },
		{ path: '/:pathMatch(.*)*', component: defineComponent(() => () => h('p', '请选择菜单')) }
	]
});
const application = createApp(App).use(router);
await router.isReady();
application.mount('#app');
