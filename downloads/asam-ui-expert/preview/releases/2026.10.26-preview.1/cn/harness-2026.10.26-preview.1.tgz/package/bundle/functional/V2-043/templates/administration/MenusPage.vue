<template>
	<section aria-label="菜单权限管理模板">
		<div class="menu-layout">
			<aside aria-label="菜单树定位">
				<h3>菜单结构</h3>
				<label
					>定位菜单
					<AsamInput v-model="filter" aria-label="定位菜单" :size="host.size.value"
				/></label>
				<p role="status">{{ error || (loading ? '正在读取菜单树' : '') }}</p>
				<AsamButton :size="host.size.value" @click="loadTree">刷新菜单树</AsamButton
				><AsamTree
					v-if="!error"
					ref="tree"
					node-key="key"
					:data="nodes"
					default-expand-all
					:filter-node-method="filterNode"
					@node-click="locate"
				/>
			</aside>
			<AsamCrudPage :controller="crud" title="菜单与权限管理" :size="host.size.value"
				><template #heading
					><span>菜单不自动导航；本地页面由显式 allowlist 绑定</span></template
				></AsamCrudPage
			>
		</div>
	</section>
</template>
<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue';
import { AsamButton, AsamInput, AsamTree, defineAsamOptions } from '@asam-ui/ui';
import type { AsamTreeExpose, AsamTreeNodeData } from '@asam-ui/ui';
import { AsamCrudPage } from '@asam-ui/pro';
import { useAdministration, useAdministrationCrud, field, readHostOptions } from './Crud.js';
import { menuCodec, versionField } from './Codecs.js';
import { validateTree } from './Tree.js';
import type { TreeNode } from './Tree.js';
import { scopeKey } from '../app/security/index.js';
const host = useAdministration(),
	tree = ref<AsamTreeExpose>(),
	filter = ref(''),
	error = ref(''),
	loading = ref(false),
	nodes = shallowRef<TreeNode[]>([]);
let generation = 0,
	abort: AbortController | undefined,
	alive = true;
function clear() {
	generation++;
	nodes.value = [];
	filter.value = '';
	error.value = '';
	loading.value = false;
	const old = abort;
	abort = undefined;
	old?.abort();
}
const unsubscribe = host.security.onInvalidate(clear);
async function loadTree() {
	if (host.security.check({ permission: 'menus:read' }) !== 'allowed') return;
	const token = ++generation,
		service = host.services.value,
		epoch = host.security.state.value.epoch;
	const old = abort;
	abort = new AbortController();
	old?.abort();
	const current = () =>
		alive &&
		token === generation &&
		service === host.services.value &&
		epoch === host.security.state.value.epoch;
	if (!current()) return;
	loading.value = true;
	error.value = '';
	nodes.value = [];
	try {
		const subject = host.security.state.value.subject!;
		const data = await service.menuNodes({
			signal: abort.signal,
			isCurrent: current,
			scope: scopeKey(subject)
		});
		if (current()) nodes.value = validateTree(data);
	} catch {
		if (current()) {
			nodes.value = [];
			error.value = '菜单树读取失败或结构无效，已整次拒绝';
		}
	} finally {
		if (current()) loading.value = false;
	}
}
const parentSource = defineAsamOptions().api({
	api: async (_: null) => readHostOptions(host, 'menus', (c) => host.services.value.menuNodes(c)),
	params: null,
	transform: (r) => {
		validateTree(r);
		return r.map((n) => ({ value: n.id, label: n.title }));
	},
	fieldNames: { value: 'value', label: 'label' }
});
const fields = [
	{ key: 'parentId', kind: 'single' as const, label: '父菜单（留空为根）', source: parentSource },
	field('title', '菜单标题'),
	field('kind', '节点种类'),
	field('permissionCode', '权限代码'),
	field('enabled', '启用状态'),
	field('grantable', '明确可授予'),
	versionField
];
const crud = useAdministrationCrud(
	host,
	'menus',
	host.services.value.menus.crud,
	menuCodec,
	fields,
	[
		{ key: 'id', label: '标识', width: 100 },
		{ key: 'parentId', label: '父标识', width: 100 },
		{ key: 'title', label: '菜单标题', width: 180 },
		{ key: 'kind', label: '种类', width: 100 },
		{ key: 'permissionCode', label: '权限代码', width: 180 },
		{ key: 'enabled', label: '启用', width: 90 },
		{ key: 'version', label: '版本', width: 80 }
	]
);
const filterNode = (v: string, data: AsamTreeNodeData) => String(data.label).includes(String(v));
function locate(data: TreeNode) {
	crud.list.setDraft({ ...crud.list.draft.value, keyword: data.source.title });
	void crud.list.submit();
}
watch(filter, (v) => tree.value?.filter(v));
watch(
	() => crud.refreshState.value.status,
	(s) => {
		if (s === 'success') void loadTree();
	}
);
onMounted(loadTree);
onBeforeUnmount(() => {
	alive = false;
	clear();
	unsubscribe();
});
defineExpose({ crud });
</script>
<style scoped>
.menu-layout {
	display: grid;
	grid-template-columns: minmax(180px, 240px) minmax(0, 1fr);
	gap: 20px;
}
aside {
	padding: 16px;
	background: var(--asam-color-surface);
	border: 1px solid var(--asam-color-border);
	min-width: 0;
}
aside :deep(.el-tree) {
	max-height: 420px;
	overflow: auto;
}
@media (width < 900px) {
	.menu-layout {
		grid-template-columns: minmax(0, 1fr);
	}
}
</style>
