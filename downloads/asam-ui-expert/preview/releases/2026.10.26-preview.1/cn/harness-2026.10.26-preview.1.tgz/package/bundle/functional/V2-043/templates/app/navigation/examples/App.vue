<template>
	<AsamApplicationProvider
		class="navigation-example"
		:config="{ size, colorMode: dark ? 'dark' : 'light' }"
	>
		<header class="example-controls">
			<label><input v-model="dark" type="checkbox">暗色</label>
			<label>尺寸
				<select v-model="size">
					<option v-for="value in sizes" :key="value">{{ value }}</option>
				</select></label>
			<label><input v-model="allowLeave" type="checkbox">允许离开</label>
			<button @click="controller.navigate('/people/2?view=detail')">人员 2</button>
			<button @click="controller.navigate('/people/3?view=detail')">人员 3</button>
			<button @click="removePeople">移除人员菜单</button>
			<button @click="rename">修改菜单标题</button>
			<button @click="controller.navigate('/embed')">嵌入页面</button>
			<button @click="router.back()">后退</button><button @click="router.forward()">前进</button>
		</header>
		<NavigationShell :controller="controller" :size="size" />
		<output data-lifecycle>{{ JSON.stringify(lifecycle) }}</output>
	</AsamApplicationProvider>
</template>
<script setup lang="ts">
import { onMounted, provide, reactive, ref } from 'vue';
import { AsamApplicationProvider } from '@asam-ui/pro';
import { useRouter } from 'vue-router';
import type { AsamControlSize } from '@asam-ui/ui';
import { createNavigation, NavigationShell } from '../index.js';
import type { NavigationItem } from '../Types.js';
import TrackedPage from './TrackedPage.vue';
import EmbeddedExample from './EmbeddedExample.vue';
import { lifecycleKey } from './Lifecycle.js';
const router = useRouter();
const dark = ref(false);
const sizes: AsamControlSize[] = ['small', 'default', 'big', 'large'];
const size = ref<AsamControlSize>('default');
const allowLeave = ref(true);
let data: NavigationItem[] = [
	{ id: 'home', path: '/home', title: '工作台', resource: 'home', pinned: true },
	{
		id: 'people',
		parentId: 'home',
		path: '/people/:id',
		location: '/people/1',
		title: '人员资料',
		resource: 'people'
	},
	{ id: 'embed', path: '/embed', title: '嵌入', resource: 'embed', cache: false }
];
const lifecycle = reactive<Record<string, number>>({});
provide(lifecycleKey, lifecycle);
const controller = createNavigation({
	router,
	components: { home: TrackedPage, people: TrackedPage, embed: EmbeddedExample },
	load: async () => data,
	fallback: '/safe',
	confirm: () => allowLeave.value,
	maxCache: 10
});
function removePeople() {
	data = data.filter((item) => item.id !== 'people');
	void controller.reload();
}
function rename() {
	data = data.map((item) => ({ ...item, title: `${item.title}（已修改）` }));
	void controller.reload();
}
onMounted(async () => {
	await controller.reload();
	if (router.currentRoute.value.path === '/') await controller.navigate('/home', true);
});
defineExpose({ controller, lifecycle });
</script>
<style>
.example-controls {
	display: flex;
	flex-wrap: wrap;
	gap: 8px;
	padding: 12px;
}
.navigation-example {
	background: var(--el-bg-color-page);
	color: var(--el-text-color-primary);
	min-height: 100vh;
}
</style>
