# 应用偏好模板

复制 `preferences` 和已验 `navigation` 模板到宿主 Vue 3 + Vue Router 工程；入口见 `examples/main.ts`。使用正式安装的 `@asam-ui/ui`、`@asam-ui/pro`，导入两包公开样式。本模板不新增强制 i18n 依赖，不修改全局 document 主题。

`createPreferences` 接受显式 app、owner、storage、dictionaries、fallbackLocale、initial、force、system。优先级为会话选择 > 有效持久值 > initial > 安全回退（fallbackLocale/system，未提供系统媒体时有效亮色）。`force` 为独立宿主策略，仅覆盖对应字段。初始配置不会覆盖重新挂载读取的偏好。locale 必须存在于宿主字典；不支持选择返回 false 并记录 issue。缺 key 使用 fallback 字典，再返回 key，并记录 issue。插值返回普通文本，模板使用 Vue 文本插值，禁止 v-html。`number/date` 使用 Intl。

`theme` 是 light/dark/system，`colorMode` 是解析后的 light/dark；将后者传给 031 Provider。system 注入真实 matchMedia，dispose 幂等移除监听。显式 light/dark 不随媒体变更。语言到 EP 公开 locale 的映射由宿主传给 Provider 的 base.locale；应用字典不会翻译远端内容。示例通过导航公开控制器和 NavigationPage 自行组合菜单/页签，翻译 title key，不重装导航或修改 identity/权限/草稿。无需共享导航投影补丁。

存储键是 JSON typed tuple，保留 0、'0'、null 和边界。owner 表示应用用户范围，业务 scope 表示租户/组织；两类 namespace 分开。owner 切换须销毁原控制器并新建，不猜测认证信息。没有跨标签页同步；每个控制器持有会话快照。

偏好 schema v2 是 `{version:2, owner:key, data:{locale,theme}}`。仅支持 v1 `{version:1,owner:key,data:{language,dark}}` 迁移。非法、归属错误、未来版本及读失败不会自动覆盖原件；选择仍在会话生效。显式 reset 只删除当前 owner 偏好键，删除失败保留当前选择。迁移写失败保持原件、返回 unavailable；修复存储后重新挂载可重试。写入使用适配器单键原子 setItem，宿主适配器须提供同等语义。

`createBusinessCache<T>` 需要 app/owner/scope/storage/version/ttl/validate/now。每个 scope 一份 envelope，包含名称到值的映射和 snapshot TTL；写任一名称刷新整个 scope snapshot TTL。read 每次重新检查版本、归属、payload 和过期时间；过期不回显。UI 中值是最后一次操作的结果，不是自动倒计时订阅，时间到后点击读取即可观察 expired。clear/invalidate/reset 只删除当前 scope 的整份 envelope。未来/损坏数据须显式 clear 后再写。switchScope 清空当前显示，不主动读新 scope；切换回旧 scope 可显式读取其未过期数据。

remember 在发起时捕获失效代次；switchScope/clear/reset/dispose 后晚到结果或错误不会写回旧/新 scope。它不取消宿主网络请求，同代次多个请求按完成顺序提交。缓存用于业务数据；不存凭据、主体或权限副本。032 页面实例缓存独立，清页面调用 controller.refresh/close 等公开入口。

示例有两页及可保留草稿、完整中英菜单/页签/操作/空错状态、四尺寸、系统/亮暗、独立局部亮色 Provider、正常/内存/抛错存储、业务 scope、1500ms TTL 与清理。普通修改配方：修改 dictionaries.ts 的 home/title，修改 App.vue 的 initial 或 cacheTtl；执行类型、生产构建与真实浏览器验证，再恢复源文件。本卡不承担 042 最终视觉三族页面。

无 window/storage 可初始化核心并获得 unavailable；系统主题由宿主注入。完整示例 main.ts 使用 WebHistory 和 DOM 挂载，不声明完整 SSR hydration 支持。存储仅同步适配器，不提供加密、服务端翻译、任意历史迁移或认证。

验证入口见 `tests/v2/preferences/README.md`；开发自测不等于独立 QA/ACC。

V2-034-QA-01 修正：示例分别显示偏好存储和业务缓存的本地化反馈，按各自状态生成说明。仅切回正常适配器不会自动清除旧失败；对应操作实际成功后该侧反馈恢复，另一侧状态保持。失败不禁止合法会话选择或草稿。机器状态码仍供诊断，不能代替自然语言的准确归属。
