import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { isAbsolute, resolve, join } from 'node:path';
import { prepareTool } from './ocr-tool.mjs';
import { installedValidation } from './validation-payload.mjs';

const base = fileURLToPath(new URL('../../../', import.meta.url));
export async function loadValidationCore() {
	if (!installedValidation(base)) throw Error('FIXED_VALIDATION_INPUT_REQUIRED');
	return import(
		new URL('../../../runtime/packages/agent-core/src/validation.mjs', import.meta.url)
	);
}

// Thin argument/installation adapter. All modes, rules, permissions and repair state stay in 051.
export async function main(args = process.argv.slice(2)) {
	try {
		const [operation, input = '{}', target] = args;
		const validation = operation?.startsWith('validation');
		let data = JSON.parse(input);
		if (validation && (typeof target !== 'string' || !isAbsolute(target)))
			throw Error('ABSOLUTE_VALIDATION_TARGET_REQUIRED');
		if (validation && !installedValidation(base))
			throw Error('FIXED_VALIDATION_INPUT_REQUIRED');
		if (operation === 'validation-ocr') {
			if (
				!data ||
				typeof data !== 'object' ||
				Array.isArray(data) ||
				data.descriptor !== undefined
			)
				throw Error('WRAPPER_DESCRIPTOR_IS_AUTOMATIC');
			const prepared = await prepareTool();
			if (prepared.status !== 'pass') {
				console.log(JSON.stringify(prepared));
				process.exitCode = prepared.status === 'unsupported' ? 3 : 2;
				return;
			}
			data = {
				...data,
				descriptor: {
					executable: prepared.binary,
					sha256: prepared.sha256,
					version: prepared.version,
					platform: process.platform,
					arch: process.arch
				}
			};
		}
		const result = spawnSync(
			process.execPath,
			[
				join(base, 'runtime/packages/agent-cli/src/cli.mjs'),
				operation,
				validation ? resolve(target) : join(base, 'bundle'),
				JSON.stringify(data)
			],
			{
				stdio: 'inherit',
				windowsHide: true,
				env: { ...process.env, pnpm_config_verify_deps_before_run: 'error' }
			}
		);
		if (result.error) throw result.error;
		process.exitCode = result.status ?? 1;
	} catch (error) {
		console.log(
			JSON.stringify({
				status: 'partial',
				code: error.code ?? error.message,
				action: '核固定套件、明确工程/检查点及宿主授权后继续'
			})
		);
		process.exitCode = 2;
	}
}
