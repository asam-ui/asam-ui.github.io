import type { AsamListRequest } from '@asam-ui/pro';
import type { AsamControlSize } from '@asam-ui/ui';
import type { SecurityController } from '../app/security/Security.js';
import type { SecuritySubject } from '../app/security/Types.js';

export type SocialId = string | number;
export interface SocialAuthor {
	id: SocialId;
	name?: string;
	avatar?: { src: string; alt: string };
}
export interface SocialPost {
	id: SocialId;
	author: SocialAuthor;
	body: string;
	time?: string;
	cover?: { src: string; alt: string };
	liked: boolean;
	likes: number;
	bookmarked: boolean;
	comments: number;
	version: number;
}
export interface SocialComment {
	id: SocialId;
	postId: SocialId;
	author: SocialAuthor;
	body: string;
	time?: string;
	canDelete: boolean;
}
export interface SocialPage<T> {
	list: readonly T[];
	total: number;
}
export interface SocialRequest {
	subject: SecuritySubject;
	signal: AbortSignal;
	/** Host must check again before committing a server-side effect. */
	isCurrent: () => boolean;
}
export type SocialWrite =
	| { kind: 'like' | 'bookmark'; postId: SocialId; desired: boolean; version: number }
	| { kind: 'comment'; postId: SocialId; body: string }
	| { kind: 'delete'; postId: SocialId; commentId: SocialId };
export interface SocialOperation {
	id: string;
	action: SocialWrite;
}
export type SocialOutcome =
	| { status: 'success'; post: SocialPost }
	| { status: 'failed'; message: string }
	| { status: 'unknown' };
/** All results are untrusted until validated by the template. No transport is owned here. */
export interface SocialService {
	feed: (query: AsamListRequest, request: SocialRequest) => Promise<SocialPage<SocialPost>>;
	comments: (
		postId: SocialId,
		page: number,
		size: number,
		request: SocialRequest
	) => Promise<SocialPage<SocialComment>>;
	write: (operation: SocialOperation, request: SocialRequest) => Promise<SocialOutcome>;
	/** Resolve the original operation. Never sends another mutation. */
	resolve: (operationId: string, request: SocialRequest) => Promise<SocialOutcome>;
}
export interface SocialHost {
	security: Pick<SecurityController, 'state' | 'check' | 'onInvalidate'>;
	service: SocialService;
	readonly?: boolean;
	disabled?: boolean;
}
export interface SocialPageProps {
	host: SocialHost;
	size?: AsamControlSize;
}
export const socialPermission = {
	read: 'social.read',
	comments: 'social.comments',
	like: 'social.like',
	bookmark: 'social.bookmark',
	comment: 'social.comment',
	delete: 'social.delete'
} as const;
