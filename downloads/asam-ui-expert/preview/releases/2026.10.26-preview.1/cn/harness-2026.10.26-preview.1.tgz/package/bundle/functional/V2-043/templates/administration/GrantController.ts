import { computed, ref, shallowRef, watch } from 'vue';
import { scopeKey } from '../app/security/index.js';
import { isId, validateTree } from './Tree.js';
import { fields, denseArray } from './Validation.js';
import type {
	AdministrationHost,
	GrantOperation,
	GrantSnapshot,
	Id,
	GrantResult
} from './Types.js';

function grantResult(value: unknown): GrantResult {
	fields(value, ['status'], ['version', 'reason']);
	if (value.status === 'success') {
		fields(value, ['status', 'version']);
		if (typeof value.version !== 'string' || !value.version.trim())
			throw new Error('授权回执版本无效');
		return { status: 'success', version: value.version };
	}
	if (value.status === 'unknown') {
		fields(value, ['status']);
		return { status: 'unknown' };
	}
	if (value.status === 'failure') {
		fields(value, ['status', 'reason']);
		if (
			value.reason === 'conflict' ||
			value.reason === 'validation' ||
			value.reason === 'denied'
		)
			return { status: 'failure', reason: value.reason };
	}
	throw new Error('授权回执无效');
}

/** Owns only local reads/drafts. Writes and receipts belong to the host. */
export function createGrantEditor(host: AdministrationHost) {
	const snapshot = shallowRef<GrantSnapshot | null>(null);
	const selected = ref<Id[]>([]),
		filter = ref(''),
		message = ref('');
	const status = ref<
		'closed' | 'loading' | 'ready' | 'error' | 'saving' | 'unknown' | 'verifying'
	>('closed');
	let generation = 0,
		alive = true,
		abort: AbortController | undefined;
	let active: Id | undefined,
		revision = 0,
		action = 0;
	let pending: GrantOperation | undefined;
	let pendingDraftRevision: number | undefined;
	let pendingOwned = false;
	const scope = () =>
		host.security.state.value.subject ? scopeKey(host.security.state.value.subject) : '';
	const canRead = () => alive && host.security.check({ permission: 'roles:read' }) === 'allowed';
	const writable = computed(
		() =>
			canRead() &&
			host.security.check({ permission: 'roles:write', write: true }) === 'allowed'
	);
	const dirty = computed(
		() =>
			!!snapshot.value &&
			(selected.value.length !== snapshot.value.direct.length ||
				selected.value.some((id) => !snapshot.value!.direct.includes(id)))
	);
	const tree = computed(() => (snapshot.value ? validateTree(snapshot.value.nodes) : []));
	const visible = computed(
		() =>
			snapshot.value?.nodes.filter((n) =>
				n.title.toLocaleLowerCase().includes(filter.value.toLocaleLowerCase())
			) ?? []
	);
	function clear() {
		// Increment and erase before abort: synchronous abort listeners may reenter.
		const stamp = ++generation;
		action++;
		revision++;
		const previous = abort;
		abort = undefined;
		if (
			pendingOwned &&
			pending &&
			host.receipts.get(pending.operationId)?.status === 'confirming'
		)
			host.receipts.delete(pending.operationId);
		active = undefined;
		pending = undefined;
		pendingDraftRevision = undefined;
		pendingOwned = false;
		snapshot.value = null;
		selected.value = [];
		filter.value = '';
		message.value = '';
		status.value = 'closed';
		previous?.abort();
		return stamp;
	}
	const unsubscribe = host.security.onInvalidate(clear);
	const stop = watch(() => [host.services.value, host.services.value.version], clear, {
		flush: 'sync'
	});
	async function discard(): Promise<boolean> {
		const token = generation;
		return (
			!dirty.value ||
			((await host.confirm('授权草稿尚未保存，确认丢弃？')) && token === generation)
		);
	}
	async function open(subject: Id, force = false) {
		if (!isId(subject) || !canRead()) return false;
		if (!force && !(await discard())) return false;
		if (!canRead()) return false;
		const token = clear();
		if (token !== generation || !canRead()) return false;
		const epoch = host.security.state.value.epoch,
			service = host.services.value;
		active = subject;
		const controller = new AbortController();
		abort = controller;
		const current = () =>
			alive &&
			token === generation &&
			epoch === host.security.state.value.epoch &&
			service === host.services.value &&
			canRead();
		status.value = 'loading';
		try {
			const data = await service.grants.load(subject, {
				signal: controller.signal,
				isCurrent: current,
				scope: scope()
			});
			if (!current()) return false;
			fields(data, ['subject', 'scope', 'version', 'nodes', 'direct', 'unavailable']);
			denseArray(data.direct);
			if (
				!Object.is(data.subject, subject) ||
				data.scope !== scope() ||
				typeof data.version !== 'string' ||
				!data.version.trim() ||
				!['preserve', 'reject'].includes(data.unavailable)
			)
				throw new Error('授权响应对象不匹配');
			validateTree(data.nodes);
			if (
				data.direct.some((id) => !isId(id)) ||
				new Set(data.direct).size !== data.direct.length
			)
				throw new Error('授权集合无效');
			const unavailable = data.direct.filter(
				(id) => !data.nodes.some((n) => Object.is(n.id, id) && n.enabled && n.grantable)
			);
			if (unavailable.length && data.unavailable === 'reject')
				throw new Error('服务策略拒绝当前不可授予权限');
			snapshot.value = {
				...data,
				nodes: data.nodes.map((n) => ({ ...n })),
				direct: [...data.direct]
			};
			selected.value = [...data.direct];
			status.value = 'ready';
			// A remount cannot issue a new write to an unresolved subject.
			const retained = [...host.receipts.values()].find(
				(r) =>
					r.operation.scope === data.scope &&
					Object.is(r.operation.subject, subject) &&
					['confirming', 'sending', 'unknown'].includes(r.status)
			);
			if (retained) {
				pending = retained.operation;
				pendingDraftRevision = revision;
				pendingOwned = false;
				status.value = 'unknown';
				message.value = '原操作未决，请核实同一操作';
			}
			return true;
		} catch {
			if (current()) {
				snapshot.value = null;
				selected.value = [];
				status.value = 'error';
				message.value = '授权读取失败或树结构无效，请重试；未显示部分结果';
			}
			return false;
		}
	}
	function toggle(id: Id, checked: boolean) {
		if (!writable.value || !snapshot.value || !['ready', 'saving'].includes(status.value))
			return;
		const node = snapshot.value.nodes.find((n) => Object.is(n.id, id));
		if (!node?.enabled || !node.grantable) return;
		const next = new Set(selected.value);
		checked ? next.add(id) : next.delete(id);
		selected.value = [...next];
		revision++;
	}
	function selectVisible(checked: boolean, ids: readonly Id[] = visible.value.map((n) => n.id)) {
		for (const id of ids) toggle(id, checked);
	}
	async function save() {
		if (
			!writable.value ||
			!snapshot.value ||
			status.value !== 'ready' ||
			!dirty.value ||
			pending
		)
			return;
		const conflict = [...host.receipts.values()].find(
			(r) =>
				r.operation.scope === snapshot.value!.scope &&
				Object.is(r.operation.subject, snapshot.value!.subject) &&
				['confirming', 'sending', 'unknown'].includes(r.status)
		);
		if (conflict) {
			pending = conflict.operation;
			pendingDraftRevision = undefined;
			pendingOwned = false;
			status.value = 'unknown';
			message.value = '宿主已有当前对象未决写入，请核实原操作';
			return;
		}
		const token = generation,
			epoch = host.security.state.value.epoch,
			draftRevision = revision,
			service = host.services.value;
		const data = snapshot.value;
		const operation: GrantOperation = Object.freeze({
			operationId: crypto.randomUUID(),
			subject: data.subject,
			scope: data.scope,
			serviceVersion: service.version,
			version: data.version,
			direct: Object.freeze([...selected.value])
		});
		// Reserve synchronously, before awaiting confirmation (double-click safe).
		status.value = 'saving';
		pending = operation;
		pendingDraftRevision = draftRevision;
		pendingOwned = true;
		host.receipts.set(operation.operationId, { operation, status: 'confirming' });
		const attempt = ++action;
		const current = () =>
			alive &&
			token === generation &&
			epoch === host.security.state.value.epoch &&
			service === host.services.value &&
			attempt === action &&
			canRead();
		let confirmed = false;
		try {
			confirmed = await host.confirm(
				`保存当前角色的 ${operation.direct.length} 项直接授权？`
			);
		} catch {
			/* fixed safe feedback below */
		}
		if (!current()) return;
		if (!confirmed || !writable.value) {
			host.receipts.delete(operation.operationId);
			pending = undefined;
			status.value = 'ready';
			message.value = confirmed ? '写入权限已撤销' : '已取消保存';
			return;
		}
		const record = { operation, status: 'sending' as const };
		host.receipts.set(operation.operationId, record);
		let result: GrantResult;
		try {
			if (!current() || !writable.value) {
				host.receipts.delete(operation.operationId);
				pending = undefined;
				status.value = 'ready';
				return;
			}
			result = grantResult(
				await service.grants.save(operation, {
					signal: new AbortController().signal,
					isCurrent: current,
					scope: operation.scope
				})
			);
		} catch {
			result = { status: 'unknown' };
		}
		host.receipts.set(operation.operationId, { operation, status: result.status, result });
		if (!current()) return;
		apply(result, operation, draftRevision);
	}
	function apply(
		result: GrantResult,
		operation: GrantOperation,
		draftRevision: number | undefined
	) {
		const ownedResult = pendingOwned;
		if (result.status === 'unknown') {
			status.value = 'unknown';
			message.value = '结果未知，禁止重发；请核实原 operationId';
			return;
		}
		pending = undefined;
		status.value = 'ready';
		if (result.status === 'failure') {
			message.value =
				result.reason === 'conflict'
					? '版本冲突，服务确认未应用；请明确重新加载并合并'
					: '服务拒绝或校验失败，确认未应用；草稿保留';
			return;
		}
		if (snapshot.value)
			snapshot.value = {
				...snapshot.value,
				version: result.version,
				direct: [...operation.direct]
			};
		if (draftRevision !== undefined && revision === draftRevision)
			selected.value = [...operation.direct];
		pendingDraftRevision = undefined;
		pendingOwned = false;
		message.value = ownedResult
			? '授权已保存；保存期间的后续修改保留'
			: '原操作已核实，已更新授权基线；本地草稿保留，请核对后保存';
	}
	async function verify() {
		if (!canRead() || !pending || status.value !== 'unknown') return;
		const operation = pending,
			token = generation,
			service = host.services.value,
			draftRevision = pendingDraftRevision;
		const retained = host.receipts.get(operation.operationId);
		if (retained?.status === 'sending' || retained?.status === 'confirming') {
			message.value = '原操作仍在确认或发送，请等待';
			return;
		}
		if (!retained) {
			pending = undefined;
			status.value = 'ready';
			message.value = '原操作已取消且未发送，可继续编辑';
			return;
		}
		if (operation.serviceVersion !== service.version || operation.scope !== scope()) return;
		status.value = 'verifying';
		const current = () =>
			alive && token === generation && canRead() && service === host.services.value;
		let result: GrantResult;
		try {
			result = grantResult(
				await service.grants.verify(operation, {
					signal: new AbortController().signal,
					isCurrent: current,
					scope: operation.scope
				})
			);
		} catch {
			result = { status: 'unknown' };
		}
		host.receipts.set(operation.operationId, { operation, status: result.status, result });
		if (current()) apply(result, operation, draftRevision);
	}
	async function close() {
		if (!(await discard())) return false;
		clear();
		return true;
	}
	return {
		snapshot,
		selected,
		filter,
		message,
		status,
		dirty,
		tree,
		visible,
		writable,
		open,
		toggle,
		selectVisible,
		save,
		verify,
		close,
		reload: () => (active === undefined ? Promise.resolve(false) : open(active)),
		invalidate: clear,
		dispose: () => {
			alive = false;
			clear();
			unsubscribe();
			stop();
		}
	};
}
