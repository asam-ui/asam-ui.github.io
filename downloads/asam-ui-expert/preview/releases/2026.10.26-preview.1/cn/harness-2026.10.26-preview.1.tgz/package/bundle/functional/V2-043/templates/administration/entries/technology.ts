import { mountAdministration } from '../examples/mount.js';
mountAdministration('technology');
