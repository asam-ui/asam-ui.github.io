export type ValidationMode = 'develop' | 'verify' | 'verify-fix';
export type ValidationStatus = 'pass' | 'fail' | 'partial' | 'unsupported';
export type CheckKind = 'static' | 'source-review' | 'runtime' | 'visual' | 'business';
export interface ValidationRequirement {
	id: string;
	text: string;
	checkIds: string[];
}
export interface ValidationVersions {
	ui: string;
	vue: string;
	pro?: string;
	elementPlus?: string;
	typescript?: string;
}
export interface ValidationBudget {
	maxRepairRounds: number;
	maxNoProgressRounds: number;
	maxDurationMs: number;
	basis: string;
}
export interface ValidationCheck {
	id: string;
	kind: CheckKind;
	files: string[];
	required: boolean;
	toolVersion: string;
}
export interface ValidationInput {
	taskId: string;
	project: string;
	request: string;
	mode?: ValidationMode;
	targets: string[];
	context?: string[];
	changes?: string[];
	requirements: ValidationRequirement[];
	versions: ValidationVersions;
	checks?: ValidationCheck[];
	profile?: 'vue-asam-consumer';
	budget?: Partial<ValidationBudget> & { basis: string };
	allowDirty?: string[];
}
export interface ValidationRule {
	id: string;
	version: number;
	scope: 'all' | 'code' | 'style';
	level: 'required' | 'advisory';
	source: string;
	requirement: string;
	positive: string;
	negative: string;
	exception: string;
	evidence: string;
	recheck: string;
}
export interface ValidationProfile {
	schemaVersion: 1;
	id: string;
	version: string;
	fingerprint: string;
	supported: string[];
	source: string;
	defaults: ValidationBudget;
	rules: ValidationRule[];
}
export interface ValidationIssueInput {
	ruleId: string;
	file: string;
	line: number;
	evidence: string;
	reason: string;
	suggestion: string;
	severity: 'blocking' | 'advisory';
	category: 'product' | 'tool' | 'requirement';
	key: string;
}
export interface ValidationIssue extends ValidationIssueInput {
	id: string;
	checkId: string;
	evidenceValidated: boolean;
	state: 'open' | 'closed';
}
export interface OcrDescriptor {
	executable: string;
	sha256: string;
	version: '1.13.1';
	platform: string;
	arch: string;
}
export interface DelegateFile {
	file: string;
	sha256: string;
	ruleHash: string;
}
export interface DelegateReady {
	status: 'pass';
	inputFingerprint: string;
	ruleFingerprint: string;
	tool: Omit<OcrDescriptor, 'executable'>;
	files: DelegateFile[];
	groups: { group_id: number; source: string; pattern: string; files: string[]; rule: string }[];
	artifacts: string;
	artifactDigest: string;
	semanticReview: 'pending-host-source-review';
}
export interface DelegatePartial {
	status: 'partial';
	inputFingerprint: string;
	ruleFingerprint: string;
	reason: string;
	nextAction: string;
}
export type DelegateResult = DelegateReady | DelegatePartial;
export interface HostReview {
	model: string;
	isolation: 'independent' | 'same-context';
	delegate: DelegateReady;
	reviewed: (DelegateFile & { evidence: string })[];
}
export interface ValidationReceipt {
	checkId: string;
	inputFingerprint: string;
	status: ValidationStatus | 'not-applicable';
	toolVersion: string;
	evidence: string;
	files: Record<string, string | null>;
	issues?: ValidationIssueInput[];
	review?: HostReview;
	reason?: string;
}
export interface RecordedValidationReceipt extends Omit<ValidationReceipt, 'issues'> {
	issues: Omit<ValidationIssue, 'checkId'>[];
	checkFingerprint: string;
	run: number;
}
export interface ValidationEdit {
	file: string;
	beforeHash: string;
	content: string;
}
export interface ValidationFix {
	inputFingerprint: string;
	edits: ValidationEdit[];
	issueIds: string[];
	diagnostics?: ValidationReceipt[];
	diagnosticBasis?: string;
}
export interface AppliedValidationEdit {
	file: string;
	beforeHash: string;
	afterHash: string;
	issueIds: string[];
	round: number;
}
export interface ValidationPlan {
	version: 1;
	taskId: string;
	project: string;
	request: string;
	mode: ValidationMode;
	selectors: string[];
	deleted: string[];
	targets: string[];
	files: string[];
	unresolved: { file: string; import: string }[];
	requirements: ValidationRequirement[];
	versions: ValidationVersions;
	profile: ValidationProfile;
	checks: ValidationCheck[];
	allowDirty: string[];
	budget: ValidationBudget;
	initialGit: { head: string | null; dirty: string[] | null };
	baseline: Record<string, string>;
}
export interface ValidationWriteProtection {
	kind:
		| 'files'
		| 'assertions'
		| 'requirements'
		| 'configuration'
		| 'dirty'
		| 'semantic'
		| 'unresolved'
		| 'product';
	source: string;
	scope: string;
}
export interface ValidationTask {
	schemaVersion: 1;
	plan: ValidationPlan;
	planDigest: string;
	current: {
		files: Record<string, string | null>;
		fingerprint: string;
		environmentFingerprint: string;
		userConstraintsFingerprint?: string;
	};
	history: RecordedValidationReceipt[];
	issues: ValidationIssue[];
	edits: AppliedValidationEdit[];
	rounds: number;
	noProgress: number;
	elapsedMs: number;
	permissions: { write: boolean };
	stopReason: string | null;
	revision: number;
	persistedRevision?: number;
	savedFileHash?: string;
	expectedSnapshot?: Record<string, string>;
	scopeChanged?: boolean;
	pendingEdits?: AppliedValidationEdit[];
	protectedFiles?: string[];
	writeProtections?: ValidationWriteProtection[];
	lastError?: string;
}
export interface ValidationReport {
	schemaVersion: 1;
	taskId: string;
	mode: ValidationMode;
	request: string;
	writeProtections: ValidationWriteProtection[];
	status: ValidationStatus;
	inputFingerprint: string;
	versions: ValidationVersions;
	ruleProfile: Pick<ValidationProfile, 'id' | 'version' | 'fingerprint'>;
	files: Record<string, string | null>;
	targets: string[];
	deleted: string[];
	context: string[];
	scopeChanged: boolean;
	unresolved: ValidationPlan['unresolved'];
	requirementCoverage: (ValidationRequirement & { verified: boolean })[];
	checks: (ValidationCheck & { result: RecordedValidationReceipt | null })[];
	issues: ValidationIssue[];
	history: RecordedValidationReceipt[];
	edits: AppliedValidationEdit[];
	unverified: string[];
	stopReason: string | null;
	budget: ValidationBudget & {
		usedRepairRounds: number;
		consecutiveNoProgress: number;
		elapsedMs: number;
	};
	limitations: string[];
}
export interface HostCheckInput {
	taskId: string;
	mode: ValidationMode;
	request: string;
	writeProtections: ValidationWriteProtection[];
	deleted: string[];
	sourceHead: string | null;
	inputFingerprint: string;
	check: ValidationCheck;
	files: Record<string, string | null>;
	sources: (DelegateFile & { source: string; rules: string })[];
	requirements: ValidationRequirement[];
	versions: ValidationVersions;
	untrustedInput: true;
	signal: AbortSignal;
}
export interface ValidationPermissions {
	write?: boolean;
	request?: string;
	cancelled?: boolean;
}
export interface ValidationHost {
	check?: (input: HostCheckInput) => ValidationReceipt | Promise<ValidationReceipt>;
	review?: (input: HostCheckInput) => ValidationReceipt | Promise<ValidationReceipt>;
	fix?: (input: {
		report: ValidationReport;
		issues: ValidationIssue[];
		inputFingerprint: string;
		signal: AbortSignal;
	}) =>
		| ValidationFix
		| { edits: []; diagnostics?: ValidationReceipt[]; diagnosticBasis?: string }
		| Promise<
				| ValidationFix
				| { edits: []; diagnostics?: ValidationReceipt[]; diagnosticBasis?: string }
		  >;
	permissions?: () => ValidationPermissions | Promise<ValidationPermissions>;
	signal?: AbortSignal;
	checkpoint?: string;
}
export function validationIntent(
	request: string,
	explicit?: ValidationMode
): ValidationMode | 'unsupported';
export function validationFailure(error: unknown): {
	status: ValidationStatus;
	reason: string;
	nextAction: string;
};
export function createValidationTask(input: ValidationInput): ValidationTask;
export function validationReport(task: ValidationTask): ValidationReport;
export function recordValidationCheck(
	task: ValidationTask,
	receipt: ValidationReceipt
): ValidationReport;
export function narrowValidationPermissions(
	task: ValidationTask,
	permission: ValidationPermissions
): boolean;
export function applyValidationEdits(
	task: ValidationTask,
	proposal: ValidationFix,
	checkpoint?: string
): void;
export function runValidation(
	task: ValidationTask,
	host: ValidationHost
): Promise<ValidationReport>;
export function saveValidationTask(task: ValidationTask, path: string): void;
export function loadValidationTask(path: string): ValidationTask;
export function resumeValidationTask(
	task: ValidationTask,
	permission: { request: string; write?: boolean }
): ValidationReport;
export function prepareDelegate(
	task: ValidationTask,
	descriptor: OcrDescriptor,
	externalDirectory: string
): DelegateResult;
export function validationProfile(id?: string): ValidationProfile;
export function ruleText(profile: ValidationProfile, file: string): string;
export const OCR_VERSION: '1.13.1';
