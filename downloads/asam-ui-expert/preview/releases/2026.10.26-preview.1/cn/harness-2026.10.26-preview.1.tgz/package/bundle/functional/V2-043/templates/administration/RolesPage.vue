<template>
	<section aria-label="角色管理模板">
		<AsamCrudPage :controller="crud" title="角色管理" :size="host.size.value">
			<template #heading><span>角色展示与应用关联，不计算后台有效权限</span></template>
			<template #toolbar>
				<label
					>当前授权角色
					<select v-model="subjectKey" aria-label="当前授权角色">
						<option value="">请选择角色</option>
						<option
							v-for="row in crud.list.page.data.value.list"
							:key="keyOf(row.id)"
							:value="keyOf(row.id)"
						>
							{{ row.name }} · {{ typeof row.id }}:{{ row.id }}
						</option>
					</select></label
				>
				<AsamButton
					:size="host.size.value"
					:disabled="
						!selected || host.security.check({ permission: 'roles:read' }) !== 'allowed'
					"
					@click="openGrant"
					>打开当前角色授权</AsamButton
				>
			</template>
		</AsamCrudPage>
		<GrantEditor ref="grant" :size="host.size.value" />
	</section>
</template>
<script setup lang="ts">
import { computed, ref } from 'vue';
import { AsamButton } from '@asam-ui/ui';
import { AsamCrudPage } from '@asam-ui/pro';
import { useAdministration, useAdministrationCrud, field } from './Crud.js';
import { roleCodec, versionField } from './Codecs.js';
import { keyOf } from './Tree.js';
import GrantEditor from './GrantEditor.vue';
const host = useAdministration(),
	subjectKey = ref(''),
	grant = ref<InstanceType<typeof GrantEditor>>();
const fields = [
	field('name', '角色名称'),
	field('code', '角色代码'),
	field('enabled', '启用状态'),
	field('members', '成员或引用说明'),
	field('note', '备注'),
	field('context', '上下文'),
	versionField
];
const crud = useAdministrationCrud(
	host,
	'roles',
	host.services.value.roles.crud,
	roleCodec,
	fields,
	[
		{ key: 'id', label: '标识', width: 100 },
		{ key: 'name', label: '角色名称', width: 180 },
		{ key: 'code', label: '角色代码', width: 150 },
		{ key: 'enabled', label: '启用状态', width: 100 },
		{ key: 'members', label: '成员或引用', width: 220 },
		{ key: 'version', label: '版本', width: 80 }
	]
);
const selected = computed(() =>
	crud.list.page.data.value.list.find((r) => keyOf(r.id) === subjectKey.value)
);
async function openGrant() {
	if (selected.value) await grant.value?.open(selected.value.id);
}
defineExpose({ crud, grant });
</script>
