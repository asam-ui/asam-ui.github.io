import { createSecurity, scopeKey } from '../../app/security/Security.js';
import type { SecurityScope, SecuritySubject } from '../../app/security/Types.js';
import { adaptSocial } from '../Adapter.js';
import { idKey } from '../Validation.js';
import { socialPermission } from '../Types.js';
import type {
	SocialComment,
	SocialId,
	SocialOperation,
	SocialOutcome,
	SocialPost,
	SocialRequest,
	SocialService
} from '../Types.js';

const wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));
const contexts = [
	{ tenant: 0, organization: null, label: '设计讨论' },
	{ tenant: '0', organization: null, label: '工程笔记' }
];
export function createDemoSecurity() {
	let saved: SecuritySubject | null = null;
	const subject = (id: SocialId, scope: SecurityScope = contexts[0]): SecuritySubject => ({
		id,
		name: typeof id === 'number' ? '林序' : '陈知',
		roles: ['member'],
		permissions: Object.values(socialPermission),
		scope,
		contexts,
		expiresAt: Date.now() + 3600000
	});
	return createSecurity<SocialId>({
		adapter: {
			login: async (id, r) => {
				await wait(100);
				const s = subject(id);
				if (r.isCurrent()) saved = s;
				return s;
			},
			restore: async () => {
				await wait(100);
				return saved;
			},
			refresh: async (s) => ({ ...s, expiresAt: Date.now() + 3600000 }),
			switchContext: async (s, target, r) => {
				await wait(100);
				const next = subject(s.id, target);
				if (r.isCurrent()) saved = next;
				return next;
			},
			logout: async (r) => {
				await wait(100);
				if (r.isCurrent()) saved = null;
			}
		}
	});
}
export function makePosts(label: string): SocialPost[] {
	return Array.from({ length: 100 }, (_, i) => ({
		id: i === 0 ? 0 : i === 1 ? '0' : `post-${i}`,
		author: {
			id: i % 2 ? '0' : 0,
			name: i % 2 ? '陈知' : '林序',
			...(i % 5 === 0
				? { avatar: { src: './missing-avatar.png', alt: '作者头像' } }
				: i % 3 === 0
					? {
							avatar: {
								src: new URL('../assets/avatar.svg', import.meta.url).pathname,
								alt: '作者头像'
							}
						}
					: {})
		},
		body: `${label} · ${i + 1} / 记录今天的设计与工程\n让细节可以被讨论，也让不同意见有清楚的上下文。\n${i % 4 === 0 ? '长文：'.repeat(120) : 'Small observations become useful shared knowledge.'}\n<script>window.UNSAFE=true</script> <b>纯文本</b> https://example.invalid/ 不自动打开。`,
		time: i % 7 ? `2026-10-19T${String(9 + (i % 10)).padStart(2, '0')}:00:00Z` : undefined,
		...(i % 13 === 0
			? {
					cover: {
						src:
							i % 26 === 0
								? './missing-cover.png'
								: new URL('../assets/cover.svg', import.meta.url).pathname,
						alt: '工作笔记封面'
					}
				}
			: {}),
		liked: false,
		likes: i,
		bookmarked: i % 4 === 0,
		comments: i === 0 ? 40 : 0,
		version: 1
	}));
}

/** In-memory demonstration only. A real server must own authorization, versions and durable idempotency. */
export function createSyntheticService(options: { label?: string; delay?: number } = {}) {
	const control = {
		readFailure: false,
		writeMode: 'normal' as 'normal' | 'failed' | 'unknown',
		failedMessage: '明确未写入',
		ignoreAbort: false,
		calls: [] as { kind: string; at: number; settled?: number }[]
	};
	const stores = new Map<
		string,
		{ posts: SocialPost[]; comments: SocialComment[]; operations: Map<string, SocialOutcome> }
	>();
	function store(r: SocialRequest) {
		const key = scopeKey(r.subject);
		let data = stores.get(key);
		if (!data) {
			const posts = makePosts(
				`${options.label ?? '公共笔记'} / ${typeof r.subject.scope.tenant}:${r.subject.scope.tenant}`
			);
			data = {
				posts,
				comments: Array.from({ length: 40 }, (_, i) => ({
					id: i === 0 ? 0 : i === 1 ? '0' : `comment-${i}`,
					postId: 0,
					author: { id: i % 2 ? '0' : 0, name: i % 2 ? '陈知' : '林序' },
					body: `评论 ${i + 1}\n${'具体的反馈与改进记录。'.repeat(i === 0 ? 100 : 2)}\n<b>保留原文</b>`,
					canDelete: (i % 2 ? '0' : 0) === r.subject.id
				})),
				operations: new Map()
			};
			stores.set(key, data);
		}
		return data;
	}
	async function gate(r: SocialRequest, kind: keyof typeof socialPermission) {
		const call: { kind: string; at: number; settled?: number } = {
			kind,
			at: performance.now()
		};
		control.calls.push(call);
		try {
			await wait(options.delay ?? 100);
		} finally {
			call.settled = performance.now();
		}
		if (
			(!control.ignoreAbort && r.signal.aborted) ||
			!r.isCurrent() ||
			!r.subject.permissions.includes(socialPermission[kind]) ||
			(kind !== 'read' && kind !== 'comments' && r.subject.readOnly)
		)
			throw Error('服务授权已失效');
	}
	const service: SocialService = {
		feed: async (q, r) => {
			await gate(r, 'read');
			if (control.readFailure) throw Error('合成读取失败');
			let rows = store(r).posts.filter(
				(p) =>
					p.body.toLowerCase().includes(String(q.query.keyword ?? '').toLowerCase()) &&
					(q.query.author === '' ||
						q.query.author === undefined ||
						p.author.id === q.query.author) &&
					(!q.query.bookmarked || p.bookmarked)
			);
			rows = [...rows].sort(
				(a, b) =>
					(q.sort?.field === 'likes'
						? a.likes - b.likes
						: store(r).posts.indexOf(a) - store(r).posts.indexOf(b)) *
					(q.sort?.order === 'descending' ? -1 : 1)
			);
			return structuredClone({
				total: rows.length,
				list: rows.slice((q.currentPage - 1) * q.pageSize, q.currentPage * q.pageSize)
			});
		},
		comments: async (id, n, size, r) => {
			await gate(r, 'comments');
			if (control.readFailure) throw Error('合成读取失败');
			const rows = store(r).comments.filter((c) => c.postId === id);
			return structuredClone({
				total: rows.length,
				list: rows.slice((n - 1) * size, n * size)
			});
		},
		write: async (op, r) => {
			await gate(r, op.action.kind);
			const data = store(r),
				known = data.operations.get(op.id);
			if (known) return structuredClone(known);
			if (control.writeMode === 'failed')
				return { status: 'failed', message: control.failedMessage };
			const action = op.action,
				row = data.posts.find((p) => p.id === action.postId);
			if (!row) return { status: 'failed', message: '帖子不存在' };
			if (action.kind === 'like' || action.kind === 'bookmark') {
				if (action.version !== row.version)
					return { status: 'failed', message: '版本冲突，请刷新' };
				if (action.kind === 'like') {
					row.likes += Number(action.desired) - Number(row.liked);
					row.liked = action.desired;
				} else row.bookmarked = action.desired;
			} else if (action.kind === 'comment') {
				if (!action.body.trim() || action.body.length > 10000)
					return { status: 'failed', message: '评论无效' };
				data.comments.unshift({
					id: `new-${op.id}`,
					postId: row.id,
					author: { id: r.subject.id, name: r.subject.name },
					body: action.body,
					canDelete: true
				});
				row.comments++;
			} else if (action.kind === 'delete') {
				const index = data.comments.findIndex(
					(c) =>
						c.id === action.commentId &&
						c.postId === row.id &&
						c.author.id === r.subject.id &&
						c.canDelete
				);
				if (index < 0) return { status: 'failed', message: '不可删除' };
				data.comments.splice(index, 1);
				row.comments--;
			}
			row.version++;
			const result: SocialOutcome = { status: 'success', post: structuredClone(row) };
			data.operations.set(op.id, result);
			return control.writeMode === 'unknown'
				? { status: 'unknown' }
				: structuredClone(result);
		},
		resolve: async (id, r) => {
			await gate(r, 'read');
			return structuredClone(store(r).operations.get(id) ?? { status: 'unknown' });
		}
	};
	return { service, control };
}

export interface EditorialDTO {
	key: SocialId;
	person: SocialPost['author'];
	text: string;
	stamp?: string;
	art?: SocialPost['cover'];
	stats: { hearts: number; replies: number };
	viewer: { heart: boolean; saved: boolean };
	revision: number;
}
export interface NoteDTO {
	key: SocialId;
	parent: SocialId;
	writer: SocialComment['author'];
	text: string;
	removable: boolean;
	stamp?: string;
}
export const toEditorial = (p: SocialPost): EditorialDTO => ({
	key: p.id,
	person: p.author,
	text: p.body,
	stamp: p.time,
	art: p.cover,
	stats: { hearts: p.likes, replies: p.comments },
	viewer: { heart: p.liked, saved: p.bookmarked },
	revision: p.version
});
export const editorialMapping = {
	post: (p: EditorialDTO): SocialPost => ({
		id: p.key,
		author: p.person,
		body: p.text,
		time: p.stamp,
		cover: p.art,
		likes: p.stats.hearts,
		comments: p.stats.replies,
		liked: p.viewer.heart,
		bookmarked: p.viewer.saved,
		version: p.revision
	}),
	comment: (c: NoteDTO): SocialComment => ({
		id: c.key,
		postId: c.parent,
		author: c.writer,
		body: c.text,
		canDelete: c.removable,
		time: c.stamp
	})
};
/** A genuinely different transport DTO travels through both read and write paths. */
export function createEditorialService(base: SocialService): SocialService {
	const result = (o: SocialOutcome) =>
		o.status === 'success' ? { status: o.status, post: toEditorial(o.post) } : o;
	return adaptSocial<EditorialDTO, NoteDTO>(
		{
			feed: async (q, r) => {
				const p = await base.feed(q, r);
				return { total: p.total, list: p.list.map(toEditorial) };
			},
			comments: async (id, n, s, r) => {
				const p = await base.comments(id, n, s, r);
				return {
					total: p.total,
					list: p.list.map((c) => ({
						key: c.id,
						parent: c.postId,
						writer: c.author,
						text: c.body,
						removable: c.canDelete,
						stamp: c.time
					}))
				};
			},
			write: async (op: SocialOperation, r) => result(await base.write(op, r)),
			resolve: async (id, r) => result(await base.resolve(id, r))
		},
		editorialMapping
	);
}
