<template>
	<AsamApplicationProvider
		:config="{
			size,
			colorMode: preferences.colorMode.value,
			base: { locale: locales[preferences.locale.value] }
		}"
		class="preferences-app"
		:data-mode="preferences.colorMode.value"
	>
		<header>
			<h1>{{ preferences.t('title') }}</h1>
			<label
				>{{ preferences.t('language') }}
				<select data-language :value="preferences.locale.value" @change="chooseLocale">
					<option v-for="language in Object.keys(dictionaries)" :key="language">
						{{ language }}
					</option>
				</select></label
			>
			<label
				>{{ preferences.t('theme') }}
				<select data-theme :value="preferences.theme.value" @change="chooseTheme">
					<option v-for="mode in themes" :key="mode" :value="mode">
						{{ preferences.t(mode) }}
					</option>
				</select></label
			>
			<span>{{ preferences.t('effective') }}: {{ preferences.colorMode.value }}</span>
			<label
				>{{ preferences.t('size') }}
				<select v-model="size" data-size>
					<option v-for="item in sizes" :key="item">{{ item }}</option>
				</select></label
			>
			<button @click="preferences.reset()">{{ preferences.t('reset') }}</button>
			<label
				>{{ preferences.t('storage') }}
				<select v-model="storageMode" data-storage>
					<option value="normal">{{ preferences.t('normal') }}</option>
					<option value="memory">{{ preferences.t('memory') }}</option>
					<option value="throwing">{{ preferences.t('throwing') }}</option>
				</select></label
			>
		</header>
		<AsamAdminLayout
			v-model:settings="layoutSettings"
			:size="size"
			:menu-label="preferences.t('menu')"
			:sidebar-label="preferences.t('menu')"
		>
			<template #header>{{ preferences.t('app') }}</template>
			<template #sidebar>
				<AsamMenu
					:default-active="activeRoute"
					background-color="var(--asam-color-surface)"
					text-color="var(--asam-color-text-primary)"
					active-text-color="var(--asam-color-primary)"
					@select="selectMenu"
				>
					<AsamMenuItem
						v-for="item in controller.visibleMenu.value"
						:key="item.id"
						:index="item.id"
						>{{ preferences.t(item.title) }}</AsamMenuItem
					>
				</AsamMenu>
			</template>
			<div role="tablist" :aria-label="preferences.t('app')" class="tabs">
				<div v-for="tab in controller.tabs.value" :key="tab.id">
					<button
						role="tab"
						:tabindex="tab.id === controller.active.value ? 0 : -1"
						@keydown="tabKey($event)"
						:aria-selected="tab.id === controller.active.value"
						@click="controller.navigate(tab.fullPath)"
					>
						{{ preferences.t(tab.title) }}
					</button>
					<button
						v-if="!tab.pinned"
						:aria-label="preferences.t('close') + ' ' + preferences.t(tab.title)"
						@click="controller.close([tab.id])"
					>
						×
					</button>
				</div>
			</div>
			<button @click="controller.refresh()">{{ preferences.t('refresh') }}</button>
			<AsamPageContainer :title="preferences.t(activeRoute || 'home')">
				<NavigationPage
					v-for="page in controller.pages.value"
					:key="`${page.cacheKey}:${page.epoch}`"
					:controller="controller"
					:tab="page"
					:active="page.id === controller.active.value"
				/>
			</AsamPageContainer>
			<section class="cache-panel">
				<label
					>{{ preferences.t('scope') }}
					<select data-scope :value="scope" @change="switchScope">
						<option>A</option>
						<option>B</option>
					</select></label
				>
				<input v-model="cacheDraft" data-cache-draft :aria-label="preferences.t('notes')" />
				<button data-save @click="cache.write('notes', cacheDraft)">
					{{ preferences.t('save') }}
				</button>
				<button data-read @click="cache.read('notes')">{{ preferences.t('read') }}</button>
				<button data-clear @click="cache.clear()">{{ preferences.t('clear') }}</button>
				<p data-cache>{{ cache.value.value ?? preferences.t('empty') }}</p>
				<p>{{ preferences.t('expire') }}: {{ cacheTtl }}ms</p>
			</section>
			<p role="status" data-status>
				{{ preferences.t('storage') }}: {{ preferences.status.value }} /
				{{ cache.status.value }} — <br /><span data-preference-feedback>{{
					preferences.t('preferences.' + preferences.status.value)
				}}</span>
				<br /><span data-cache-feedback>{{
					preferences.t('cache.' + cache.status.value)
				}}</span>
			</p>
		</AsamAdminLayout>
		<aside v-if="showPreview">
			<AsamApplicationProvider :config="{ colorMode: 'light' }"
				><p data-preview>{{ preferences.t('preview') }}</p></AsamApplicationProvider
			>
		</aside>
		<button data-preview-toggle @click="showPreview = !showPreview">
			{{ preferences.t(showPreview ? 'destroy' : 'restore') }}
		</button>
	</AsamApplicationProvider>
</template>
<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, provide, ref } from 'vue';
import { useRouter } from 'vue-router';
import { AsamApplicationProvider, AsamAdminLayout, AsamPageContainer } from '@asam-ui/pro';
import { AsamMenu, AsamMenuItem } from '@asam-ui/ui';
import type { AsamControlSize } from '@asam-ui/ui';
import type { AsamLayoutSettingsValue } from '@asam-ui/pro';
import zhCn from 'element-plus/es/locale/lang/zh-cn.mjs';
import en from 'element-plus/es/locale/lang/en.mjs';
import { createNavigation } from '../../navigation/index.js';
import NavigationPage from '../../navigation/NavigationPage.vue';
import { createPreferences, createBusinessCache, browserStorage, memoryStorage } from '../index.js';
import type { StorageAdapter, ThemeChoice } from '../Types.js';
import { dictionaries } from './dictionaries.js';
import BusinessPage from './BusinessPage.vue';
import { preferenceKey } from './context.js';
const locales: Record<string, typeof en> = { 'zh-CN': zhCn, en };
const normal = browserStorage();
const memory = memoryStorage();
const storageMode = ref('normal');
const storage: StorageAdapter = {
	getItem(key) {
		if (storageMode.value === 'throwing') throw new Error('demo failure');
		return (storageMode.value === 'memory' ? memory : normal)?.getItem(key) ?? null;
	},
	setItem(key, value) {
		if (storageMode.value === 'throwing' || (!normal && storageMode.value === 'normal'))
			throw new Error('demo unavailable');
		(storageMode.value === 'memory' ? memory : normal)!.setItem(key, value);
	},
	removeItem(key) {
		if (storageMode.value === 'throwing' || (!normal && storageMode.value === 'normal'))
			throw new Error('demo unavailable');
		(storageMode.value === 'memory' ? memory : normal)!.removeItem(key);
	}
};
const preferences = createPreferences({
	app: 'preferences-example',
	owner: ['demo-user'],
	storage,
	dictionaries,
	fallbackLocale: 'zh-CN',
	initial: { locale: 'zh-CN', theme: 'system' },
	system:
		typeof window === 'undefined'
			? undefined
			: window.matchMedia('(prefers-color-scheme: dark)')
});
provide(preferenceKey, preferences);
const themes: ThemeChoice[] = ['light', 'dark', 'system'];
const sizes: AsamControlSize[] = ['small', 'default', 'big', 'large'];
const size = ref<AsamControlSize>('default');
const layoutSettings = ref<Partial<AsamLayoutSettingsValue>>({});
const scope = ref('A');
const cacheTtl = 1500;
const cache = createBusinessCache({
	app: 'preferences-example',
	owner: ['demo-user'],
	scope: [scope.value],
	storage,
	version: 1,
	ttl: cacheTtl,
	validate: (value): value is string => typeof value === 'string'
});
const cacheDraft = ref('');
const showPreview = ref(true);
const router = useRouter();
const controller = createNavigation({
	router,
	components: { business: BusinessPage },
	fallback: '/safe',
	load: async () => [
		{ id: 'home', path: '/home', title: 'home', resource: 'business', pinned: true },
		{ id: 'notes', path: '/notes', title: 'notes', resource: 'business' }
	]
});
const activeRoute = computed(
	() => controller.tabs.value.find((tab) => tab.id === controller.active.value)?.routeId ?? ''
);
async function tabKey(event: KeyboardEvent) {
	if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
	event.preventDefault();
	const buttons = [
		...((event.currentTarget as HTMLElement)
			.closest('[role="tablist"]')
			?.querySelectorAll<HTMLButtonElement>('[role="tab"]') ?? [])
	];
	const current = buttons.indexOf(event.currentTarget as HTMLButtonElement);
	const index =
		event.key === 'Home'
			? 0
			: event.key === 'End'
				? buttons.length - 1
				: (current + (event.key === 'ArrowLeft' ? -1 : 1) + buttons.length) %
					buttons.length;
	const tab = controller.tabs.value[index];
	if (tab && (await controller.navigate(tab.fullPath))) {
		await nextTick();
		buttons[index]?.focus();
	}
}
function selectMenu(id: string) {
	const item = controller.visibleMenu.value.find((entry) => entry.id === id);
	if (item) void controller.navigate(item.path);
}
function chooseLocale(event: Event) {
	preferences.choose({ locale: (event.target as HTMLSelectElement).value });
}
function chooseTheme(event: Event) {
	preferences.choose({ theme: (event.target as HTMLSelectElement).value as ThemeChoice });
}
function switchScope(event: Event) {
	scope.value = (event.target as HTMLSelectElement).value;
	cache.switchScope([scope.value]);
}
onMounted(async () => {
	await controller.reload();
	if (router.currentRoute.value.path === '/') await controller.navigate('/home', true);
});
onBeforeUnmount(() => {
	preferences.dispose();
	cache.dispose();
	controller.dispose();
});
defineExpose({ preferences, cache, controller });
</script>
<style>
.preferences-app {
	min-height: 100vh;
	background: var(--asam-color-surface);
	color: var(--asam-color-text-primary);
}
.preferences-app header,
.cache-panel,
.tabs {
	display: flex;
	flex-wrap: wrap;
	gap: var(--asam-space-3, 12px);
	padding: var(--asam-space-4, 16px);
	align-items: center;
}
.preferences-app h1 {
	flex-basis: 100%;
	font-size: var(--asam-font-size-xl, 24px);
}
.preferences-app input,
.preferences-app select,
.preferences-app button {
	max-width: 100%;
	font: inherit;
	color: inherit;
	background: var(--asam-color-surface);
	border: 1px solid var(--el-border-color);
	border-radius: var(--asam-radius-sm, 4px);
	padding: var(--asam-space-2, 8px);
}
.preferences-app button:focus-visible,
.preferences-app select:focus-visible,
.preferences-app input:focus-visible {
	outline: 2px solid var(--asam-color-primary);
	outline-offset: 2px;
}
.preferences-app [aria-selected='true'] {
	border-color: var(--asam-color-primary);
}
.preferences-app section,
.preferences-app aside {
	padding: var(--asam-space-4, 16px);
	min-width: 0;
}
.preferences-app [data-cache] {
	overflow-wrap: anywhere;
}
@media (max-width: 500px) {
	.preferences-app header label {
		width: 100%;
	}
}
</style>
