import { defineComponent, getCurrentInstance, h, ref } from 'vue';
import type { PropType } from 'vue';
import { AsamSelectV2, defineAsamControl, getAsamDataRuntime } from '@asam-ui/ui';
import type { AsamSelectV2Expose, AsamValue } from '@asam-ui/ui';
import { clearAsamFieldValue, isAsamFieldValue, useAsamFieldOptions } from '@asam-ui/pro';
import type { AsamFieldDefinition, AsamFieldOptionsConfig } from '@asam-ui/pro';

type SingleField = Extract<AsamFieldDefinition, { kind: 'single' }>;
function scalar(value: unknown): AsamValue | null | undefined {
	if (
		value == null ||
		typeof value === 'string' ||
		typeof value === 'boolean' ||
		(typeof value === 'number' && Number.isFinite(value))
	)
		return value;
	throw new TypeError('角色查询模型类型不兼容');
}
export function useRoleQueryOptions(
	original: SingleField,
	config: Omit<AsamFieldOptionsConfig, 'field'>
) {
	return useAsamFieldOptions({ ...config, field: original });
}
/** Template-owned bridge. Original full-source field owns reads; V2 only renders its snapshot. */
export function createRoleQueryField(original: SingleField): AsamFieldDefinition {
	if (original.remote || !original.source) throw new TypeError('角色查询需要完整候选源');
	const Control = defineComponent({
		name: 'AdministrationRoleQuery',
		inheritAttrs: false,
		props: {
			modelValue: { type: null as unknown as PropType<unknown> },
			session: { type: [String, Number] },
			active: { type: Boolean, default: true },
			disabled: Boolean
		},
		emits: { 'update:modelValue': (_value: unknown) => true },
		setup(props, { attrs, emit, expose }) {
			const instance = getCurrentInstance();
			if (!instance) throw new Error('角色查询需要组件上下文');
			const data = useRoleQueryOptions(original, {
				value: () => props.modelValue,
				session: () => props.session,
				active: () => props.active,
				runtime: getAsamDataRuntime(instance.appContext.app)
			});
			const input = ref<AsamSelectV2Expose>();
			expose({ focus: () => input.value?.focus(), refresh: data.refresh });
			return () =>
				h(
					'div',
					{
						class: 'administration-role-query',
						'aria-busy': data.search.loading.value || data.resolution.loading.value
					},
					[
						h(AsamSelectV2, {
							...attrs,
							ref: input,
							modelValue: scalar(props.modelValue),
							options: data.options.value,
							valueMode: 'value',
							multiple: false,
							filterable: false,
							remote: false,
							disabled: props.disabled || !props.active,
							emptyValues: [undefined, null],
							valueOnClear: null,
							style: { width: '100%' },
							'onUpdate:modelValue': (value: unknown) =>
								emit('update:modelValue', value)
						}),
						data.search.loading.value
							? h('span', { role: 'status' }, '选项加载中')
							: null,
						data.search.status.value === 'empty'
							? h('span', { role: 'status' }, '无匹配选项')
							: null,
						data.search.error.value
							? h('span', { role: 'alert' }, [
									'选项读取失败 ',
									h(
										'button',
										{ type: 'button', onClick: data.search.retry },
										'重试选项'
									)
								])
							: null,
						data.labelStatus.value === 'loading'
							? h('span', { role: 'status' }, '标签解析中')
							: null,
						data.labelStatus.value === 'unresolved'
							? h(
									'span',
									{ role: 'status' },
									`未解析：${data.labels.value
										.filter((item) => !item.resolved)
										.map((item) => item.label)
										.join('、')}`
								)
							: null,
						data.resolution.error.value
							? h('span', { role: 'alert' }, [
									'标签解析失败（保留原值） ',
									h(
										'button',
										{ type: 'button', onClick: data.resolution.retry },
										'重试标签'
									)
								])
							: null
					]
				);
		}
	});
	const { source: _source, remote: _remote, control: _control, kind: _kind, ...base } = original;
	return {
		...base,
		kind: 'custom',
		control: defineAsamControl<unknown, object>({
			component: Control,
			emptyValue: () => clearAsamFieldValue(original),
			sourceKinds: []
		}),
		isValue: (value) => isAsamFieldValue(original, value),
		emptyValue: () => clearAsamFieldValue(original),
		isEmpty: (value) => value === null,
		format: (value) => (value == null ? '—' : String(value)),
		query: (value, context) =>
			value === undefined
				? undefined
				: original.query
					? original.query(scalar(value)!, context)
					: value === null
						? undefined
						: value,
		submit: (value, context) =>
			value === undefined
				? undefined
				: original.submit
					? original.submit(scalar(value)!, context)
					: value
	};
}
