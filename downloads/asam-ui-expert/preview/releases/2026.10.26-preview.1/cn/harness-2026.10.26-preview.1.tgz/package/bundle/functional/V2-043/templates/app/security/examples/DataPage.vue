<template>
	<section aria-label="范围数据">
		<p role="status">{{ error || (loading ? '读取中' : '当前范围资料') }}</p>
		<ul>
			<li v-for="row in rows" :key="row">{{ row }}</li>
		</ul>
		<label>选择记录 <input v-model="selected" aria-label="选择记录" /></label>
		<label>敏感草稿 <input v-model="draft" aria-label="敏感草稿" /></label>
		<AsamPermission permission="record:write" mode="disable" v-slot="permission">
			<AsamButton
				:disabled="
					permission.disabled ||
					security.check({ permission: 'record:write', write: true }) !== 'allowed'
				"
				@click="save"
				>保存记录</AsamButton
			>
		</AsamPermission>
		<AsamButton @click="load">重试读取</AsamButton>
		<output aria-live="polite">{{ result }}</output>
	</section>
</template>
<script setup lang="ts">
import { inject, onBeforeUnmount, onMounted, ref } from 'vue';
import { AsamButton } from '@asam-ui/ui';
import { AsamPermission } from '@asam-ui/pro';
import { applicationKey } from './Context.js';
const application = inject(applicationKey);
if (!application) throw new Error('Missing application');
const { security, fixture } = application;
const rows = ref<string[]>([]);
const draft = ref('');
const selected = ref('');
const result = ref('');
const error = ref('');
const loading = ref(false);
let generation = 0;
let alive = true;
function clear() {
	generation++;
	rows.value = [];
	draft.value = '';
	selected.value = '';
	result.value = '';
	error.value = '';
	loading.value = false;
}
const remove = security.onInvalidate(clear);
async function load() {
	const subject = security.state.value.subject;
	if (!subject || security.check({ permission: 'workspace:read' }) !== 'allowed') return;
	const token = ++generation;
	const epoch = security.state.value.epoch;
	loading.value = true;
	error.value = '';
	try {
		const value = await fixture.read(subject);
		if (alive && token === generation && epoch === security.state.value.epoch)
			rows.value = value;
	} catch {
		if (alive && token === generation && epoch === security.state.value.epoch)
			error.value = '资料读取失败，请重试';
	} finally {
		if (alive && token === generation) loading.value = false;
	}
}
function save() {
	// UI visibility is insufficient; check immediately before calling the host write adapter.
	if (security.check({ permission: 'record:write', write: true }) !== 'allowed') {
		result.value = '操作已拒绝';
		return;
	}
	result.value = '本地示例保存完成（真实写入由后端再次鉴权）';
}
onMounted(load);
onBeforeUnmount(() => {
	alive = false;
	clear();
	remove();
});
</script>
