# @asam-ui/pro

ASAM UI 的 Vue 业务组合层。当前候选包含字段语义、注册与渲染适配，查询列表、编辑弹窗和详情组合。版本标识 `asamProVersion` / `AsamProVersion` 保持不变。

```ts
import { asamProVersion } from '@asam-ui/pro';
import type { AsamProVersion } from '@asam-ui/pro';

const candidate: AsamProVersion = asamProVersion;
```

字段入口：`AsamField`、`defineAsamFields`、`createAsamFieldModel`、
`clearAsamFieldValue`、`transformAsamFields`、`createAsamFieldSchema`、
`useAsamFieldOptions`；相关公开类型从同一入口导入。初始化仅在新增/加载会话边界调用，
表单使用返回的 schema/registry 与现有 `AsamForm`，无需重建表单引擎。

```ts
import {
	defineAsamFields,
	createAsamFieldModel,
	createAsamFieldSchema,
	transformAsamFields
} from '@asam-ui/pro';
const fields = defineAsamFields([
	{ key: 'name', label: '名称', kind: 'text', defaultValue: () => '' }
]);
const model = createAsamFieldModel(fields, {}, 'create');
const { schema, registry } = createAsamFieldSchema(fields, 'edit');
const result = transformAsamFields(fields, model, 'submit', ['name']);
```

缺失/undefined 不等于清空，默认不向旧记录补默认值。文本清空为 `''`，单选为 null，
多选为新数组；单选合法空字符串、0、false 均保留。标签不写回值；转换失败返回 issues，
调用方必须检查 `status` 再发请求。显示解析失败默认不阻断合法业务值的提交，
需要校验可用性的应用显式提供规则。所有提交均使用显式字段白名单。

字段 `modes.query/edit/detail` 分别配置显隐、禁用、只读、规则和布局元数据。
隐藏默认保值/跳校验/不提交；折叠只由容器隐藏布局，仍校验和转换。
公开 `source` 复用 UI 的 static/api/request/dict factory，`remote.search/resolve` 分别返回
api/request source，组件不存跨范围隐式缓存。数据范围由 `setAsamDataScope` 更新，
新会话可更改 `AsamField.session`，旧范围/会话结果不会回填。

消费端显式安装 `@asam-ui/ui@0.1.0-alpha.1`、`vue@>=3.5.34 <3.6.0`、
`element-plus@2.14.7`，并满足 UI 的 peer。预发布包版本相同不代表源码相同，
本地 pack 必须与送测报告记录的 UI 候选配对。

当前提供独立样式出口 `@asam-ui/pro/style.css`，`sideEffects` 为 `['**/*.css']`。
消费组合时显式引入该样式，并按 UI 文档引入 `@asam-ui/ui/style.css`。

本包只使用 UI 公开 API，不包含 CL 业务或 Agent/CLI 运行时。
字段契约、状态与迁移边界见 `docs/reports/V2-002-CONTRACT-R1.md`；完整可运行 SFC、
类型正反例、模型/异步/浏览器及 pack 消费入口见 `tests/v2/fields/README.md`。
这是新增可选入口；既有 UI/Pro 版本入口不变，无旧 API 删除或自动迁移。

## 编辑与详情组合

消费组合时显式引入 `@asam-ui/pro/style.css`，并按既有方式加载 UI 样式与 provider。

`useAsamEditor` / `AsamFormDialog` 提供新增和编辑弹窗；应用持有
`createAsamWriteCoordinator()` 并以稳定 operationId 关联跨弹窗未决写入。
保存适配返回 success/failure/unknown；断连异常保守保持未知，只有核实未生效后才允许显式再保存。
`onSaved` 是唯一成功结果事件，应用自行提示和刷新列表，读取失败不改变保存成功。

`useAsamDetail` / `AsamDetailPanel` 明确区分 direct 和 load 来源；同 id 直接数据使用
update 更新，主动加载只在 open/refresh 时读取。两种来源冲突会报配置错误并零请求。
以上组合复用现有字段、Form、provider 和 scope，不包含具体业务 API。
完整可运行 SFC 配方见仓库 `tests/v2/editor/src/App.vue`，公开接口见发布的 `.d.ts`。

## 查询列表组合（V2-003）

本卡新增 `useAsamListController`、`AsamSearchForm`、`AsamProTable`，从同一公开入口导入。
本组合契约见 `docs/reports/V2-003-CONTRACT-R1.md`。

页面在setup中创建唯一controller，向查询表单和表格传同一个实例。controller的`api`
接收`{ query, currentPage, pageSize, sort }`及UI的scope/epoch/AbortSignal上下文，返回
`{ list, total }`。URL/DTO/权限由应用适配。`AsamProTable.columns`按顺序声明key/label，
可配置单字段远程排序、宽度或render；`cell`插槽接收row/column，`toolbar`接收controller，
`rowActions`接收row/controller，`empty`及`error`可替换对应状态（error还接收retry）。

```vue
<template>
	<AsamSearchForm :controller="list" />
	<AsamProTable :controller="list" :columns="columns" />
</template>
<script setup lang="ts">
import { AsamSearchForm, AsamProTable, useAsamListController } from '@asam-ui/pro';
import type { AsamListColumn } from '@asam-ui/pro';
import '@asam-ui/ui/style.css';
interface Row {
	id: number;
	name: string;
}
const columns: readonly AsamListColumn<Row>[] = [{ key: 'name', label: '名称' }];
const list = useAsamListController<Row>({
	fields: [{ key: 'name', label: '名称', kind: 'text' }],
	initial: { name: '' },
	rowKey: 'id',
	api: async (params, context) => {
		// 应用在此调用自己的适配器；此配方仅返回合成空页。
		void params;
		void context;
		return { list: [], total: 0 };
	}
});
</script>
```

首屏默认加载一次；异步准备使用`immediate:false`，显式替换草稿/基准后调用`submit()`。
带规则的独立controller使用须提供`validate`；查询表单会注册现有Form校验。`draft`
编辑不请求；`intent`是最近有效意图；`successfulSource`标记旧结果实际来源。失败后
刷新/重试沿用意图，翻页禁用；排序/数量可基于已生效条件形成新意图。`reset`恢复最新
`setResetBaseline`基准。`replaceConditions(model,{mode:'draft'|'submit',force?})`默认拒绝
覆盖dirty草稿，返回conflict，应用决定是否显式force；基准更新自身零请求。

默认当前页选择；每次有效请求开始清空。应用action声明id/label/run，默认result作用域，
可显式selection或independent；visible/enabled由应用判断，busyKey共享互斥。实际拒绝
进入actionError，库不做删除、事务或自动写重试。插槽中的自定义操作也应调用
`canAction`/`runAction`。保存提示由页面唯一负责；明确保存成功后调用一次`refresh()`，
读取失败单独呈现“保存成功，列表更新失败”，重试只调用`retry()`。新增需要第一页时，
应用根据当前意图选择`setPage(1)`或第一页`refresh()`，不得双发。

scope/epoch失效立即清除本实例敏感内容并停用交互。应用通过UI公开scope接口先隔离旧
范围，再调用`resumeScope(initial)`准备新范围并显式submit；组件不改业务鉴权或全局
字典分区。不要把同范围保留旧结果用于跨租户切换。合成完整SFC与验证命令见
`tests/v2/list/README.md`；CL真实业务未指定，不是本卡验收前置。

查询表单复用公开AsamForm的原生校验能力诊断。当前原生规则链对部分Object.prototype
同名目标存在“未执行规则却返回成功”的限制；命中当前实际适用/注册的字段时，查询返回
精确字段能力错误并停止请求，折叠字段仍参与检查和展开定位。合法的数据key及其读值、
输入和格式化不被全局禁止，也不声称这些原生规则已能执行。普通字段继续原生校验；
业务隐藏字段不参与，隐藏后可恢复查询。错误沿既有`issues`字段键呈现，不需解析消息
猜测字段，也没有新增校验引擎。

查询会话失效时，查询视图通过公开`clearValidate()`同步清理自身Form诊断，避免旧范围的
能力错误残留；这不重置调用方业务值，也不修改其他Form实例。
