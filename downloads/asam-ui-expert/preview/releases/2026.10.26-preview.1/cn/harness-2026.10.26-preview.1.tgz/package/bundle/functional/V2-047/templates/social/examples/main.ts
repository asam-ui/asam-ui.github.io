import { createApp } from 'vue';
import 'element-plus/dist/index.css';
import '@asam-ui/ui/style.css';
import '@asam-ui/pro/style.css';
import App from './App.vue';
const application = createApp(App);
const view = application.mount('#app');
if (new URLSearchParams(location.search).has('test'))
	Object.assign(window, { socialDemo: { view, application } });
