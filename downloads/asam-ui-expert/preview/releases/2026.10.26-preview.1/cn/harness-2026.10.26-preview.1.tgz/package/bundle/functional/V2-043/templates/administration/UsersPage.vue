<template>
	<section aria-label="用户管理模板">
		<p>
			用户关联角色由宿主提供；未知角色按
			{{ host.unknownRoles === 'preserve' ? '保留原关联' : '拒绝保存' }}
			策略处理。不收集密码。
		</p>
		<AsamCrudPage :controller="crud" title="用户管理" :size="host.size.value">
			<template #heading><span>用户、账号与角色关联</span></template>
		</AsamCrudPage>
	</section>
</template>
<script setup lang="ts">
import { defineAsamOptions } from '@asam-ui/ui';
import { AsamCrudPage } from '@asam-ui/pro';
import {
	useAdministration,
	useAdministrationCrud,
	field,
	queryFields,
	readHostOptions
} from './Crud.js';
import { userCodec, versionField } from './Codecs.js';
import { withUserRolePolicy, validateRoleOptions } from './UserRoles.js';
import type { UserRow } from './Types.js';
import { createRoleQueryField } from './RoleQueryField.js';
const host = useAdministration();
const source = defineAsamOptions().api({
	api: async (_: null) =>
		readHostOptions(host, 'users', (c) => host.services.value.roleOptions(c)),
	params: null,
	transform: (r) =>
		validateRoleOptions(r).map((n) => ({ value: n.id, label: n.name, disabled: !n.enabled })),
	fieldNames: { value: 'value', label: 'label', disabled: 'disabled' }
});
const fields = [
	field('name', '姓名'),
	field('account', '账号'),
	field('status', '状态'),
	{ key: 'roleIds', label: '关联角色', kind: 'multiple' as const, source },
	field('context', '上下文'),
	field('note', '备注'),
	versionField
];
const queries = queryFields.map((f) =>
	f.key === 'role' && f.kind === 'single' ? createRoleQueryField({ ...f, source }) : f
);
const crud = useAdministrationCrud(
	host,
	'users',
	withUserRolePolicy(host, host.services.value.users.crud),
	userCodec,
	fields,
	[
		{
			key: 'id',
			label: '标识',
			width: 120,
			render: (row: UserRow) => `${typeof row.id}:${row.id}`
		},
		{ key: 'name', label: '姓名', width: 160 },
		{ key: 'account', label: '账号', width: 160 },
		{ key: 'status', label: '状态', width: 100 },
		{
			key: 'roleIds',
			label: '角色关联',
			width: 220,
			render: (row: UserRow) => row.roleIds.map((id) => `${typeof id}:${id}`).join('、')
		},
		{ key: 'version', label: '版本', width: 80 }
	],
	queries
);
defineExpose({ crud });
</script>
