# 精确集成提案

本卡仅新增templates/desktop与tests/v2/desktop，不改公共配置、锁、包出口、官网导航或知识索引。源码模板由普通消费应用直接复制；不把模板强塞UI/Pro运行包。

开发主控在本卡独立QA→ACC后精确集入本卡路径。050可在统一模板目录增加 `desktop-window-workspace`，三族条目分别指向本目录的MinimalDesktop.vue/BrandDesktop.vue/TechDesktop.vue，API/README与全屏示例来自同一候选；保已有入口/搜索/版本，不新建第二站或公开Storybook。051同源目录索引收录capability.json→API.md→AGENT.md，version=0.1.0-alpha.1，依赖029/032/034。052只消费同源方法，不由本卡改hosts。

无需root package/workspace/锁新增依赖；DEV独立consumer固定包/工具/锁在外置封套，pnpm verifyDepsBeforeRun=error。必要的根脚本可串行增加 `test:v2:desktop` 指向本卡配方，但配方需要显式新输出目录与已验正常包，不应默认全库build或安装root partial。该提案不是已发生的聚合修改或发布授权。
