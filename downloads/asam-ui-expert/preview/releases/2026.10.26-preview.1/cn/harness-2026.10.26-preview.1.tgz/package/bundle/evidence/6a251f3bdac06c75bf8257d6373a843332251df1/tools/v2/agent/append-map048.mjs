import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';

// Data-only successor. Use the qualified installed SDK, never pnpm's partial root auto-sync.
const root = resolve(import.meta.dirname, '../../..');
const output = resolve(process.argv[2]);
assert(!existsSync(output) && output.startsWith('E:\\DevCache\\'), 'NEW_EXTERNAL_OUTPUT_REQUIRED');
assert.equal(process.cwd(), root, 'EXPLICIT_OWNER_CWD_REQUIRED');
assert.equal(process.env.PNPM_CONFIG_VERIFY_DEPS_BEFORE_RUN, 'error');
const config = JSON.parse(readFileSync(join(root, 'agent-content/map048-input.json')));
const sdkConsumer = process.env.ASAM_MAP_SDK_CONSUMER;
assert(sdkConsumer && existsSync(sdkConsumer), 'EXPLICIT_OWN_QUALIFIED_SDK_CONSUMER_REQUIRED');
const own = createRequire(resolve(sdkConsumer));
const sdkEntry = own.resolve('@asam-ui/agent-core');
const localHash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sdkSourceBytes = readFileSync(join(dirname(sdkEntry), 'SOURCE.json'));
assert.equal(localHash(sdkSourceBytes), config.sdkSourceSHA256, 'ACTUAL_SDK_SOURCE_SIGNATURE');
for (const file of JSON.parse(sdkSourceBytes).files)
	assert.equal(
		localHash(readFileSync(join(dirname(sdkEntry), file.path))),
		file.sha256,
		`ACTUAL_SDK_COMPILED:${file.path}`
	);
const api = await import(pathToFileURL(sdkEntry));
const { hash, loadBundle } = api;
const checked = (path, sha) => {
	const bytes = readFileSync(path);
	assert.equal(hash(bytes), sha, path);
	return bytes;
};
checked(config.sdkTar, config.sdkSHA256);
const inheritedManifest = checked(
	join(config.baseBundle, 'manifest.json'),
	config.baseManifestSHA256
);
const base = loadBundle(config.baseBundle);
assert.equal(base.knowledge.length, 38);
assert.equal(
	base.knowledge.reduce((n, c) => n + c.examples.length, 0),
	103
);
const closeoutBytes = checked(config.closeout, config.closeoutSHA256);
const closeout = JSON.parse(closeoutBytes);
assert.equal(closeout.product, config.mapSourceSha);
assert(closeout.status.startsWith('COMPLETE'));
assert.equal(closeout.fullQA, '0e72b3b03915b1dea96cc25ee25ee5f710fa5526');
assert.equal(closeout.fullACC, '915ae30f6f0907085ccc62022a6809b74b53c5be');
const bindingBytes = checked(config.binding, config.bindingSHA256);
const binding = JSON.parse(bindingBytes);
assert.equal(binding.archiveSHA256, config.mapTarSHA256);
const archive = checked(config.mapTar, config.mapTarSHA256);
const tar = gunzipSync(archive),
	members = new Map();
let long;
for (let offset = 0; offset + 512 <= tar.length;) {
	const field = (start, size) =>
		tar
			.subarray(offset + start, offset + start + size)
			.toString()
			.replace(/\0.*$/s, '');
	const name = field(0, 100);
	if (!name) break;
	const size = parseInt(field(124, 12).trim(), 8) || 0;
	const type = field(156, 1),
		bytes = tar.subarray(offset + 512, offset + 512 + size);
	if (type === 'L') long = bytes.toString().replace(/\0.*$/s, '');
	else if (type === 'x') long = bytes.toString().match(/\d+ path=(.*)\n/)?.[1];
	else if (type === '0' || type === '') {
		const path = (long || (field(345, 155) ? `${field(345, 155)}/${name}` : name)).replace(
			/^package\//,
			''
		);
		assert(!path.split('/').includes('..'));
		assert(!members.has(path));
		members.set(path, bytes);
		long = undefined;
	}
	offset += 512 + Math.ceil(size / 512) * 512;
}
const pkg = JSON.parse(members.get('package.json'));
assert.equal(pkg.name, '@asam-ui/maps-template');
assert.equal(pkg.dependencies.leaflet, '1.9.4');
assert.equal(pkg.dependencies['@types/leaflet'], '1.9.21');
for (const path of ['dist/maps.js', 'dist/index.d.ts', 'dist/maps-template.css'])
	assert(members.has(path), path);
assert.equal(pkg.exports['./source/*'], './*');
const git = (...args) => execFileSync('git', args, { cwd: root, windowsHide: true });
const producer = git('rev-parse', 'HEAD').toString().trim();
assert.equal(
	git('merge-base', producer, config.canonicalSha).toString().trim(),
	config.canonicalSha
);
const gitFile = (sha, path) => git('show', `${sha}:${path}`);
for (const path of [
	'agent-content/map048-input.json',
	'agent-content/map048.md',
	'agent-content/ready-knowledge.json',
	'tools/v2/agent/append-map048.mjs',
	'tests/v2/agent/map048/knowledge.test.mjs'
])
	assert.equal(
		readFileSync(join(root, path)).toString().replaceAll('\r\n', '\n'),
		gitFile(producer, path).toString().replaceAll('\r\n', '\n'),
		`COMMITTED_PRODUCER_REQUIRED:${path}`
	);
const paths = git('ls-tree', '-r', '--name-only', config.mapSourceSha, '--', 'templates/maps')
	.toString()
	.trim()
	.split(/\r?\n/);
assert.equal(paths.length, 33);
const files = paths.map((path) => {
	const bytes = gitFile(config.mapSourceSha, path);
	return {
		path,
		sha256: hash(bytes),
		content: bytes.toString(),
		gitSourceSha: config.mapSourceSha,
		normalTarMember: members.has(path.slice('templates/maps/'.length))
	};
});
const archiveSources = [];
for (const file of files) {
	const member = members.get(file.path.slice('templates/maps/'.length));
	if (!member || file.path.endsWith('/package.json')) continue;
	assert.equal(
		member.toString().replaceAll('\r\n', '\n'),
		file.content.replaceAll('\r\n', '\n'),
		file.path
	);
	archiveSources.push({ path: file.path, archiveSHA256: hash(member), gitSHA256: file.sha256 });
}
const guide = readFileSync(join(root, 'agent-content/map048.md'));
const guideFile = {
	path: 'agent-content/map048.md',
	sha256: hash(guide),
	content: guide.toString(),
	gitSourceSha: producer
};
files.push(guideFile);
const ledger = gitFile(config.canonicalSha, 'docs/TODOLIST.md');
assert.match(ledger.toString(), /\[V2-048\]\(#v2-048\)[^\n]*已完成/);
const start = ledger.toString().indexOf('### V2-048 ·');
const end = ledger.toString().indexOf('\n### ', start + 1);
const ledgerPath = `evidence/${config.canonicalSha}/docs/TODOLIST.md`;
const oldData = JSON.parse(readFileSync(join(config.baseBundle, 'source-knowledge.json')));
const inherited = structuredClone(oldData.records);
for (const record of inherited) {
	record.sources.snapshotSourceSha = record.sources.snapshotSourceSha ?? record.sources.sourceSha;
	record.sources.sourceSha = producer;
	record.versions.sourceSha = producer;
}
const sources = new Map(base.manifest.sourceFiles.map((f) => [f.path, f]));
const addSource = (path, bytes) => {
	if (sources.has(path))
		assert.equal(sources.get(path).sha256, hash(bytes), `SOURCE_COLLISION:${path}`);
	sources.set(path, { path, sha256: hash(bytes) });
};
for (const file of files) addSource(file.path, Buffer.from(file.content));
addSource(ledgerPath, ledger);
const ready = JSON.parse(readFileSync(join(root, 'agent-content/ready-knowledge.json')));
assert.deepEqual(
	ready.pending,
	oldData.pending.filter((id) => id !== 'V2-048')
);
const migration = ready.migrations['V2-048'];
const capability = JSON.parse(files.find((file) => file.path.endsWith('/capability.json')).content);
const map = {
	id: 'ready.v2-048',
	task: 'V2-048',
	purpose: '地图前端示例、本地GeoJSON、点位筛选与三族可编辑地图页面',
	kind: 'source-knowledge',
	runtimePairing: 'not-checked',
	versions: { sourceSha: producer },
	tags: ['地图', 'GeoJSON', 'WGS84', 'MapProvider', '主动定位', 'V2-048'],
	symbols: [
		...new Set(
			files.flatMap(
				(file) =>
					file.content.match(
						/\b(?:MinimalMap|BrandMap|TechMap|MapProvider|MapDataset|MapController|LocationPort|createMapController|localProvider|browserLocation)\b/g
					) ?? []
			)
		)
	]
		.sort()
		.map((name) => ({ name, kind: 'source-reference' })),
	sources: {
		sourceSha: producer,
		snapshotSourceSha: config.mapSourceSha,
		ledger: {
			path: ledgerPath,
			sha256: hash(ledger),
			gitSourceSha: config.canonicalSha,
			taskStatus: '已完成',
			card: ledger
				.toString()
				.slice(start, end < 0 ? undefined : end)
				.trim()
		},
		files: files.map(({ content, ...file }) => file)
	},
	api: files.filter((file) =>
		/\/(?:API\.md|Types\.ts|index\.ts|capability\.json|package\.json)$/.test(file.path)
	),
	recipe: files.filter(
		(file) => file.path.startsWith('templates/maps/') && /\.md$/.test(file.path)
	),
	examples: files.filter(
		(file) => file.path.startsWith('templates/maps/') && !/\.md$/.test(file.path)
	),
	unavailableExamples: [],
	migration: { ...migration, documents: [guideFile] },
	verification: [
		'原048完整QA→ACC/有限QA/永久收尾继承',
		'具名正常tar/binding与Git源码资格',
		'本新增知识/迁移SDK与CLI必要验证'
	],
	limitations: capability.limitations,
	normalPackageEvidence: {
		name: pkg.name,
		version: pkg.version,
		tar: config.mapTar,
		sha256: config.mapTarSHA256,
		bindingSHA256: config.bindingSHA256,
		exports: pkg.exports,
		peers: pkg.peerDependencies,
		dependencies: pkg.dependencies,
		archiveSources,
		runtime: 'inherited V2-048 independent receipts; no new V2-051 runtime run',
		onlineProviders: 'NOT_RUN'
	},
	finalInput: {
		status: 'consumed-accepted-input',
		fullQA: closeout.fullQA,
		fullACC: closeout.fullACC,
		integration: closeout.productIntegration,
		finiteQA: closeout.finiteQA,
		finiteIntegration: closeout.finiteIntegration,
		closeoutSHA256: config.closeoutSHA256
	}
};
const data = {
	...oldData,
	sourceSha: producer,
	sourceKind: 'git-commit',
	records: [...inherited, map],
	pending: ready.pending,
	inheritedSnapshot: {
		sourceSha: oldData.sourceSha,
		manifestSHA256: config.baseManifestSHA256,
		records: 38,
		examples: 103
	}
};
mkdirSync(output, { recursive: true });
for (const file of base.manifest.files) {
	mkdirSync(dirname(join(output, file.path)), { recursive: true });
	writeFileSync(join(output, file.path), readFileSync(join(config.baseBundle, file.path)), {
		flag: 'wx'
	});
}
const extra = [];
function evidence(path, bytes) {
	mkdirSync(dirname(join(output, path)), { recursive: true });
	writeFileSync(join(output, path), bytes, { flag: 'wx' });
	addSource(path, bytes);
	extra.push({ path, sha256: hash(bytes) });
}
evidence(ledgerPath, ledger);
evidence('evidence/v2-048/FINAL-CLOSEOUT.json', closeoutBytes);
evidence('evidence/v2-048/normal-binding.json', bindingBytes);
evidence('map048.md', guide);
for (const path of [
	'agent-content/map048-input.json',
	'agent-content/ready-knowledge.json',
	'tools/v2/agent/append-map048.mjs'
])
	evidence(`evidence/${producer}/${path}`, readFileSync(join(root, path)));
const bytes = Buffer.from(JSON.stringify(data) + '\n');
writeFileSync(join(output, 'source-knowledge.json'), bytes);
const manifest = {
	...base.manifest,
	sourceSha: producer,
	sourceKnowledge: {
		...base.manifest.sourceKnowledge,
		sourceSha: producer,
		count: 39,
		sha256: hash(bytes)
	},
	sourceFiles: [...sources.values()],
	files: [
		...base.manifest.files.map((file) =>
			file.path === 'source-knowledge.json' ? { ...file, sha256: hash(bytes) } : file
		),
		...extra
	],
	knowledgeIncrement: {
		event: config.event,
		baseManifestSHA256: hash(inheritedManifest),
		inheritedSnapshotSourceSha: oldData.sourceSha,
		inputSourceSha: config.mapSourceSha,
		canonicalSha: config.canonicalSha,
		normalSDKSourceSha: 'c69ef053a38145424cc25db245d9fd9c2fb68c85'
	}
};
manifest.contentDigest = hash(JSON.stringify(manifest.sourceFiles));
writeFileSync(join(output, 'manifest.json'), JSON.stringify(manifest) + '\n');
loadBundle(output);
console.log(
	JSON.stringify({
		output,
		producer,
		records: 39,
		inheritedRecords: 38,
		inheritedExamples: 103,
		mapSources: paths.length,
		mapExamples: map.examples.length,
		archiveMembers: members.size,
		archiveSourceMatches: archiveSources.length,
		manifestSHA256: hash(readFileSync(join(output, 'manifest.json'))),
		knowledgeSHA256: hash(bytes)
	})
);
