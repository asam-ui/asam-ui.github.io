import { createHash, randomUUID } from 'node:crypto';
import {
	chmodSync,
	closeSync,
	existsSync,
	lstatSync,
	mkdirSync,
	openSync,
	readFileSync,
	realpathSync,
	renameSync,
	unlinkSync,
	writeFileSync,
	writeSync
} from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { homedir } from 'node:os';
import { captureSync } from './process-capture.mjs';
import { fileURLToPath } from 'node:url';
import { foreignDependency } from './host-runtime.mjs';
import { ocrArchive } from './ocr-archive.mjs';

const manifestPath = new URL('../../../integrations/agents/ocr-toolchain.json', import.meta.url);
export const toolchain = JSON.parse(readFileSync(manifestPath, 'utf8').replace(/^\uFEFF/, ''));
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const failure = (code, action, details = {}) => ({ status: 'partial', code, action, ...details });

// Installed wrappers call prepareTool without arguments, so host configuration
// belongs here rather than at one CLI call site. Never scan arbitrary PATH shims.
export function preparationDefaults(env = process.env, settings = {}) {
	env = {
		...env,
		ASAM_OCR_CACHE_ROOT: env.ASAM_OCR_CACHE_ROOT || settings.cacheRoot,
		ASAM_OCR_BINARY: env.ASAM_OCR_BINARY || settings.binary,
		ASAM_OCR_DOWNLOAD_TIMEOUT_MS: env.ASAM_OCR_DOWNLOAD_TIMEOUT_MS ?? settings.downloadTimeoutMs
	};
	for (const name of [
		'ASAM_OCR_CACHE_ROOT',
		'ASAM_OCR_BINARY',
		'WORKBUDDY_CONFIG_DIR',
		'LOCALAPPDATA',
		'XDG_CACHE_HOME'
	])
		if (env[name] && (!isAbsolute(env[name]) || env[name].includes('${')))
			throw Error(`INVALID_${name}`);
	let cacheRoot = env.ASAM_OCR_CACHE_ROOT;
	if (!cacheRoot && env.WORKBUDDY_CONFIG_DIR)
		cacheRoot = join(env.WORKBUDDY_CONFIG_DIR, 'tools/open-code-review');
	if (!cacheRoot && env.LOCALAPPDATA)
		cacheRoot = join(env.LOCALAPPDATA, 'ASAMUI/tools/open-code-review');
	cacheRoot ||= join(env.XDG_CACHE_HOME || join(homedir(), '.cache'), 'asam-ui/open-code-review');
	const downloadTimeoutMs =
		env.ASAM_OCR_DOWNLOAD_TIMEOUT_MS === undefined
			? 600000
			: Number(env.ASAM_OCR_DOWNLOAD_TIMEOUT_MS);
	if (
		!Number.isInteger(downloadTimeoutMs) ||
		downloadTimeoutMs < 1000 ||
		downloadTimeoutMs > 1800000
	)
		throw Error('INVALID_OCR_DOWNLOAD_TIMEOUT');
	return {
		cacheRoot,
		downloadTimeoutMs,
		candidates: [...(env.ASAM_OCR_BINARY ? [env.ASAM_OCR_BINARY] : []), ...nativeCandidates()]
	};
}

export function hostToolDefaults(host, env = process.env, settings = {}) {
	const clean = { ...settings };
	for (const [key, variable] of [
		['binary', 'ASAM_OCR_BINARY'],
		['cacheRoot', 'ASAM_OCR_CACHE_ROOT']
	]) {
		if (foreignDependency(env[variable], host, env))
			throw Error(
				'OCR_FOREIGN_APPLICATION: 请改用当前平台或系统工具目录中的 OCR，不能引用其他应用的私有目录。'
			);
		// Old installer versions persisted sibling host paths. Ignore those values;
		// the caller backs up the original settings before saving the repaired ones.
		if (foreignDependency(clean[key], host, env)) delete clean[key];
	}
	const defaults = preparationDefaults(
		{
			...env,
			WORKBUDDY_CONFIG_DIR: host === 'workbuddy' ? env.WORKBUDDY_CONFIG_DIR : undefined
		},
		clean
	);
	if (foreignDependency(defaults.cacheRoot, host, env))
		throw Error('OCR_FOREIGN_APPLICATION: OCR 缓存不能位于其他应用的私有目录。');
	defaults.candidates = defaults.candidates.filter((path) => !foreignDependency(path, host, env));
	defaults.preferMirror = true;
	return defaults;
}

function configuredDefaults() {
	const packagedRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
	const codex = existsSync(join(packagedRoot, '.codex-plugin/plugin.json'));
	const root =
		process.env.ASAM_TOOLS_CONFIG_DIR ||
		(codex
			? process.env.CODEX_HOME || join(homedir(), '.codex')
			: process.env.WORKBUDDY_CONFIG_DIR || join(homedir(), '.workbuddy'));
	if (!isAbsolute(root) || root.includes('${')) throw Error('INVALID_WORKBUDDY_CONFIG_DIR');
	const file = join(root, 'asam-ui-tools.json');
	noLinks(file);
	const settings = existsSync(file)
		? JSON.parse(readFileSync(file, 'utf8').replace(/^\uFEFF/, ''))
		: {};
	if (
		!settings ||
		typeof settings !== 'object' ||
		Array.isArray(settings) ||
		Object.keys(settings).some(
			(key) => !['cacheRoot', 'binary', 'downloadTimeoutMs'].includes(key)
		)
	)
		throw Error('INVALID_HOST_TOOL_SETTINGS');
	return hostToolDefaults(codex ? 'codex' : 'workbuddy', process.env, settings);
}

export function nativeCandidates() {
	const root = dirname(realpathSync(process.execPath));
	const name = process.platform === 'win32' ? 'opencodereview.exe' : 'opencodereview';
	// Exact global package location for this running Node; no home/PATH scan.
	return [
		join(
			root,
			'node_modules/@alibaba-group/open-code-review/node_modules/@alibaba-group',
			`ocr-${process.platform}-${process.arch}`,
			'bin',
			name
		)
	];
}

export function noLinks(path) {
	if (!isAbsolute(path)) throw Error('ABSOLUTE_PATH_REQUIRED');
	for (let current = resolve(path); ; current = dirname(current)) {
		try {
			if (lstatSync(current).isSymbolicLink()) throw Error('SYMLINK_NOT_ALLOWED');
		} catch (error) {
			if (error.code !== 'ENOENT') throw error;
		}
		if (current === dirname(current)) break;
	}
}

// A configured native executable is hashed before it can be executed. Never run PATH shims.
export function inspectTool(binary, descriptor, { signal } = {}) {
	if (signal?.aborted) return failure('CANCELLED', '从原任务检查点恢复准备');
	try {
		noLinks(binary);
		const stat = lstatSync(binary);
		if (
			!stat.isFile() ||
			stat.size !== descriptor.bytes ||
			hash(readFileSync(binary)) !== descriptor.sha256
		)
			return failure('TOOL_HASH_MISMATCH', '使用套件固定来源准备匹配工具', { binary });
		const run = captureSync(binary, ['--version'], {
			encoding: 'utf8',
			timeout: 10000,
			windowsHide: true,
			env: { ...process.env, OCR_NO_UPDATE: '1' }
		});
		if (
			run.error ||
			run.status !== 0 ||
			!new RegExp(`open-code-review v${toolchain.version.replaceAll('.', '\\.')} \\(`).test(
				run.stdout
			)
		)
			return failure('TOOL_NOT_EXECUTABLE', '核对平台及宿主执行权限后从原检查点恢复', {
				binary
			});
		return { status: 'pass', binary, version: toolchain.version, sha256: descriptor.sha256 };
	} catch (error) {
		return failure(
			error.code === 'ENOENT' ? 'TOOL_MISSING' : error.message,
			'保留现有文件并检查明确指定的工具路径',
			{ binary }
		);
	}
}

// Download is bounded and hashed while streaming; a failed/cancelled download never becomes executable.
async function download(
	url,
	destination,
	descriptor,
	signal,
	timeoutMs,
	onProgress,
	archive = false
) {
	const requestSignal = signal
		? AbortSignal.any([signal, AbortSignal.timeout(timeoutMs)])
		: AbortSignal.timeout(timeoutMs);
	onProgress({
		phase: 'connecting',
		message: `正在连接${archive ? '国内 npmmirror 镜像' : 'GitHub 官方下载源'}，OCR 原生文件 ${(descriptor.bytes / 1048576).toFixed(1)} MB；网络超时上限 ${Math.ceil(timeoutMs / 1000)} 秒…`,
		url,
		receivedBytes: 0,
		totalBytes: archive ? undefined : descriptor.bytes
	});
	const response = await fetch(url, { signal: requestSignal, redirect: 'follow' });
	if (!response.ok || !response.body)
		throw Object.assign(Error('TOOL_DOWNLOAD_HTTP'), { status: response.status });
	const target = archive ? `${destination}.tgz` : destination;
	const fd = openSync(target, 'wx');
	const reportedSize = Number(response.headers.get('content-length'));
	const totalBytes = archive
		? reportedSize > 0 && reportedSize <= descriptor.bytes + 1048576
			? reportedSize
			: undefined
		: descriptor.bytes;
	const digest = createHash('sha256');
	let size = 0;
	let lastNotice = 0;
	try {
		onProgress({
			phase: 'downloading',
			message: '正在下载 OCR 工具…',
			url,
			receivedBytes: 0,
			totalBytes
		});
		for await (const chunk of response.body) {
			requestSignal.throwIfAborted();
			size += chunk.length;
			if (size > descriptor.bytes + (archive ? 1048576 : 0))
				throw Error('TOOL_DOWNLOAD_SIZE');
			digest.update(chunk);
			let offset = 0;
			while (offset < chunk.length) offset += writeSync(fd, chunk, offset);
			if (Date.now() - lastNotice >= 1000 || size === totalBytes) {
				onProgress({
					phase: 'downloading',
					message: '正在下载 OCR 工具…',
					url,
					receivedBytes: size,
					totalBytes
				});
				lastNotice = Date.now();
			}
		}
	} finally {
		closeSync(fd);
	}
	if (archive) {
		onProgress({
			phase: 'extracting',
			message: '国内镜像下载完成，正在提取固定 OCR 文件并核对 SHA256…'
		});
		const binary = ocrArchive(readFileSync(target), descriptor.bytes);
		if (hash(binary) !== descriptor.sha256) throw Error('TOOL_DOWNLOAD_HASH');
		writeFileSync(destination, binary, { flag: 'wx', mode: 0o600 });
		unlinkSync(target);
		return;
	}
	onProgress({
		phase: 'verifying',
		message: '下载结束，正在核对 OCR 文件大小和 SHA256…',
		receivedBytes: size,
		totalBytes: descriptor.bytes
	});
	if (size !== descriptor.bytes || digest.digest('hex') !== descriptor.sha256)
		throw Error('TOOL_DOWNLOAD_HASH');
}

async function prepare({
	cacheRoot = configuredDefaults().cacheRoot,
	candidates = configuredDefaults().candidates,
	downloadTimeoutMs = configuredDefaults().downloadTimeoutMs,
	allowDownload = true,
	preferMirror = existsSync(new URL('../../../.codex-plugin/plugin.json', import.meta.url)) ||
		existsSync(new URL('../../../.codebuddy-plugin/plugin.json', import.meta.url)),
	onProgress = () => {},
	signal
} = {}) {
	if (
		typeof allowDownload !== 'boolean' ||
		typeof preferMirror !== 'boolean' ||
		typeof onProgress !== 'function' ||
		!Number.isInteger(downloadTimeoutMs) ||
		downloadTimeoutMs < 1000 ||
		downloadTimeoutMs > 1800000 ||
		!Array.isArray(candidates) ||
		candidates.some((path) => typeof path !== 'string' || !isAbsolute(path)) ||
		(cacheRoot !== undefined && (typeof cacheRoot !== 'string' || !isAbsolute(cacheRoot)))
	)
		return failure('INVALID_PREPARATION_INPUT', '使用套件生成的固定工具准备参数');
	const platform = `${process.platform}-${process.arch}`;
	const descriptor = toolchain.platforms[platform];
	if (descriptor?.preparation !== 'supported')
		return {
			status: 'unsupported',
			code: 'PLATFORM_NOT_VALIDATED',
			platform,
			action: '使用支持矩阵中已验证的平台'
		};
	if (signal?.aborted) return failure('CANCELLED', '从原任务检查点恢复准备');
	const license = readFileSync(
		new URL('../../../integrations/agents/OCR-LICENSE', import.meta.url)
	);
	if (hash(license) !== toolchain.license.sha256)
		return failure('TOOL_LICENSE_MISMATCH', '恢复固定套件中的第三方许可');
	noLinks(cacheRoot);
	const directory = join(cacheRoot, `${toolchain.version}-${platform}`);
	const binary = join(directory, descriptor.asset);
	const checked = [];
	onProgress({ phase: 'checking-tool', message: '正在检查已有 OCR 工具及固定版本摘要…' });
	for (const path of [binary, ...candidates]) {
		const result = inspectTool(path, descriptor, { signal });
		checked.push(result);
		if (result.status === 'pass') {
			onProgress({ phase: 'tool-ready', message: '已找到并验证兼容 OCR 工具，无需下载。' });
			return { ...result, disposition: 'reused', checked };
		}
	}
	// Unknown/corrupt entries are preserved. A different private cache root is a recoverable minimum action.
	if (existsSync(directory))
		return failure('TOOL_CACHE_CONFLICT', '保留该目录，指定新的套件工具目录后重试', {
			directory,
			checked
		});
	if (!allowDownload)
		return failure(
			'TOOL_PREPARATION_UNAVAILABLE',
			'允许固定来源下载，或提供已有同版本原生工具',
			{ checked }
		);
	mkdirSync(cacheRoot, { recursive: true });
	const lock = join(cacheRoot, `.prepare-${toolchain.version}-${platform}.lock`);
	let fd;
	try {
		fd = openSync(lock, 'wx');
	} catch (error) {
		if (error.code !== 'EEXIST') throw error;
		return failure(
			'TOOL_PREPARATION_BUSY',
			'等待当前准备结束；中断遗留锁需核归属后保留并使用新目录',
			{ lock }
		);
	}
	const stage = join(cacheRoot, `.incoming-${randomUUID()}`);
	try {
		writeSync(fd, JSON.stringify({ pid: process.pid, version: toolchain.version, stage }));
		mkdirSync(stage);
		const incoming = join(stage, descriptor.asset);
		const packageName = `ocr-${process.platform}-${process.arch}`;
		const mirror = `https://registry.npmmirror.com/@alibaba-group/${packageName}/-/${packageName}-${toolchain.version}.tgz`;
		if (preferMirror) {
			try {
				await download(
					mirror,
					incoming,
					descriptor,
					signal,
					downloadTimeoutMs,
					onProgress,
					true
				);
			} catch (error) {
				if (signal?.aborted) throw error;
				onProgress({
					phase: 'source-fallback',
					message: `国内镜像未完成（${error.cause?.code || error.message}），正在切换 GitHub 官方源…`
				});
				try {
					await download(
						descriptor.url,
						incoming,
						descriptor,
						signal,
						downloadTimeoutMs,
						onProgress
					);
				} catch (fallback) {
					fallback.mirrorFailure = {
						url: mirror,
						message: error.message,
						code: error.cause?.code || error.code
					};
					throw fallback;
				}
			}
		} else
			await download(
				descriptor.url,
				incoming,
				descriptor,
				signal,
				downloadTimeoutMs,
				onProgress
			);
		chmodSync(incoming, 0o755);
		onProgress({ phase: 'tool-probe', message: '摘要校验通过，正在验证 OCR 是否可以运行…' });
		const result = inspectTool(incoming, descriptor, { signal });
		if (result.status !== 'pass') return { ...result, preserved: stage, checked };
		writeFileSync(join(stage, 'LICENSE'), license, { flag: 'wx' });
		// Exclusive preparation lock prevents concurrent writers; never replace a pre-existing directory.
		if (existsSync(directory)) throw Error('TOOL_CACHE_CONFLICT');
		renameSync(stage, directory);
		onProgress({ phase: 'tool-ready', message: 'OCR 工具下载、校验与运行检查完成。' });
		return { ...result, binary, disposition: 'prepared', checked };
	} catch (error) {
		let code = error.message;
		if (error instanceof TypeError && error.message === 'fetch failed')
			code = 'TOOL_DOWNLOAD_NETWORK';
		if (error.name === 'TimeoutError') code = 'TOOL_DOWNLOAD_TIMEOUT';
		if (signal?.aborted) code = 'CANCELLED';
		const describe = (value, depth = 0) => {
			if (!value || depth >= 3) return undefined;
			const detail = {
				name: value.name,
				message: value.message,
				code: value.code,
				status: value.status
			};
			if (value.cause) detail.cause = describe(value.cause, depth + 1);
			if (Array.isArray(value.errors))
				detail.errors = value.errors.slice(0, 4).map((item) => describe(item, depth + 1));
			return detail;
		};
		onProgress({ phase: 'failed', message: `OCR 工具准备失败，原因已保存到日志（${code}）。` });
		return failure(
			code,
			'保留下载现场；可通过 ASAM_OCR_BINARY 复用固定版本工具，或配置 ASAM_OCR_DOWNLOAD_TIMEOUT_MS 后重试',
			{
				preserved: stage,
				checked,
				download: {
					url: descriptor.url,
					timeoutMs: downloadTimeoutMs,
					error: describe(error),
					...(error.mirrorFailure ? { mirrorFailure: error.mirrorFailure } : {})
				}
			}
		);
	} finally {
		closeSync(fd);
		unlinkSync(lock);
	}
}

export async function prepareTool(options = {}) {
	if (
		!options ||
		typeof options !== 'object' ||
		Array.isArray(options) ||
		(options.signal !== undefined && !(options.signal instanceof AbortSignal))
	)
		return failure('INVALID_PREPARATION_INPUT', '使用套件生成的固定工具准备参数');
	try {
		return await prepare(options);
	} catch (error) {
		return failure(
			error.code ?? error.message,
			'保留现有文件，核工具目录或执行权限后从原任务恢复'
		);
	}
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	const result = await prepareTool(
		process.argv[2] ? JSON.parse(readFileSync(process.argv[2], 'utf8')) : {}
	);
	console.log(JSON.stringify(result));
	process.exitCode = result.status === 'pass' ? 0 : 1;
}
