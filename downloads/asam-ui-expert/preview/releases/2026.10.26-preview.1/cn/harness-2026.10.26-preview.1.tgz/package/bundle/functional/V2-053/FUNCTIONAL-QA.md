# V2-053 首次完整独立 QA 报告

2026-10-19（Asia/Shanghai）。**完整本卡 QA PASS，未关闭问题 0；可由原测试主控送独立 ACC。**
本结论不代替 ACC、codex/v2 集成及资源收尾。产品候选、包与阈值均未因本次 QA 改动。

## 固定候选与实际角色

- 完整 base `3f07c7582c6be38ee22ef86783b7022adf31e316` → head
  `85f502a65f3f2e128dadd52e74bdecf33275a230`，完整 27 changed paths，含 4 份产品/包资料。
- QA chat `01a154c3-99ed-7772-aaa9-c0b1192b5b01`，真实项目
  `f6046b3c-155c-49e3-9180-a827eb816dbb` 已由 app 回读；独立
  `E:/worktree-tmp/c7ff/asam-ui`，分支 `codex/v2-053-qa-r1`。
  原始两次 HEAD 同为 85f，初始工作树干净。实际 native 新 turn 为
  gpt-6.1-sol/high、danger-full-access/never，首工程工具有效。无 `.codegraph`，未初始化。
- 完整 DEV 交付 SHA256 `6eafa3e2154ad5d8593925893e7a94fccf307fd6e8c80f2e864689a3dd69994e`；
  TC 输入资格 `af30fd686be581430d2c21ce5f1c868b0f2ce197faa7f2fc66ba14146e98f7fa` 只作输入资格。
- 001 仅继承固定集成报告/同字节范围；031 只读精简收尾报告与最终小回执，重算回执 SHA256
  `6547015e3e3d425bf364e04d6c9ddb31dcc82f24b43b25e0e8d893ca8cd3095c`。
  未访问归档角色、旧安装、保护残留或大 raw；原生失败/不支持和既有未测不被改为 PASS。

## OCR 实际审查

OCR v1.13.1，range mode 的 merge_base 正是完整 base；preview 20 个可审源码/脚本/示例，
另 7 个 Markdown 因 unsupported_ext 排除，均补充人工全文审查。
宿主实际阅读完整新增内容、4 份产品差异及 Tour 类型/raw 委托、tokens 应用清除、按钮状态、
配置/尺寸上下文；固定正常 EP2.14.7 的 Tour 公开配置和事件实现也定向核对。
适用正确性、安全、生命周期、契约和测试规则；React 专属规则不套用 Vue。

可审源码 20/20 reviewed，skipped=0，coverage_rate=100%；补查文档 7/7，完整候选 27/27。
逐路径、状态、Git blob、工作区 raw hash 与适用规则见外置 `ocr-review.json`。
未发现需整改问题；没有将 preview/rule 退出成功或公开符号数量作为行为通过依据。
Tour 仅恢复既有明确 props 类型；token 新字段可选；CSS 只分离六实心前景及 plain 前景优先级，
无复制、生成或接管上游执行算法，无锁/依赖/版本升级。

## 正常包与独立执行

复用的固定 UI tar SHA256 为
`e12f10b272d2a4607910cdacaa60c245f3c6f386b45774048a7053c2b411adbd`，
JS/声明源 `2f8ecc78fb48d694222e5d0d0991d6edb9fb5105`，CSS 源
`51810e4d1de3dc5c5504e517c4405e7e7cb760ac`。Pro tar
`117b9190fc85031f4956d43a2128a7094c6432a2169fc58ee788add041ec72be` 精确复用。
当前产品文件分别与对应 sourceHead 的 Git blob 相同；不冒新 UI/Pro 重建。

自有 consumer 全新正常解析锁→offline/frozen 安装（安装 5m24.5s，未并行重型构建），
UI 1722 与 Pro 182 个 dist 文件在本次独立 tar 解包、安装及固定原 receipt 三者逐文件配对。
DEV mutable consumer/node_modules 未借用。根锁
`6c70b50cc9b729badfb57b746457a5aa08a4f029dcaf42632a1b4fd932c9c2a7`、补丁
`c1fea5923b0d78c0155c213ee186b0417e3790a0de3fdbe646e1aa5c9a1332c4` 未变；
现有补丁只含声明，consumer 锁实际应用同 hash。

实际 Node22.19.0/x64、pnpm11.9.0、EP2.14.7、Vue3.5.34、TS6.0.3、Vite8.0.10、
Chrome155.0.8059.82、宿主 Playwright1.62.1。
进程加载 E 入口后 D pnpm；store/cache/state 唯一 D 根，浏览器下载/profile/temp/原件在 E。
父子 pnpm verifyDepsBeforeRun=error，未修改全局守卫或补 root partial 安装。
安装及 browser/build 前均实查 CPU/可用内存，未停止他人有效工具；无 runtime/browser 下载。

类型检查、普通生产构建、全部真实 JS 深入口/公开声明解析与 native alias 引用身份通过。
缺 JS export、缺 TS 符号、私有路径反例都非零并命中指定错误；恢复正例、
纯 ASAM skipLibCheck=false、Tour 正反类型、可选 onSolid/错误类型与完整旧 theme 均通过。
根/深符号清单仅作索引，行为结论以固定同字节资格和以下实测差额为依据。

## BASE 与适用共同 Q

| 范围           | 独立结论与实际依据                                                                                                                                                                             |
| -------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| BASE-01 / Q-01 | PASS。完整家族映射、固定同字节原生/ASAM/高级职责复用，加正常包公开声明与真实行为差额；Tour 默认布尔、打开关闭、current/model、change/finish/close、默认与 indicators slot 及打开时卸载均实测。 |
| BASE-02 / Q-04 | PASS。四高度40/36/32/28、字号16/14/14/12、padding20/18/16/14；Textarea非单行不强制定高，图标实际几何；组件→Group→Form→Provider/031桥、嵌套/动态/清空回退通过；桌面/移动截图实际查看。          |
| BASE-03 / Q-08 | PASS。原生公开入口、ASAM扩展、高级/Pro协议可辨；完整TS/JS SFC用公开包运行，无源alias或UI→Agent依赖；同候选CONTRACTS/AGENT方法已核。                                                            |
| BASE-04 / Q-09 | PASS。Tour声明恢复及onSolid真实语义变化有来源/理由/替代/迁移与正常消费前后证据；历史删除接口与本次变化分列，未新增任意删除。                                                                   |
| Q-02           | PASS适用范围。加载、禁用阻断、只读、空/错切换恢复、卸载重挂载、服务DOM清理。未增加权限业务，031权限仅按原已验边界继承。                                                                        |
| Q-03           | PASS适用本地模型、事件、插槽、点击/键盘一致性；新后端请求/提交时序不适用。                                                                                                                     |
| Q-05           | PASS名称、键盘激活、focus/clear、禁用阻断及受影响前景；真实读屏未测。                                                                                                                          |
| Q-06           | PASS局部尺寸/主题、插槽、显式onSolid、完整旧对象省略字段/清旧inline回退；新增生产测试验证嵌套undefined继承、partial延续、null重置及外层不受污染。                                              |
| Q-07           | PASS有限代表与资源范围。原事前参数/方法已核、完整2308.3738ms成本未扣除；只承诺本场景粗迟滞守卫。服务DOM/卸载与本QA独占runner finally关闭实测。详见下节。                                       |
| Q-10           | PASS适用边界。主题污染反例与默认对象不变；无新增富文本/上传/后端鉴权，UI权限不冒后端授权。                                                                                                     |
| Q-11           | PASS本卡普通Vue/Chrome可核范围；其他浏览器/Agent宿主/真实CL未测，不借052代签。                                                                                                                 |
| Q-12           | PASS。独立正常安装、固定27路径、锁/补丁、原SFC实际改→HMR效果→恢复原字节；只新增QA自有目录，产品/其他owner无dirty。                                                                             |

独立生产预览验证六实心 primary/success/warning/danger/info/gradient 在 light、surface-only、
dark、显式 `#f5e663` 的前景；accent 仍为 tonal，不当作第六实心。
plain 每场景 rest/settled hover/active/移出恢复通过，显式状态背景与原 FAIL 实测值严格相同。
旧完整 theme 应用前黄色、移除显式字段后白色且 inline 字段为空。
所有观察等待真实有限 CSS transition 完成；本 QA 两轮生产边界记录均保留，第二轮对应最终
格式化/幂等 QA fixture。普通浏览器与生产浏览器 pageerror 都为0。

## Q07 时间、理由和资格

DEV 小指针 `qa-support/Q07-BUDGET-PREDECLARATION-20261019/POINTER.json`，SHA256
`f854f2ecb9b44a094b3b77e3ae1c020b663d50c3f60464b4b0d664ba3e3f48fc`。
QA 仅定位7个指定 native 行，逐原行 hash/时间及三个具名小回执重核，未扫整会话/旧raw。
50/15000/完整点击与Vue/style成本于21:10:24.967请求、21:10:25.620成功写入，
README21:18:23成功，早于最早保全测量21:45:16.756。

最早2236.6755ms阶段视觉fixture仍FAIL，保持FAIL；后续Tour为2220.1719ms。
最终2308.3738000000003ms只绑定 `delta-on-solid/browser.json`，22:18:24.290→22:18:26.599，
performance起4258.6758、终6567.0496，算术一致；最后CSS只改plain前景优先级，
配置更新算法和普通切换场景未变。未扣点击/actionability/观测成本，未升阈值或删字段。

50次是25对明暗来回、回初态且负载有界；15s为共享机器上包含浏览器工具成本的粗异常迟滞
守卫。数值理由为DEV本次补述，当时没有另存数值推导，不能补造事前benchmark。
QA接受它用于本卡有界重复更新的粗回归判定，同时结合实际响应式切换和卸载清理；
不推出每次300ms、FPS、分位数、端到端UI稳定或通用性能承诺。未另开性能窗。

## 原失败、限制及收尾

原Tour首类型FAIL、前景初帧假PASS、稳定dark FAIL、两plain FAIL及漏EP CSS视觉FAIL全部保留；
本QA不覆盖这些原件。首次QA bootstrap把Windows CRLF checkout raw与LF Git直接比较而失败，
改为核Git clean blob并单列raw hash；产品和包未改。一次`pnpm --offline dlx`因CLI不支持该选项
退出1，原日志保留，随后复用已装D共享cache的Prettier3.9.6；未安装新工具。
正常生产构建有大于500KB chunk提示，完整示例无拆包性能承诺，未改阈值消警告。

真实读屏、其他浏览器/宿主、CL/后端、上游内部全组合、公开部署未测或不适用。
没有新角色/子代理/心跳、main/canonical/CL/云写入、push/publish/deploy或全局清理。
外置原件根为 `E:/DevCache/artifacts/asam-ui/v2-053/qa-r1/`；`evidence-index.json`及
`FINAL-QA-DELIVERY.json`固定命令、输入、文件、哈希、QA提交和全部结果。
中文提交只含本QA目录，staged仓储、diff与适用格式检查通过后交TC；
独立ACC、精确集入/回归、保全与资源归档由原链接续，本角色保留整改用途，不自行归档。
