# V2-003 固定集成候选有限回归（原 QA-R1）

结论：**PASS**。本轮只验固定集成 `28ae9856b28b7446b718a50d916f51018bb6aa71`，
确认已验查询列表与当前 fields/editor/detail、UI 和组合包出口可共同消费。
源码及真实打包消费的类型、构建、公开出口、CSS、真实提交长错误和四键能力限制均通过。
未发现新增阻断问题；下述 README 链接 LOW 已由开发主控承接治理后继。

## 固定输入与责任边界

| 项目             | 固定值                                                             |
| ---------------- | ------------------------------------------------------------------ |
| 集成前基线       | `1071392df1ea02dc9d25db7d6d2af8f147173008`                         |
| 本轮产品 HEAD    | `28ae9856b28b7446b718a50d916f51018bb6aa71`                         |
| 已验列表产品来源 | `a9beb31cfd74ec4dfd900cb68c944ff27e6e2153`                         |
| 原 R4 QA         | `716ea6efbf3d0fce4d946240ead9577925bd7842`                         |
| 原独立 ACC       | `3543583a9291e023e60fc54b591cf2f98320b894`，ACC003-01 已闭环       |
| 固定 UI 来源     | `1956f2d0e689ec5f2f4e8ce3db0cd91af12b844d`                         |
| UI tree          | `39342e6e80482b0dffa60e10483d59159f2c52aa`                         |
| pnpm lock SHA256 | `5efa11b5c7253f021b081851046f6e1f853a8db1f7617d394bae50e8993c81d8` |

原 QA 对话 `01a142a7-d4b0-7b02-a424-2b2842e015d0`，真实 Asam-ui 项目
`f6046b3c-155c-49e3-9180-a827eb816dbb`，独立工作区 `E:/worktree-tmp/636b/asam-ui`。
实际本轮 `gpt-6.1-sol/high`、`danger-full-access/never` 见外部 `execution-context.json`。
仅新增本报告；不写共享 main、唯一台账及治理文件，不部署、发布、推送，不新增角色或扩大到 V2-004。

## 来源核对与 OCR 委托审查

对照开发主控的 `E:/DevCache/artifacts/asam-ui/v2-003/integration/source-map.json`：
25 个列表源码/测试/说明路径的 Git blob 与 SHA256 均等于已验产品来源。
部分测试文件本地为 CRLF，分别记录 canonical blob 与 checkout SHA，核实仅行尾差异，未将两者混算。
`source-map-verification.json` 保存逐文件结果。

相对集成前基线，以下完整 tree 不变：

| 路径                      | tree                                       |
| ------------------------- | ------------------------------------------ |
| `packages/pro/src/fields` | `95976dc461152599433a422088c920ee6b8b8439` |
| `packages/pro/src/editor` | `d0258ad9f02da9efc4708c20e2a10987fed96bf6` |
| `packages/pro/src/detail` | `7ccbdd24cc3061bba38efd4c8e3593665b7a2377` |
| `packages/ui`             | `39342e6e80482b0dffa60e10483d59159f2c52aa` |
| `tests/v2/fields`         | `df1b44abe54b2de2868ffe46c207e237c031bae2` |
| `tests/v2/editor`         | `cace9032cd3ff525344588add96501c2fba42bfc` |

OCR preview 使用实际 range `1071392…→28ae985…`，merge-base 为 `1071392…`，共 28 文件：
26 个可审源码、2 个因 unsupported_ext 排除的 Markdown。
24 个可审文件逐 blob 核同已验列表，继承原 QA/OCR→ACC；本轮宿主亲审新组合的
`packages/pro/src/index.ts` 和 `tests/v2/consumer/verify.mjs`，核对新增列表类型及运行出口、
保留原 15 个运行出口、组合目录白名单及 18 项公开导出断言。
两份文档分别为原样继承的 `tests/v2/list/README.md` 与本轮亲审的 `packages/pro/README.md`。
适用规则来自 OCR system/default，保留 `ocr-preview.json`、`ocr-composed-rules.json`、
`ocr-coverage.json`；没有将工具清单成功冒充 26 文件重新亲审。

集成与原列表候选之间的 UI 变更仅为 `packages/ui/src/styles/index.css`；fields 无差异。
本轮使用已验 UI 包，并真实重跑受样式和组合消费影响的场景。
原已验 24 个 core、21 个浏览器组及性能样本保持适用，未重新全组采样，未冒称本轮重跑。

## 新包与逐字节对应

UI 使用原独立 QA 已验归档：

`E:/DevCache/artifacts/asam-ui/V2-002/qa-r1/integration-1956/consumer/packs/ui-d4c9ded9b0427960/asam-ui-ui-0.1.0-alpha.1.tgz`

SHA256：`2fbc5fb5e240d0f737e24f72c8ea65f4f839022374f08f48bdc6003c0090ab12`。
先验证本工作区旧 UI producer 的 1722 文件已有原 QA 归档逐字节保全，再仅替换本工作区 UI dist，
从此固定包恢复 producer。未重建 UI 的 885 声明。

Pro 在本工作区 `packages/pro` cwd 分别执行 `build:js`、`build:types` 后新打包：

`E:/DevCache/artifacts/asam-ui/V2-003/qa-r1/integration-28ae/consumer-check/packs/1e6217f3a362a071/asam-ui-pro-0.1.0-alpha.1.tgz`

SHA256：`8178313c26177ac1b79da2c1fe21dd1f8bfa7fcea191af4b74a348b70961078d`。
这是包含 fields/editor/detail/list 的新组合包，未使用原 11 文件列表专包代替。

动态枚举全部 producer dist：UI **1722**、Pro **21** 文件，逐项核 producer→tar→本轮独立安装的
路径集合、字节与 SHA256；另核 tar 全部文件与安装文件相同。
JS、所有声明及 CSS 均在内。Pro CSS **1330 字节**，两个 scoped ID
`data-v-783ed3da`、`data-v-9d929c0b` 同时存在于 producer JS 与真实 consumer 构建 CSS。
结果见 `all-producer-tar-consumer-pairs.json`。

新 consumer 位于本轮 `consumer-check/consumer`，与原 `qa-r1/packed-consumer` 完全分离。
开工前核原 consumer 1733 项旧对应无错误，并保全原 QA 报告、原分支和归档，未覆盖旧失败证据。

## 本轮实际执行结果

| 验证                                                    | 本轮结果                                                                 |
| ------------------------------------------------------- | ------------------------------------------------------------------------ |
| Pro JS、声明、package 类型检查                          | PASS                                                                     |
| 原通用 consumer 的 source SFC 类型及构建                | PASS                                                                     |
| 新独立 consumer 离线严格 peer 安装、真实 SFC 类型及构建 | PASS                                                                     |
| 列表 source SFC 类型及构建                              | PASS                                                                     |
| 列表 packed SFC 类型及构建                              | PASS，使用公开包与 CSS 入口                                              |
| 18 公开运行出口                                         | PASS，精确集合、非空运行值及版本值                                       |
| 18 公开名称的 TypeScript 导入                           | PASS，真实 consumer 中 `AllExports.ts`                                   |
| CSS 公开入口与构建保留                                  | PASS，解析成功且非空，两个 scoped ID 保留                                |
| 不存在运行出口                                          | 按预期拒绝 named import                                                  |
| 不存在类型出口                                          | 按预期 TS2305；副作用私有导入亦被 TS2882 拒绝                            |
| 私有深层类型导入                                        | 按预期 TS2307                                                            |
| 人为缺失声明                                            | 按预期 TS7016；探针结束后声明与 manifest 恢复并经全文件对应复核          |
| 缺失 peer 安装                                          | 按预期 `ERR_PNPM_PEER_DEP_ISSUES`                                        |
| source/packed 正常查询组合                              | 各 PASS；初始请求一次，改草稿零请求，提交后累计两次，10 行，CSS HTTP 200 |
| source/packed 四键能力校验                              | 各 4/4 PASS：normal、toString、valueOf、hasOwnProperty                   |
| source/packed 320/640 长值场景                          | 各 10/10 PASS，包含真实提交后长错误                                      |

真实 Chrome `155.0.8059.82`。四键检查包含原生 slot 规则执行/拒绝、能力限制、精确字段 issues、
折叠展开定位、业务隐藏后恢复、原结果来源和选择保留；拒绝动作相对已有请求零增量。
长错误场景实际触发探针提交，断言完整 240 字长消息、错误正文及汇总可选择、无容器/页面横溢、
汇总可聚焦并按 Enter、草稿不变及请求数组为空。人工复看 source/packed 的 320/640 错误截图和正常组合截图，
与 DOM/请求断言一致。浏览器 JSON 的 errors 均为空。

原工具 `receipt.json` 保留其通用“DEV 自测通过，待独立 QA/OCR 与 ACC”标签；此轮由本独立 QA 实际执行，
本报告给出 QA 结论，不修改原始回执以冒充新的 ACC。

独立复现 helper 放在 `E:/DevCache/temp/asam-ui/V2-003-QA-R1/integration-28ae`。
仅适配绝对 fixture、独占 profile、UI 固定归档、Pro package cwd 和 pnpm11 显式 peer 策略，
浏览器原断言保留；辅助脚本及原/适配哈希纳入外部索引。
所有 child pnpm 使用 `--config.verifyDepsBeforeRun=never`。
pnpm 为 11.9.0、Node 为 22.19.0；实际加载本任务环境，store/cache/state 统一 `D:/.pnpm-store`，
新 profile/temp/证据位于 E。Playwright 复用宿主管理运行时，Chrome 复用已安装程序，未新增下载。

初次从无 package.json 的嵌套 list-fixture cwd 运行 pnpm exec 得到
`ERR_PNPM_RECURSIVE_EXEC_NO_PACKAGE`，原日志保留；改在独立 consumer package cwd
传入 fixture 绝对路径后，类型与构建通过。这是测试驱动路径修正，没有改产品源码。

## LOW、证据与收尾

`packages/pro/README.md` 引用的 `docs/reports/V2-003-CONTRACT-R1.md` 在固定 28ae 缺失。
开发主控已明确确认原 a9 含正式契约、本次集成漏带，由其治理后继补齐；
此项为非功能链接 LOW，不阻本轮有限集成 QA。没有跟进更新产品 HEAD 或声称固定 28ae 已修复。

外部证据根：`E:/DevCache/artifacts/asam-ui/V2-003/qa-r1/integration-28ae`。
`FINAL.json` 索引 **117 文件**，SHA256：
`8612140e6754ba41eb686e12b6d9ef2847fe3e319e0af11d1123359028270dfb`。
包含来源/OCR/保全回执、构建与负例日志、浏览器 JSON/截图、两端构建、helper 和 consumer 复现输入；
包另按上述固定路径及哈希引用。原 QA/ACC 正文亦在外部保全。

本轮独占浏览器 profile 与浏览器脚本进程核查无残留，HTTP 服务均由脚本 finally 关闭。
`process-closeout.json` 留档；未停止其他角色资源，未删除原 consumer、归档或有效工作区。
本报告是固定集成的有限 QA，不替代原独立 ACC，也不宣称 V2-004 或整批完成。
交开发与测试主控据此完成本卡适用的同轮保全、集成和资源收尾。
