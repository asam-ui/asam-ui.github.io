import { createApp, defineComponent, h } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import 'element-plus/dist/index.css';
import '@asam-ui/ui/style.css';
import '@asam-ui/pro/style.css';
import App from './App.vue';
const router = createRouter({
	history: createWebHistory(),
	routes: [
		{ path: '/safe', component: defineComponent(() => () => h('p', '页面已关闭，请选择菜单')) },
		{ path: '/redirect', redirect: '/home' },
		{
			path: '/:pathMatch(.*)*',
			component: defineComponent(() => () => h('p', '未匹配页面，可通过菜单恢复'))
		}
	]
});
export const application = createApp(App).use(router);
await router.isReady();
export const view = application.mount('#app');
