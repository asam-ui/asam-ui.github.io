# V2-047 · DEV-R1 交付记录

状态：完整实现候选；强端点计时门槛尚未闭合。不是整卡 PASS，不是独立 QA/ACC 结论。

固定 base：`37b0e6cdee3e6a969194ff39f07e7f9152176b53`。
仅新增 `templates/social/` 与 `tests/v2/social/`，未修改公共出口、根配置/锁、canonical、main、CL 或云。
首次 `8900` 候选 head、所有源码成员、完整外置文件哈希与实际来源见
`E:/DevCache/artifacts/asam-ui/v2-047/dev-r1/DELIVERY.json`。

## QA047-01 后继整改

独立 QA 在固定 `8900` 发现：service 替换清理尚未使旧列表失效时，
`selected` 的同步 watcher 可重入 `open(oldRow)`，把旧服务正文重新带回详情。
本 DEV 已在自己的普通 consumer 复现；首轮定向 FAIL 与 QA 原件保持原路径。
QA 首轮证据只限定清理同步返回时的旧正文残留；未把首个 assert 失败后的值当作已独立留证结论。

后继先使旧 runtime/list 失效，并在整个清理和 abort 回调期间阻止新动作。
嵌套 host 通知归入同一清理，外层完成后只恢复最新服务。
公开草稿改为受当前详情、权限、清理及销毁状态约束的可写 computed；内部清空不受公开 setter 干扰。
清理标记为响应式状态，缓存的 allowed computed 能正确撤回和恢复；旧 row 引用只查当前结果，
不能把旧服务正文重新写回新服务的详情或权威结果。
清理期间的 close/cancel 也不会反向修改本地状态。
详情在选帖或列表 session 改变时重置删除确认与 composition 状态，避免旧详情的输入状态阻止新服务提交。
对应合成 composition 场景已由定向真实浏览器复验；不代替真实系统 IME 验证。
整改只在本卡控制器、详情与定向检查中完成，不修改共享实现。

原 53 项行为检查继续通过；新增五个定向场景覆盖原复现、动作/草稿回灌、
嵌套换服务恢复、清理回调销毁后的终态与借入所有权，以及 allowed computed 恢复。
完整新 head、实际构建/功能验证和差额见
`E:/DevCache/artifacts/asam-ui/v2-047/dev-r1/remediation-r1/DELIVERY.json`。
此修复不关闭下方计时门槛，也不代替独立 QA 对新候选的复审。

## QA047-02/03 局部样式整改

QA047-02 的 default/small 原生控件被 15px/1.65 行高与 padding 撑高，
现仅为单行 button/input/select 使用 1.2 行高，并给原生 select 明确四档高度。
textarea 保留原多行行高和 120px 最小高度；长按钮标签仍可自然换行，不设固定按钮高度。
三族实际 button/input/select 均核四档 40/36/32/28，原文、20评论和多行草稿同时保全。

QA047-03 为页面皮肤与借入列表/工具栏的文本变量未接通，新增本卡局部 ASAM/EP
文本、表面和边框 token 桥接；不修改公共包。
`control-size-browser.mjs` 与 `theme-browser.mjs` 分别保存原始尺寸/样式与实际前景/背景链。
对比度只作实测诊断，不宣称特定可访问性认证；原首轮 FAIL 与本轮修复结果分开保全。

## QA047-04 服务失败原文整改

原 failed 分支只保留通用恢复提示，丢失服务的具体原因。本轮新增 `writeError` 独立状态，
对已经校验的 `failed.message` 拍下字符串快照，以 Vue 纯文本完整显示；恢复提示与草稿单独保留。
新操作、切帖、服务/身份清理会清空原因，忽略 abort 的迟到失败不污染新帖。
非法非字符串原因仍按 unknown 处理，不冒服务明确失败；异常对象不直接显示。
本地 Fixture 增加可配置失败文字，仍使用原100ms服务等待、100帖/20当前与40评论/20当前。
`failure-reason.ts` 和 `failure-reason-browser.mjs` 分别覆盖状态所有权与三族宽窄的长原因原文，
检查 HTML/script/链接不执行、不截断、不横溢和草稿保留；实际结论保全在后继封套。

本轮 DEV 验证：原行为 53 项、清理重入 5 项、失败原因 5 项通过；三族四档原生控件尺寸、
三族明暗色文本、三族宽窄长失败原因、9 组普通功能流程与最终服务切换流程通过。
最终严格类型与三个 SFC 构建通过。普通功能 9 组早于最后的详情 composition/session 小修，
该受影响路径以最终构建上的定向流程补验，不冒称全组重跑。
后继封套分别列明每份 receipt 的实际 source/dist 输入；视觉检查不作为完整强时序通过依据。

## 实现与自审

三种可编辑完整 SFC，共享真实 003/025 列表 controller 与 033 安全边界。
已实现查询/排序/分页/刷新、完整纯文本正文、点赞/收藏 desired state、评论分页、
新增/取消保草稿/删除确认、failed/unknown 与原 operationId 核实。
服务注入、两种真正不同的 DTO、typed 0/'0'、两身份/上下文、实际 logout、
权限撤回、迟到结果隔离、同步 watcher 重入与借入资源所有权均在本卡源码范围。
原文不执行 HTML/script/链接；图片为本地 SVG 或明确失败替代。

开发自审覆盖响应完整形状、非法 JS 参数、重复 ID、计数/版本、跨对象和服务代次、
await 前后 gate、同步重入、终端销毁与双实例。自审发现的问题已在候选内修复。
源码未复制上游组件算法，未增加真实社交服务或账号依赖。

## 首次 8900 的验证历史

- 严格公开类型正负、三个 SFC 生产构建及 53 项行为检查通过。
- 前序 normal 与实际改配各 9 组真实 UI 流程检查通过，包含宽窄、主题/尺寸选择、
  查询/排序/分页、stale 恢复、评论失败/unknown 核实、权限与退出。
  这些旧流程未核原生控件实际四档高度或暗色文本可读性，不能替代 QA047-02/03 的真实几何和颜色检查。
- Agent 实际改动三个 SFC 的信息结构、DTO 字段映射、配置和服务权限，共六个文件。
  改配先封 CAS，再物理复制独立 source/dist 并只读复放；30 文件只读且写入句柄被拒绝。
- 两轮改配原字节分别实际恢复 21、23 个文件，不用生成签名代替恢复。
- UI/Pro 普通包全部 1726/154 个 tarball 成员与自身 consumer 安装逐字节相等。
  独立安装仅一次，后续继承未改变的安装，不借其他角色 node_modules。
- pnpm 11 的命令子进程会收到 false 注入；外层命令配置回读为 error。
  后继 runner 已在实际进程恢复并回读 error，原继承值与生效值分别保全。

## 强端点原件与限制

所有场景维持 100 帖/默认20、40评论/默认20、读写真实100ms，阈值始终3000ms。
旧读器外置 raw 保留其实际观察的字段，但 QA047-M01 已指出资格缺项：不存在 pseudo
分支曾裁掉完整属性，控件未完整保留 typed/inert 原值、动画 pending 未核，且浏览器终点
早于 host 解码/比较后所需的最后 RPC。旧结果不具完整强协议资格，不能泛称完整观测。
raw/哈希、各自时钟、实际落盘观测仍保留原记录，不追改或回填。

| 窗口                  | 实际结果                                                               |
| --------------------- | ---------------------------------------------------------------------- |
| normal 首次           | feed FAIL，host 10199.98ms/browser 4164.10ms；详情/写入未测            |
| normal-qualified 后继 | 两帧几何不等且超过阈值；保留 FAIL                                      |
| normal-final 前序候选 | 原轻读器记 2848.37/1954.53/2006.26ms 为 PASS；M01 降级为无完整协议资格 |
| modified 首次         | feed FAIL 3074.09ms；详情/写入未测                                     |
| current-normal 首次   | 读器在首次 capture 前异常，强端点 UNKNOWN；没有 raw，不能补称已测      |
| current-modified      | feed FAIL 3205.95ms；详情/写入未测                                     |
| restored              | feed FAIL 3038.96ms；详情/写入未测                                     |

旧后继使用字典/gzip，但不能凭无损传输一项抵消上述观察字段和时钟缺项。
早期原件与首 FAIL 未覆盖，也未用后继 PASS 改写首次。
QA 的首次完整 normal 固定原始 raw 为 SHA256
`5b026adfbbe586cff5a803f8a3cf4a19e254ab32dc155a582e1b7289934868d6`，
host/browser 为 12077.47/12067.90ms，详情/写入未测。既有一次有界诊断记录 capture
约 5.25/4.90s，观察器成本全计；不据此认定唯一产品原因或盲改公共库。
本轮采用原 QA 当前完整 `strong.mjs`，包含完整 pseudo、typed 值/inert、动画 pending、
独立字典/gzip oracle 与解码比较后的最后浏览器 RPC。`browser.mjs full` 转交该读器，
旧缩减端点实现已删除；functional-only 的结果明确标记未测强端点。
采用的当前 QA 源脚本哈希与首测脚本哈希分别登记，不混为同一来源。
本 DEV 不重采旧首次窗口追绿，也不把源码接入或功能 PASS 冒新候选完整强窗口通过。
当前完整端点门槛仍需原 DEV 整改和独立核验；不能据功能 PASS 送 ACC。
真实系统 IME、实际读屏与外部真实社交服务未测试；composition 为合成事件。

## 独立接续

TC 按固定 base/head 组织 OCR delegate 实际源码审查和适用 QA；强端点 FAIL/UNKNOWN 必须保真。
消费配方从 `tests/v2/social/prepare.mjs` 创建新的独立 consumer，使用自身锁与安装。
`environment.ps1`、`command.mjs`、`freeze.mjs`、`agent.mjs`、`seal.mjs` 和 `browser.mjs`
提供实际可运行的环境、编译、改配、只读复放与完整观测方法。
仓储检查由完整 consumer 经 `pnpm exec node tests/v2/social/repository.mjs <Git根>` 执行，
runner 内部切换 Git cwd，不补 root partial 安装。
QA PASS 与完整新输入成立后才独立 ACC。未推送、发布、部署或自行归档回收。
