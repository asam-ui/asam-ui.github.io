# 固定公开契约与复用判定

输入是 `3f07c7582c6be38ee22ef86783b7022adf31e316`，EP **2.14.7**、Vue **3.5.34**、
TS **6.0.3**、pnpm **11.9.0**；没有依赖升级。29 个公开输入逐原字节与准备 READINESS 配对。
tokens 的真实目录为 `packages/ui/src/tokens`。

## 依据与资格

- 既有基础完整接受依据：`docs/TODOLIST_HISTORY_20261015_R1.md` 的已完成 UI-034～040、
  DATA-009、INT-006、DOC-014；其中原生失败、类型兼容限制、未测和文档整改记录仍保留。
  不将早期 README 的 DEV 自查、早期 ACC FAIL 或旧五层数量作为最终 PASS。
- 同字节复用锚点：V2-001 集成 `b35131ee100c2c9c2f8ea118ef45455f61cbe7b8` 与
  `docs/reports/V2-001-INTEGRATION-R1.md`。其后 UI 源仅 Form SFC/Index、data/index、
  styles/index.css 发生既有变化；本卡逐文件 SHA 记录完整源，不读旧归档工作区或 raw。
- 配置桥：`docs/reports/V2-031-CLOSEOUT-R1.md`、已关闭031固定小回执
  `6547015e3e3d425bf364e04d6c9ddb31dcc82f24b43b25e0e8d893ca8cd3095c`；只继承
  同版配置/主题/四尺寸及明确边界，实际新浏览器只补本卡组合差额。
- 当前正常包来源：本角色正常 UI/Pro build、portable UI pack/Pro pack、新 consumer 的
  frozen/offline install，全 dist 三方逐文件配对；sourceHead、锁、patch、tar、每个文件哈希
  都在外置 `normal-package.json`。885 份 type-only 上游声明与现有补丁保持。
- [上游 ConfigProvider](https://element-plus.org/en-US/component/config-provider.html)、
  [Input](https://element-plus.org/en-US/component/input.html)、
  [Button](https://element-plus.org/en-US/component/button.html) 为已读取的一手说明；在线页面
  会变化，版本敏感的实际契约以正常安装的固定2.14.7公开 JS/声明及既有固定来源为准。

## 完整入口映射的读法

下表列出所有公开家族及分支。每个真实深入口和根符号的最终展开清单分别在
`source-audit.json` / `public-contracts.json`，记录真实 source paths/hash、上游 import、
props（含事件 listener/v-model）、slots、instance keys。没有公开构造签名的服务/指令
按各自函数/钩子签名复核，不伪造 props。EP instance 的内部 setup 状态不自动视为公开 expose。

| ASAM 完整家族                                                                                    | 原生/ASAM职责、公开契约与例外                                                                  | 本卡复用/差额验证                                                                       |
| ------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| Affix、Anchor/AnchorLink、Backtop                                                                | 对应 El 同名入口；props/events/slots/expose 原生，Anchor installer 仅更名                      | 同字节基础接受；native alias 所有 options 引用身份及实际包导入                          |
| Container/Aside/Main/Header/Footer、Row/Col                                                      | 原生容器/栅格；宽高与栅格配置保持，不视为控件四尺寸                                            | 同字节；正常包/声明映射，图形/布局尺寸例外                                              |
| Alert、Avatar/AvatarGroup、Badge、Breadcrumb/BreadcrumbItem、Calendar                            | 原生展示与相关事件/slots；Avatar 的 size 为图形语义                                            | 同字节；alias身份/公开类型/正常导入，Alert 状态在新SFC                                  |
| Button/ButtonGroup                                                                               | ElButton/ButtonGroup公开能力；type/图标/press等ASAM扩展；四尺寸；省略type=secondary            | UI-040同字节；Group/Form/Provider覆盖回退、键盘/禁用/加载、旧variant反类型              |
| Card/CardList、TaskCard                                                                          | Card原生与ASAM样式；CardList/TaskCard为组合，不能按El一一对应判漏                              | 同字节已验；实际公开根/深入口与声明                                                     |
| Carousel/CarouselItem、Collapse/CollapseItem/CollapseTransition                                  | 原生模型/事件/slots/expose及展示语义                                                           | 同字节；无新行为，alias身份/正常包/类型                                                 |
| CheckTag、CheckboxItem/CheckboxButton/CheckboxGroup、RadioItem/RadioButton/RadioGroup            | 逐项原生控件和组；四尺寸；对应ElCheckbox/ElRadio等公开能力                                     | UI-036同字节；新SFC用Checkbox组实际消费；声明/包映射                                    |
| Choice深入口的Radio/Checkbox/Switch                                                              | Radio/Checkbox聚合options与高级值协议；Switch原生基础；不把聚合协议混作原生单项                | 同字节；根符号与Choice深入口均展开，保留高级协议                                        |
| Choice中的RemoteRadio/DictRadio/RemoteCheckbox/DictCheckbox                                      | provider/数据协议属于高级入口，原生基础由单项/组承接                                           | DATA-009同字节有限继承；不重开数据卡或新增后台请求                                      |
| Autocomplete/RemoteAutocomplete、Mention、InputNumber、InputTag、InputOtp                        | 对应原生公开能力；Autocomplete原生fetchSuggestions优先，options等为高级分支；OTP保留前导零     | UI-035及既有固定接受；完整类型与包；本卡不改其算法或数据协议                            |
| Input/Password/Textarea                                                                          | ElInput能力按已确认职责拆分；Password显示密码能力，Textarea rows/autosize；普通Input排除两模式 | 新完整SFC运行三个入口；模型/事件/插槽/expose；TS拒绝旧普通Input用法                     |
| ColorPicker/ColorPickerPanel                                                                     | 原生公开颜色能力；单行密度与面板几何区分                                                       | 同字节；正常包/声明，无重写颜色算法                                                     |
| ConfigProvider、localeEn/localeZhCn                                                              | 原生配置选项/slot；ASAM保四尺寸上下文，底层仅桥接EP三档                                        | 031小回执继承；本卡正常包的新层级/嵌套/响应式/清空组合验证                              |
| DatePicker/DatePickerPanel、TimePicker/TimeSelect                                                | 原生模型/空值/格式/事件/slots/expose；不默认valueFormat，不归一上游清空                        | UI-039同字节；新SFC基础DatePicker实际消费，类型清单保留原生边界                         |
| DateTimePicker/DateTimeRangePicker                                                               | ASAM双端完整范围组合及endpoint slot/事件，非原生单面板range替身                                | UI-039同字节接受与限制继承；仅包/声明复核                                               |
| Hierarchy深入口的Cascader/TreeSelect/Transfer、CascaderPanel                                     | valueMode=native承接原生模型/公开能力；高级value/object/string及slots可辨识                    | UI-034/036同字节；真实根及Hierarchy深入口、声明清单                                     |
| Hierarchy中的RemoteCascader/DictCascader/RemoteTreeSelect/DictTreeSelect                         | 高级provider/options/source协议，不向基础包装复制上游算法                                      | DATA-009同字节继承；包/声明、责任区分                                                   |
| Select/SelectV2、Option/OptionGroup、RemoteSelect/DictSelect/RemoteSelectV2/DictSelectV2         | 原生分支与高级值/创建选项/数据分支分别由公开类型约束                                           | UI-036/DATA-009同字节；新SFC静态Select空/恢复；全部根/深公开清单                        |
| BaseForm/FormItem                                                                                | ElForm/FormItem公开props/events/slots/expose及四尺寸，原生验证交给EP                           | 既有基础接受；新正常SFC Form尺寸/禁用传递、类型                                         |
| Form、FormSection/FormGrid/FormActions                                                           | Schema/fields/布局组合为ASAM协议，BaseForm承接原生入口；不复制执行算法                         | 当前已验Form影响属于实际差额；本卡不改其产品，包声明与组合消费复核                      |
| DataTable、Table/TableColumn/TableV2、AutoResizer、DynamicSizeGrid/List、FixedSizeGrid/List      | DataTable为高级数据组合；Table/虚拟/测量公开接口委托原生；行高/测量不强改成单行40等            | UI-037及DATA同版继承；全部公开深入口/类型，alias setup/props等身份                      |
| Descriptions/DescriptionsItem、Divider、Empty、Result                                            | 原生展示/slot；Descriptions密度、Divider几何等保持各自语义                                     | UI-040同字节；正常包/声明/alias身份                                                     |
| Dialog/Drawer、Dropdown/DropdownItem/DropdownMenu、Popover/PopoverDirective、Popconfirm、Tooltip | 原生交互/模型/事件/slots/expose；Dialog图标与宽度、ASAM容器size为扩展                          | UI-038同字节；完整契约清单和正常包；容器size明确不归控件四尺寸                          |
| Overlay、Popper/PopperArrow/PopperContent/PopperTrigger、TrapFocus、ClickOutside                 | 公开辅助/指令与原生钩子、参数/返回对象分别核对                                                 | 同字节；实际JS/declaration及钩子身份，无冒充组件props                                   |
| Loading/LoadingDirective/LoadingService、vAsamLoading                                            | 聚合service/directive与原生生命周期；style/class桥接保留live返回实例                           | UI-038同字节；指令钩子身份，公开函数声明/包                                             |
| Message/MessageBox/Notification                                                                  | 原生服务签名、typed methods、关闭方法及返回对象；ASAM class和安装名                            | UI-038同字节；新消息服务真实展示→结束DOM清理                                            |
| Mousewheel、InfiniteScroll、vAsamRepeatClick                                                     | 原生指令生命周期/绑定/参数与ASAM注册名，不改私有调度算法                                       | UI-037同字节；公开钩子引用身份与真实包导入                                              |
| Menu/MenuItem/MenuItemGroup/SubMenu、PageHeader、Pagination                                      | 原生导航/分页公开能力及ASAM样式密度，模型/事件/slot保留                                        | 同字节；全部入口类型与正常包                                                            |
| Image/ImageViewer                                                                                | 原生完整props/events/slots/expose；不再有Bounded派生                                           | UI-034同字节；alias身份与源/正常包禁派生检查                                            |
| Progress、Rate、Scrollbar、Segmented、Skeleton/SkeletonItem、Slider                              | 原生行为；四尺寸只在适用密度上；Slider inputSize与size桥接独立                                 | 同字节；类型/正常包，无内部组合穷举                                                     |
| Space、Splitter/SplitterPanel、Statistic/Countdown、Step/Steps                                   | 原生公开能力；gap、分隔几何、统计字号等不强制控件高度                                          | 同字节；alias/声明/正常包                                                               |
| Tabs/TabPane、Tag/Text、Timeline/TimelineItem、Tour/TourStep、Tree/TreeV2、Upload、Watermark     | 原生公开能力与已确认ASAM扩展；Upload原生文件流与高级资源协议可辨                               | UI-038/040及基础接受同字节；完整正常入口/声明，原限制保持                               |
| Editor                                                                                           | ASAM富文本组合入口及其安全URL/文档帮助函数；不归EP原生组件                                     | 同字节；正常包帮助函数/声明映射；无本卡新内容上传或后端                                 |
| theme/control-size/data/full/resolver及其他根函数/类型                                           | ASAM tokens/四尺寸/provider/安装/自动导入/数据协议；非原生组件                                 | 正常JS根与非组件export完整清单，主题安全partial/默认不变/反例与类型；已有resolver不重造 |
| Pro configuration（ApplicationProvider/Permission/composables/key）                              | 031可选应用配置/主题/前端权限；与UI基础runtime职责分离                                         | 只继承已闭031固定小回执；本卡新正常SFC用应用桥，不新建宿主或权限业务                    |

## BASE 与共同Q逐项判定

最终 PASS/FAIL/不适用/未测及具体证据看 DEV-REPORT。以上每家族是适用范围映射，
不是仅因列在表内就行为 PASS。完整运行键清单保留外部，不作为大JSON提交。
原DEV修复Tour声明；root另串行补color.onSolid语义及plain前景specificity，原DEV通过正常包补验。
除tokens/index.d.ts外1408声明同字节；最终CSS差额外1721dist同字节，既有有效范围依此继承。
不撤销历史原生FAIL。Tour运行时仍按raw vnode委托上游，未引入执行算法；主题差异与迁移见MIGRATION。

| 要求                | 本卡适用性与对应证据                                                                           |
| ------------------- | ---------------------------------------------------------------------------------------------- |
| BASE-01 / Q-01      | 正常入口/公开声明完整映射、原生引用身份、职责拆分、同字节有效接受与新模型/事件/slot/expose差额 |
| BASE-02 / Q-04/Q-06 | 四尺寸与几何例外、配置层级、partial/null/light/dark、可扩展CSS、真实截图                       |
| BASE-03 / Q-08      | UI原生/ASAM扩展/Pro协议区分；同候选包、完整TS/JS SFC、AGENT方法                                |
| BASE-04 / Q-09      | 本卡无新破坏项；历史差异逐项来源/理由/替代/迁移/正反类型与消费                                 |
| Q-02                | 适用加载/禁用/只读/空错恢复与卸载恢复；应用权限继承031，不虚构基础组件权限功能                 |
| Q-03                | 本卡本地模型/事件/点击操作一致；新请求时序/提交接口不适用，既有数据协议不重开                  |
| Q-05                | 可理解label、键盘激活/焦点/expose、禁用阻断；读屏与其他浏览器明确未测                          |
| Q-07                | 预先定义50次主题切换预算及完整成本；服务DOM、应用卸载恢复、runner资源finally关闭               |
| Q-10                | 不新增业务权限/后端/内容写入；UI权限不代后端，原内容处理协议保持；theme污染反例                |
| Q-11                | TS/JS普通Vue/Chrome结果可核；跨宿主归052，本卡其他浏览器/宿主未测                              |
| Q-12                | 29输入原字节与dirty/作用域检查；独立consumer/node_modules，SFC恢复哈希；无无关修改             |
