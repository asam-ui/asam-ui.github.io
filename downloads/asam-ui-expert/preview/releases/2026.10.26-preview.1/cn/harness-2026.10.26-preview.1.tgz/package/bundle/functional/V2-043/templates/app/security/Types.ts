export type SecurityId = string | number;
export interface SecurityScope {
	tenant: SecurityId | null;
	organization: SecurityId | null;
}
export interface SecurityContext extends SecurityScope {
	label: string;
}
/** Display-safe normalized backend result. Never include credentials or raw DTOs. */
export interface SecuritySubject {
	id: SecurityId;
	name: string;
	roles: readonly string[];
	permissions: readonly string[];
	scope: SecurityScope;
	contexts: readonly SecurityContext[];
	expiresAt: number;
	readOnly?: boolean;
}
export interface SecurityRequest {
	signal: AbortSignal;
	/** False immediately after supersession, including synchronous abort/state/listener reentry.
	 * Host must also use this before committing credential/storage side effects. */
	isCurrent: () => boolean;
}
export interface SecurityAdapter<Credentials> {
	login: (credentials: Credentials, request: SecurityRequest) => Promise<SecuritySubject>;
	restore: (request: SecurityRequest) => Promise<SecuritySubject | null>;
	refresh: (subject: SecuritySubject, request: SecurityRequest) => Promise<SecuritySubject>;
	switchContext: (
		subject: SecuritySubject,
		scope: SecurityScope,
		request: SecurityRequest
	) => Promise<SecuritySubject>;
	logout: (request: SecurityRequest) => Promise<void>;
}
export type SecurityStatus =
	| 'anonymous'
	| 'restoring'
	| 'authenticating'
	| 'refreshing'
	| 'switching'
	| 'authenticated'
	| 'expired'
	| 'error'
	| 'logging-out'
	| 'disposed';
export interface SecurityState {
	status: SecurityStatus;
	subject: SecuritySubject | null;
	/** Fixed local message, never the adapter's exception text. */
	error: string;
	epoch: number;
}
export interface SecurityRule {
	permission?: string;
	role?: string;
	write?: boolean;
}
