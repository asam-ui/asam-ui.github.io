<template>
	<div ref="shell">
		<AsamAdminLayout :size="size">
			<template #header><slot name="header">应用导航</slot></template>
			<template #sidebar>
				<AsamMenu
					:default-active="activeRoute"
					background-color="var(--asam-color-surface)"
					text-color="var(--asam-color-text-primary)"
					active-text-color="var(--asam-color-primary)"
					@select="selectMenu"
				>
					<NavigationMenuItems :items="controller.visibleMenu.value" />
				</AsamMenu>
			</template>
			<div class="navigation-tabs" role="tablist" aria-label="打开的页面">
				<div v-for="tab in controller.tabs.value" :key="tab.id" class="navigation-tab">
					<button
						type="button"
						role="tab"
						:aria-selected="tab.id === controller.active.value"
						:tabindex="
							tab.id === (controller.active.value || controller.tabs.value[0]?.id)
								? 0
								: -1
						"
						:draggable="!tab.pinned"
						:data-tab="tab.id"
						@dragstart="startDrag($event, tab.id)"
						@dragend="dragging = ''"
						@dragover.prevent
						@drop.prevent="drop(tab.id)"
						@keydown="keyMove($event, tab.id)"
						@click="controller.navigate(tab.fullPath)"
					>
						{{ tab.pinned ? '固定：' : '' }}{{ tab.title }}
					</button>
					<button
						v-if="!tab.pinned"
						type="button"
						:aria-label="`关闭 ${tab.title}`"
						@click="close(tab.id)"
					>
						×
					</button>
				</div>
			</div>
			<div class="navigation-actions">
				<button type="button" @click="controller.refresh()">刷新当前页</button>
				<button type="button" @click="controller.closeOthers()">关闭其他</button>
				<button type="button" @click="controller.closeAll()">关闭全部</button>
				<button
					type="button"
					:disabled="controller.loading.value"
					@click="controller.reload()"
				>
					更新菜单
				</button>
			</div>
			<p role="status" aria-live="polite">
				{{
					controller.loading.value
						? '正在加载菜单'
						: controller.error.value || announcement
				}}
			</p>
			<AsamPageContainer :title="activeTitle">
				<NavigationPage
					v-for="page in controller.pages.value"
					:key="`${page.cacheKey}:${page.epoch}`"
					:controller="controller"
					:tab="page"
					:active="page.id === controller.active.value"
				/>
				<RouterView v-if="!controller.active.value" />
			</AsamPageContainer>
		</AsamAdminLayout>
	</div>
</template>
<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref } from 'vue';
import type { VNode } from 'vue';
import { RouterView } from 'vue-router';
import { AsamAdminLayout, AsamPageContainer } from '@asam-ui/pro';
import { AsamMenu } from '@asam-ui/ui';
import type { AsamControlSize } from '@asam-ui/ui';
import type { NavigationController } from './Navigation.js';
import NavigationPage from './NavigationPage.vue';
import NavigationMenuItems from './NavigationMenuItems.vue';
const props = defineProps<{ controller: NavigationController; size?: AsamControlSize }>();
defineSlots<{ header?: () => VNode[] }>();
const dragging = ref('');
const shell = ref<HTMLElement>();
const announcement = ref('');
const activeRoute = computed(() =>
	JSON.stringify([
		'item',
		props.controller.tabs.value.find((tab) => tab.id === props.controller.active.value)
			?.routeId ?? ''
	])
);
const activeTitle = computed(
	() =>
		props.controller.tabs.value.find((tab) => tab.id === props.controller.active.value)
			?.title ?? '页面'
);
function selectMenu(id: string) {
	const item = props.controller.menu.value.find(
		(entry) => JSON.stringify(['item', entry.id]) === id
	);
	if (item) void props.controller.navigate(item.location ?? item.path);
}
function startDrag(event: DragEvent, id: string) {
	dragging.value = id;
	event.dataTransfer?.setData('text/plain', id);
}
function drop(id: string) {
	if (dragging.value) props.controller.move(dragging.value, id);
	dragging.value = '';
	announcement.value = '页签顺序已更新';
}
async function keyMove(event: KeyboardEvent, id: string) {
	if (!event.altKey && ['ArrowLeft', 'ArrowRight', 'Home', 'End', 'Delete'].includes(event.key)) {
		event.preventDefault();
		if (event.key === 'Delete') {
			await close(id);
			return;
		}
		const tabs = props.controller.tabs.value;
		const index = tabs.findIndex((tab) => tab.id === id);
		const targetIndex =
			event.key === 'Home'
				? 0
				: event.key === 'End'
					? tabs.length - 1
					: (index + (event.key === 'ArrowLeft' ? -1 : 1) + tabs.length) % tabs.length;
		const target = tabs[targetIndex];
		if (target && (await props.controller.navigate(target.fullPath))) {
			await nextTick();
			focusActive();
		}
		return;
	}
	if (!event.altKey || !['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
	event.preventDefault();
	const movable = props.controller.tabs.value.filter((tab) => !tab.pinned);
	const index = movable.findIndex((tab) => tab.id === id);
	const target = movable[index + (event.key === 'ArrowLeft' ? -1 : 1)];
	if (target) {
		props.controller.move(id, target.id);
		announcement.value = '页签顺序已更新';
	}
}
async function close(id: string) {
	if (await props.controller.close([id])) {
		announcement.value = '页签已关闭';
		await nextTick();
		focusActive();
	}
}
// This shell owns its module, never the host router.
onBeforeUnmount(() => props.controller.dispose());
function focusActive() {
	const buttons = shell.value?.querySelectorAll<HTMLButtonElement>('[data-tab]') ?? [];
	[...buttons].find((button) => button.dataset.tab === props.controller.active.value)?.focus();
}
defineExpose({
	focusActive: async () => {
		await nextTick();
		focusActive();
	}
});
</script>
<style scoped>
.navigation-tabs {
	display: flex;
	gap: var(--asam-space-2, 8px);
	overflow-x: auto;
	padding: 8px;
}
.navigation-tab {
	display: flex;
	flex: 0 0 auto;
}
.navigation-actions {
	display: flex;
	flex-wrap: wrap;
	gap: 8px;
}
button {
	color: inherit;
	background: var(--asam-color-bg, transparent);
	border: 1px solid var(--el-border-color);
	padding: 8px;
	cursor: pointer;
}
button[aria-selected='true'] {
	border-color: var(--el-color-primary);
}
button:focus-visible {
	outline: 2px solid var(--el-color-primary);
	outline-offset: 2px;
}
</style>
