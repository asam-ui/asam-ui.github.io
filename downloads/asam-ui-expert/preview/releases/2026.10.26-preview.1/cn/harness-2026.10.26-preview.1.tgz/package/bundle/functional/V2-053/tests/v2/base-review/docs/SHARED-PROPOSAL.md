# BASE-02 暗色实心按钮前景的最小共享 proposal

最终：两个共享差额均已由root单写并精确承接。d5c81504的plain前景specificity后继，在正常
新CSS包上settled hover/active及原背景/静态文字职责定点通过。DEV-REPORT为当前结论；
以下保留最初提案来路，不代表仍待实施，也不表示独立QA/ACC完成。

状态：root已在唯一共享源6623d292817fa3dc1cf1f6c7c5d5593568c6721a实现并授权原DEV精确择取，
本分支对应43352fe9eefbd8c06820ddb7322864c065aa7ef4。实际仅tokens/styles及包README；
正常后继验证见DEV-REPORT，root源码语义检查不冒正常包/浏览器/独立QA通过。以下原proposal
保留问题与建议来路；root实核第六实心类型是gradient，accent为tonal且未修改，并同因修复
plain的hover/active前景。原文的accent建议不能覆盖实际提交范围。

`AsamApplicationProvider` 合法 dark 配置将 `color.surface` 设为 `#141414`。
`packages/ui/src/styles/index.css` 六个实心按钮类型又以 surface 作为文字颜色，导致 primary、
success、warning、danger、info、accent 的 foreground 跟着页面背景变暗。正常消费切品牌
primary=`#7a315c` 再切 dark，primary 实测前景从 `rgb(255,255,255)` 变为 `rgb(20,20,20)`。
这不是要求 wrapper 接管 EP 执行算法。

实据：`delta-tour/solid-foreground-1792418032353.json` 的最终 FAIL，
`solid-foreground-settled-before.log` 与相应 PNG。第一次立即采样的 PASS 发生在 CSS transition
初帧，保留但不作为有效结论。最终测量等 dark 状态和按钮有限 transition 结束，未扣除成本。
普通 Browser 自动交互 PASS 与最终视觉/foreground FAIL 分开，不互相替代。

建议只改两份共享源：

1. `packages/ui/src/tokens/index.ts`：在 `AsamThemeTokens.color` 加可选 `onSolid?: string`，
   `defaultAsamTheme.color.onSolid` 取已有 `foundation.color.white`。可选字段保持旧完整
   theme 对象类型兼容；createAsamTheme 继续用现有合并/安全策略。
2. `packages/ui/src/styles/index.css`：仅六个实心类型的
   `--asam-button-ink: var(--asam-color-surface)` 改为
   `--asam-button-ink: var(--asam-color-on-solid, var(--el-color-white))`。
   兼容直接传旧完整 theme 的消费者；plain/text/link 的现有覆盖规则保持。

不新增 index 导出、依赖、锁、补丁，不改公开版本。031 合法 theme merge 会自然保留默认
onSolid，宿主可显式定制。root 可选择已有更合适的语义前景 token，但不能继续将页面 surface
作为实心前景。以上为原proposal，实际实现范围与正常包结果只看顶部及DEV-REPORT。

root 给出精确单笔共享候选后，原DEV在自己的分支消费其精确差异，保留之前的失败包和截图，
正常重建/打包 UI，仅更新本角色消费输入并补前景/light-dark/显式覆盖/兼容回退及受影响类型
验证，最后固定完整候选供独立 OCR→QA→ACC。无需重新创建角色或恢复原031归档空间。
