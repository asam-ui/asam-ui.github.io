import { shallowRef, watch } from 'vue';
import type { Component } from 'vue';
import type { Router } from 'vue-router';
import { createNavigation } from '../navigation/Navigation.js';
import type { NavigationController } from '../navigation/Navigation.js';
import type { NavigationItem } from '../navigation/Types.js';
import type { SecurityController } from './Security.js';
import { safeReturnPath, scopeKey } from './Security.js';
import type { SecurityRule } from './Types.js';

/** Public paths are explicit; all other paths require a rule, including direct history access. */
export function createSecurityNavigation(options: {
	security: Pick<SecurityController, 'state' | 'check' | 'onInvalidate'>;
	router: Router;
	components: Readonly<Record<string, Component>>;
	items: readonly NavigationItem[];
	rules: Readonly<Record<string, SecurityRule>>;
	publicPaths: readonly string[];
	safePage: string;
}) {
	const { security, router } = options;
	if (!options.publicPaths.includes(options.safePage)) throw new Error('安全页必须公开');
	const navigation = shallowRef<NavigationController | null>(null);
	let returnPath = '/safe';
	let generation = 0;
	let disposed = false;
	function clear() {
		generation++;
		navigation.value?.dispose();
		navigation.value = null;
	}
	const removeInvalidation = security.onInvalidate(() => {
		clear();
		if (
			['anonymous', 'expired', 'logging-out', 'disposed'].includes(
				security.state.value.status
			)
		)
			returnPath = options.safePage;
		void router.replace(options.safePage);
	});
	const removeGuard = router.beforeEach((to) => {
		if (options.publicPaths.includes(to.path)) return true;
		const rule = options.rules[to.path];
		if (rule && security.check(rule) === 'allowed') return true;
		if (['anonymous', 'restoring', 'authenticating'].includes(security.state.value.status))
			returnPath = safeReturnPath(to.fullPath, options.safePage);
		return options.safePage;
	});
	const stop = watch(
		() => security.state.value,
		async (state) => {
			if (state.status !== 'authenticated' || !state.subject || disposed) return;
			clear();
			const token = generation;
			const next = createNavigation({
				router,
				components: options.components,
				fallback: options.safePage,
				scope: scopeKey(state.subject),
				load: async () => options.items,
				visible: (item) =>
					!!options.rules[item.path] &&
					security.check(options.rules[item.path]!) === 'allowed'
			});
			navigation.value = next;
			if ((await next.reload()) && !disposed && token === generation) {
				const target = safeReturnPath(returnPath, options.safePage);
				returnPath = options.safePage;
				await next.navigate(target, true);
			}
		},
		{ flush: 'sync', immediate: true }
	);
	return {
		navigation,
		/** Logout/expiry intentionally forget any previous protected destination. */
		forgetReturn: () => {
			returnPath = options.safePage;
		},
		resume: (path: unknown) => {
			returnPath = safeReturnPath(path, options.safePage);
		},
		dispose: () => {
			disposed = true;
			stop();
			removeGuard();
			removeInvalidation();
			clear();
		}
	};
}
