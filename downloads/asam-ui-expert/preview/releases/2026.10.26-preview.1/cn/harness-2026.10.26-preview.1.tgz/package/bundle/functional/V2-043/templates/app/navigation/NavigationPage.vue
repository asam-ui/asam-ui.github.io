<template>
	<RouterView v-slot="{ Component }" :route="route">
		<KeepAlive :max="1">
			<component :is="Component" v-if="active" :key="tab.cacheKey" />
		</KeepAlive>
	</RouterView>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import { RouterView } from 'vue-router';
import type { NavigationTab } from './Types.js';
import type { NavigationController } from './Navigation.js';
const props = defineProps<{
	controller: NavigationController;
	tab: NavigationTab;
	active: boolean;
}>();
const route = computed(() => {
	const resolved = props.controller.router.resolve(props.tab.fullPath);
	return { ...resolved, name: resolved.name ?? undefined };
});
</script>
