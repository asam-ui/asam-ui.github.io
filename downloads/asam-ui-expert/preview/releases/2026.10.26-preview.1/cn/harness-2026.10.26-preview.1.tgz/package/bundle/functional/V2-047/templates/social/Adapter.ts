import type { AsamListRequest } from '@asam-ui/pro';
import type {
	SocialComment,
	SocialId,
	SocialOperation,
	SocialOutcome,
	SocialPage,
	SocialPost,
	SocialRequest,
	SocialService
} from './Types.js';

/** Replace transport and both explicit DTO mappings; no package-source alias or service singleton. */
export function adaptSocial<P, C>(
	transport: {
		feed: (query: AsamListRequest, request: SocialRequest) => Promise<SocialPage<P>>;
		comments: (
			id: SocialId,
			page: number,
			size: number,
			request: SocialRequest
		) => Promise<SocialPage<C>>;
		write: (
			op: SocialOperation,
			request: SocialRequest
		) => Promise<
			Exclude<SocialOutcome, { status: 'success' }> | { status: 'success'; post: P }
		>;
		resolve: (
			id: string,
			request: SocialRequest
		) => Promise<
			Exclude<SocialOutcome, { status: 'success' }> | { status: 'success'; post: P }
		>;
	},
	mapping: { post: (dto: P) => SocialPost; comment: (dto: C) => SocialComment }
): SocialService {
	const result = (
		value: Exclude<SocialOutcome, { status: 'success' }> | { status: 'success'; post: P }
	): SocialOutcome =>
		value.status === 'success' ? { status: 'success', post: mapping.post(value.post) } : value;
	return {
		feed: async (q, r) => {
			const p = await transport.feed(q, r);
			return { total: p.total, list: p.list.map(mapping.post) };
		},
		comments: async (id, n, s, r) => {
			const p = await transport.comments(id, n, s, r);
			return { total: p.total, list: p.list.map(mapping.comment) };
		},
		write: async (op, r) => result(await transport.write(op, r)),
		resolve: async (id, r) => result(await transport.resolve(id, r))
	};
}
