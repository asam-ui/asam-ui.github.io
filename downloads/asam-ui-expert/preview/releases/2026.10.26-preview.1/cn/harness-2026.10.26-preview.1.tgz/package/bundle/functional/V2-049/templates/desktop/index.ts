export * from './Types.js';
export { createDesktop, clampRect, validateLayout } from './Desktop.js';
export type { DesktopController } from './Desktop.js';
export { default as MinimalDesktop } from './MinimalDesktop.vue';
export { default as BrandDesktop } from './BrandDesktop.vue';
export { default as TechDesktop } from './TechDesktop.vue';
