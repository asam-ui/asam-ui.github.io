import type { InjectionKey, Ref } from 'vue';
import type { AsamControlSize, AsamDataRuntime } from '@asam-ui/ui';
import type {
	AsamCrudServices,
	AsamWriteCoordinator,
	AsamTableOperationCoordinator
} from '@asam-ui/pro';
import type { SecurityController } from '../app/security/Security.js';

export type Id = string | number;
export type Entity = 'users' | 'roles' | 'menus';
export interface Query {
	keyword: string;
	status: string;
	role: Id | null;
	context: string;
}
export interface UserEdit {
	name: string;
	account: string;
	status: string;
	roleIds: Id[];
	context: string;
	note: string;
	version: number;
}
export interface UserRow extends UserEdit {
	id: Id;
}
export interface RoleEdit {
	name: string;
	code: string;
	enabled: string;
	members: string;
	note: string;
	context: string;
	version: number;
}
export interface RoleRow extends RoleEdit {
	id: Id;
}
export interface MenuEdit {
	parentId: Id | null;
	title: string;
	kind: string;
	permissionCode: string;
	enabled: string;
	grantable: string;
	version: number;
}
export interface MenuRow extends MenuEdit {
	id: Id;
}
export interface RoleOption {
	id: Id;
	name: string;
	enabled: boolean;
}
export interface GrantNode {
	id: Id;
	parentId: Id | null;
	title: string;
	kind: string;
	permissionCode: string;
	enabled: boolean;
	grantable: boolean;
	version: number;
}
export interface GrantSnapshot {
	subject: Id;
	scope: string;
	version: string;
	nodes: readonly GrantNode[];
	direct: readonly Id[];
	unavailable: 'preserve' | 'reject';
}
export interface Request {
	signal: AbortSignal;
	isCurrent(): boolean;
	scope: string;
}
export interface GrantOperation {
	readonly operationId: string;
	readonly subject: Id;
	readonly scope: string;
	readonly serviceVersion: string;
	readonly version: string;
	readonly direct: readonly Id[];
}
export type GrantResult =
	| { status: 'success'; version: string }
	| { status: 'failure'; reason: 'conflict' | 'validation' | 'denied' }
	| { status: 'unknown' };
export interface GrantReceipt {
	readonly operation: GrantOperation;
	status: 'confirming' | 'sending' | 'success' | 'failure' | 'unknown';
	result?: GrantResult;
}
export interface GrantService {
	load(subject: Id, request: Request): Promise<GrantSnapshot>;
	save(operation: GrantOperation, request: Request): Promise<GrantResult>;
	verify(operation: GrantOperation, request: Request): Promise<GrantResult>;
}
export interface EntityServices<Row extends object, Edit extends object> {
	crud: AsamCrudServices<Row, Query, Edit, Id>;
}
export interface AdministrationServices {
	version: string;
	users: EntityServices<UserRow, UserEdit>;
	roles: EntityServices<RoleRow, RoleEdit>;
	menus: EntityServices<MenuRow, MenuEdit>;
	roleOptions(request: Request): Promise<readonly RoleOption[]>;
	menuNodes(request: Request): Promise<readonly GrantNode[]>;
	grants: GrantService;
}
export interface AdministrationHost {
	security: Pick<SecurityController, 'state' | 'check' | 'permission' | 'onInvalidate'>;
	runtime: AsamDataRuntime;
	writes: AsamWriteCoordinator;
	operations: AsamTableOperationCoordinator;
	/** Host owned, retained across page removal and security invalidation. */
	receipts: Map<string, GrantReceipt>;
	services: Ref<AdministrationServices>;
	size: Ref<AsamControlSize>;
	confirm(message: string): Promise<boolean>;
	unknownRoles: 'preserve' | 'reject';
	leaves?: Set<() => Promise<boolean>>;
}
export const administrationKey: InjectionKey<AdministrationHost> = Symbol('asam-administration');
