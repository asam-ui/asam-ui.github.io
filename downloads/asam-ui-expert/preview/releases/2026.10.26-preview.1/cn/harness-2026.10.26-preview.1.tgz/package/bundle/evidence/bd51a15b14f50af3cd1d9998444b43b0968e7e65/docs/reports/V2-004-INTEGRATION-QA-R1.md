# V2-004 有限集成回归 QA-R1

2026-10-16；结论 **PASS**，仅适用于固定集成 `1071392df1ea02dc9d25db7d6d2af8f147173008`。原独立QA `79739accea83868733852c72e1bb7437e689a332`、ACC `bb323bd51294ee1f2552a4df0da00c10bac24a28` 和全部历史归档/红件保持，不追开发主控后继、不等003、不扩大发布或规划。

## 身份与固定映射

原QA `01a14315-6bb0-7842-abd1-1bf0012d2fbd`，原独立E:/worktree-tmp/b4c5/asam-ui。实际本回合 `01a143a7-cf48-7b92-83a0-3c89b013d55a` 为gpt-6.1-sol/high、danger-full-access/never；成功Git、文件、构建、真实浏览器工具已核。Node22.19.0/pnpm11.9.0、D:/.pnpm-store/v11及同根cache/state、E NTFS实核；进程加载主仓E入口与D pnpm入口，角色TEMP仍在E，profile独占INTEGRATION107。无所属在跑旧浏览器，未操作WorkBuddy、其他任务或全局配置。

- Pro整树 `d0de86ad8d67a72ed81b2b426b3d810bc8c23374`，107与已验4240逐Git对象相等。
- UI整树 `39342e6e80482b0dffa60e10483d59159f2c52aa`、字段树 `95976dc461152599433a422088c920ee6b8b8439`，107与已验1956f2d0e689ec5f2f4e8ce3db0cd91af12b844d相等。
- source-map.json的23路径分别重算107 blob并核来源与集成值，errors=[]。consumer额外差异逐行审，仅editor/detail目录、5公开export及真正不存在的负例名；保留never、pnpm入口、UI精确复用与隔离防护。
- OCR范围bbd8adf5→107，实际24路径、22可审/22 reviewed、0 skipped，2文档人工核；原21可审路径源码覆盖按精确映射继承，consumer增量亲审。预览/规则/清单外置，不借工具零退出代替审查。

## 新归档与安装

外置根 `E:/DevCache/artifacts/asam-ui/v2-004/qa-r1/integration-107`。先保全本QA旧consumer非依赖文件（含manifest/lock/fixture）和旧UI producer/dist，再在本QA原安装环境串行更新，不共享他人node_modules。原QA/ACC归档与索引未改。

| 对象                     | 本次真实SHA256与对应关系                                                                                                               |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| 1956固定UI归档           | `2fbc5fb5e240d0f737e24f72c8ea65f4f839022374f08f48bdc6003c0090ab12`；核源码树相等后解入自身producer/dist，并按原归档安装，未重建885声明 |
| 本QA从107构建并pack的Pro | `940c332d953e06972971b0e9554ca29c140f279d3ff002213dea45be24bbb270`；14命令驱动真实完成，Pro build实际cwd为packages/pro                 |
| 原004 UI（仅历史比较）   | `541943da405deb00da10c69cba5aed242fec91d461b747ed3ca5305293b1b676`；不冒本次新UI                                                       |

Pro新归档20文件与已验Pro全部内容相等，归档SHA也相等；不是不同source包串hash。新旧UI归档集合相同，仅dist/style.css及_upstream/provenance.json不同，所有JS/声明逐字节相等。新UI provenance准确记录1956；本QA没有改元数据冒107生产者。

`full-pairing.json`：**UI全部1726归档文件→安装相等，其中1722 dist→自身producer相等；Pro全部20归档文件→安装相等，其中17 dist→自身producer相等**，包含全部JS/声明/CSS；此次UI provenance也原字节相等，没有放宽元数据字段。根锁仍为5efa11b5c7253f021b081851046f6e1f853a8db1f7617d394bae50e8993c81d8。

## 有限实际检查

| 检查                  | 独立结果                                                                                                                                                                  |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 107 consumer与Pro工程 | Pro类型/构建、源码消费类型/生产构建、原始pack、offline安装、真实包类型/生产构建通过                                                                                       |
| 公共出口与保护负例    | 15 runtime exports、CSS解析/内容、private路径保护通过；不存在runtime导出、TS2305、私有路径TS2307、缺声明、缺peer均按预期失败，finally恢复已破坏的本QA安装文件后全配对通过 |
| 真实FormDialog        | 新UI+本次真实Pro包上原生能力精确key、折叠展开/焦点/零写入及F01旧callback隔离、保值/dirty和显式重验两场景通过                                                              |
| 公开原生方法          | Promise、异步callback、validateField单值/数组/path、局部/全clear、恢复hidden合法校验及folded-v-hidden四组通过；严格fixture类型与生产构建通过                              |
| input-count组合       | input/textarea及count-inner实际计算背景均透明；对875字符unknown场景还核原生编辑输入的计数背景透明                                                                         |
| 长unknown窄暗容器     | 320视口、暗tokens，875字符连续诊断换行，内容client=scroll=256，名称disabled、保存入口为0；真实截图亲看无横撑，核实/关闭入口可见                                           |

用于长unknown/计数的本QA普通SFC补配方仅增加公开componentProps及诊断长度，未修改产品。Form F01 driver沿用同一原断言，外置导航/资产缓存仅控制就绪，不含性能；native方法driver仅增加计数背景断言。自身新profile的Chrome实际155.0.8059.82。

原41核心、完整矩阵及性能按Pro树等值、UI JS/声明等值和本次CSS影响范围继承，不重新全组采样。无真实新产品失败需要扩大范围；没有将UI CSS变化当作旧004 UI完全相同，也没有重开003或其他卡。

## 驱动与异常界限

consumer原驱动保留所有断言；外置适配明确固定fixture/consumer/output路径，UI pack步骤改为已核精确原归档复用，显式保持本QA原安装的hoisted/symlink=false/global-virtual-store=false。原文件与外置driver差异保存在driver-path.diff。receipt内“DEV自测”是原驱动固定文字，本次实际执行者与QA结论由本报告说明，不改写原件冒另一角色。

初期准备尚未完成时缺UI产物门禁、随后复用安装选项未对齐的NO_TTY中止均保留原日志；准备完成及显式安装选项对齐后，14命令驱动完整真实通过，没有禁用断言或确认后盲删目录。配对Python初版读取UTF8 JSON时受Windows默认GBK影响，明确UTF8后全部断言通过，非产品缺陷。

所有自身浏览器/HTTP由finally关闭，进程核无所属残留。只提交本报告，截图/依赖/包/JSON均在外部；保留工作树和有效原件至主控确认本卡集成/回归/保全收尾，不自归档、发布、推送、部署或改主台账。

本次外置索引evidence-index.json SHA256：`e6469917af6ba26f2af0b84e93e8f838bc554001c14d45bb727e0205394fb2f1`。报告格式、diff及repository staged检查通过。
