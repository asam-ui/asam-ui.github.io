# 桌面布局前端示例 · V2-049

Vue 3.5.34 / Vue Router 4.6.3 / ASAM UI 与 Pro 0.1.0-alpha.1 / Element Plus 2.14.7。浏览器内的窗口式工作台，含快捷入口、任务栏及三个可替换面板。完整可编辑 SFC 为 MinimalDesktop、BrandDesktop、TechDesktop，共用 DesktopStage 和 typed 控制器。没有 OS 桌面、系统快捷键、Electron/Tauri、在线账号或真实 CL 业务。

将本目录与同版 `templates/app/preferences` 一起复制到应用的 templates 下；完整示例另消费同版 `templates/app/navigation`。正常安装 UI/Pro，依次导入 EP、UI、Pro CSS，配置 Vue SFC 插件。不要 alias 到作者包源码。`examples/main.ts`、`examples/App.vue`、`examples/config.ts` 是完整应用入口与普通修改点。`tests/v2/desktop/prepare.mjs` 生成独立普通 consumer 并绑定已验完整包；pnpm 配置需保持 verifyDepsBeforeRun=error。

先阅读 [API](./API.md)、[设计参考](./DESIGN.md) 与 [Agent 方法](./AGENT.md)。能力与版本机器入口为 [capability.json](./capability.json)。页面使用已验029的 AsamPageContainer 和同版 Provider/四尺寸；示例导航只调用032的 createNavigation/router，面板 id 是本地 allowlist，不变成 URL、import、HTML 或权限凭据。034的 createBusinessCache/Scope/StorageAdapter 是唯一持久协议；Preferences 只处理 locale/theme。

窗口打开/激活会移到最上层；最小化和窄屏切换仅隐藏内容，移动、缩放、最大化、恢复不改变实例 key。关闭、权限撤回和整个页面卸载才释放内容；业务异步请求由注入内容的宿主取消，示例面板在 beforeUnmount 中终止 timer/AbortController。DesktopStage 只拥有 ResizeObserver、三个 window 监听与临时 pointer capture，卸载逐项释放；控制器由宿主创建并 dispose，模板切换或嵌套宿主不能私自销毁共享控制器。

容器宽度严格小于720px进入单面板。坐标是工作区内 CSS px；桌面逻辑 rect 与当前视口投影分开，窄屏、容器缩小或最大化不把宽屏布局覆盖。允许坐标有限且绝对值不超过100000；恢复时每次显示 clamp，最小尺寸280×180，视口更小时缩至视口本身。窗口层级来自数组顺序，不存无限增长的 z-index。最多32个本地面板。关闭后重开是新的内容实例。

移动标题手柄和右下缩放手柄均支持方向键，每次8px，Shift为32px；Enter/Space操作快捷入口、任务栏和窗口动作。Escape取消未提交 pointer 预览；pointercancel/lostcapture、窗口失焦、嵌套滚动、容器 resize、身份/策略/权限变化同样取消。触控手柄 touch-action:none，其余内容保留自然滚动。捕获中的指针移出窗口仍在对应手柄处理，最终up提交，cancel/失焦回退。布局键盘事件只在本地手柄处理，不拦截系统键或业务输入。

只读/禁用阻止窗口操作、偏好按钮和保存；注入内容获得 readonly，宿主须落实自己的业务控件权限。权限撤回立即移除窗口和内容，恢复也按当前 allowlist 过滤；隐藏入口不能替代后端鉴权。focus-change 在下一次 Vue 更新后只在焦点不在目标窗口内时回落到标题手柄；没有窗口时回到首个可用入口，避免抢走输入框焦点。

布局只包含 version/windows/active，窗口仅 id/rect/minimized/maximized。业务正文、草稿、凭据、权限结果均不保存。namespace 是 app + `/desktop-layout`，owner/scope原类型保留数字0、字符串0及null；TTL默认30天，可通过now精确测试。恢复非法/旧版/未来版/过期或不可用存储时使用默认布局；坏/未来记录须显式重置后才可写，绝不自动clear其他键。多实例同键采用读前比对：检测到外部变化先conflict，由用户恢复或重置。localStorage没有跨进程原子CAS，不声称能解决同时写入到单次setItem之间的竞争。

save/restore可传宿主异步准备回调。每次本地修改、策略/权限/身份变化与dispose使旧代失效；迟到结果返回stale，不写新身份。getItem等宿主回调可能重入，控制器在读后与写前再次核代。宿主回调不得自己写布局键或在setItem内部制造业务副作用；同步StorageAdapter仍遵循034的公开边界。

save的末次读取、reset的removeItem与末次getItem返回后核对代号、context与销毁状态，再发布操作状态或恢复默认；旧完成stale保留最新编辑。存储基线按cache实例另行维护：自身成功写入的准确字节或删除后的null是该context已知持久状态，不因同scope编辑导致epoch变化而丢失。因此回调内新关闭的面板可继续直接save，不需restore丢弃编辑；换context或dispose不会把旧context的基线带过去。

setContext为新scope建立读取基线时允许保留同context的新编辑，但基线版本标记阻止较早读值覆盖回调内reset等已完成的持久操作。save/reset末次读取不会接受外部新字节作为自身基线，外部写入仍conflict。getItem/removeItem可重入的既有边界保持；同步StorageAdapter仍不承诺跨进程原子CAS。

此前没有桌面公开 API，新增本地源码模板无旧桌面迁移。替换自有工作台时把已有业务请求/鉴权留在host，只将布局字段映射到DesktopPanel与slot；不要将 Preferences 扩成任意字段、把普通菜单URL当面板资源或将旧不带owner的布局直接迁入。升级先diff Types/Desktop/Stage，再验证坏存储、旧schema、权限和scope竞态。停用Agent后普通Vue项目仍独立运行。

DEV实测、首失败、未测与后续QA/ACC状态只以 [DELIVERY](./DELIVERY.md) 和外置原件为准，本文不代替验收。
