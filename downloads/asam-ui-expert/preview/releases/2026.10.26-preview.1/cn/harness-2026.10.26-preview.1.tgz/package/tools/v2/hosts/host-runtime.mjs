import { existsSync, realpathSync } from 'node:fs';
import { dirname, resolve, relative, isAbsolute, sep } from 'node:path';

// Resolve the existing prefix too: a missing cache below a linked directory must
// not permit a foreign application's private runtime to be created or reused.
function canonical(path) {
	let current = resolve(path);
	const tail = [];
	while (!existsSync(current) && current !== dirname(current)) {
		tail.unshift(current.slice(dirname(current).length + 1));
		current = dirname(current);
	}
	return resolve(realpathSync(current), ...tail);
}
export function foreignDependency(path, host, env = process.env) {
	if (!path || !isAbsolute(path)) return false;
	const value = canonical(path).replaceAll('\\', '/').toLowerCase();
	const other = host === 'codex' ? 'workbuddy' : 'codex';
	if (new RegExp(`/(?:\\.${other}|${other}|${other}\\.app)(?:/|$)`).test(value)) return true;
	if (
		/\/(?:\.cursor|cursor\.app|\.trae|trae\.app|\.vscode|visual studio code\.app)(?:\/|$)/.test(
			value
		)
	)
		return true;
	const foreignRoot = host === 'codex' ? env.WORKBUDDY_CONFIG_DIR : env.CODEX_HOME;
	if (foreignRoot && isAbsolute(foreignRoot)) {
		const rel = relative(canonical(foreignRoot), canonical(path));
		if (!rel || (!isAbsolute(rel) && rel !== '..' && !rel.startsWith(`..${sep}`))) return true;
	}
	const app = value.match(/^(.+?\.app)\//)?.[1];
	return Boolean(app && !app.endsWith(`/${host}.app`));
}
export function assertHostRuntime(host, env = process.env) {
	if (foreignDependency(process.execPath, host, env))
		throw Error(
			`NODE_FOREIGN_APPLICATION: 不能使用其他应用的私有 Node：${process.execPath}；请使用当前平台自带 Node 或 PATH 中的系统 Node。`
		);
}
