import { onBeforeUnmount } from 'vue';
import { createSocial } from './Social.js';
import type { SocialPageProps } from './Types.js';
export function useSocialPage(props: SocialPageProps) {
	const c = createSocial(() => props.host);
	onBeforeUnmount(c.dispose);
	return c;
}
