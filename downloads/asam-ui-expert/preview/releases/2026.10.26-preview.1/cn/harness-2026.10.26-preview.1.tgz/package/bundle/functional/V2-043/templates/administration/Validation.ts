/** Runtime DTO boundaries reject absent/extra fields and accessors before reading values. */
export function fields(
	value: unknown,
	required: readonly string[],
	optional: readonly string[] = []
): asserts value is Record<string, unknown> {
	if (
		!value ||
		typeof value !== 'object' ||
		Array.isArray(value) ||
		![Object.prototype, null].includes(Object.getPrototypeOf(value))
	)
		throw new Error('记录格式无效');
	const descriptors = Object.getOwnPropertyDescriptors(value);
	if (
		Reflect.ownKeys(value).some(
			(key) =>
				typeof key !== 'string' ||
				![...required, ...optional].includes(key) ||
				!('value' in descriptors[key]) ||
				!descriptors[key].enumerable
		) ||
		required.some((key) => !Object.hasOwn(descriptors, key))
	)
		throw new Error('记录字段缺失或不受支持');
}
export function stringField(value: Readonly<Record<string, unknown>>, key: string): string {
	const result = value[key];
	if (typeof result !== 'string') throw new Error('字段格式无效');
	return result;
}
export function versionValue(value: unknown): number {
	if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0)
		throw new Error('版本无效');
	return value;
}
export function denseArray(value: unknown): asserts value is unknown[] {
	if (
		!Array.isArray(value) ||
		Reflect.ownKeys(value).length !== value.length + 1 ||
		Array.from({ length: value.length }, (_, i) =>
			Object.getOwnPropertyDescriptor(value, String(i))
		).some((d) => !d || !('value' in d))
	)
		throw new Error('集合格式无效');
}
