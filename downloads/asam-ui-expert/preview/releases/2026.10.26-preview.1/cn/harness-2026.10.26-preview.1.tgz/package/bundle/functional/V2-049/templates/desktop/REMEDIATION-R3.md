# V2-049 QA049-03 同 scope 基线连续性整改 R3

原DEV/原consumer继续，已审产品 `b0fb0f30bad05a19173511b389a5db45ad8af3b5`，独立QA固定提交 `517ad75eb1e57603b7eedcd05f0dc3ba15403cf7`。全卡base仍为 `2d814770fafa3a9268707d7202d31e6b698d4896`；新head和Git/raw/配置/锁/包/产物/日志在 `E:/DevCache/artifacts/asam-ui/v2-049/dev-r1/remediation-r3/CANDIDATE.json`。待TC核准后由原QA接续，本说明不是独立QA签署。

原QA确认QA049-01/02跨context缺陷已闭；QA049-03以固定now=100、refined 21场景中的4项nextSave conflict为本轮目标。status-only初稿误差不作为整改目标，原件不改。原consumer与b0fb冻结的81项先逐字节核同；原21场景/4 FAIL原字节另存QA-REFINED-BEFORE.json。DEV新增四场景表先在b0fb真实失败，日志保留所有4项nextSave=conflict。

## 修复规则

操作代号保护UI完成，cache实例保护持久基线。自身成功setItem的准确序列化字节、成功removeItem后的null，立即记为仍归属同cache/context的已知持久状态。回调内同scope编辑可以使旧完成stale，但不能丢失这个已发生的持久结果。真正context替换（即使A→B→A同键）使用不同cache实例，dispose也不会接收旧基线。

setContext初始化读取基线不以布局epoch变化直接丢弃观察：同context新编辑保持，仍能save。基线版本标记防止较早getItem返回值覆盖回调内reset已完成的持久操作。save/reset末次读取只比较已知基线，不采用外部新字节；真实外部写入继续conflict，不关闭冲突检测、不强制restore丢掉编辑，也不新增原子CAS承诺。

| 原反例                                           | b0fb原结果                              | 当前DEV复验                                         |
| ------------------------------------------------ | --------------------------------------- | --------------------------------------------------- |
| save写入2窗后，第4次getItem同scope再close(notes) | 旧完成stale，下一save conflict          | 旧完成stale，notes保持关闭，下一save ok并存最新布局 |
| reset removeItem回调同scope close(notes)         | 删除已发生但基线仍旧，下一save conflict | 保留自身删除的null基线，下一save ok                 |
| reset末次getItem同scope close(notes)             | 下一save conflict                       | 最新编辑保留，下一save ok                           |
| setContext基线读回调同scope close(notes)         | baseline未建立，下一save conflict       | 建立本context观察基线，最新编辑保持，下一save ok    |

## 实际验证与继承

17逻辑组通过：原14组保持，新增四反例完整表、同四操作中外部写入必须conflict且外部原字节不改、context基线读内嵌reset后不得退回早先读值。公开类型正反、正常生产构建通过，三族67项相关真实浏览器边界通过；同版UI/Pro完整正常包及1874实际安装载荷继续核同，无新安装或依赖改动。

从固定QA提交读取原r2-adversarial.mjs，仅将consumer/输出路径改至本DEV、将静态product字段标识为reviewedProduct，所有21场景与断言逐字保留。DEV本机重放21项全部通过，原始/改配脚本、三处精确映射与编译模块SHA均保全。格式化前后实际编译模块逐字一致，FORMAT-COMPILE-PROJECTION.json精确绑定当前源与重放模块，不把格式化后的源raw声称为旧raw。该重放是DEV验证，不冒独立QA通过；原QA须对新head重新精确审查。

三族SFC/CSS/Types/示例/Agent改配方法未改，旧174功能、修改/还原、动态/异常与首预算只保留原候选和原结果，不冒本轮重新执行。首次完整双钟预算FAIL、全raw、精度、方法及历史R2 FAIL均不覆盖，本轮未重采预算。未创建角色/子代理/心跳，未写canonical/云/main或推送部署发表。
