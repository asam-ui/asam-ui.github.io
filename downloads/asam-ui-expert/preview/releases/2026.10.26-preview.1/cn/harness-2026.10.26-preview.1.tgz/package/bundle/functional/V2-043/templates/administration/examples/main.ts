import { mountAdministration } from './mount.js';
mountAdministration();
