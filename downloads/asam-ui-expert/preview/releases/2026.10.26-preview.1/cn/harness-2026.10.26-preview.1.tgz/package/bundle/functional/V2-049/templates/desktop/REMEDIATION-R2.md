# V2-049 QA-R1 重入缺陷整改 R2

2026-10-19，原DEV/原独立consumer继续。已审候选 `5cc2991112beba6925ac89e451eabd041efa3b1b`，全卡固定base仍为 `2d814770fafa3a9268707d7202d31e6b698d4896`。新head与Git/raw/生产/安装/方法及日志哈希在 `E:/DevCache/artifacts/asam-ui/v2-049/dev-r1/remediation-r2/CANDIDATE.json`；独立QA须复审新差异，本文件不签QA PASS。

原QA的adversarial-results.json独立记录两项FAIL，保持原字节。DEV先核原consumer完整80项与5cc冻结源/配置/锁/包/dist/metadata一致，再补回归：原8组通过，新增3组首轮失败，未改产品前真实红灯日志为regression-first-red.log。

| 原缺陷                                                                       | 精确整改                                                                                                                                      | 新回归                                                                                                     |
| ---------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| save末次getItem回调切换scope后，旧完成发布ok/旧baseline，新scope后续save冲突 | 末次raw先存局部值，返回后复核epoch/key/disposed，再发布baseline/status。setContext用新cache当前记录建立自己的基线，且该读自身也受代号/key保护 | 第4次读重入新owner/scope：旧save stale，新状态missing、新键无旧值，后续新save ok；旧键2窗、新键3窗互不混写 |
| reset的removeItem回调切换scope并关闭notes，旧reset重新defaults覆盖新操作     | clear与末次raw每个宿主边界返回后分别核代号/key/disposed；有效当前操作才更新baseline/defaults/status                                           | removeItem重入新context+close：旧reset stale，notes保持关闭，旧键清除/无关键保留，新scope后续save ok       |

另覆盖save/reset末次读中同scope编辑、换context及dispose的六组合；覆盖setContext初始化基线时再次换context或dispose。沿同类边界补查又实际复现外部storage通知读回调污染新context状态、迟到异步准备reject仍返回unavailable两项缺口；保留12通过/2失败的same-boundary-extra-red.log，补同代号/key保护与reject旧代stale。没有收紧getItem/removeItem可重入的公开契约，没有改变同版034存储实现或清理他人存储。

整改后14逻辑组通过，公开类型正反通过，正常生产SFC build通过。三族67项受影响浏览器边界通过：storage坏JSON/旧未来/schema/链接/TTL、跨页conflict显式恢复、迟到save/restore、焦点、pointer resize/touchCancel、子任务取消及销毁。UI/Pro正常包、配置/锁/安装环境继续复用，不补装root，不重新安装consumer。

原三族SFC/CSS/公开Types/示例配置与Agent改配操作没有产品差异；首次174三族功能、modified/restored各30、11项动态/滚动/异常及324项原阶段二次核验保持原来源和候选，不冒本轮重新执行。共享控制器本次精确差异由14组逻辑、类型/生产和67边界重新验证。

原首次完整预算FAIL及10MB完整raw、双钟、精度和方法SHA保持不变；本轮没有预算重采、抬阈值或削字段，也没有将QA两项缺陷关闭推断为性能或整卡PASS。生产大chunk已有告警保留。未增加角色/子代理/心跳，未写canonical/云/main、推送部署或发表，当前只交原测试主控复审。
