<template>
	<main class="social-page social-brand" :data-size="size ?? 'default'">
		<div class="social-brand-shell">
			<aside class="social-brand-sidebar">
				<span class="social-wordmark">COMMON<br />GROUND.</span>
				<h1>{{ socialConfig.brand.title }}</h1>
				<p>{{ socialConfig.brand.description }}</p>
				<dl>
					<dt>社区成员</dt>
					<dd>{{ host.security.state.value.subject?.name ?? '访客' }}</dd>
					<dt>阅读方式</dt>
					<dd>完整原文 / 真实讨论</dd>
				</dl>
			</aside>
			<section class="social-brand-main">
				<header>
					<p>COMMUNITY JOURNAL / 2026</p>
					<h2>把观察，变成对话。</h2>
				</header>
				<SocialFeed :c="c" :size="size" /><SocialDetail :c="c" />
			</section>
			<aside class="social-author-rail">
				<h2>关于这里</h2>
				<p>让工程经验与设计判断，在一个安静的地方相遇。</p>
				<hr />
				<p>作者与时间缺失时明确展示未知。</p>
				<p>{{ c.rows.value.length }} 条当前结果</p>
			</aside>
		</div>
	</main>
</template>
<script setup lang="ts">
import type { SocialPageProps } from './Types.js';
import { socialConfig } from './config.js';
import { useSocialPage } from './useSocialPage.js';
import SocialFeed from './parts/SocialFeed.vue';
import SocialDetail from './parts/SocialDetail.vue';
import './Social.css';
const props = defineProps<SocialPageProps>();
const c = useSocialPage(props);
defineExpose({ controller: c });
</script>
