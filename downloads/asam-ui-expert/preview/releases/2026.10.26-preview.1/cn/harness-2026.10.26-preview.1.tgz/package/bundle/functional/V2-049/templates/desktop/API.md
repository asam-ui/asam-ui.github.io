# Desktop API · 0.1.0-alpha.1

存储回调边界：操作完成用epoch/key/disposed保护status和默认布局；持久基线另按cache实例维护。同context已成功写入的准确字节/删除后的null立即成为已知基线，即使回调中有新编辑、旧完成stale，最新布局仍可继续save。末次读取只核对，不能把外部新字节认作自己的写入。setContext可在保留同context编辑的同时建立读取基线；若回调中已有reset等更新基线，较早读值不覆盖它；真正换context/dispose仍隔离。getItem/removeItem可重入的既有契约保持，不强制restore丢弃编辑。

入口 `index.ts`；公开结构见 `Types.ts`。控制器与三个页面通过显式props组合，不依赖Agent运行时。

| 入口                                        | 契约                                                                                                                         |
| ------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| createDesktop(options)                      | app/owner/scope/panels必填；storage可选；ttl默认2592000000ms；now默认Date.now；breakpoint默认720；disabled/readonly默认false |
| DesktopPanel                                | id/title/allowed必填；description/status/disabled/readonly/initial/initialOpen可选；只接受本地显式资源                       |
| WindowRect                                  | x/y/width/height有限CSS px，位置相对surface，尺寸为正；投影时限视口                                                          |
| LayoutSnapshot                              | version=1；windows有序，active为现有非最小化id或null；严格拒绝额外正文/凭据字段                                              |
| MinimalDesktop / BrandDesktop / TechDesktop | props controller必填；title/description/size可选，size为small/default/big/large                                              |
| slots                                       | panel({panel,window,readonly,close})注入本地业务SFC；navigation()/footer()注入普通导航与说明                                 |
| 事件                                        | retry(id)，错误状态下由AsamPageContainer重试按钮触发；宿主更新对应panel状态                                                  |
| expose                                      | focus()聚焦工作区；cancel()放弃临时拖缩放                                                                                    |

控制器公开只读refs：panels、visiblePanels、windows、active、viewport、narrow、disabled、readOnly、status、revision、focusRevision、contextRevision。contextRevision仅真实owner/scope切换时递增，使旧身份内容释放；普通移动/激活/断点不改变内容身份。不得直接改props或ref内部。

| 方法                                    | 结果与边界                                                                                             |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| open(id) / activate(id)                 | boolean；已开复用实例，激活恢复最小化并置顶；未知/撤权/禁用/只读false                                  |
| close(id) / minimize(id) / maximize(id) | boolean；关闭销毁、最小化保留、最大化再次还原；最大化保留原rect                                        |
| setRect(id, rect)                       | boolean；宽屏非最大化可操作窗口才可修改，实际clamp；每次修改使异步旧代失效                             |
| displayRect(window)                     | 当前投影，不修改逻辑rect；窄屏或最大化占满surface                                                      |
| setViewport(width,height)               | 正有限测量，纯投影，不保存位置                                                                         |
| setPanels(panels)                       | 替换宿主允许列表，撤回面板立即销毁；不自动打开新增授权面板                                             |
| setPolicy({disabled?,readonly?})        | 省略为false；使旧异步失效                                                                              |
| setContext(owner,scope)                 | 严格typed身份；不同上下文先dispose旧cache并恢复本地默认，随后宿主可await restore()                     |
| restore(beforeRead?)                    | Promise&lt;LayoutStatus&gt;；读取后当前权限过滤；不存在/损坏/未来/过期采用默认；新操作/回调重入时stale |
| save(beforeWrite?)                      | Promise&lt;LayoutStatus&gt;；只保存调用时完整布局，异步等待中发生新操作返回stale；同键冲突conflict     |
| reset()                                 | LayoutStatus；仅移除本cache键并恢复默认，不全局clear                                                   |
| externalChange(key)                     | storage事件检测，仅相关key或clear事件；不自动覆盖本地未存布局                                          |
| snapshot() / key()                      | 当前布局的深复制 / 当前034命名键                                                                       |
| canOperate(id) / dispose()              | 当前布局操作资格 / 幂等释放cache与窗口状态，后续操作不写入                                             |

LayoutStatus继承034的missing/ok/migrated/invalid/future/expired/unavailable/disposed/stale，增加conflict。桌面v1无旧版迁移映射，因此migrated仅保留同版类型兼容，不声称会产生。存储异常反馈在工作台工具栏；恢复或重置是明确用户动作。具体reentrant/TTL与存储能力边界见README。
