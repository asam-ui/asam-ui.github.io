# Agent 配方 · Social 0.1.0

先读 Types/API/README，再编辑本模板。只消费普通 UI/Pro 包与 033 安全源码。
禁止包源码 alias、补 dist/d.ts、复制分页排序引擎或自行更改已验 025 API。

1. 在 `Adapter.ts` 的 `adaptSocial<P,C>` 填写真实运输层和两个 DTO 映射。
   所有 post/comment 字段必须完整映射，包括原文、typed ID、版本、权限状态和计数。
   示例 EditorialDTO 将 person/text/stats/viewer/revision 映回标准模型，NoteDTO 使用 parent/writer/removable。
2. 修改三族 SFC 的信息结构与 `config.ts`。保留真实查询、列表、互动、详情与评论入口。
   可移动侧栏、阅读台或作者说明；不能只换标题或删除功能。
3. 修改本地服务或权限组合，明确 033 的登录、恢复、切上下文与 logout。
   服务注入可替换；不得把合成 fixture 写成全局唯一实现。
4. 独立 consumer 安装普通 JS/CSS/d.ts，实际回读 verifyDepsBeforeRun=error，执行 typecheck/build。
   正类型接受两个 DTO，负类型禁止错误 desired、缺 resolve、错误 ID/计数类型。
5. 浏览器实际观察三族的改配，包含查询、完整正文、评论、一次权威写入与失败恢复。
   宽1280/窄390、父亮暗、40/36/32/28与 reduced-motion 按有区分能力场景核查。
6. 变更前冻结源码/配置/有效锁/metadata/包成员/links/dist/日志。
   改配先封不可变 CAS，再在物理只读源码/dist 上独立复放。
   最终恢复原源码实际字节并重新核哈希；不能用生成签名冒实际恢复。

迁移现有页面时先替换接口边界，再映射原文/typed ID/权限，最后移动布局。
未知写结果只核实原 operationId；不从 transport exception 猜“未生效”。
保留失败/UNKNOWN与未测结果，不能靠减数据、改阈值或重采旧首次追绿。
合成系统不需真实账号、key 或外部社交服务；真实 CL 业务仍由用户指定。
