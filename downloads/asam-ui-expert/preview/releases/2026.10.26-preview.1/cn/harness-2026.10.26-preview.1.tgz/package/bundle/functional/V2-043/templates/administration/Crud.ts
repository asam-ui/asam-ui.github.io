import { inject, onBeforeUnmount, watch } from 'vue';
import { defineAsamOptions } from '@asam-ui/ui';
import { useAsamCrudController } from '@asam-ui/pro';
import type {
	AsamCrudCodec,
	AsamCrudServices,
	AsamFieldDefinition,
	AsamOperationColumn
} from '@asam-ui/pro';
import { scopeKey } from '../app/security/index.js';
import { administrationKey } from './Types.js';
import type { AdministrationHost, Entity, Id, Query } from './Types.js';
import { isId } from './Tree.js';
import { fields, stringField, versionValue } from './Validation.js';

export const initialQuery: Query = { keyword: '', status: '', role: null, context: '' };
export function useAdministration() {
	const host = inject(administrationKey);
	if (!host) throw new Error('需要 AdministrationHost');
	return host;
}
export const text = stringField;
export const version = (model: Readonly<Record<string, unknown>>) => versionValue(model.version);
export const queryCodec: AsamCrudCodec<Query> = {
	encode: (q) => ({ ...queryCodec.decode(q) }),
	decode: (q) => {
		fields(q, ['keyword', 'status', 'role', 'context']);
		const m = q;
		if (m.role !== null && !isId(m.role)) throw new Error('角色条件无效');
		return {
			keyword: text(m, 'keyword'),
			status: text(m, 'status'),
			context: text(m, 'context'),
			role: m.role
		};
	}
};
/** 003 explicitly omits empty query values. Only this named projection boundary restores them. */
export const queryProjectionCodec: AsamCrudCodec<Query> = {
	encode: queryCodec.encode,
	decode: (q) => {
		fields(q, [], ['keyword', 'status', 'role', 'context']);
		return queryCodec.decode({ ...initialQuery, ...q });
	}
};
export const queryFields: readonly AsamFieldDefinition[] = [
	{ key: 'keyword', kind: 'text', label: '关键字' },
	{ key: 'status', kind: 'text', label: '状态' },
	{
		key: 'role',
		kind: 'single',
		label: '角色',
		source: defineAsamOptions().static({ options: [] })
	},
	{ key: 'context', kind: 'text', label: '上下文' }
];
export const field = (key: string, label: string): AsamFieldDefinition => ({
	key,
	label,
	kind: 'text',
	...(['name', 'account', 'code', 'title'].includes(key)
		? { modes: { edit: { rules: [{ required: true, message: `请输入${label}` }] } } }
		: {})
});
export async function readHostOptions<T>(
	host: AdministrationHost,
	entity: Entity,
	request: (context: import('./Types.js').Request) => Promise<T>
): Promise<T> {
	const service = host.services.value,
		epoch = host.security.state.value.epoch,
		c = host.runtime.createContext();
	const current = () =>
		service === host.services.value &&
		epoch === host.security.state.value.epoch &&
		host.runtime.isCurrent(c) &&
		host.security.check({ permission: `${entity}:read` }) === 'allowed';
	try {
		if (!current()) throw new Error();
		const result = await request({ ...c, isCurrent: current });
		if (!current()) throw new Error();
		return result;
	} catch {
		throw new Error('候选读取失败，请重试');
	} finally {
		host.runtime.release(c);
	}
}
export function useAdministrationCrud<Row extends { id: Id }, Edit extends object>(
	host: AdministrationHost,
	entity: Entity,
	services: AsamCrudServices<Row, Query, Edit, Id>,
	codec: AsamCrudCodec<Edit>,
	fields: readonly AsamFieldDefinition[],
	columns: readonly AsamOperationColumn<Row>[],
	queries: readonly AsamFieldDefinition[] = queryFields
) {
	const bound = host.services.value;
	const serviceVersion = bound.version;
	const epoch = host.security.state.value.epoch;
	const currentScope = () =>
		host.security.state.value.subject ? scopeKey(host.security.state.value.subject) : '';
	const scope = currentScope();
	const current = () =>
		host.services.value === bound &&
		bound.version === serviceVersion &&
		host.security.state.value.epoch === epoch &&
		currentScope() === scope;
	const read = () =>
		current() && host.security.check({ permission: `${entity}:read` }) === 'allowed';
	const write = () =>
		read() && host.security.check({ permission: `${entity}:write`, write: true }) === 'allowed';
	const safeRead = async <T>(fn: () => Promise<T>): Promise<T> => {
		if (!read()) throw new Error('当前读取已关闭');
		try {
			const value = await fn();
			if (!read()) throw new Error();
			return value;
		} catch {
			throw new Error('资料读取失败，请重试');
		}
	};
	// The 024 controller freezes operations, checks permissions around confirmation,
	// retains unknown writes and owns list/editor/detail orchestration.
	const guarded: AsamCrudServices<Row, Query, Edit, Id> = {
		list: (q, c) => safeRead(() => services.list(q, c)),
		defaults: (c) => safeRead(() => services.defaults(c)),
		load: (k, c) => safeRead(() => services.load(k, c)),
		create: (m, o, c) =>
			write()
				? services
						.create(m, o, c)
						.catch(() => ({ status: 'unknown', message: '写入结果未知，请核实' }))
				: Promise.resolve({ status: 'failure', message: '权限已撤销，未发送' }),
		update: (k, m, o, c) =>
			write()
				? services
						.update(k, m, o, c)
						.catch(() => ({ status: 'unknown', message: '写入结果未知，请核实' }))
				: Promise.resolve({ status: 'failure', message: '权限已撤销，未发送' }),
		verify: (o, c) => safeRead(() => services.verify(o, c)),
		resolve: (k, c) => safeRead(() => services.resolve(k, c)),
		remove: (t, s) =>
			write()
				? services
						.remove(t, s)
						.catch(() => ({ key: t.key, status: 'unknown', message: '删除结果未知' }))
				: Promise.resolve({ key: t.key, status: 'failure', message: '权限已撤销，未发送' }),
		verifyRemove: (t, s) => safeRead(() => services.verifyRemove(t, s))
	};
	const crud = useAsamCrudController<Row, Query, Edit, Id>({
		runtime: host.runtime,
		writes: host.writes,
		operations: host.operations,
		rowKey: (r) => r.id,
		isKey: isId,
		dataset: () => JSON.stringify([scope, bound.version, entity]),
		initial: { ...initialQuery },
		queryFields: queries,
		queryCodec: queryProjectionCodec,
		editFields: fields,
		detailFields: fields,
		editCodec: codec,
		services: guarded,
		detail: {
			mode: 'load',
			load: async (id, context) => ({
				status: 'ready',
				data: codec.encode(await guarded.load(id, context))
			})
		},
		columns,
		preferences: {
			scope: () => ({
				application: 'administration',
				principal: scope,
				table: entity,
				version: bound.version
			}),
			adapter: { load: async () => null, save: async () => {}, reset: async () => {} }
		},
		pageSize: 20,
		disabled: () => !read(),
		readonly: () => !write(),
		allowed: (a) => (a === 'detail' ? read() : write()),
		allowedRemove: () => write(),
		confirmDiscard: () => host.confirm('修改尚未保存，确认丢弃？'),
		confirmRemove: (s) =>
			host.confirm(
				`确认删除 ${s.targets.length} 项？${s.targets.map((t) => `${typeof t.key}:${t.key}`).join('、')}。取消不会发送。`
			),
		operationId: () => crypto.randomUUID()
	});
	const clear = () => {
		crud.editor.invalidate();
		crud.detail.close();
		crud.selection.clear();
	};
	const unsubscribe = host.security.onInvalidate(clear);
	const stop = watch(() => host.services.value, clear, { flush: 'sync' });
	const leave = async () =>
		!crud.editor.dirty.value || host.confirm('页面修改尚未保存，确认离开并丢弃？');
	host.leaves?.add(leave);
	onBeforeUnmount(() => {
		host.leaves?.delete(leave);
		unsubscribe();
		stop();
		crud.dispose();
	});
	return crud;
}
