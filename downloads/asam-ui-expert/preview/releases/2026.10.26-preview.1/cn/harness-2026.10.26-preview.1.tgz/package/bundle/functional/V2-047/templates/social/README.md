# 社交前端示例 · V2-047

供应方中立的可编辑 Vue 应用源码。仅处理信息流、正文、点赞、收藏、评论和服务替换。
不包含真实社交账号、私信、推荐、上传、推送、审核或后端。

## 三种完整页面

| 页面                    | 信息结构                         | 设计依据                                    |
| ----------------------- | -------------------------------- | ------------------------------------------- |
| `MinimalSocialPage.vue` | 编辑手记标题、窄说明栏、单列阅读 | minimalist-ui                               |
| `BrandSocialPage.vue`   | 品牌侧栏、社区主栏、作者说明栏   | high-end-visual-design，Editorial Luxury    |
| `TechSocialPage.vue`    | 活动网格、独立阅读台、状态遥测   | industrial-brutalist-ui，Tactical Telemetry |

三者共享完整查询、排序、分页、刷新、正文展开、详情、评论分页、点赞、收藏、
新增评论、取消保草稿、删除确认及失败恢复。布局源码可直接改动。
颜色/字体/尺寸通过 CSS variables 消费 ASAM 与宿主主题；简单 CSS 动效支持 reduced motion。

## 普通消费

复制本目录与 `templates/app/security/{Security,Types}.ts`，保留相对目录关系。
应用正常安装 Vue 3.5.34、Element Plus 2.14.7 与匹配 003/025 公开闭包的 ASAM UI/Pro 包。
导入 `element-plus/dist/index.css`、`@asam-ui/ui/style.css`、`@asam-ui/pro/style.css`。
本模板使用包 JS、CSS 与声明文件，不 alias 包源码、不补写 dist 或声明。
项目 Element Plus patch 及 peer override 按锁定消费者配置保留。

```vue
<template><MinimalSocialPage :host="host" size="default" /></template>
<script setup lang="ts">
import MinimalSocialPage from './templates/social/MinimalSocialPage.vue';
// host 由应用持有，包含借入的 security、service 和可选 readonly/disabled。
import { host } from './social-host';
</script>
```

本卡可复现 consumer 在仓库外创建：

```powershell
. D:/Work/department/asam-ui/tools/use-e-drive.ps1 -ForNewTask
. D:/.pnpm-store/use-pnpm.ps1
node tests/v2/social/prepare.mjs E:/DevCache/temp/asam-ui/V2-047-QA/consumer
Set-Location E:/DevCache/temp/asam-ui/V2-047-QA/consumer
$env:pnpm_config_verify_deps_before_run='error'
pnpm config get verifyDepsBeforeRun
pnpm install
pnpm run typecheck
pnpm run build
pnpm run dev -- --port 5047
```

prepare 拒绝覆盖现有 consumer。独立安装，复用固定正常 tarball，禁止借入 mutable node_modules。
生产接入由宿主替换本地 tarball 位置并固定自己的锁，不把合成服务当成生产后端。
pnpm 11 会在命令子进程注入 `verify_deps_before_run=false`；本卡 runner 在实际进程
重新设置并通过 pnpm 回读 `error`，再启动类型/构建工具。不要只检查 `.npmrc` 文本。
验证时可加载 `tests/v2/social/environment.ps1 -Consumer <自己的consumer> -Task <自己的角色ID>`，
其任务临时目录、Node/pnpm 和实际配置会被逐项核验。
普通宿主应保留 `assets` 并关闭 Vite 小资源内联（本例 `assetsInlineLimit: 0`），
示例图片仍为本地静态资源；宿主真实数据也可直接映射自己的本地资源路径。

## 身份与边界

示例设置提供两身份（数字 `0` 与字符串 `'0'`）、两上下文、登录、恢复、实际 logout。
033 的 `createSecurity/check/onInvalidate/scopeKey` 是真实执行边界。
只读仍允许读取与选择原文；禁用/身份 pending/失效禁止新服务动作。
身份、权限、上下文、service 或 host 模式变化会清除本页草稿、评论和历史内容。
宿主必须在权限改变时调用安全 controller 的正规刷新/失效入口。
前端 gate 只保护本页；真实服务必须自行鉴权、版本检查与持久幂等。
借入的 security/service 永不由页面 dispose。

完整正文、评论、script/HTML/代码/链接均以纯文本渲染，不执行或自动链接。
可选头像/封面只接受本地路径，失败显示替代文本；未知作者和时间明确显示未知。

## 写入与恢复

点赞/收藏提交 desired 与当前版本，消费服务权威返回；不对旧行盲加计数。
新增/删除评论使用 operationId。明确 failed 可由用户重新提交；unknown 只核实原 id。
不因重渲染或重复点击重发。切帖后核实仍操作原对象，不污染当前详情。
明确服务失败的 `message` 完整显示为安全纯文本，恢复提示单独保留；HTML/脚本/链接不执行。
提交期间继续编辑的草稿不会被旧成功清除。取消编辑保留原值。
本地合成 adapter 的幂等表仅在内存生存期内有效，不承诺跨进程持久性。

## 可替换服务与 Agent

最小完整协议见 [API](./API.md)、[Types](./Types.ts)，迁移步骤见 [AGENT](./AGENT.md)。
`examples/Fixture.ts` 含标准模型与真正嵌套的 EditorialDTO/NoteDTO 两条运行链；
读、评论、写、原操作核实都通过映射。
normal 与改配均保留 100 帖/默认 20、40 评论/默认 20 和实际 100ms 服务等待。
`config.ts` 与三族 SFC 是可维护的信息结构入口，不修改 003/025 公共 API。

完整观察使用 `tests/v2/social/strong.mjs`（`browser.mjs full` 也转交它）。
旧轻读器因 QA047-M01 缺项不具完整协议资格，旧三窗口 PASS 不可沿用为完整强证据。
`browser.mjs ... functional-only` 只做功能流程，结果明确标记 `strongTiming: NOT_SAMPLED`。
首次完整 QA normal 的 12077.47/12067.90ms FAIL 与后继未测保持原件，详见 [交付记录](./DELIVERY.md)。
