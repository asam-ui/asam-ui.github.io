import { mountAdministration } from '../examples/mount.js';
mountAdministration('brand');
