# 接入与迁移

这是新增模板，没有删除既有包接口。复制模板目录及 032/033 的相对依赖；保留正常包 import。
从旧管理页迁入时逐项替换：

1. 将 Row/Edit/Query 映射到 Types.ts；使用明确 codec 保留原 typed ID、版本与原始服务映射。
2. 注入三组 AsamCrudServices 和应用持有的 writes/operations，不把各页未决写放到临时组件内。
3. 接入宿主 SecurityAdapter 与 scopeKey。给每个 route 明确读取规则，写前单独检查权限；禁用通配超级角色推导。
4. 将后端授权模型转换为 direct 集合，明确全量/差额、不可授保留/拒绝、版本与 unknown 核实策略。
5. 服务替换更改 version 和服务引用；失效优先清数据。普通离开可以询问丢弃，安全失效不能让确认保留旧主体。
6. 删除旧“失败自动重试写”的流程；对 unknown 使用原 operationId 核实。

Directory/Catalog 的真实可运行合成映射见 Codecs.ts 与 Fixture.ts。
真实后端授权引擎、认证服务器、租户平台及真实 CL 页面不属于本模板，接入方保留这些职责。

QA43 整改后，Edit/Query/GrantNode 与示例 DTO 的字段必须完整且无额外字段；service.load 显式返回 Edit，不把含 id 的 Row 直接传给 Edit codec。新增字段同时更新 Types、字段定义、codec 白名单和 DTO adapter。003 空查询省略只经 `queryProjectionCodec` 适配，不把缺失 Edit/parentId/version 默认为合法值。自有 consumer 使用 pnpm-workspace.yaml 的 camelCase 校验设置并实际回读；旧 .npmrc 配方不足以证明 pnpm11 生效。
