import type { GrantNode, Id } from './Types.js';
import { denseArray, fields, versionValue } from './Validation.js';

export const isId = (id: unknown): id is Id =>
	typeof id === 'string'
		? id.trim().length > 0
		: typeof id === 'number' && Number.isFinite(id) && !Object.is(id, -0);
/** JSON tuple preserves numeric/string identity. Never used as a backend ID. */
export function keyOf(id: Id): string {
	if (!isId(id)) throw new Error('标识必须为非空字符串或有限数字');
	return JSON.stringify([typeof id, id]);
}
export interface TreeNode {
	key: string;
	label: string;
	disabled: boolean;
	source: GrantNode;
	children: TreeNode[];
}
/** Domain input validation only. Display/check/keyboard algorithms belong to AsamTree. */
export function validateTree(nodes: readonly GrantNode[]): TreeNode[] {
	denseArray(nodes);
	const entries = new Map<Id, TreeNode>();
	for (const source of nodes) {
		fields(source, [
			'id',
			'parentId',
			'title',
			'kind',
			'permissionCode',
			'enabled',
			'grantable',
			'version'
		]);
		if (!isId(source.id) || (source.parentId !== null && !isId(source.parentId)))
			throw new Error('菜单标识无效');
		if (entries.has(source.id)) throw new Error('菜单标识重复');
		if (
			typeof source.title !== 'string' ||
			!source.title.trim() ||
			typeof source.kind !== 'string' ||
			!source.kind.trim() ||
			typeof source.permissionCode !== 'string' ||
			typeof source.enabled !== 'boolean' ||
			typeof source.grantable !== 'boolean'
		)
			throw new Error('菜单字段无效');
		versionValue(source.version);
		entries.set(source.id, {
			key: keyOf(source.id),
			label: source.title,
			disabled: !source.enabled || !source.grantable,
			source: { ...source },
			children: []
		});
	}
	const roots: TreeNode[] = [];
	for (const item of entries.values()) {
		const seen = new Set<Id>([item.source.id]);
		let parent = item.source.parentId;
		while (parent !== null) {
			if (seen.has(parent)) throw new Error('菜单包含循环');
			seen.add(parent);
			const value = entries.get(parent);
			if (!value) throw new Error('菜单包含孤立节点');
			parent = value.source.parentId;
		}
		if (item.source.parentId === null) roots.push(item);
		else entries.get(item.source.parentId)!.children.push(item);
	}
	return roots;
}
