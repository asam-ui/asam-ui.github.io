export { default as MinimalSocialPage } from './MinimalSocialPage.vue';
export { default as BrandSocialPage } from './BrandSocialPage.vue';
export { default as TechSocialPage } from './TechSocialPage.vue';
export { createSocial } from './Social.js';
export { adaptSocial } from './Adapter.js';
export { socialConfig } from './config.js';
export type * from './Types.js';
