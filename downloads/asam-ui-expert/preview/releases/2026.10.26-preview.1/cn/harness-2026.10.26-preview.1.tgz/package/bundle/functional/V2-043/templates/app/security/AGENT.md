# Agent 任务配方

先读 capability.json → Types.ts → API.md → examples/App.vue / Fixture.ts / DataPage.vue。确认现有宿主后端协议、应用router和安全页，复制security与同版navigation源；正常安装同版UI/Pro，不使用包源码alias。

1. 为已有后端实现 SecurityAdapter，明确凭据所有权、DTO归一化、isCurrent提交检查与远端登出的会话隔离。
2. 配置明确的roles、permission codes、readOnly、contexts和毫秒expiresAt。空/非法权限关闭操作，不从角色名推导权限，不默认通配符。
3. 配置components allowlist、items、每条真实path的rules和公开安全页。菜单可见性、真实router guard与写入前check分别验证。
4. 接入onInvalidate清理每个业务读取、选择、详情与草稿；先dispose旧导航，再创建新身份导航。异步读取验证epoch及卸载，不能只信AbortSignal。
5. 复制普通应用后实际修改一组身份/权限和一组上下文数据；运行类型、生产构建与真实history/DOM，核窄屏、键盘、四尺寸/明暗和旧缓存真实消失。保留修改前后字节与截图，不以控制器计数替代实际页面。
6. 固定完整base/head、源码/正常包provenance与命令结果，交独立QA执行OCR委托源码审查及测试，完整QA通过才ACC。失败与未测明确列出；不要写canonical或发布。

真实CL待指定不阻本模板；不要新增后端身份平台、改基础UI、猜租户DSL或等待其他页面卡。

同步回调也是可重入边界：验证abort/state/onInvalidate内嵌套login/reset/logout、throw和合法当前恢复。旧操作应在回调返回后停止，不能调用尚未开始的旧adapter；分别核新身份实际刷新、同代合并及旧结算不清新槽，不能只数promise或依赖宿主isCurrent承担模块错误。
