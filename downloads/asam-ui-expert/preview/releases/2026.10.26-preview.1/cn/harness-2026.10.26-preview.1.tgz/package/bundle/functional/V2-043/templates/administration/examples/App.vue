<template>
	<AdministrationApp
		ref="application"
		:host="host"
		:family="family"
		:mode="dark ? 'dark' : 'light'"
	>
		<template #controls>
			<label
				>风格
				<select v-model="family" aria-label="风格">
					<option value="minimal">克制简约</option>
					<option value="brand">品牌分栏</option>
					<option value="technology">深色科技</option>
				</select></label
			>
			<label
				>尺寸
				<select v-model="size" aria-label="尺寸">
					<option value="large">40</option>
					<option value="big">36</option>
					<option value="default">32</option>
					<option value="small">28</option>
				</select></label
			>
			<label><input v-model="dark" type="checkbox" />暗色</label>
			<label
				>本地身份
				<select v-model="identity" aria-label="本地身份">
					<option value="editor">合成编辑者</option>
					<option value="reader">合成只读者</option>
					<option value="denied">合成无权者</option>
				</select></label
			>
			<AsamButton @click="login">切换身份</AsamButton
			><AsamButton @click="security.expire()">模拟失效</AsamButton>
			<AsamButton @click="security.logout()">退出示例会话</AsamButton>
			<AsamButton @click="switchContext">切换示例上下文</AsamButton>
			<label
				>DTO
				<select :value="format" aria-label="DTO" @change="replaceService">
					<option value="directory">Directory DTO</option>
					<option value="catalog">Catalog DTO</option>
				</select></label
			>
		</template>
		<template #recovery><AsamButton @click="login">恢复本地示例会话</AsamButton></template>
	</AdministrationApp>
	<details class="fixture-controls">
		<summary>合成服务控制与计数</summary>
		<label><input v-model="fixture.controls.readError" type="checkbox" />读取失败</label
		><label><input v-model="fixture.controls.refreshError" type="checkbox" />写后刷新失败</label
		><label><input v-model="fixture.controls.malformedTree" type="checkbox" />非法树</label
		><label><input v-model="fixture.controls.partial" type="checkbox" />部分删除失败</label
		><label
			>写入结果
			<select v-model="fixture.controls.outcome" aria-label="写入结果">
				<option v-for="v in outcomes" :key="v">{{ v }}</option>
			</select></label
		><label
			>等待毫秒
			<input
				v-model.number="fixture.controls.delay"
				type="number"
				aria-label="等待毫秒" /></label
		><output v-if="visibleMetrics" data-metrics>{{ JSON.stringify(visibleMetrics) }}</output>
	</details>
</template>
<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, shallowRef } from 'vue';
import { useRouter } from 'vue-router';
import { AsamButton, AsamMessageBox, createAsamDataRuntime } from '@asam-ui/ui';
import type { AsamControlSize } from '@asam-ui/ui';
import { createAsamWriteCoordinator, createAsamTableOperationCoordinator } from '@asam-ui/pro';
import { createSecurity, scopeKey } from '../../app/security/index.js';
import type { SecuritySubject } from '../../app/security/Types.js';
import type { AdministrationHost } from '../Types.js';
import AdministrationApp from '../AdministrationApp.vue';
import { createSyntheticServices } from './Fixture.js';
const params = new URLSearchParams(location.search);
const props = defineProps<{ initialFamily?: 'minimal' | 'brand' | 'technology' }>();
const family = ref<'minimal' | 'brand' | 'technology'>(
	props.initialFamily ??
		(params.get('family') === 'brand'
			? 'brand'
			: params.get('family') === 'technology'
				? 'technology'
				: 'minimal')
);
const dark = ref(params.has('dark') || family.value === 'technology'),
	size = ref<AsamControlSize>('default');
const identity = ref<'editor' | 'reader' | 'denied'>('editor');
const router = useRouter();
const application = ref<InstanceType<typeof AdministrationApp>>();
const outcomes = ['success', 'failure', 'conflict', 'unknown-applied', 'unknown-unapplied'];
const format = ref<'directory' | 'catalog'>('directory'),
	fixture = shallowRef(createSyntheticServices());
function subject(
	id: string,
	scope = { tenant: 0 as string | number | null, organization: null as string | number | null }
): SecuritySubject {
	return {
		id,
		name: id === 'editor' ? '合成编辑者' : id === 'reader' ? '合成只读者' : '合成无权者',
		roles: ['sample'],
		permissions:
			id === 'denied'
				? []
				: ['users', 'roles', 'menus'].flatMap((v) => [
						`${v}:read`,
						...(id === 'editor' ? [`${v}:write`] : [])
					]),
		scope,
		contexts: [
			{ tenant: 0, organization: null, label: '数字零空间' },
			{ tenant: '0', organization: null, label: '字符串零空间' }
		],
		expiresAt: Date.now() + 3600000,
		readOnly: id === 'reader'
	};
}
const security = createSecurity<string>({
	adapter: {
		login: async (id) => subject(id),
		restore: async () => subject(identity.value),
		refresh: async (s) => subject(String(s.id), s.scope),
		switchContext: async (s, scope) => subject(String(s.id), scope),
		logout: async () => {}
	}
});
const visibleMetrics = computed(() => {
	const state = security.state.value;
	if (state.status !== 'authenticated' || !state.subject) return null;
	const scope = scopeKey(state.subject);
	return {
		...fixture.value.metrics,
		events: fixture.value.metrics.events.filter((event) => event.scope === scope)
	};
});
const runtime = createAsamDataRuntime();
const host: AdministrationHost = {
	security,
	runtime,
	writes: createAsamWriteCoordinator(),
	operations: createAsamTableOperationCoordinator(),
	receipts: new Map(),
	services: shallowRef(fixture.value.services),
	size,
	unknownRoles: 'preserve',
	confirm: (text) =>
		AsamMessageBox.confirm(text, '请确认', {
			confirmButtonText: '确认',
			cancelButtonText: '取消',
			closeOnClickModal: false
		}).then(
			() => true,
			() => false
		)
};
const unsubscribe = security.onInvalidate(() =>
	runtime.setScope(`invalid:${security.state.value.epoch}`)
);
const setScope = security.state;
import { watch } from 'vue';
const stop = watch(
	setScope,
	(state) => {
		if (state.subject) runtime.setScope(scopeKey(state.subject));
	},
	{ flush: 'sync' }
);
async function switchContext() {
	const s = security.state.value.subject;
	if (s)
		await security.switchContext({
			tenant: typeof s.scope.tenant === 'number' ? '0' : 0,
			organization: null
		});
}
async function login() {
	application.value?.resume('/users');
	await security.login(identity.value);
}
async function replaceService(e: Event) {
	const v = (e.target as HTMLSelectElement).value;
	if (v !== 'directory' && v !== 'catalog') return;
	if (!(await host.confirm('更换宿主服务并丢弃当前本地草稿？'))) return;
	format.value = v;
	fixture.value = createSyntheticServices(v);
	host.services.value = fixture.value.services;
}
onMounted(() => security.login(identity.value));
onBeforeUnmount(() => {
	stop();
	unsubscribe();
	security.dispose();
	runtime.setScope('unmounted');
});
</script>
<style scoped>
.fixture-controls {
	padding: 16px;
	background: var(--asam-color-surface, #fff);
	color: var(--asam-color-text-primary, #222);
}
label {
	margin-right: 12px;
}
output {
	display: block;
	overflow-wrap: anywhere;
	font-size: 11px;
	max-height: 160px;
	overflow: auto;
}
</style>
