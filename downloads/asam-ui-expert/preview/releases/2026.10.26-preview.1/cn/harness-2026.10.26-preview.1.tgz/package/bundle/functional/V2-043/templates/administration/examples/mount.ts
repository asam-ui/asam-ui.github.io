import { createApp, h } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import 'element-plus/dist/index.css';
import '@asam-ui/ui/style.css';
import '@asam-ui/pro/style.css';
import App from './App.vue';
export async function mountAdministration(initialFamily?: 'minimal' | 'brand' | 'technology') {
	if (initialFamily && location.pathname.endsWith('.html'))
		history.replaceState(null, '', `/?family=${initialFamily}`);
	const router = createRouter({
		history: createWebHistory(),
		routes: [
			{ path: '/', component: { render: () => h('div') } },
			{ path: '/safe', component: { render: () => h('div') } }
		]
	});
	const application = createApp(App, { initialFamily }).use(router);
	await router.isReady();
	return application.mount('#app');
}
