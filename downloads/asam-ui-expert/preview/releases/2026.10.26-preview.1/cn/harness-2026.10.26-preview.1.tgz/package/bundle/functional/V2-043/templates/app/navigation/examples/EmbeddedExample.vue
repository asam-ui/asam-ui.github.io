<template><EmbedPage v-if="src" :src="src" :policy="policy" /></template>
<script setup lang="ts">
import { onMounted, ref } from 'vue';
import EmbedPage from '../EmbedPage.vue';
import type { EmbedPolicy } from '../Types.js';
const src = ref('');
const policy: EmbedPolicy = {
	resolve: (input) => input,
	allow: (url) => ['localhost', '127.0.0.1'].includes(url.hostname),
	sandbox: 'allow-same-origin',
	permissions: 'fullscreen'
};
onMounted(() => {
	src.value = `${location.origin}/embedded.html`;
});
</script>
