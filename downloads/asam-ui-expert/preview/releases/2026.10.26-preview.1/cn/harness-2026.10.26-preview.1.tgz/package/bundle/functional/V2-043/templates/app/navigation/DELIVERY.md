# V2-032 DEV-R1 完整导航候选

2026-10-18；独占 `templates/app/navigation`、`tests/v2/navigation`。完整产品 base `3a710d76d3a611fc0ddb17d56e9129e5b4d56d61`；完整 head、Git/工作字节、模板源码 ZIP、双包、普通 dist/tar/安装逐文件配对，以提交后外置 `receipt-final-r3/manifest.json` 为准。branch `codex/v2-032-dev-r1`。没有更改包源码、根配置/锁、其他任务或 canonical。

首 actual：线程01a14b64-0f93-7353-8096-80cca7df2186，真实项目f6046b3c-155c-49e3-9180-a827eb816dbb，独立 E:/worktree-tmp/4ec9/asam-ui；本会话首 turn_context 实录 gpt-6.1-sol/high、danger-full-access/never，list_threads 核项目，成功工程工具及干净3a710起点。固定3e88交接已全文读取，无.codegraph未初始化。公共缓存 E:/DevCache，pnpm store/cache/state为D唯一根；Node22.19.0/pnpm11.9.0，实际字段见 preflight.json。根独立 hoisted/copy 安装，consumer 独立 isolated/copy 安装；E 当前 NTFS，不套用历史 exFAT 限制。宿主管理 Playwright1.62.1通过依赖发现工具复用，Chrome版本以浏览器回执为准；profile/temp为任务独占目录。

## 完整交付

- A01/A02：真实 Vue Router history/参数/query/命名位置/深链接/重定向/未匹配反馈、宿主确认；稳定菜单结构和 allowlist；整批校验/注册回滚、并发代次、scope/卸载隔离、当前路由移除落点及自身 disposer。
- A05：fullPath页签与独立缓存身份、单页刷新、当前/其他/全部关闭、固定页保护、原生拖放/键盘、真实 RouterView/KeepAlive 激活/停用/销毁；显式复用策略、LRU及无缓存页。
- A13：可恢复的宿主 URL/来源策略、HTTP(S)/sandbox/allow/referrer边界、旧 iframe DOM事件隔离、不接收消息总线；原生全屏/实际事件校准、拒绝恢复、卸载只释放自身全屏。
- 同版本 Types/API/README/capability/Agent 与完整普通 App/main/页面资源。模板源码与 UI/Pro npm 包分开交付，应用拥有 router/权限/缓存策略，不进入 UI/Pro 运行时。

## 工程与实际验证

外置原件根 `E:/DevCache/artifacts/asam-ui/v2-032/dev-r1`。包源固定3a710，build-input-tree.txt登记；普通 UI 完整 build（JS/声明/CSS、885 type-only 上游声明）及当前 Pro 聚合 build:js/build:types均成功，正常 pnpm pack生成双 tar。自有 consumer实际双tar安装，未使用源码alias或其他角色可变 node_modules/dist。离线安装日志的 downloaded=2指本地file tar导入；命令 --offline，没有网络下载升级。

源码9组真实 Router 测试覆盖参数/query/命名跳转、取消/确认异常恢复、菜单非法/重复/循环/未知资源/宿主路径与名称冲突、晚到/卸载、缓存预算/身份/排序及多实例所有权。类型正反例与完整SFC、普通生产构建通过。初始普通消费构建1835模块、JS约1.2MB（gzip约386KB），保留Vite大chunk警告，不声称全库性能；缓存预算默认10个保留身份，无缓存当前页可额外占一个活动实例。

真实 Chrome 矩阵覆盖初始深链接、输入/滚动保留、单页刷新不伤其他实例、前进后退、确认取消、原生拖放与键盘、当前菜单移除、同源/跨源iframe与实际DOM来源边界、脚本协议/allowlist拒绝、旧节点事件/无关消息隔离、原生全屏和真实Permissions-Policy拒绝恢复、四尺寸、亮暗主题、1280/390及动作可达、整应用释放；双应用 Probe 检验真实挂载/激活/停用/卸载、共享cacheKey、LRU/无缓存/关闭销毁。完整运行包含真实 lifecycle计数，不以数组长度或截图替代。

`verified-variant-r6` 保存实际修改菜单标题、路由参数名、页面正文、缓存预算10→2后的 before/modified源码、类型、生产构建、浏览器回执和真实命令退出码。最终恢复原版后以 `verified-final-r6/commands.json` 的全部exitCode=0作为送测条件；新增其他实例全屏保护验证列在最终浏览器回执。最终源码、双tar/安装、dist、资料及所有原件bytes/hash由receipt-final-r3固定，不继承旧候选签名。

## 首失败与修复

- 首unit及UI构建在依赖未装完整时报缺少devtools/Element Plus类型，首日志保留。首类型检查同时发现 RouterView normalized类型与深readonly位置类型不匹配，已修；类型工具尚未就绪时报bin缺失保留。一次pnpm exec自动复核触发重复安装，仅中断本次重复会话；原有效安装自然完成，后续显式verifyDepsBeforeRun=never。
- browser-first：水平菜单的尺寸反馈出现ResizeObserver错误，改为已验布局公开sidebar槽中的原生垂直Menu；Escape退出全屏未得到真实确认，改实际退出按钮并等待fullscreenElement为空。browser-r2完整通过，首失败不删除。
- 暗色截图发现页面背景与文字对比不足；普通App引入EP同版暗色变量，在应用根管理html.dark并卸载恢复原主题。修正后390/1280图像已复核。
- 内联修改命令首试因PowerShell/JS引号失败，在执行修改前报Unexpected eof；随后两条variant-type/build只验证原版，不作为修改版证据。改用variant.mjs逐项断言修改并保存before/modified。
- verified-variant首完整测试发现旧 iframe节点事件通过当前session表达式改写新状态；改为核事件currentTarget自身data-navigation-session与当前代次，verified-variant-r2实际旧事件/消息隔离通过。原FAIL及commands.json保留。

## 后继与边界

本记录仅DEV实现与自测。完整候选交两主控后，独立QA须对完整base/head实际OCR preview/rule/逐文件源码审查及适用QA，通过后独立ACC；不以此文档代签。原角色和空间保留供整改，不自归档回收。集入目标仅codex/v2，开发根单写canonical。

未验证真实后端/CL、远端认证/拒绝嵌入站点实际功能、其他浏览器、真实读屏、完整SSR/hydration、上游全部组合及全库性能。SSR仅保证可导入模板模块不在顶层访问DOM；ordinary main是浏览器入口。没有推送、部署、发表、云写入或新增角色/心跳。

最终脚本补核记录：verified-final的第二次原生全屏搭建未完成并已中断本次测试；verified-final-r2以5秒超时明确失败，原日志/截图保留。后继在已实际进入全屏的主Embed旁挂载并卸载另一真实Embed，直接核原全屏仍由主实例持有；不把测试搭建失败计为通过。菜单内部索引同时按item/group及id编码，避免业务id与分组索引碰撞；浏览器通过真实嵌套菜单点击核跳转与活动态。

1280截图补核发现ordinary main漏导入EP基础CSS，菜单显示默认列表；首5bb3候选的完整32源/1829普通dist三方配对与ZIP保留在receipt-final，仅为历史未送QA。当前入口显式先导入同版element-plus/dist/index.css，按新原版/修改版复验和新receipt-final-r3送测，不把旧视觉检查冒新候选通过。

末轮普通App主题接入改用基线已包含的公开AsamApplicationProvider，完整ASAM/EP变量在应用容器内继承，避免只切EP暗色造成ASAM菜单文字对比不足；移除普通App的documentElement主题写入。只消费当前已验公开入口，导航运行时仍仅持有宿主router与策略，无031共享源码改动或新增等待。

菜单通过原生公开background-color/text-color/active-text-color消费ASAM语义tokens，暗色下同时核真实computed背景与文字颜色，保留亮暗主题继承。新包收据可用NAV_PACKAGE_RECEIPT指向本角色receipt-final/manifest.json，重核同tar哈希与全部普通dist/解包/安装字节，复用原解包不复制重复包原件。

收据末态修正：receipt-final和receipt-final-r2中的当前生产日志原记录均为0字节，脚本末尾stdout完成行随后追加；精确before/after与原SHA分列在producer-log-audit-complete.json，原清单/原件不改。当前生成器成功时静默，退出后再读INDEX，新的receipt-final-r3需逐件复核全清单，无泛跳过；本修正只影响收据/交付文字，全部应用源码与verified-final-r6、verified-variant-r6仍逐字节相同。

## Q032-01 原QA整改候选

原QA固定6588a08复现：/old 当前页更新为 /bad/:id( 时，注册失败前已跳转/safe。首FAIL原件保留于E:/DevCache/artifacts/asam-ui/v2-032/qa-r1/repro.mjs与repro-r3.txt。当前在任何确认/导航/宿主注册前，以同版Vue Router的公开createRouterMatcher和宿主parser options预检完整候选。临时matcher只调用上游注册解析器，不承担路由/history功能。新增真实router.addRoute抛错对照、旧route对象/活动页签/缓存页/菜单版本/宿主records不变与随后合法更新恢复的源码回归；浏览器另核草稿与挂载/停用/卸载计数均不变。

本轮原版/修改版命令与回执分别在q032-01-final、q032-01-variant，新增源码回归共10组；完整新head及源码ZIP、复用同源双tar的逐字节配对由receipt-q032-01固定。旧receipt-final-r3及先前PASS/FAIL不覆盖，不作为新候选QA通过。包源码/锁/公开根出口没有变化，继续由原QA独立复审与整卡验证，不创建ACC或新角色。
