import { readFileSync } from 'node:fs';
import { join, isAbsolute, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export function configureHarnessTools() {
	const [major, minor] = process.versions.node.split('.').map(Number);
	if (major !== 22 || minor < 19) throw Error('ASAM_NODE22_REQUIRED');
	const root = fileURLToPath(new URL('../../../', import.meta.url));
	const settings = JSON.parse(readFileSync(join(root, 'harness-runtime.json'), 'utf8'));
	if (
		settings.schemaVersion !== 1 ||
		!isAbsolute(settings.toolsConfigRoot || '') ||
		!isAbsolute(settings.cacheRoot || '') ||
		(settings.binary && !isAbsolute(settings.binary))
	)
		throw Error('HARNESS_TOOL_CONFIGURATION_REQUIRED');
	// Bind only this child process. Do not inherit a sibling host's profile or
	// read its tool settings when reusing the unchanged shared CLI wrapper.
	process.env.ASAM_TOOLS_CONFIG_DIR = settings.toolsConfigRoot;
	process.env.ASAM_OCR_CACHE_ROOT ||= settings.cacheRoot;
	if (settings.binary) process.env.ASAM_OCR_BINARY ||= settings.binary;
	delete process.env.CODEX_HOME;
	delete process.env.WORKBUDDY_CONFIG_DIR;
	return settings;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try {
		configureHarnessTools();
		await (await import('../../../tools/v2/hosts/agent-entry.mjs')).main();
	} catch (error) {
		console.error(
			JSON.stringify({
				status: 'partial',
				code: error.message,
				action: '通过同版统一安装器核对当前 Harness profile 的独立 Node 22 与工具设置。'
			})
		);
		process.exitCode = 2;
	}
}
