<template>
	<figure v-if="image">
		<img v-if="!failed" :src="image.src" :alt="image.alt" @error="failed = true" />
		<figcaption v-else role="status">{{ image.alt }} · 图片不可用</figcaption>
	</figure>
</template>
<script setup lang="ts">
import { ref, watch } from 'vue';
const props = defineProps<{ image?: { src: string; alt: string } }>();
const failed = ref(false);
watch(
	() => props.image?.src,
	() => {
		failed.value = false;
	}
);
</script>
