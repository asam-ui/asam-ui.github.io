# 043 当前角色查询示例补充

本补充只更新既有 functional.v2-043 的两个完整模板文件：UsersPage.vue 与 RoleQueryField.ts。固定产品源为79b70b2f305f8b43c508b6eda2879a0e88095245；原05f6c4d/c942功能输入及验收历史保留，不改写原整卡、预算、runtimePairing或其他来源资格。

UsersPage.vue 的角色查询显式调用 createRoleQueryField；必须连同同目录 RoleQueryField.ts 消费，不能只替换页面。其余相对依赖沿既有 administration、security、navigation 文件，公开 API/Types/协议与这些依赖没有变化。当前源补充的逐文件 sourceSha 优先描述这两文件；sources.product 与 versions.sourceSha 仍描述原功能输入基线。

原 single 定义和 source 由模板桥闭包保留，useAsamFieldOptions 仍唯一持有 model/session/active/runtime 下的选项读取、取消、标签与迟到处理。AsamSelectV2 只渲染完整 options，不分页、不 remote/filter、不截30项；数值0与字符串0保型。clear/query/submit 复用原单选语义，加载、错误、重试、未解析标签、focus/refresh 保留。只影响 UsersPage 的 role 查询，编辑 roleIds 与其他字段不改，不是公共包新导出或所有字段的 drop-in 替代。

047 当前 social/security 源、公开契约和用法无差额；原资料已经包含 assetsInlineLimit:0。既有39 ready与其余 functional 输入照原范围继承。本补充不是43卡重新测试、SDK升级、宿主安装或全部知识运行配对通过。
