import type { InjectionKey } from 'vue';
import type { PreferenceController } from '../Preferences.js';
export const preferenceKey: InjectionKey<PreferenceController> = Symbol('preferences');
