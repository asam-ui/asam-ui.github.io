<template>
	<template v-for="item in children" :key="item.id">
		<AsamSubMenu
			v-if="items.some((entry) => entry.parentId === item.id)"
			:index="JSON.stringify(['group', item.id])"
		>
			<template #title>{{ item.title }}</template>
			<AsamMenuItem :index="JSON.stringify(['item', item.id])">{{ item.title }}</AsamMenuItem>
			<NavigationMenuItems :items="items" :parent-id="item.id" />
		</AsamSubMenu>
		<AsamMenuItem v-else :index="JSON.stringify(['item', item.id])">
			<span v-if="item.icon" aria-hidden="true">{{ item.icon }}</span>{{ item.title }}
		</AsamMenuItem>
	</template>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import { AsamMenuItem, AsamSubMenu } from '@asam-ui/ui';
import type { NavigationItem } from './Types.js';
const props = defineProps<{ items: readonly NavigationItem[]; parentId?: string }>();
const children = computed(() =>
	props.items.filter((item) =>
		props.parentId
			? item.parentId === props.parentId
			: !item.parentId || !props.items.some((entry) => entry.id === item.parentId)
	)
);
</script>
