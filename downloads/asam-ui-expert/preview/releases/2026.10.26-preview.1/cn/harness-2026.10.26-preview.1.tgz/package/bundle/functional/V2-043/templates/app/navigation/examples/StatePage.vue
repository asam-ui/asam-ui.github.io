<template>
	<section>
		<h2>{{ label }} · {{ route.params.id ?? '首页' }}</h2>
		<label>本页草稿 <input v-model="draft" data-draft></label>
		<div ref="scroll" class="state-scroll" @scroll="position = scroll?.scrollTop ?? 0">
			<p v-for="line in 30" :key="line">可修改页面内容 {{ line }}</p>
		</div>
		<output>滚动位置：{{ position }}；草稿：{{ draft }}</output>
	</section>
</template>
<script setup lang="ts">
import { onActivated, onDeactivated, onMounted, onUnmounted, ref } from 'vue';
import { useRoute } from 'vue-router';
withDefaults(defineProps<{ label?: string }>(), { label: '应用页面' });
const route = useRoute();
const draft = ref('');
const position = ref(0);
const scroll = ref<HTMLElement>();
const emit = defineEmits<{ (event: 'lifecycle', value: string): void }>();
onMounted(() => emit('lifecycle', 'mounted'));
onActivated(() => {
	if (scroll.value) scroll.value.scrollTop = position.value;
	emit('lifecycle', 'activated');
});
onDeactivated(() => emit('lifecycle', 'deactivated'));
onUnmounted(() => emit('lifecycle', 'unmounted'));
</script>
<style scoped>
.state-scroll {
	height: 160px;
	overflow: auto;
	border: 1px solid var(--el-border-color);
}
</style>
