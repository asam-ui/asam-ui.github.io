# 应用安全模板

V2-033 / A03、A04、A12。这是应用源码，复制 security 与同版 navigation 两目录到自己的 Vue Router 应用；UI/Pro 包没有认证单例、业务路由或凭据存储。配套版本 0.1.0-alpha.1，Vue 3.5.34 / Vue Router 4.6.3 / EP 2.14.7。公开协议见 Types.ts、API.md；Agent 从 capability.json、AGENT.md 发现。

examples/main.ts 与 App.vue 是正常应用入口，使用公开 `@asam-ui/ui`、`@asam-ui/pro` 和同版可修改导航源码，无源码 alias 或手补声明。生产服务器应将应用内 history 路由回退到 index.html。本地 fixture 无跨刷新持久化，刷新页面后回到匿名；真实恢复行为由宿主已有会话适配器决定。运行方法见 tests/v2/security/README.md。

宿主实现 SecurityAdapter：登录、恢复、刷新、登出、上下文切换返回经过归一化的展示主体。宿主拥有 HTTP client、Cookie/token、实际存储、后端 URL/DTO、组织租户列表和最终鉴权。模板不猜 CL 接口，不提供 OAuth 或后端租户管理平台。不要把原始响应、密码、token放进 SecuritySubject、错误消息、DOM、日志或 URL。控制器只复制明确字段；异常使用固定本地消息。宿主凭据提交也必须检查 request.isCurrent()；取消信号只是辅助，不能使忽略取消的外部写入变得安全。远端登出与后继登录若并发，需要宿主按会话标识隔离远端操作。

每次恢复/登录/刷新/上下文切换先关闭权限并触发同步 onInvalidate。宿主在此清除独立数据读取、选择、详情和敏感草稿。导航桥销毁旧导航（路由、页签和缓存）并转公开安全页，认证成功才创建新实例。不要用旧导航的 reload(scope) 代替身份隔离，不得在身份改变后用 dirty 确认保留旧页面。若要取消切换，应在调用 switchContext 之前确认。DataPage 示范读取的本地代次、控制器 epoch 与卸载检查，旧读取即使忽略 AbortSignal 也不会写回。

权限必须明确、同步，分别检查 role 和 permission，不推导超级管理员或通配符。入口 visible 只影响菜单；真实 router guard 独立检查，调用业务写入前再次检查 write/readOnly。后端最终拒绝仍须正常处理。非 authenticated、过期、空/错误权限都关闭受限操作。刷新不自动重发业务写入，不循环刷新；并发只合并同代次刷新。失败后主体清空，可明确重试登录/恢复；没有保留凭据用于自动重试。

App 的身份选择用于本地演示，不能作为生产身份来源。替换 Fixture.ts 为实际后端 adapter，再按真实资源配置 rules/items/components/publicPaths。所有 protected path 必须有规则，未知路径回安全页。安全页必须在 publicPaths 中。普通示例明确区分数值0、字符串'0'和null，作用域键使用JSON数组避免拼接碰撞。多个应用/SSR请求各建实例，卸载同时 dispose桥及控制器。

已有项目迁移：将认证状态从全局UI配置移到应用实例；将旧菜单可见性规则补到router guard及写调用前检查；为数据读取补epoch/销毁检查；在上下文切换前拆除旧缓存。此模板没有修改已有包契约，不要求迁移其他组件。尚未验证真实CL/真实后端、其他浏览器、OS读屏及完整SSR hydration。

同步重入：每次操作在通知之前独立绑定token与AbortController，abort、状态watch或onInvalidate回调发起的新操作使旧操作立即失效。旧操作返回后不再通知旧代次的后续监听器、不调用尚未开始的adapter、不更新新状态或timer。刷新合并槽也在通知前绑定请求所有权；旧操作结算不能清新槽。同代监听器内再次refresh仍复用同一promise，新身份则发新adapter调用。清理监听器抛错时继续当前代次其余清理并进入固定错误状态，明确重试；抛错前已重入新代次时不覆盖新代次。dispose先进入终态，所有同步回调均不能重新登录。宿主仍负责凭据提交检查和最终后端鉴权。
