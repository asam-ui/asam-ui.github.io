<template>
	<section
		v-if="c.selected.value"
		class="social-detail"
		role="region"
		aria-label="帖子详情"
		tabindex="-1"
		ref="panel"
	>
		<header>
			<h2>正文与评论</h2>
			<button @click="close">返回信息流</button>
		</header>
		<p>
			{{ c.selected.value.author.name ?? '作者未知' }} ·
			{{ c.selected.value.time ?? '时间未知' }}
		</p>
		<p class="social-body" data-full-body>{{ c.selected.value.body }}</p>
		<p v-if="!c.list.resultReady.value" role="status">
			信息流正在更新或已过期；当前详情为旧快照，写入已暂停。
		</p>
		<h3>评论 · {{ c.commentTotal.value }}</h3>
		<p v-if="!c.allowed('comments')" role="status">当前没有评论读取权限。</p>
		<p v-if="c.commentsLoading.value" role="status">评论读取中…</p>
		<p v-if="c.commentsError.value" role="alert">
			{{ c.commentsError.value }}<button @click="c.loadComments()">重试评论</button>
		</p>
		<p
			v-if="
				c.allowed('comments') &&
				!c.commentsLoading.value &&
				!c.commentsError.value &&
				!c.comments.value.length
			"
		>
			暂无评论
		</p>
		<ol class="social-comments">
			<li
				v-for="comment in c.comments.value"
				:key="idKey(comment.id)"
				:data-comment="idKey(comment.id)"
			>
				<strong>{{ comment.author.name ?? '作者未知' }}</strong
				><small>{{ comment.time ?? '时间未知' }}</small>
				<p class="social-body">{{ comment.body }}</p>
				<button
					v-if="comment.canDelete"
					:disabled="
						!c.allowed('delete') || !!c.pending.value || !c.list.resultReady.value
					"
					@click="confirmId = comment.id"
				>
					删除这条评论
				</button>
			</li>
		</ol>
		<nav aria-label="评论分页">
			<button
				:disabled="
					c.commentPage.value <= 1 || c.commentsLoading.value || !c.allowed('comments')
				"
				@click="c.loadComments(c.commentPage.value - 1)"
			>
				上一页评论</button
			><span>第 {{ c.commentPage.value }} 页</span
			><button
				:disabled="
					c.commentPage.value * 20 >= c.commentTotal.value ||
					c.commentsLoading.value ||
					!c.allowed('comments')
				"
				@click="c.loadComments(c.commentPage.value + 1)"
			>
				下一页评论
			</button>
		</nav>
		<form @submit.prevent="submit">
			<label
				>写下评论<textarea
					v-model="c.draft.value"
					maxlength="10000"
					:readonly="!c.allowed('comment')"
					@compositionstart="composing = true"
					@compositionend="composing = false"
				/></label
			><button
				type="submit"
				:disabled="
					!c.allowed('comment') ||
					!!c.pending.value ||
					!c.draft.value.trim() ||
					!c.list.resultReady.value
				"
			>
				提交评论</button
			><button type="button" @click="c.cancelDraft">取消编辑并保留草稿</button>
		</form>
		<div
			v-if="confirmId !== null"
			role="alertdialog"
			aria-label="确认删除评论"
			aria-modal="false"
		>
			<p>删除后无法从本示例恢复，确认删除这条自己的评论？</p>
			<button
				@click="remove"
				:disabled="!c.allowed('delete') || !!c.pending.value || !c.list.resultReady.value"
			>
				确认删除</button
			><button @click="confirmId = null">保留评论</button>
		</div>
	</section>
</template>
<script setup lang="ts">
import { nextTick, ref, watch } from 'vue';
import type { SocialController } from '../Social.js';
import type { SocialId } from '../Types.js';
import { idKey } from '../Validation.js';
const props = defineProps<{ c: SocialController }>();
const confirmId = ref<SocialId | null>(null),
	composing = ref(false),
	panel = ref<HTMLElement>();
watch([() => props.c.selected.value?.id, () => props.c.list.session.value], async () => {
	confirmId.value = null;
	composing.value = false;
	await nextTick();
	panel.value?.focus();
});
function close() {
	props.c.close();
	const element = Reflect.get(props.c, 'returnFocus');
	void nextTick(() => {
		if (element instanceof HTMLElement && element.isConnected) element.focus();
	});
}
function submit() {
	if (!composing.value && props.c.selected.value)
		void props.c.write({
			kind: 'comment',
			postId: props.c.selected.value.id,
			body: props.c.draft.value
		});
}
function remove() {
	const id = confirmId.value;
	confirmId.value = null;
	if (id !== null && props.c.selected.value)
		void props.c.write({ kind: 'delete', postId: props.c.selected.value.id, commentId: id });
}
</script>
