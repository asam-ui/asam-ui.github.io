<template>
	<main class="social-page social-tech" :data-size="size ?? 'default'">
		<header class="social-tech-header">
			<div>
				<span>[ OPEN CHANNEL / 03 ]</span>
				<h1>{{ socialConfig.tech.title }}</h1>
			</div>
			<dl>
				<dt>IDENTITY</dt>
				<dd>{{ host.security.state.value.subject?.name ?? 'OFFLINE' }}</dd>
				<dt>SESSION</dt>
				<dd>{{ host.security.state.value.status }}</dd>
			</dl>
		</header>
		<div class="social-tech-layout">
			<section class="social-tech-stream">
				<header>
					<h2>ACTIVITY / 活动记录</h2>
					<p>{{ socialConfig.tech.description }}</p>
				</header>
				<SocialFeed :c="c" :size="size" grid />
			</section>
			<aside class="social-tech-inspector">
				<h2>[ READING DESK ]</h2>
				<p v-if="!c.selected.value">从活动中打开正文与评论。完整原文将在这里显示。</p>
				<SocialDetail :c="c" />
				<dl>
					<dt>RESULT</dt>
					<dd>
						{{
							c.list.page.stale.value
								? 'STALE'
								: c.list.page.loading.value
									? 'PENDING'
									: 'CURRENT'
						}}
					</dd>
					<dt>WRITE</dt>
					<dd>{{ c.writeStatus.value }}</dd>
				</dl>
			</aside>
		</div>
	</main>
</template>
<script setup lang="ts">
import type { SocialPageProps } from './Types.js';
import { socialConfig } from './config.js';
import { useSocialPage } from './useSocialPage.js';
import SocialFeed from './parts/SocialFeed.vue';
import SocialDetail from './parts/SocialDetail.vue';
import './Social.css';
const props = defineProps<SocialPageProps>();
const c = useSocialPage(props);
defineExpose({ controller: c });
</script>
