# 用户、角色与菜单权限管理模板

P25/P26/P27 的可编辑 Vue 3 应用模板。入口 `AdministrationApp.vue`，三页是
`UsersPage.vue`、`RolesPage.vue`、`MenusPage.vue`，授权交互为 `GrantEditor.vue`。
复用正常 `@asam-ui/ui` / `@asam-ui/pro`，不提供认证服务或真实 RBAC 引擎。

复制本目录及相邻 `../app/security`、`../app/navigation` 到普通 Vue 应用，保留相对路径。
安装仓库锁定版本的 UI/Pro、Vue、Element Plus、vue-router，通过 `examples/main.ts`
启动。入口依次加载 Element Plus 的 `element-plus/dist/index.css`、UI/Pro 样式。
`examples/App.vue` 是完整本地合成宿主，生产接入替换其 adapter。
普通 consumer 必须 `verify-deps-before-run=error`，禁止使用源码 alias 或借用别的任务的 node_modules。
pnpm11 的实际声明写在 consumer 的 `pnpm-workspace.yaml`：`verifyDepsBeforeRun: error`；工程进程设置 `pnpm_config_verify_deps_before_run=error`，并在该 consumer cwd 实际运行 `pnpm config get verifyDepsBeforeRun` 核 error。`.npmrc` 文字不能作为 pnpm11 已生效的证据。

## 同源应用与设计

使用 `minimal.html`、`brand.html`、`technology.html` 三个独立生产入口，或
`?family=minimal`、`?family=brand`、`?family=technology` 启动三个完整应用外壳。
三族共享同版三页面，完整路由为 `/users`、`/roles`、`/menus`，公开恢复页为 `/safe`。
三风格的布局分别为横向编辑式目录、品牌侧栏、窄轨科技控制台；支持父级明暗、390 窄屏、
键盘焦点、40/36/32/28 四档。轻反馈仅按钮颜色与位移，减少动态时关闭，不等待入场动画才可操作。

采用 Skill：

- `C:/Users/Administrator/.agents/skills/minimalist-ui/SKILL.md`：横向简约外壳的留白、字级、细分隔。
- `C:/Users/Administrator/.agents/skills/design-taste-frontend/SKILL.md`：只借用品牌构图和层次；该 Skill 明确主要面向营销页面，本模板不搬营销 hero、React/Tailwind 或新图标依赖。
- `C:/Users/Administrator/.agents/skills/high-end-visual-design/SKILL.md`：科技外壳的窄轨、对比和节奏；不采用巨大圆角、嵌套卡片或遮挡数据的动画。

项目的 Vue/ASAM、tokens、可访问性及立即可操作要求优先于上述 Skill 的视觉偏好。

## 宿主职责

`Types.ts` 定义稳定协议。宿主持有 security、runtime、writes、operations、receipts、services 和 size。
页面只释放自己的 watch/读请求/订阅/控制器；`AdministrationApp` 释放自己的导航 bridge/guard，
不 dispose 借入的 security/router/runtime/写协调器。`examples/App.vue` 因为创建了这些资源，才在卸载时释放。
每个实例使用自己的 router 和 runtime；可以借同一个 security 与宿主写回执。

权限来源为 033 `security.check/permission`；每个读取路由都有独立明确规则。
菜单隐藏仅控制展示。写前同步检查 `read`、`write` 和 readOnly，pending/error/失效关闭受限页。
033 失效同步清草稿和树，不通过 dirty 确认保留失效资料。宿主先切 runtime scope，再建立新页面。
服务替换由宿主明确确认；其引用及 version 参与页面代次，旧读取即使忽略 Abort 也不覆盖新页面。

默认合成字段不是用户指定的 CL 业务：100 用户、30 角色、50 节点、20 条/页、4 查询条件、
6 编辑字段，100ms 受控读取。没有真实密码、真实端点、超级管理员或通配符推导。
原始异常不直接展示。adapter 返回的消息/字段错误必须已经是展示安全内容，不能携带后端原异常或凭据。

## 写入与恢复

CRUD 用 024 `useAsamCrudController/AsamCrudPage/AsamCrudServices`。版本随编辑 payload、删除目标冻结；
服务确认未应用才是 failure；无法确定是 unknown。unknown 保留原 operationId，仅核实，不自动重发。
删除逐目标保留结果；写成功而列表刷新失败时只重试列表，不重复写。

授权是 **direct grant** 集合，不推导继承权限。树勾选使用 check-strictly；结构父节点/禁用节点不新增，
过滤不丢隐藏项。未知或当前不可授的旧 grant 按 load 返回的 unavailable preserve/reject 策略处理。
preserve 项在摘要中可见且不能被“取消可见”静默清除。相同 scope/对象的未决回执阻止换 ID 重发。
保存期间可以继续修改树；成功回执只更新所发快照，后继草稿继续 dirty。确认前、调用前、异步后核当前代次。
离开范围后仍留 host.receipts，宿主可用原 serviceVersion 对原操作核实。

菜单树在显示前整体验证重复、孤儿、循环与非法 typed ID，坏输入整次拒绝。UI key 用类型化 JSON tuple，
回传仍为原 ID；数字 `0` 和字符串 `'0'`、根 `null` 分开。树行为由原生 AsamTree 实现。

## 两种宿主适配

`Codecs.ts` 的 DirectoryUserDTO 与 CatalogUserDTO 字段结构不同；`examples/Fixture.ts`
分别实际用这两种映射读取/写入。Directory 保存全量 grant，Catalog 明确计算 set 差额；UI API 保持同一集合协议。
替换时实现 `AdministrationServices`，自行适配 DTO/版本/服务鉴权/引用限制；不在 UI 内猜 URL 或授权规则。
角色候选来自 roleOptions，未知用户角色按宿主 unknownRoles 策略保留或拒绝，不从候选缺失推断新增授权。

修改步骤和验证入口见 [AGENT.md](./AGENT.md)、[API.md](./API.md)、[Migration.md](./Migration.md)。
