/** Editable information architecture and copy, shared with the Agent recipe. */
export const socialConfig = {
	minimal: { title: '写下值得留下的事。', description: '公共笔记 / 设计与工程的日常观察' },
	brand: { title: '共同创作的日常', description: '一个为创作者留白的社区。' },
	tech: { title: 'SOCIAL SIGNAL', description: '公开记录 / 保留上下文 / 有依据的回应' }
};
