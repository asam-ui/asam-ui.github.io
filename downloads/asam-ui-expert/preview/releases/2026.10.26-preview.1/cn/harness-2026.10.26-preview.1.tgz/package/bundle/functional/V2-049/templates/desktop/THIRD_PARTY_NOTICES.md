# 来源与许可材料

本卡窗口控制器、SFC与测试为本仓库新增源码，适用仓库LICENSE。没有复制Element Plus执行算法、系统桌面代码、外部图片/字体或其他模板实现。

运行依赖通过正常完整包消费。UI包带有LICENSE、Element Plus与icons-vue的LICENSE；Pro包带LICENSE及其原第三方声明。Vue、Vue Router、Element Plus、markdown-it及构建工具由consumer正常pnpm锁记录实际版本。`snapshot.mjs`对1874项已签UI/Pro载荷逐文件核实际安装raw字节，许可文件随载荷核验，不用写入此文档替代实际许可文件。

精确包SHA、来源b9 producer、消费签名及实际安装身份在外置package-inputs.json与各阶段SNAPSHOT.json。完整库许可适用性沿用已验包的声明，本卡不授予新的商业或发布权利。
