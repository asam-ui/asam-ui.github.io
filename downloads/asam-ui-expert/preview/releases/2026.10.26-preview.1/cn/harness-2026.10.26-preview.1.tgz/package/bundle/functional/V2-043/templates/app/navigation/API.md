# 导航 API 0.1.0-alpha.1

源码类型是 Types.ts，控制器类型由 Navigation.ts 导出。此 API 是 Vue 3.5.34 / Vue Router 4.6.3 应用适配，其他 router 未验证。

| 输入                            | 类型/默认                   | 契约                                                                                        |
| ------------------------------- | --------------------------- | ------------------------------------------------------------------------------------------- |
| NavigationItem                  | id/path/title/resource 必填 | id 稳定；parentId 是同版本菜单 id；path 为绝对 Router 路径；location 可指定带参数的菜单落点 |
| icon/hidden/pinned/cache/iframe | 可选，cache 默认 true       | 图标为宿主显示标识；iframe 为宿主页面元数据，不隐式加载未知远端内容                         |
| router/components/load/fallback | 必填                        | router 归宿主；资源为显式 allowlist；load 接受 signal/scope；fallback 是宿主静态安全页      |
| confirm                         | 可选，默认允许              | navigate/close/refresh/update，接收当前 route；false 或异常取消操作                         |
| visible                         | 可选，默认显示              | 与 hidden 共同过滤菜单，只影响入口                                                          |
| cacheKey                        | 可选，默认 fullPath         | 必须返回非空 string；同 route id+key 共享状态                                               |
| maxCache/scope                  | 10/空字符串                 | maxCache 为正整数；scope 传给每次加载，不自动替换业务身份                                   |

| 控制器方法                          | 返回                | 行为                                                        |
| ----------------------------------- | ------------------- | ----------------------------------------------------------- |
| reload(scope?)                      | Promise<boolean>    | 原子校验安装完整菜单版本；最新代生效                        |
| navigate(location, replace?)        | Promise<boolean>    | 使用宿主 router 的真实匹配/history/guards                   |
| location(id)                        | {name:string}       | 返回本实例拥有的命名位置，可添加 params/query 后交 navigate |
| close(ids)/closeOthers()/closeAll() | Promise<boolean>    | 保护 pinned，先确认/跳转再移除和释放缓存                    |
| refresh(id?)                        | Promise<boolean>    | 确认后更新目标身份 epoch，其他身份保留                      |
| move(id,targetId)                   | void                | 非固定页重排，过期或未知 id 无操作                          |
| component(id)                       | Component/undefined | 读取明确本地映射                                            |
| dispose()                           | void                | 幂等释放自身路由、guards、加载和页面状态                    |

只读 ref：menu、visibleMenu、tabs、pages、active、error、loading、revision。router 是原宿主引用。NavigationTab 的 id/fullPath 与 cacheKey/epoch 分别表示页签与页面实例；禁止宿主原地修改状态。通过控制器操作。

NavigationShell props 为 controller、size?；header slot 无参数；无业务事件；公开 focusActive():Promise<void> 将焦点移到本实例当前页签。Shell 卸载调用 controller.dispose。NavigationPage/MenuItems 是内部应用源码组件，不是包级公共契约。

EmbedPage props 为 src、policy、title?；status(string) 事件；无 slot；公开 open(string):void 与 toggleFullscreen():Promise<void>。policy.resolve/allow 必填；sandbox=''、permissions=''、referrerPolicy='no-referrer'。错误以可恢复状态显示，无自动消息协议。原生全屏与 SSR 边界见 README。
