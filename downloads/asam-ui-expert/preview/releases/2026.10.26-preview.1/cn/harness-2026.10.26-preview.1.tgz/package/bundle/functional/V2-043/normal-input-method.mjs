import { readFileSync, writeFileSync, mkdirSync, cpSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { join } from 'node:path';
const root = process.cwd(),
	out = process.env.V2_ADMIN_OUTPUT;
assert.ok(out?.startsWith('E:/DevCache/'));
const hash = (b) => createHash('sha256').update(b).digest('hex');
const base = '1c3132e0cd1085daf9a210682a3222176c25bd5b';
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), base);
const readiness = JSON.parse(
	readFileSync(
		'E:/DevCache/artifacts/asam-ui/v2-043/controller/READINESS-R1-20261019/READINESS.json'
	)
);
const qualifications = [];
for (const f of readiness.files) {
	assert.equal(hash(readFileSync(f.source)), f.sha256, f.path);
	const blob = execFileSync('git', ['show', `${base}:${f.path}`]);
	assert.equal(hash(blob), f.sha256, f.path);
	const raw = readFileSync(join(root, f.path));
	if (!raw.equals(blob))
		assert.deepEqual(Buffer.from(raw.toString().replaceAll('\r\n', '\n')), blob, f.path);
	qualifications.push({
		path: f.path,
		worktreeSHA256: hash(raw),
		sourceSHA256: hash(blob),
		eolOnly: !raw.equals(blob)
	});
}
for (const d of readiness.dependencies) {
	assert.equal(hash(readFileSync(d.closeout)), d.closeoutSHA256);
	execFileSync('git', ['merge-base', '--is-ancestor', d.integration, base]);
}
const packages = JSON.parse(
	readFileSync('E:/DevCache/artifacts/asam-ui/v2-024/root-3f0791-qa/PACKAGES.json')
);
for (const p of [packages.ui, packages.pro]) assert.equal(hash(readFileSync(p.path)), p.sha256);
// No change to any producer public package source/config/lock. Reuse exact normal tarballs.
execFileSync('git', [
	'diff',
	'--exit-code',
	packages.target,
	base,
	'--',
	'packages/ui',
	'packages/pro',
	'pnpm-lock.yaml',
	'pnpm-workspace.yaml',
	'package.json',
	'tools'
]);
const session = readFileSync(
	'C:/Users/Administrator/.codex/sessions/2026/10/19/rollout-2026-10-19T11-54-27-01a1524b-e244-7e82-ac4b-d07aa3a571be.jsonl',
	'utf8'
)
	.split('\n')
	.filter(Boolean)
	.map((l) => JSON.parse(l))
	.find((x) => x.type === 'turn_context').payload;
assert.equal(session.model, 'gpt-6.1-sol');
assert.equal(session.effort, 'high');
assert.equal(session.approval_policy, 'never');
assert.equal(session.sandbox_policy.type, 'danger-full-access');
mkdirSync(out, { recursive: true });
writeFileSync(
	join(out, 'FIRST-ACTUAL.json'),
	JSON.stringify(
		{
			base,
			cwd: root,
			model: session.model,
			effort: session.effort,
			approval_policy: session.approval_policy,
			sandbox_policy: session.sandbox_policy,
			readinessVerified: readiness.files.length,
			qualifications,
			packages,
			node: process.execPath,
			nodeVersion: process.version,
			temp: process.env.TEMP,
			profile: process.env.V2_ADMIN_PROFILE,
			firstFailure:
				'Initial setup compared raw checkout bytes to fixed LF source; new Windows worktree has CRLF for app source. Git blobs and independently stored fixed raw sources match; only checkout EOL differs. Native first tool output retained in session.'
		},
		null,
		2
	)
);
const consumer = join(out, 'consumer');
assert.ok(!existsSync(join(consumer, 'package.json')));
mkdirSync(consumer, { recursive: true });
const manifest = JSON.parse(readFileSync('tests/v2/consumer/package.json'));
manifest.name = 'asam-v2-043-ordinary-consumer';
manifest.devDependencies.prettier = '3.9.6';
manifest.scripts = {
	build: 'vite build',
	typecheck: 'vue-tsc --noEmit -p tsconfig.json',
	test: 'node --loader ./tests/loader.mjs --test tests/*.test.mjs'
};
manifest.dependencies['vue-router'] = '4.6.3';
for (const name of ['ui', 'pro'])
	manifest.dependencies[`@asam-ui/${name}`] = `file:${packages[name].path.replaceAll('\\', '/')}`;
writeFileSync(join(consumer, 'package.json'), JSON.stringify(manifest, null, 2));
cpSync('patches', join(consumer, 'patches'), { recursive: true });
for (const f of ['.npmrc', 'pnpm-workspace.yaml'])
	cpSync(join('E:/DevCache/artifacts/asam-ui/v2-024/qa-r5/consumer', f), join(consumer, f));
writeFileSync(
	join(consumer, '.npmrc'),
	readFileSync(join(consumer, '.npmrc'), 'utf8') + '\nverify-deps-before-run=error\n'
);
writeFileSync(
	join(consumer, 'pnpm-workspace.yaml'),
	readFileSync(join(consumer, 'pnpm-workspace.yaml'), 'utf8') + '\nverifyDepsBeforeRun: error\n'
);
writeFileSync(
	join(consumer, 'tsconfig.json'),
	JSON.stringify(
		{
			compilerOptions: {
				target: 'ES2022',
				module: 'ESNext',
				moduleResolution: 'Bundler',
				strict: true,
				skipLibCheck: true,
				noEmit: true,
				types: ['vite/client'],
				allowImportingTsExtensions: true
			},
			include: ['**/*.ts', '**/*.vue']
		},
		null,
		2
	)
);
writeFileSync(
	join(consumer, 'index.html'),
	'<!doctype html><html lang="zh-CN"><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ASAM 管理模板</title><div id="app"></div><script type="module" src="/main.ts"></script></html>'
);
writeFileSync(
	join(consumer, 'vite.config.ts'),
	"import{defineConfig}from'vite';import vue from'@vitejs/plugin-vue';export default defineConfig({plugins:[vue()],build:{chunkSizeWarningLimit:2000,rollupOptions:{input:['index.html','templates/administration/minimal.html','templates/administration/brand.html','templates/administration/technology.html']}}});\n"
);
console.log(JSON.stringify({ consumer, receipt: join(out, 'FIRST-ACTUAL.json'), packages }));
