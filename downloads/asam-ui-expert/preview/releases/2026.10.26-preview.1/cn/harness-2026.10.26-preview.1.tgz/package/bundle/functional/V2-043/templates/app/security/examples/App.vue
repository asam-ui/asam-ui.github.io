<template>
	<AsamApplicationProvider
		class="security-application"
		:config="{
			size,
			colorMode: dark ? 'dark' : 'light',
			permission: { check: security.permission }
		}"
	>
		<header>
			<h1>安全应用示例</h1>
			<label
				>尺寸
				<select v-model="size" aria-label="尺寸">
					<option v-for="value in sizes" :key="value">{{ value }}</option>
				</select></label
			>
			<label><input v-model="dark" type="checkbox" />暗色</label>
			<label><input v-model="fixture.controls.fail" type="checkbox" />模拟认证失败</label>
			<label><input v-model="fixture.controls.readFail" type="checkbox" />模拟读取失败</label>
			<p role="status" aria-live="polite">会话：{{ state.status }} {{ state.error }}</p>
			<p v-if="state.subject">
				{{ state.subject.name }} / 角色：{{ state.subject.roles.join('、') || '无' }} /
				有效期：{{ new Date(state.subject.expiresAt).toLocaleTimeString() }}
			</p>
			<form @submit.prevent="login">
				<label
					>本地示例身份
					<select v-model="identity" aria-label="本地示例身份">
						<option v-for="(value, key) in identities" :key="key" :value="key">
							{{ value.name }}
						</option>
					</select></label
				>
				<AsamButton native-type="submit">登录 / 替换身份</AsamButton>
			</form>
			<AsamButton @click="security.restore()">恢复会话</AsamButton>
			<AsamButton :disabled="!state.subject" @click="security.refresh()">刷新会话</AsamButton>
			<AsamButton :disabled="!state.subject" @click="expire">模拟过期</AsamButton>
			<AsamButton @click="logout">登出</AsamButton>
			<label v-if="state.subject"
				>租户 / 组织
				<select aria-label="租户 / 组织" :value="contextIndex" @change="changeContext">
					<option
						v-for="(context, index) in state.subject.contexts"
						:key="index"
						:value="index"
					>
						{{ context.label }}
					</option>
				</select>
			</label>
			<AsamButton @click="router.push('/workspace')">直接访问工作台</AsamButton>
			<AsamButton @click="router.push('/audit')">直接访问审计</AsamButton>
			<AsamButton @click="router.back()">后退</AsamButton>
		</header>
		<NavigationShell
			v-if="navigation"
			:key="state.epoch"
			:controller="navigation"
			:size="size"
		/>
		<main v-else tabindex="-1" ref="safe">
			<h2>安全页</h2>
			<p>请登录或重试恢复；受限内容已清除。</p>
		</main>
	</AsamApplicationProvider>
</template>
<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, provide, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { AsamButton } from '@asam-ui/ui';
import type { AsamControlSize } from '@asam-ui/ui';
import { AsamApplicationProvider } from '@asam-ui/pro';
import { NavigationShell } from '../../navigation/index.js';
import { createSecurity } from '../Security.js';
import { createSecurityNavigation } from '../Navigation.js';
import { createFixture, identities } from './Fixture.js';
import type { FixtureIdentity } from './Fixture.js';
import { applicationKey } from './Context.js';
import DataPage from './DataPage.vue';
const router = useRouter();
const fixture = createFixture();
fixture.controls = reactive(fixture.controls);
const security = createSecurity({ adapter: fixture.adapter });
const state = security.state;
const identity = ref<FixtureIdentity>('editor');
const dark = ref(false);
const sizes: AsamControlSize[] = ['small', 'default', 'big', 'large'];
const size = ref<AsamControlSize>('default');
const safe = ref<HTMLElement>();
provide(applicationKey, { security, fixture });
const bridge = createSecurityNavigation({
	security,
	router,
	components: { workspace: DataPage, audit: DataPage },
	items: [
		{ id: 'workspace', path: '/workspace', title: '工作台', resource: 'workspace' },
		{ id: 'audit', path: '/audit', title: '审计资料', resource: 'audit' }
	],
	rules: {
		'/workspace': { permission: 'workspace:read' },
		'/audit': { role: 'auditor', permission: 'audit:read' }
	},
	publicPaths: ['/safe', '/'],
	safePage: '/safe'
});
const navigation = bridge.navigation;
bridge.resume(router.currentRoute.value.fullPath);
const contextIndex = computed(
	() =>
		state.value.subject?.contexts.findIndex(
			(c) =>
				c.tenant === state.value.subject?.scope.tenant &&
				c.organization === state.value.subject?.scope.organization
		) ?? -1
);
const remove = security.onInvalidate(() => {
	void nextTick(() => safe.value?.focus());
});
async function login() {
	await security.login(identity.value);
}
function expire() {
	bridge.forgetReturn();
	security.expire();
}
async function logout() {
	bridge.forgetReturn();
	await security.logout();
}
async function changeContext(event: Event) {
	const index = Number((event.target as HTMLSelectElement).value);
	const context = state.value.subject?.contexts[index];
	if (context) await security.switchContext(context);
}
onMounted(() => security.restore());
onBeforeUnmount(() => {
	remove();
	bridge.dispose();
	security.dispose();
});
</script>
<style>
.security-application {
	min-height: 100vh;
	background: var(--asam-color-surface);
	color: var(--asam-color-text-primary);
}
.security-application header {
	padding: 16px;
	display: flex;
	flex-wrap: wrap;
	gap: 12px;
	align-items: center;
}
.security-application h1,
.security-application header p {
	flex-basis: 100%;
	margin: 0;
}
.security-application label {
	display: inline-flex;
	flex-wrap: wrap;
	gap: 8px;
	align-items: center;
}
.security-application main,
.security-application section {
	padding: 16px;
}
.security-application input,
.security-application select {
	max-width: 100%;
	color: inherit;
	background: var(--asam-color-surface);
	border: 1px solid var(--asam-color-border);
	padding: 6px;
}
.security-application section label {
	display: flex;
	margin-block: 12px;
}
</style>
