<template>
	<section
		v-if="editor.status.value !== 'closed'"
		class="grant-editor"
		aria-label="直接授权编辑"
		:aria-busy="editor.status.value === 'loading'"
	>
		<h3 ref="heading" tabindex="-1">角色直接授权</h3>
		<p>仅保存明确勾选的直接授权；结构父节点和半选状态不会推导成后台权限。</p>
		<p role="status">
			{{ editor.message.value }} {{ editor.dirty.value ? '有未保存修改' : '' }}
		</p>
		<p v-if="editor.status.value === 'loading'">正在读取完整授权树</p>
		<AsamButton v-if="editor.status.value === 'error'" @click="editor.reload()"
			>重试授权读取</AsamButton
		>
		<template v-if="editor.snapshot.value">
			<label
				>定位权限
				<AsamInput v-model="editor.filter.value" aria-label="定位权限" :size="size"
			/></label>
			<div class="grant-actions">
				<AsamButton
					:size="size"
					:disabled="!editor.writable.value"
					@click="selectVisible(true)"
					>选择可见可授项</AsamButton
				>
				<AsamButton
					:size="size"
					:disabled="!editor.writable.value"
					@click="selectVisible(false)"
					>取消可见可授项</AsamButton
				>
			</div>
			<AsamTree
				ref="tree"
				:data="editor.tree.value"
				node-key="key"
				show-checkbox
				check-strictly
				default-expand-all
				:props="{ label: 'label', children: 'children', disabled: nodeDisabled }"
				:filter-node-method="filterNode"
				@check-change="checkChanged"
			>
				<template #default="{ data }"
					><span
						>{{ data.label }} ·
						{{
							data.source.grantable && data.source.enabled
								? editor.selected.value.includes(data.source.id)
									? '已授'
									: '未授'
								: '不可授'
						}}</span
					></template
				>
			</AsamTree>
			<p>全量已选 {{ editor.selected.value.length }} 项（过滤不改变集合）</p>
			<ul aria-label="全量已选摘要">
				<li v-for="id in editor.selected.value" :key="keyOf(id)">
					{{ label(id) }} · {{ typeof id }}:{{ id }}
				</li>
			</ul>
			<AsamButton
				:size="size"
				type="accent"
				:disabled="
					!editor.writable.value || !editor.dirty.value || editor.status.value !== 'ready'
				"
				@click="editor.save()"
				>保存直接授权</AsamButton
			>
			<AsamButton
				v-if="editor.status.value === 'unknown'"
				:size="size"
				@click="editor.verify()"
				>核实原授权操作</AsamButton
			>
			<AsamButton
				:size="size"
				:disabled="['saving', 'verifying'].includes(editor.status.value)"
				@click="editor.reload()"
				>重新加载授权</AsamButton
			>
		</template>
		<AsamButton :size="size" @click="close">关闭授权</AsamButton>
	</section>
</template>
<script setup lang="ts">
import { nextTick, onBeforeUnmount, ref, watch } from 'vue';
import { AsamButton, AsamInput, AsamTree } from '@asam-ui/ui';
import type { AsamControlSize, AsamTreeExpose, AsamTreeNodeData } from '@asam-ui/ui';
import { createGrantEditor } from './GrantController.js';
import { useAdministration } from './Crud.js';
import { keyOf } from './Tree.js';
import type { TreeNode } from './Tree.js';
import type { Id } from './Types.js';
defineProps<{ size?: AsamControlSize }>();
const emit = defineEmits<{ closed: [] }>();
const host = useAdministration();
const editor = createGrantEditor(host);
const leave = async () => !editor.dirty.value || host.confirm('授权修改尚未保存，确认离开并丢弃？');
host.leaves?.add(leave);
const tree = ref<AsamTreeExpose>(),
	heading = ref<HTMLElement>();
let syncing = false;
const filterNode = (value: string, data: AsamTreeNodeData) =>
	String(data.label).toLocaleLowerCase().includes(String(value).toLocaleLowerCase());
const nodeDisabled = (data: AsamTreeNodeData) =>
	!!data.disabled || !editor.writable.value || !['ready', 'saving'].includes(editor.status.value);
function checkChanged(data: TreeNode, checked: boolean) {
	if (!syncing) editor.toggle(data.source.id, checked);
}
function selectVisible(checked: boolean) {
	const ids =
		editor.snapshot.value?.nodes
			.filter((n) => tree.value?.getNode(keyOf(n.id))?.visible)
			.map((n) => n.id) ?? [];
	editor.selectVisible(checked, ids);
}
function label(id: Id) {
	return (
		editor.snapshot.value?.nodes.find((n) => Object.is(n.id, id))?.title ?? '服务保留的未知权限'
	);
}
watch(
	[editor.selected, tree],
	async () => {
		await nextTick();
		syncing = true;
		tree.value?.setCheckedKeys(editor.selected.value.map(keyOf));
		syncing = false;
	},
	{ deep: true }
);
watch(editor.filter, (v) => tree.value?.filter(v));
async function open(id: Id) {
	if (await editor.open(id)) {
		await nextTick();
		heading.value?.focus();
	}
}
async function close() {
	if (await editor.close()) emit('closed');
}
onBeforeUnmount(() => {
	host.leaves?.delete(leave);
	editor.dispose();
});
defineExpose({ open, editor });
</script>
<style scoped>
.grant-editor {
	border: 1px solid var(--asam-color-border, #ddd);
	padding: var(--asam-space-6, 24px);
	margin-top: 24px;
	background: var(--asam-color-surface, #fff);
}
.grant-actions {
	display: flex;
	flex-wrap: wrap;
	gap: 8px;
	margin-block: 16px;
}
ul {
	max-height: 160px;
	overflow: auto;
}
.grant-editor :deep(.el-tree) {
	max-height: 420px;
	overflow: auto;
}
:focus-visible {
	outline: 2px solid var(--asam-color-primary);
	outline-offset: 3px;
}
</style>
