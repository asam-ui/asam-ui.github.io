# Social API · 0.1.0

`Types.ts` 为唯一完整类型源；模板与 API/README/Agent/capability 同版。

| 入口                    | 契约                                                               |
| ----------------------- | ------------------------------------------------------------------ |
| 三种 `*SocialPage`      | `host: SocialHost`，可选 ASAM 四档 `size`；expose `controller`     |
| `createSocial(getHost)` | 每页面独立；返回 list、rows、selected、comments、draft、状态与动作 |
| `adaptSocial<P,C>`      | 运输层泛型与显式 post/comment DTO 映射；结果仍经完整校验           |
| `socialConfig`          | 三族标题与说明，可独立编辑                                         |

`SocialHost` 借入 security、service；可选 readonly/disabled，均参与最终服务 gate。
不可通过改按钮 disabled 来代替服务前和 await 后复核。

## Service

`feed(AsamListRequest, SocialRequest)` 返回 `{list,total}`，query/sort/currentPage/pageSize
完整复用 003/025 协议；宿主对全量源做筛选与排序后分页。
query 为 keyword、author（typed ID 或空字符串）、bookmarked。
`comments(postId,page,size,request)` 返回评论分页，默认 size=20。
`write({id,action},request)` 与 `resolve(originalId,request)` 返回判别联合：

- `success`：完整 `post`，包含权威 version/liked/likes/bookmarked/comments。
- `failed`：明确未完成，允许显式重试，草稿保留。
- `failed.message`：服务明确返回的显示原因，完整安全纯文本显示，不执行 HTML/链接。
- `unknown`：可能已提交；保留原 operation，不允许盲重发。

action 包括 like/bookmark（desired/version）、comment（完整 body）、delete（commentId）。
服务负责匹配真实权限、scope、当前对象、版本和幂等。
`SocialRequest` 含 subject、signal、isCurrent；宿主副作用提交前应再调用 isCurrent。
前端不能撤销已经被远端接受的操作。

## Controller

`list` 为公开 `AsamListController<SocialPost>`，拥有唯一信息流读事务。
`rows` 合并版本不倒退的权威结果；所有权在页面，不改变公共组件语义。
`open(row)` 仅接受当前成功结果，读取完整正文与评论；`close()` 清当前详情及草稿。
`loadComments(page?)` 明确评论分页/失败/重试，迟到结果不覆盖新帖。
`draft` 可编辑，提交期间允许继续输入；`cancelDraft()` 保留原值并给反馈。
草稿只在已有当前详情、允许评论且页面未清理/销毁时接受字符串写入。清理先撤销旧列表结果，
再清除详情等本地状态；这些同步通知触发的 open/read/write 与旧草稿回写均被拒绝。
清理期间再次更换服务时，外层清理结束后只恢复最新 host；借入 security 仍由宿主管理。
`allowed` 的清理状态可被 Vue computed 正常跟踪。`open` 只按 typed ID 查当前结果，
不会把调用方保存的旧 row 正文或计数重新导入当前详情与权威结果。
`write(action)` 最多一项未决写；`resolve()` 只核实 pending 原操作。
`writeError` 是失败原因的只读独立快照；恢复提示另保留在 `feedback`，
原因在新操作、切帖、换服务或身份清理时清空。异常对象不会直接充当服务原文。
`allowed(kind)` 用于展示且动作执行时重新校验。
`dispose()` 终止自己的 effectScope/读事务/订阅，不释放借入资源。

## 数据与错误

ID 为有限数字或非空字符串；0 与 '0' 不合并。
作者、原文、布尔状态、非负安全整数计数/版本、分页总数与重复 ID 整体校验。
未知状态、错误 postId、非法计数、缺少必需字段拒绝整体结果。
name/time/本地图片为可选项，缺省不伪造信息。
传输异常在写路径按 unknown 处理，因为客户端不能推断远端是否已生效。

## 权限

social.read、social.comments 分别读取信息流与评论。
social.like、social.bookmark、social.comment、social.delete 为独立写权限。
删除还要求该评论 canDelete，示例服务再核实际作者 ID。
使用 security 正规操作更新 subject；不直接篡改 readonly 安全 state。
