# V2-043 原独立 QA · 05f 整改复审

事件 `V2-043-ORIGINAL-QA-05F-REMEDIATION-REVIEW`。
产品为 `05f6c4d24e41983cf584022a72cfaf81cb82a822`，整改 base 为
`f19aa666f797a8dd8069f181d0c870488d009a9a`，foundation 为 `1c3132e0cd1085daf9a210682a3222176c25bd5b`。
原 f19 FAIL、QA 提交 `7cf1df78b8f5e2ff5567f317f2c8814d810cd53c` 及其分支/原件保持。

**结论：QA43-01～06 修复独立复验关闭；整卡仍 FAIL，强预算未闭环，不送 ACC。**
没有新增足证产品 finding，也没有派发无依据的性能优化。

## 当前输入与审查

原 QA `01a15292-5d10-78a3-bfaa-15946ab2dad7` 在 E0703 继续。
本回合实际 native 为 Sol/high、danger-full-access/never；真实项目关联 f6046b3c，独立 E 工作区，
两次 HEAD 为完整 05f。旧 clean QA 分支保全后才检出候选，未混入产品修改。

OCR 实际 range 为 f19→05f，23 个 selected 文件全部亲审、skipped=0，6 个 unsupported Markdown
全部人工补读。完整当前 48 路径按 42 源码/配置及 6 文档覆盖，其中 19 个未变源码精确继承旧独立审查。
源代码与 fixed Git、48 项送测来源、29 个当前编译模板均核对；不重开 024/032/033。

TC 最小输入 SHA256 `5f0c9a83a90ce74c692c64916548e5c80066b9ffd155411a2d91a88f1ffd1d11`，
声明阶段闭包 SHA256 `1439dedcb420869e97f2b2a89140aaaf9e1013d11f3d2559cf957a91499ffda5`，
DEV REMEDIATION-FINAL SHA256 `d18596f5e2ee145ef6b8a0a146723a5ffccb7844e0914e3c64b19df281e738ff`
均实际核值。声明闭包不作为独立行为通过。

## 六项关闭证据

| finding | 独立复审与复验                                                                                                                                                                                                                                                                                                                                                        |
| ------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| QA43-01 | 亲审借原 c/signal、scope/service/permission 与末次资格；完整合法 operation 的 create、数字0/字符串0、冻结后继输入、release/撤权/换服务回归通过。原五断言改用合法 edit operation 后均 PASS。另在真实普通 UsersPage 保存时设置独立慢服务2000ms，通过 native history 确认离页和真实组件卸载，迟到候选后 updates 仍0，原用户名称未被改写。该慢服务窗口不参与100ms强预算。 |
| QA43-02 | 逻辑复验及同 DOM 两个真实 GrantEditor 通过；B 核实 A 成功只推进 baseline，B 对节点20的选择保留且 dirty；实际卸载借用 B 后，A confirming 回执仍在，确认后只发一次且 security 保持 authenticated。                                                                                                                                                                      |
| QA43-03 | 完整 Edit/Query/GrantNode/Snapshot/Result/DTO 边界亲审；22 项逻辑含缺失/额外/非法类型、typed0/'0'/null、false布尔、唯一稠密数组与非法 grant 成功回执。非法回执为 unknown，原基线/草稿与原操作保留。queryProjectionCodec 只适配列表明确省略的空条件。                                                                                                                  |
| QA43-04 | 当前 CAS 静态产物与非等待宿主均实际 logout；dirty grant、保护 DOM、树和 metrics 被移除，真实受限 history 返回被拒绝，随后重新登录成功。没有 dispose 借入 security。                                                                                                                                                                                                   |
| QA43-05 | 当前 CAS 静态产物及故意不等待 router-ready 的标准宿主，都实际验证 /roles、/menus 和 minimal/brand/technology 五个初始入口。带 family 查询的根路径进入正常用户页，初始深链保持。                                                                                                                                                                                       |
| QA43-06 | 亲审 setup 的 workspace camelCase 与 env 的正确 pnpm_config 变量；当前实际 consumer 关闭环境覆盖后回读仍为 error，恢复进程设置也为 error。没有仅以 .npmrc 或根 undefined 冒生效，没有补根 partial。                                                                                                                                                                   |

另在自有 normal consumer 实际 typecheck、22逻辑、生产 build 全0；17组受影响普通 UI
回归通过，涵盖三页完整 CRUD、未知回执、部分删除、草稿、typed scope、服务替换、权限与四尺寸/三族。
所有浏览器功能结果明确不作强预算通过。

## 源、安装、改配与回读限度

复用原正常 UI/Pro 两包和本 QA 自有安装。实际复核 16251 文件及448内部链接，共16699条目，
与 f19 恢复签名及本次 normal 完全相同；类型/构建后再核，无新安装、依赖或 metadata 手改。
Node22.19.0/pnpm11.9.0，D 唯一 pnpm 数据，E 独占 temp/profile/output；每个工程进程实际加载入口。

本次 `05f-normal` 以命令前 source/config/有效锁/metadata/完整自有安装/正常包/实际工具封存。
从自己的 CAS 独立物化77源及10dist，静态回放验证当前正常入口和 logout。
另从同一 CAS 源建立81源标准宿主变体，只改测试 bootstrap、测试双实例宿主及 Vite 测试入口；
实际 typecheck/build 并运行，AdministrationApp/GrantController 仍为完整05f原字节。
源码重编译显式继承本 QA 已签名未变安装，不冒另一次安装或借 DEV mutable。

DEV 的八源改配/恢复10dist属于真实 qa43-remediation-r5 早期阶段。
它与最终05f的 AdministrationApp、GrantController、Migration、README、remediation.test 有5路径差额。
仅精确继承未变字段/列/候选/DTO/布局改配结果；本次用当前源/资料审查、非法回执逻辑、当前 CAS
静态回放和非等待 bootstrap/双实例实际重编译补受影响范围。没有把旧阶段改标为最终全源，也未机械重跑三阶段。

## 原强预算仍未通过

没有重复同05f first。对已有 `qa43-candidate-root-first` 原 raw 仅做一次有界只读核查，
实际验证源/产物绑定及原采样器 `c30de0ae9038bfc8ad358e93df3f0326542b127f1f8566498f4e1ac5512843cd`。

浏览器 elapsed=3719.1000000089407ms，hostElapsed=6091.289400000001ms。
共4真实RAF，末两帧20行值完整、complete=true、CSS/fonts已就绪、动画0、page/service/CDP pending0；
但最后 stable=1，未达到原 stable≥2，且超过3000ms。末两次观察成本992.5/881.6000000089407ms
原样保留；没有扣除观察、运输或等待成本，也没有量化值、修改签名谓词或把完整/稳定混为一谈。
后三端点树1280、页390、树390保持 NOT_RUN。

该失败不被唯一归因为产品、观察或运输中的某一项；没有新足证差额时不盲派优化。
f19及所有DEV旧first失败、各自输入与 raw 都保留，功能轻量时间不替代强资格。

## 保全与剩余

外部原件根 `E:/DevCache/artifacts/asam-ui/v2-043/qa-r1/recheck-05f`；完整闭合索引另列实际SHA与来源，
current/source/review、UI、variant及budget qualification分列。
旧资源和失败保留，仅关闭本 QA 自己的浏览器/server；不自归档/清理，不写 canonical/main/CL/云，
不推送、部署或 publish。没有新增角色、子代理、心跳或 ACC。

剩余为原强预算的有效通过资格及未执行端点；在有明确必要新输入和合法方法前不能整卡 PASS。
