# Agent 使用配方

先读取 Types.ts、README.md 和当前固定 Git 的 DELIVERY。此模板适用于 Vue Router 4.6.3 的应用导航；UI/Pro 包不管理业务 router。

1. 确认宿主 router、静态安全落点、菜单来源和组件 allowlist；后端字符串只映射本地资源键。不要动态 import 后端路径或 eval。
2. 复制整个 navigation 目录；main 注册宿主 router 并导入同版本 UI/Pro CSS。参考完整 App，修改菜单、业务页面与加载器。
3. 用稳定 id/parentId/path/resource/title 构造完整菜单；非法批次必须整体保留旧版本。scope 变更若业务身份变化，用新 id 或新 controller。
4. 决定 fullPath 独立实例还是显式 cacheKey 复用，设置 maxCache。保留 NavigationPage 的 RouterView/KeepAlive 独立 key；不要改成全局 key 刷新。
5. 提供离开确认并处理 false；固定页保护不替代业务数据保存。iframe 注入 resolve/allow，按可信来源声明 sandbox 和 permissions。
6. 实际改一次标题/路由参数/正文与刷新动作，跑类型正反例、生产构建和浏览器输入保留/销毁、菜单非法/晚到、拖放/键盘及嵌入/全屏拒绝恢复。

路由解析交给 Vue Router；权限交给宿主/后端；不扩展认证、租户、请求或 CL 业务。本卡资料可被上层聚合，不需要另建 MCP 或 Skill。
