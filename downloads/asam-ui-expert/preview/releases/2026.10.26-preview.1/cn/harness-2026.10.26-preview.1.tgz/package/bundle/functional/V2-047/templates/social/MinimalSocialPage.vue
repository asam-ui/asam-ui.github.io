<template>
	<main class="social-page social-minimal" :data-size="size ?? 'default'">
		<header class="social-masthead">
			<span>FIELDNOTES / 社区手记</span>
			<h1>{{ socialConfig.minimal.title }}</h1>
			<p>{{ socialConfig.minimal.description }}</p>
		</header>
		<div class="social-editorial">
			<aside>
				<h2>留给讨论的空间</h2>
				<p>记录、阅读与回应。每一条内容都保留完整上下文。</p>
				<dl>
					<dt>当前身份</dt>
					<dd>{{ host.security.state.value.subject?.name ?? '未登录' }}</dd>
					<dt>会话</dt>
					<dd>{{ host.security.state.value.status }}</dd>
				</dl>
			</aside>
			<div><SocialFeed :c="c" :size="size" /><SocialDetail :c="c" /></div>
		</div>
	</main>
</template>
<script setup lang="ts">
import type { SocialPageProps } from './Types.js';
import { socialConfig } from './config.js';
import { useSocialPage } from './useSocialPage.js';
import SocialFeed from './parts/SocialFeed.vue';
import SocialDetail from './parts/SocialDetail.vue';
import './Social.css';
const props = defineProps<SocialPageProps>();
const c = useSocialPage(props);
defineExpose({ controller: c });
</script>
