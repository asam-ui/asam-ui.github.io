# 安全应用 API

Types.ts 是类型权威，Security.ts/Navigation.ts 与此文同版。

| 接口                                       | 契约                                                                                                                                              |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| SecurityId                                 | 非空字符串或有限数字；严格区分0和'0'                                                                                                              |
| SecurityScope                              | tenant/organization分别为SecurityId或null，不把空字符串当null                                                                                     |
| SecuritySubject                            | id/name/roles/permissions/scope/contexts/expiresAt/readOnly；只含展示安全字段；expiresAt为毫秒时间戳                                              |
| SecurityAdapter<C>                         | login(C,request)、restore(request)、refresh(subject,request)、switchContext(subject,scope,request)、logout(request)，异步宿主边界                 |
| SecurityRequest                            | signal + isCurrent()；宿主在实际凭据/存储提交前也核当前代次                                                                                       |
| createSecurity({adapter,now?})             | 独立控制器；now默认Date.now，可注入测试时钟                                                                                                       |
| state                                      | 深只读ref，status/subject/error/epoch；没有原异常、凭据或原DTO                                                                                    |
| login/restore/refresh/switchContext/logout | Promise<boolean>；旧代次、失败或匿名为false，成功认证/登出为true                                                                                  |
| check({permission?,role?,write?})          | allowed/denied/pending/error；permission与role为AND；至少一个明确非空条件，write额外检查readOnly                                                  |
| permission(code)                           | 031 provider同步check桥，禁止用菜单可见性替代路由鉴权                                                                                             |
| expire/reset                               | 同步撤销旧会话和读取；分别expired/anonymous；无远端副作用                                                                                         |
| onInvalidate(listener)                     | 同步清理边界，返回取消订阅函数；允许同步login/reset/logout重入，后发操作取代旧操作；异常关闭本次操作并继续当前代次其余清理，不回显异常正文        |
| dispose                                    | 幂等废弃全部旧结果、计时器、订阅；终态disposed                                                                                                    |
| scopeKey(subject)                          | JSON数组编码用户/租户/组织的类型化身份，无字符串分隔符碰撞                                                                                        |
| safeReturnPath(input,fallback?)            | 只接收规范应用内绝对路径；拒绝外部、反斜线、控制字符、路径编码及dot规范化；fallback默认/safe，宿主只传可信fallback                                |
| createSecurityNavigation                   | security/router/components/items/rules/publicPaths/safePage；每个非公开path明确规则；只支持这里声明的精确路径，参数路由由宿主先转成明确策略再接入 |
| navigation                                 | shallowRef，认证成功生成的新032实例或null；模板以epoch为key，不能复用旧页缓存                                                                     |
| resume(path)/forgetReturn                  | 设置已过滤的登录后位置/忘记位置；登出和失效前forgetReturn                                                                                         |
| dispose桥                                  | 取消guard/watch/订阅并dispose其拥有导航；宿主router不销毁                                                                                         |

状态：anonymous → restoring/authenticating → authenticated；authenticated → refreshing/switching → authenticated；任意操作失败→error，过期→expired，登出→logging-out→anonymous/error。所有开始操作都先清subject和增加epoch。刷新结果必须同主体/同scope，切换结果必须同主体/指定scope。新恢复/登录、reset、logout、expire、dispose废弃旧成功和失败。刷新时禁用受限交互，成功后以新权限重建导航。

examples组件不是包级API。App负责组装/焦点/真实history，DataPage负责自己的范围数据和草稿。宿主提供凭据输入时只短暂传给adapter，不存入展示状态；当前fixture用身份枚举演示而无密码。错误后可以明确登录或恢复，远端登出失败仍保持本地清空。
