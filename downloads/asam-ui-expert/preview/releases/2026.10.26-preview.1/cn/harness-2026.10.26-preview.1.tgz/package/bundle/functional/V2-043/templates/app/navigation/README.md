# 应用导航源码模板

本目录是应用代码，直接复制整个目录后修改。入口 `index.ts`；匹配 Vue 3.5.34、Vue Router 4.6.3、ASAM UI/Pro 0.1.0-alpha.1。模板 Git SHA 与 UI/Pro tar 哈希分别固定，源码模板不在 npm UI/Pro 运行时中。宿主创建和销毁 router、提供资源 allowlist、菜单数据、离开确认、可见性及 iframe 策略。本模板不持有账号、后端权限、租户或 token。

完整普通应用见 `examples/main.ts`、`examples/App.vue`、`examples/StatePage.vue`。安装真实 UI/Pro 包后先导入 element-plus/dist/index.css，再导入 UI/Pro CSS，普通App复用同版AsamApplicationProvider配置作用域内的亮暗主题和四尺寸；配置 Vue 插件并使用 history 回退服务。动态注册在初次菜单成功后重新解析深链接；静态 `/safe` 是移除当前动态路由的落点，未匹配页给出可恢复反馈。浏览器前进后退与宿主 router.push 都经过本模块离开确认。菜单 visibility 只控制入口显示，服务端继续负责真实授权。

## 控制器

`createNavigation(options)` 返回独立控制器。完整类型见 Types.ts。必需 router、components、load、fallback；components 只接受本地显式映射，不执行远端字符串。load 收到 signal/scope；reload(scope?) 取消旧代，忽略 signal 的旧请求同样不能覆盖新版本或在卸载后报错。加载、校验和注册失败保留上一版本并可 reload 重试。所有候选记录在离开确认或 fallback 跳转前，先用同版 Vue Router 公开 createRouterMatcher 和宿主 parser options 完成注册语法预检；临时 matcher 随即丢弃，不持有 history、不注册到宿主，也不参与实际导航。非法参数正则等解析失败时，当前路由、页签与缓存实例保持不变。空数组是合法版本，关闭模块动态页。id/路径重复、宿主路径冲突、父级缺失、父子循环和未知资源均拒绝整批。父子结构用于菜单组织元数据，页面路由采用明确绝对路径，不创建第二套路由匹配引擎。

`navigate(location, replace=false)` 使用真实 router，支持路径/名称/params/query 与上游重定向；未匹配、确认取消/异常、导航失败返回 false。重复当前导航是成功的无操作。快速连续确认只允许最新一次生效。确认在路由切换前执行；close/refresh/update 另有操作确认，若随后发生真实跳转还会经过 navigate 确认。宿主确认应无副作用且允许重复询问。取消保留当前内容和页签。

`menu/visibleMenu/tabs/pages/active/error/loading/revision` 是只读状态。error 不暴露后端异常正文。`close(ids)`、`closeOthers()`、`closeAll()` 保护固定页，关闭当前先导航到第一个剩余页或 fallback，再删除页签。`refresh(id=active)` 只改变目标缓存身份对应 epoch，立即销毁并重建该实例。`move(id,targetId)` 只重排非固定页，不改变路由和缓存身份。`dispose()` 幂等，取消请求、移除自身 guards/afterEach/动态注册并释放页面状态，不销毁宿主 router。

## 实际缓存与交互

页签 id 默认是 router 解析后的 fullPath；缓存身份是 route id 加 cacheKey(route,item)，默认 fullPath。可设置 `cacheKey: route => String(route.name)` 将同名路由不同参数共享实例，或 `route => route.path` 忽略 query。同一身份的多个页签共享页面状态与刷新生命周期，最后一个关联页签关闭后销毁。组件显示名、数组下标与随机数不参与缓存身份。

NavigationPage 使用真实 RouterView + KeepAlive，每个身份一个容器，停用时组件从 KeepAlive 活动树移出。关闭、刷新和 LRU 淘汰均卸载目标容器；其他容器不换 key。默认最多保留10个页面身份（maxCache 正整数可配置），超预算淘汰最久未激活实例，页签仍可重开并重新挂载。cache=false 的页面只保留当前活动期间。include/exclude 按显式 item.cache 决策，不依赖组件名。跨 id 或不同控制器从不共享缓存。示例输入与滚动位置可检查；测量预算是本模板10个本地轻页面，不声称全库性能。

页签支持浏览器原生拖放、Alt+左右箭头移动、Enter/Space 激活及独立关闭按钮。所有按钮可 Tab 到达；tablist/aria-selected/status 提供选择和变更信息。固定页不可拖移；过期拖动的 id 已被关闭或菜单移除时 move 无操作。窄屏页签横向滚动、动作换行。布局继承已验 AsamAdminLayout 四尺寸 small/default/big/large 与主题，不替换业务子树。

## 嵌入与全屏

EmbedPage props：src、policy、title?；status 事件反馈；公开 open(input)、toggleFullscreen()。policy 必需 resolve/allow；只接受绝对 HTTP(S) URL，拒绝凭据 URL、脚本协议、非法地址和策略拒绝。sandbox 默认空（最严格），permissions 默认空，referrerPolicy 默认 no-referrer。宿主按来源最小授予权限；同时授予同源与脚本需宿主自行评估可信内容。

更换地址销毁旧 iframe，旧代 load/error 回调不能更新新实例。load 只说明文档事件，不能证明远端应用成功。跨源 DOM、远端认证、拒绝嵌入站点能力不由模板绕过；浏览器可能不提供可信 error，状态明确保留未知。模板不提供 postMessage 总线、不自动信任或广播任何消息。需要协作时由宿主建立独立来源/window/会话协议。

原生全屏由用户按钮调用 requestFullscreen/exitFullscreen；pending 防重，fullscreenchange 校准状态，拒绝或不支持给出恢复反馈。只退出本实例持有的全屏，卸载待完成请求也回收。模块导入不访问 DOM；挂载和原生全屏依赖浏览器，完整 SSR/hydration 不承诺。

## 开发、升级与验证

保持模板和 UI/Pro 来源分别可追踪。升级时先 diff Types/Navigation/三个 SFC，再对 route id、cacheKey、fallback、allowlist 和 EmbedPolicy 逐项迁移；不把旧缓存身份直接迁入新的业务 scope。scope 更新若需清空身份，应在宿主数据 id 中带 scope 或先卸载旧控制器再创建。不要把菜单隐藏当授权，不把 URL 中放 token 当认证实现。

`tests/v2/navigation/prepare.mjs` 接受新的 NAV_CONSUMER 绝对路径及 NAV_UI_TAR/NAV_PRO_TAR，复制可修改源码并生成普通 Vite 应用。consumer 独立安装、typecheck/build/dev；不使用源码 alias 或其他角色 node_modules。修改菜单标题、人员路由参数、StatePage 正文后重新编译、生产构建并操作输入/刷新确认开发效果。源码测试与浏览器测试见同目录测试配方；实际结果、未测与首失败只以 DELIVERY/外置回执为准。
