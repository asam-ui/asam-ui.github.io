import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root = process.cwd();
const out = process.env.DESKTOP_OUT ?? 'E:/DevCache/artifacts/asam-ui/v2-049/dev-r1';
if (!/^E:[/\\]/i.test(out)) throw Error('New task evidence/consumer must use explicit E path');
const target = path.join(out, 'consumer');
const sha = (v) => crypto.createHash('sha256').update(v).digest('hex');
if (fs.existsSync(target))
	throw Error('Consumer exists; inspect and reuse, never overwrite installation');
const origin = 'E:/DevCache/artifacts/asam-ui/v2-015/qa-root-b9';
const manifest = JSON.parse(fs.readFileSync(path.join(origin, 'MANIFEST.json')));
const packagesFile = path.join(origin, 'PACKAGES.json');
const signed = manifest.files.find((f) => f.path === 'PACKAGES.json');
if (!signed || sha(fs.readFileSync(packagesFile)) !== signed.sha256)
	throw Error('Signed normal packages');
const packs = JSON.parse(fs.readFileSync(packagesFile)).packages;
const diff = execFileSync('git', [
	'diff',
	'--name-only',
	'b9a7432080058bd7638dc4213783845862cc6edf',
	'2d814770fafa3a9268707d7202d31e6b698d4896',
	'--',
	'packages/ui',
	'packages/pro/src/layout',
	'packages/pro/src/configuration'
]).toString();
if (diff.trim()) throw Error('Consumed public library source changed');
fs.mkdirSync(target, { recursive: true });
for (const dir of ['desktop', 'app/preferences', 'app/navigation'])
	fs.cpSync(path.join(root, 'templates', dir), path.join(target, 'templates', dir), {
		recursive: true
	});
const dependencies = { vue: '3.5.34', 'vue-router': '4.6.3', 'element-plus': '2.14.7' };
const packBindings = [];
for (const [name, p] of Object.entries(packs)) {
	const bytes = fs.readFileSync(p.tar);
	if (sha(bytes) !== p.sha256 || bytes.length !== p.bytes) throw Error(name);
	const file = `${name}.tgz`;
	fs.writeFileSync(path.join(target, file), bytes);
	dependencies[`@asam-ui/${name}`] = `file:./${file}`;
	packBindings.push({
		name,
		producer: manifest.product,
		tar: p.tar,
		sha256: p.sha256,
		bytes: p.bytes,
		payloadCount: p.payloadCount
	});
}
fs.writeFileSync(
	path.join(target, 'package.json'),
	JSON.stringify(
		{
			name: 'v2-049-desktop-consumer',
			private: true,
			type: 'module',
			packageManager: 'pnpm@11.9.0',
			scripts: {
				build: 'vue-tsc --noEmit && vite build',
				typecheck: 'vue-tsc --noEmit',
				dev: 'vite --host 127.0.0.1',
				format: 'prettier --write templates/desktop tests',
				'format:check': 'prettier --check templates/desktop tests',
				test: 'node run-unit.mjs'
			},
			dependencies,
			devDependencies: {
				'@vitejs/plugin-vue': '6.0.9',
				vite: '8.0.10',
				typescript: '6.0.3',
				'vue-tsc': '3.3.11',
				prettier: '3.9.6',
				playwright: '1.58.2'
			}
		},
		null,
		'\t'
	)
);
fs.writeFileSync(
	path.join(target, '.npmrc'),
	'# pnpm 11 project settings are explicit in pnpm-workspace.yaml. No local storage overrides.\n'
);
fs.mkdirSync(path.join(target, 'patches'));
fs.copyFileSync(
	'patches/element-plus@2.14.7.patch',
	path.join(target, 'patches/element-plus@2.14.7.patch')
);
fs.writeFileSync(
	path.join(target, 'pnpm-workspace.yaml'),
	'packages: []\nnodeLinker: hoisted\npackageImportMethod: copy\nsymlink: false\nenableGlobalVirtualStore: false\nverifyDepsBeforeRun: error\nstrictPeerDependencies: false\nautoInstallPeers: false\nallowBuilds:\n  esbuild: true\npatchedDependencies:\n  element-plus@2.14.7: patches/element-plus@2.14.7.patch\n'
);
fs.writeFileSync(
	path.join(target, 'tsconfig.json'),
	JSON.stringify(
		{
			compilerOptions: {
				target: 'ES2023',
				module: 'ESNext',
				moduleResolution: 'Bundler',
				strict: true,
				skipLibCheck: true,
				lib: ['ES2023', 'DOM', 'DOM.Iterable'],
				types: ['vite/client'],
				noEmit: true
			},
			include: ['templates/desktop/**/*.ts', 'templates/desktop/**/*.vue', 'tests/types.ts']
		},
		null,
		'\t'
	)
);
fs.writeFileSync(
	path.join(target, 'vite.config.ts'),
	"import { defineConfig } from 'vite'; import vue from '@vitejs/plugin-vue'; export default defineConfig({ plugins:[vue()], build:{ target:'es2022' } });\n"
);
fs.writeFileSync(
	path.join(target, 'index.html'),
	'<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ASAM 桌面工作台</title></head><body><div id="app"></div><script type="module" src="/templates/desktop/examples/main.ts"></script></body></html>'
);
fs.copyFileSync('.prettierrc.json', path.join(target, '.prettierrc.json'));
fs.mkdirSync(path.join(target, 'tests'));
for (const name of ['controller.test.mjs', 'types.ts'])
	fs.copyFileSync(path.join(import.meta.dirname, name), path.join(target, 'tests', name));
fs.copyFileSync(path.join(import.meta.dirname, 'run-unit.mjs'), path.join(target, 'run-unit.mjs'));
fs.writeFileSync(
	path.join(out, 'package-inputs.json'),
	JSON.stringify(
		{
			at: new Date().toISOString(),
			base: '2d814770fafa3a9268707d7202d31e6b698d4896',
			packs: packBindings,
			signedManifest: path.join(origin, 'MANIFEST.json'),
			signedManifestSHA256: sha(fs.readFileSync(path.join(origin, 'MANIFEST.json'))),
			packagesSHA256: sha(fs.readFileSync(packagesFile)),
			publicSourceDiff: diff,
			note: 'Normal full packages from accepted b9 producer, as consumed by accepted034. Entire UI plus consumed Pro layout/configuration are byte-identical at fixed base. Other Pro features are not claimed as this card input or tested.'
		},
		null,
		2
	)
);
console.log(target);
