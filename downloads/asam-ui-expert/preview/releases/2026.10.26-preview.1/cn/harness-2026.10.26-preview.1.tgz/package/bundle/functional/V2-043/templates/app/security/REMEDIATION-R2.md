# V2-033 同步重入整改 R2

2026-10-18；唯一事件 `V2-033-QA01-02-24A84B`。原DEV/E2086接续，不新增角色。DEV整改候选已完成，待原QA固定新完整候选OCR复审及独立验证；两项缺陷是否正式关闭由原QA判断，完整PASS才首ACC。

完整base `14f2dc76078452d82b5cc3ef36752c1b1ea03f12`，上轮FAIL head `1e91b0d6f150cf98c979df99609275b3af095b04`，本轮产品 `7c09cac5f427958a481088cd67d1763172c728e7`；此后仅交付文档。根正式输入523a、原QA报告SHA256 `24a84b8db44ec17f89be115ed493bdff7f29f8480fe8c07a2857ded21b7301a1`均全文亲读；原角色回合实核Sol/high、danger-full-access/never、f604、E2086和成功工程工具。

完整25路径仍仅security两目录：原23＋reentry.test.ts＋本文。相对1e91，最终11差异路径（9个原路径修改、2个新增），14个原路径同blob；App/Fixture/DataPage/main、导航源、包/锁/共享出口均未改。原A03/A04/A12/Types/API/README/Agent/普通应用范围保留，无新依赖、后端事务或042/其他卡前置。

## 修复和反例判据

QA-033-01：begin现在在任何状态通知、abort和清理回调前，独立捕获本次token/controller并绑定所有权；旧controller只由捕获的previous取消。发布关闭状态后，所有同步边界返回都复核本次所有权。嵌套login/reset/logout使旧外层立即停止，不再更新新状态、调用尚未开始的旧adapter、继续旧通知循环或建立旧timer。认证成功通知、normalize/clock和旧异步结果后处理也检查当前请求；dispose先成为终态。

QA-033-02：刷新promise与request槽在任何用户同步通知前登记；同代同步回调内再次refresh取得同一promise。后继操作清空旧槽后，旧外层不会在run返回时把旧promise重新登记；结算只清理同一个槽。新增身份确实调用自身adapter，已开始的旧刷新结算也不清新槽。清理回调异常时当前操作关闭并继续该代次其余清理；异常前已重入新操作时不覆盖新操作。固定错误不回显异常正文，普通宿主凭据/后端职责保持。

先在原普通consumer未修改的1e91 Security上，照原QA两份脚本逐字节独立复现：`original-qa-red.log/json` 明确tests2/pass0/fail2、exit1。QA原脚本及原红结果不改记PASS。修复后的契约比原夹具探针更强：在abort/onInvalidate已重入时，older-outer请求和旧refresh adapter根本不应再启动。因此原脚本的pending.get('older-outer')/必有一次旧adapter调用假设不再成立，不能声称原脚本逐字节绿。新回归直接断言零旧调用及当前身份新调用；另外在旧adapter已实际开始后内部重入的场景保留真实old/new两次调用，核旧成功/失败结算不清新槽、同代仍单次。没有把旧计数2简单改1冒关闭。

## 本轮实际验证

- 独立consumer `E:/DevCache/temp/asam-ui/v2-033-dev-r2/consumer`，冻结原锁离线hoisted/copy安装，自有node_modules；原dev-r1 consumer的已签名模板、配置与dist不覆盖。Node22.19.0/pnpm11.9.0，实际E入口/D唯一pnpm，后继测试/profile/TEMP独占dev-r2，Chrome155/宿主Playwright1.62.1复用。
- `green-final.log`：18/18，exit0；原8组＋新增10组（多分支）。覆盖abort嵌套login success/reject/sync throw、reset/logout成功/失败；state/onInvalidate嵌套login/reset/logout、清理throw与新代次后throw；新身份刷新、同代合并、旧结算、认证成功通知及getter重入、旧异步结果不再读getter、dispose终态及当前恢复正对照。故意抛出的Vue同步watch示例可能产生Vue warning，测试断言及进程通过；没有屏蔽或当浏览器错误。
- 新模板的完整普通SFC/公开正负类型、生产构建及普通Chrome认证/导航/DOM完整操作通过。沿用同版App真实深链接/后退、权限正反/空/只读、scope失败/草稿和旧DOM销毁、数据恢复、过期/刷新/登出/重载及键盘焦点。
- 实际修改普通Fixture的editor姓名/roles并移除write权限、readonly姓名、tenant和总部organization=research/label，以及App标题；修改后类型/生产/真实页面通过，显示改后身份与组织资料、保存禁用。冻结`variant-final`后恢复普通源，再类型/生产/真实操作通过。两版各亲看390亮色default图；未变四尺寸/亮暗/1280矩阵继承原独立QA32图，未机械重跑或冒本轮新验。
- 新普通消费者模板及自身测试源与本次工作字节核同；`product-7c09cac`绑定全部24产品/测试/资料源、正常消费/锁/编译输入/生产输出。无包源码alias、测试wrapper或补声明。Prettier、git diff --check与pnpm check:repository:staged通过。

## 精确原件与保留

外置根 `E:/DevCache/artifacts/asam-ui/v2-033/dev-r2`，最终完整head、源码tar、所有原件库存及读路哈希在FINAL.json。原dev-r1所有首FAIL/normal/variant/正常包及原consumer继续保留；原QA完整3746原件及根永久3748读路沿正式输入继承，不冒本轮新复制或重验完整QA。

| 原件                                        | 绑定                                                                                                                                             |
| ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| original-qa-red.log/json                    | 原1e91普通consumer独立两例红，exit1；原QA两反例源在red-input原字节保留                                                                           |
| product-7c09cac/manifest.json               | SHA256 `8a20628603e4fce18dba0c55ceba026b5f5e0497810636af8093f94c38c59f25`；24源及当前正常消费，1927记录                                          |
| variant-final/manifest.json                 | SHA256 `df82cc9bd8046ea64fc1528e32d2245fb98858543d8fd3817f2ce2c89b9d7ca3`；1e91 Git起点＋本轮实际新工作字节和真实修改消费，不冒该起点已含修复    |
| normal/manifest.json                        | SHA256 `4660f674089f6ad610f0f80e44395e569a11a22295cfbc7b69220eddd8910dc8`；本轮前一阶段普通消费，最后两个旧后处理guard之前，精确保留不冒最终产品 |
| green-final.log、variant-final-_、restore-_ | 最终18绿、完整修改和恢复普通工程/浏览器日志；normal-*、green-r1和variant-*旧阶段保留                                                             |
| READROUTES.json、PRESERVATION.json          | 当前各阶段工作路径转同版不可变snapshot/installed-payload，逐bytes/hash；原dev-r1旧读路和原普通consumer单独核同，不改旧签名                       |

032正常UI/Pro双tar继续准确复用永久CAS 7a810ec0/01897898，保持6588真实构建/3a710未变源码provenance；1504编译源/116精确CRLF及1836 tar/实际安装payload本轮精确配对，不改称新库重建。源模板新工作字节、同版API资料、实际修改效果、生产输出与源码tar分别绑定，不拿旧绿冲抵原两红。

仍未测真实CL/认证后端/Cookie并发策略、其他浏览器/OS读屏/IME/完整SSR hydration；fixture刷新匿名、宿主DTO/URL/HTTP/凭据提交前isCurrent及后端最终鉴权保持。只送原QA复审，DEV未写canonical/shared/main/CL/云、未推送部署发布、建角色/心跳或自归档；原空间保留待定向整改。
