import type { AsamCrudServices, AsamWriteOperation } from '@asam-ui/pro';
import type { AsamRequestContext } from '@asam-ui/ui';
import type { AdministrationHost, Id, Query, UserEdit, UserRow, RoleOption } from './Types.js';
import { userCodec } from './Codecs.js';
import { fields, denseArray } from './Validation.js';
import { isId } from './Tree.js';

export function validateRoleOptions(options: readonly RoleOption[]): readonly RoleOption[] {
	denseArray(options);
	const ids = new Set<Id>();
	for (const option of options) {
		fields(option, ['id', 'name', 'enabled']);
		if (
			!isId(option.id) ||
			ids.has(option.id) ||
			typeof option.name !== 'string' ||
			!option.name.trim() ||
			typeof option.enabled !== 'boolean'
		)
			throw new Error('角色候选无效');
		ids.add(option.id);
	}
	return options;
}

/** Policy is explicit, scoped and based on the original loaded association set. */
export function withUserRolePolicy(
	host: AdministrationHost,
	service: AsamCrudServices<UserRow, Query, UserEdit, Id>
): AsamCrudServices<UserRow, Query, UserEdit, Id> {
	const originals = new Map<string, readonly Id[]>();
	const key = (scope: string, id: Id) => JSON.stringify([scope, typeof id, id]);
	const bound = host.services.value,
		serviceVersion = bound.version,
		epoch = host.security.state.value.epoch,
		boundScope = host.runtime.scope;
	const identityCurrent = (caller: AsamRequestContext) =>
		host.runtime.isCurrent(caller) &&
		caller.scope === boundScope &&
		host.services.value === bound &&
		bound.version === serviceVersion &&
		host.security.state.value.epoch === epoch;
	const current = (caller: AsamRequestContext, write: boolean) =>
		identityCurrent(caller) &&
		host.security.check({ permission: 'users:read' }) === 'allowed' &&
		(!write || host.security.check({ permission: 'users:write', write: true }) === 'allowed') &&
		identityCurrent(caller);
	async function validate(model: Readonly<UserEdit>, caller: AsamRequestContext, id?: Id) {
		if (!current(caller, true)) return null;
		const scope = caller.scope;
		const isCurrent = () => current(caller, true);
		try {
			fields(model, ['name', 'account', 'status', 'roleIds', 'context', 'note', 'version']);
			const frozen = userCodec.decode(model);
			Object.freeze(frozen.roleIds);
			Object.freeze(frozen);
			if (!isCurrent()) return null;
			const options = validateRoleOptions(
				await bound.roleOptions({
					...caller,
					isCurrent
				})
			);
			if (!isCurrent()) return null;
			const original = id === undefined ? [] : (originals.get(key(scope, id)) ?? []);
			const unavailable = original.filter(
				(k) => !options.some((o) => Object.is(o.id, k) && o.enabled)
			);
			if (host.unknownRoles === 'reject' && unavailable.length) return null;
			if (
				frozen.roleIds.some(
					(k) =>
						!original.includes(k) &&
						!options.some((o) => Object.is(o.id, k) && o.enabled)
				)
			)
				return null;
			if (
				!isCurrent() ||
				host.services.value !== bound ||
				bound.version !== serviceVersion ||
				host.security.state.value.epoch !== epoch ||
				host.security.check({ permission: 'users:write', write: true }) !== 'allowed'
			)
				return null;
			return {
				...frozen,
				roleIds: [
					...new Set([
						...frozen.roleIds,
						...(host.unknownRoles === 'preserve' ? unavailable : [])
					])
				]
			};
		} catch {
			return null;
		}
	}
	function freezeOperation(
		operation: AsamWriteOperation,
		caller: AsamRequestContext,
		id?: Id
	): AsamWriteOperation | null {
		if (
			!current(caller, true) ||
			operation.scope !== caller.scope ||
			!operation.target ||
			operation.target.mode !== (id === undefined ? 'create' : 'edit') ||
			!Object.is(operation.target.id, id) ||
			typeof operation.target.operationId !== 'string' ||
			!operation.target.operationId
		)
			return null;
		const record = (model: Readonly<Record<string, unknown>>) =>
			Object.freeze({
				...model,
				...(Array.isArray(model.roleIds)
					? { roleIds: Object.freeze([...model.roleIds]) }
					: {})
			});
		return Object.freeze({
			...operation,
			target: Object.freeze({ ...operation.target }),
			input: record(operation.input),
			payload: record(operation.payload)
		});
	}
	function freezeEdit(model: UserEdit): Readonly<UserEdit> {
		Object.freeze(model.roleIds);
		return Object.freeze(model);
	}
	return {
		...service,
		async load(id, c) {
			if (!current(c, false)) throw new Error('读取上下文已失效');
			const row = await service.load(id, c);
			if (!current(c, false)) throw new Error('读取上下文已失效');
			fields(row, ['name', 'account', 'status', 'roleIds', 'context', 'note', 'version']);
			const edit = userCodec.decode(row);
			originals.set(key(c.scope, id), [...edit.roleIds]);
			return edit;
		},
		async create(m, o, c) {
			const operation = freezeOperation(o, c);
			const safe = await validate(m, c);
			return safe && operation && current(c, true)
				? service.create(freezeEdit(safe), operation, c)
				: {
						status: 'failure',
						message: '角色候选或权限已变化，确认未发送；请检查关联策略'
					};
		},
		async update(id, m, o, c) {
			const operation = freezeOperation(o, c, id);
			const safe = await validate(m, c, id);
			return safe && operation && current(c, true)
				? service.update(id, freezeEdit(safe), operation, c)
				: { status: 'failure', message: '未知角色策略、候选或权限拒绝，确认未发送' };
		}
	};
}
