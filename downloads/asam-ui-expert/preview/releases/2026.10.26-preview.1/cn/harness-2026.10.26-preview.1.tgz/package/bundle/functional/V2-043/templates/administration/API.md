# 管理模板 API

类型权威为 Types.ts，所有 `.vue`、配方与同版文档一起复制。

运行时 Edit/Query/GrantNode 与示例 DTO 使用完整字段白名单：缺字段、额外字段、非法类型、访问器、重复或稀疏 ID 集合整次拒绝。版本不默认补零；parentId 必须显式为 null 或有效 typed ID。`queryProjectionCodec` 是唯一列表适配入口，仅补 003 明确省略的空查询值，随后仍调用完整 Query 校验。Row→Edit 由宿主显式投影，不能把含 id 或后端私有字段的 Row 直接当 Edit。
跨实例核实回执只推进已授基线，不吞本实例 dirty 草稿；只有本实例原操作且无后继修改，才能用该操作快照更新选中集合。示例提供实际 logout，bootstrap 等 router 初始导航就绪后建立 bridge 以保持深链。

| 协议                   | 输入 / 输出与职责                                                                                                                               |
| ---------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| AdministrationHost     | 宿主 security/runtime/writes/operations/receipts/services/size/confirm/unknownRoles；只借用                                                     |
| AdministrationServices | version，三组 AsamCrudServices，roleOptions、menuNodes、grants；无内置 URL                                                                      |
| Query                  | keyword/status/role/context；role 为 typed Id 或 null                                                                                           |
| UserEdit / UserRow     | name/account/status/roleIds/context/note/version，Row 另有 id                                                                                   |
| RoleEdit / RoleRow     | name/code/enabled/members/note/context/version，Row 另有 id；members 只读含义由宿主定义                                                         |
| MenuEdit / MenuRow     | parentId/title/kind/permissionCode/enabled/grantable/version，Row 另有 id                                                                       |
| GrantNode              | typed id/parentId/title/kind/permissionCode/enabled/grantable/version                                                                           |
| GrantSnapshot          | subject/scope/version/nodes/direct/unavailable；只读完整输入                                                                                    |
| GrantOperation         | operationId/subject/scope/serviceVersion/version/direct；冻结原操作                                                                             |
| GrantService           | load(subject,Request)、save(operation,Request)、verify(operation,Request)                                                                       |
| Request                | signal/isCurrent/scope；服务写副作用由宿主后端再次鉴权                                                                                          |
| GrantResult            | success/version；failure/reason(conflict/validation/denied，明确未应用)；unknown                                                                |
| GrantReceipt           | 原 operation、sending/success/failure/unknown 与 result；Map 由宿主跨卸载保存                                                                   |
| GrantEditor expose     | open(typedId)、editor；关闭发 closed；自身卸载只清本地状态                                                                                      |
| createGrantEditor      | snapshot/selected/filter/status/message/dirty/tree/visible/writable refs；open/toggle/selectVisible/save/verify/close/reload/invalidate/dispose |
| AdministrationApp      | host，family(minimal/brand/technology)，mode(light/dark)；controls/recovery slots；navigation expose                                            |

CRUD 公开能力沿用 024 原协议，不能通过这里绕过原 controller。详情读取当前服务，失效原 Row 不再发起编辑。
各服务 DTO 必须经显式 codec 转成展示安全字段。version 字段参与隐藏编辑提交，不由 UI 猜后端 etag。
纯字符串状态是示例显示协议；换布尔、枚举、数值后端用 codec 显式转换。

GrantEditor status：closed→loading→ready/error；ready→saving→ready/unknown；unknown→verifying→ready/unknown。
失效优先 closed，不等用户确认。读取失败不保留半树。刷新 dirty 先确认；保存中的后继修改不会被旧成功覆盖。
confirmed failure 可显式更正后再次保存；unknown 只核实原操作。
