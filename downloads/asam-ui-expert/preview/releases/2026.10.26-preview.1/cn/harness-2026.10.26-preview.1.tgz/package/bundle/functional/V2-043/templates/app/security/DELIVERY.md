# V2-033 DEV-R1 完整候选

当前整改候选见 [同步重入整改 R2](./REMEDIATION-R2.md)。以下是首次1e91送测历史；原独立QA已判FAIL，QA-033-01/02待新候选独立复审，不以本页历史DEV自测代QA通过。

2026-10-18；唯一事件 V2-033-FIRST-DEV-FULL-A03-A04-A12。DEV交付完成，待独立OCR QA→ACC；本报告不代QA/ACC或集成收尾。

产品base `14f2dc76078452d82b5cc3ef36752c1b1ea03f12`，产品head `bf8fb0d4055f61479486405de38e925d997d87c5`，分支 `codex/v2-033-security-dev-r1`，工作区 `E:/worktree-tmp/2086/asam-ui`。此索引为其后独立文档提交；QA使用base到最终交接head的完整差异，不能只审最后一次提交。共13模板/资料与9测试/工具文件，另加本索引；逐路径与工作字节见product manifest的records及同目录完整源码快照。

## 完整范围

- A03：同步031权限桥、明确role/permission AND、pending/error/空/非法关闭、只读写入限制、入口过滤、真实Vue Router guard与调用前再次check；后端最终鉴权。
- A04：类型化host适配的登录/恢复/刷新/登出、当前失败恢复、实际过期计时器、同代刷新合并、不同代次隔离、忽略AbortSignal的晚到成功/失败丢弃、多实例和销毁。公开状态allowlist不含凭据，错误不回显适配器异常。
- A12：显式tenant/organization上下文、类型化0/string/null身份；同步清除交互/选择/草稿/数据，032导航dispose撤路由/页签/缓存后重建，新scope失败保持清空；安全返回与真实history。宿主拥有DTO/URL/HTTP/凭据提交/最终授权，不自建后端平台。

同版Types/API/README/capability/Agent配方、完整普通App/main/DataPage/Fixture均已交。只改本卡security两目录，无共享源码缺口、不依赖017/014/015/018或真实CL，不写canonical/main/CL/云、不推送部署发布或创建角色/心跳。

## 实际验证

首actual真实f604关联、E独立工作区与本回合turn_context的gpt-6.1-sol/high、danger-full-access/never和成功exec均已逐核并由TC独核；TC固定证据见其V2-033-CTRL/FIRST-ACTUAL-{CONTEXT,PROJECT,TOOLS}.json。Node22.19.0/pnpm11.9.0；实际加载E入口与D唯一pnpm，store/cache/state均D对应目录；TEMP/profile独占E。复用宿主Playwright1.62.1与Chrome155.0.8059.82，未下载浏览器或新运行时。

正常consumer `E:/DevCache/temp/asam-ui/v2-033-dev-r1/consumer`。正常双tar从032永久CAS核哈希后复制本任务.tgz，正常file安装。原provenance是6588真实构建上下文、源码未变3a710；本轮不声称14f2重建，未重建无影响包。1504实际输入的永久字节/116精确CRLF与14f2 Git blob逐项核对，1836 tar/安装JS、声明、CSS、metadata逐文件配对通过。无源码alias、测试wrapper或手补声明。

通过项：

- `vue-tsc --noEmit`：完整普通SFC及公开正负类型；凭据泛型、只读状态、无公开token、非法scope/permission的类型边界。
- 8组Node核心测试：乱序恢复/登录/上下文/刷新成功与失败、reset/logout/dispose、同代合并/跨scope新刷新、空/非法/只读/role/permission、实际过期timer与当前合法正对照、多个实例、真实MemoryHistory路由与安全返回。
- 普通Vite生产构建及Chrome生产页面：初始受限深链接登录后返回、直接非法路由拒绝、同query真实后退草稿缓存、切换后旧DOM脱离文档且草稿/选择/数据清除、失败scope无旧内容、角色与空权限、只读按钮、数据失败恢复、过期/恢复/刷新/登出/页面刷新与键盘焦点。
- 正常及实际修改普通SFC分别完成类型、生产及浏览器；修改editor姓名/角色并移除写权限，真实保存按钮禁用；修改readonly姓名、tenant标识、总部organization为research、可见label与App标题，页面真实显示改后数据。两版各16张1280/390×明暗×四尺寸截图，已实际查看正常390暗色large、1280亮色default及修改390亮色default，无控件截断，长页滚动操作可达。
- 最终导航自动忘记失效/登出/reset返回位置后，类型/8核心/生产/真实浏览器受影响回归通过；仅格式化的最后源码与已验生产输出逐hash完全一致。Prettier、git diff --check、pnpm check:repository:staged通过。

生产聚合chunk超过500kB为构建提示；真实CL/认证后端/远端Cookie并发策略、其他浏览器、OS读屏/IME及完整SSR hydration未测。fixture无跨刷新持久化，刷新页面回匿名是明确示例行为。宿主必须在凭据提交前检查isCurrent并隔离远端登出，后端仍最终鉴权。

## 外置精确来源与失败保留

根：`E:/DevCache/artifacts/asam-ui/v2-033/dev-r1`。

| 原件                                                                       | SHA256/说明                                                                                                                           |
| -------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| product-bf8fb0/manifest.json                                               | `1920de3a65f9496d815e8f17547b100f1b0814c27478085e229aa222c0ec286a`；完整产品22文件快照、1922工作/快照/包记录、1504源与1836payload绑定 |
| normal-r2/manifest.json                                                    | `e6b76c4634317a39df1d9edc8f2b7ef4657eb0072847dcc8154bd84a00f395b6`；原普通版本/锁/生产输出及源码                                      |
| variant-r2/manifest.json                                                   | `2d2efdc9091e746fc2775d70c0826bd398a9510fecf22ddf7417f19de6366e23`；真实修改后的普通源码/锁/生产输出                                  |
| READROUTES.json                                                            | 原manifest记录不改写；将可变工作路径映射到各版不可变源码副本和installed-payload，每条重新核bytes/hash                                 |
| variant-before/                                                            | 真实修改前Fixture.ts/App.vue；修改版本在variant-r2/consumer/templates中                                                               |
| normal-browser、variant-browser                                            | 各版PASS.json、实际截图与服务日志；失败截图/JSON另存不删                                                                              |
| final-core.log、return-typecheck.log、return-build.log、return-browser.log | 最终受影响核心/类型/生产/浏览器成功日志                                                                                               |
| format-dist-equivalence.json、product-build.log                            | 最后格式化前后生产输出相同及正常构建                                                                                                  |

首FAIL均保留：core-r1为Windows loader绝对路径未用file URL；browser-r1误将不同query缓存位置当原页；r2未等数据返回；r3精确label选择器未匹配，已为身份/尺寸select补aria-label；variant-browser首轮因header多匹配改first。normal-receipt首轮git ls-tree输出超过Node默认缓冲，改16MiB后全量核通过；format-check首轮指出新增导航换行，修正后二次全量通过。各原日志/脚本或before源码保留，均未冒PASS。

独立QA：按完整base/head做OCR delegate preview/rule/逐文件源码审查，核本次适配边界/竞态/导航销毁及完整普通工程，复用同源包并独立执行适用测试；完整QA通过才ACC。资料与测试工具若OCR过滤应人工补审并记录。最终源码/回执只给两主控；DEV不自行验收、集入codex/v2或回收本空间。
