# Agent 选择与增量修改方法

适用：固定 EP 2.14.7 / Vue 3.5.34 / TS 6.0.3 下的 ASAM 基础复核。此资料不创建新 Skill、
MCP 或宿主适配，UI runtime 不导入 Agent。050/051 可引用这里的事实，本卡不写其索引。

1. 先读取消费项目规范、package.json、锁、已有样例。识别框架/构建工具和已用包版本，
   不覆盖既有配置、不因 Agent 套件停用而损害应用运行。没有实际 CL 需求时保持业务留空。
2. 按意图选择入口：基本编辑/选择/展示用 UI；普通表单用 BaseForm；Schema/fields 用 Form；
   Remote/Dict 用公开数据协议/provider；局部应用主题/前端权限才用 Pro configuration。
   普通 Input、Password、Textarea 分工明确。权限 UI 不替代服务器鉴权。
3. 用本卡 CONTRACTS 的家族映射找到真实 `Types.ts` 与 `Index.ts`，再核正常包 exports 和
   声明；原生 props/events/slots/v-model/expose 与 ASAM 扩展分别阅读。不要仅据组件名、
   `$attrs`、文档数量或在线最新官网推断固定版本支持。资料缺项时记录，不发明 API。
4. 从 `examples/Baseline.vue` 或 `Plain.vue` 复制完整 SFC；真实应用导入公开包和两包所需 CSS，
   同时先导入 `element-plus/dist/index.css` 基础样式；正常 lock/frozen install/typecheck/build 后浏览器验证。无源码 alias、裸 dist 替换、
   私有 EP 路径或 Agent runtime 注入。只有 UI 的项目可省去 Pro 应用桥和 Pro CSS。
5. 增量修改时先定位 props/模型/slot/主题的责任层；四档尺寸通过现有提供者传播，不复制
   key；局部主题给 partial，清除覆盖给 null，undefined 留给继承。保持其他文件和用户修改。
6. 执行对应正反类型、模型事件/键盘/禁用只读/主题/空错恢复、适用销毁检查。完整 SFC 的
   修改→效果→恢复字节测试可重放。真实请求/权限/数据源由业务注入，不把 mock 冒充 CL。
7. 报告固定版本/sourceHead/锁/补丁/产物哈希、运行命令与结果、未测和原生限制。
   找不到符号、缺声明、版本错配、未安装依赖分别给出具体原因；不要把 exit0 当完成。
   改动候选固定后由独立 QA 实际 OCR 委托审查，再独立 ACC；DEV 自查不代替两者。

主题增量：页面`surface`与实心按钮前景`onSolid`分工不同。默认onSolid为白色，改dark surface
不会将按钮文字变暗；确需更改实心前景才显式覆盖该可选字段。完整旧theme可省略，应用旧对象
时应验证先前显式前景被移除后恢复默认；plain hover/active同样消费这一语义。不要在业务页面
复制按钮CSS算法或把surface同时当文字颜色。可运行例子为Foreground.vue。

幂等原则：重复阅读、正常导入和主题切换不重复注入工程配置；本卡重建脚本要求新输出目录，
不覆盖旧原件。包部署、公开发布、真实业务写入和宿主安装均不在这里自动执行。
