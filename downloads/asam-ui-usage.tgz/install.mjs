import { createHash } from 'node:crypto';
import {
	existsSync,
	lstatSync,
	mkdirSync,
	readFileSync,
	readdirSync,
	writeFileSync
} from 'node:fs';
import { dirname, resolve, relative, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

function rejectLinks(path) {
	const leaf = resolve(path);
	let cursor = leaf;
	while (true) {
		if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink())
			throw new Error(`Symlink target is not supported: ${cursor}`);
		if (cursor !== leaf && existsSync(cursor) && !lstatSync(cursor).isDirectory())
			throw new Error(`Parent is not a directory: ${cursor}`);
		if (cursor === dirname(cursor)) break;
		cursor = dirname(cursor);
	}
}

export function skillFiles(source) {
	const files = [];
	function walk(directory) {
		for (const entry of readdirSync(directory, { withFileTypes: true })) {
			const path = resolve(directory, entry.name);
			if (entry.isSymbolicLink()) throw new Error(`Symlink source is not supported: ${path}`);
			if (entry.isDirectory()) walk(path);
			else if (entry.isFile()) files.push(relative(source, path).split(sep).join('/'));
		}
	}
	walk(source);
	return files.sort();
}

export function installUsage({ source, target, apply = false, manifest }) {
	source = resolve(source);
	const destination = resolve(target, '.agents/skills/asam-ui-usage');
	rejectLinks(source);
	rejectLinks(destination);
	const files = skillFiles(source);
	if (!files.includes('SKILL.md')) throw new Error('Source is not an asam-ui-usage Skill');
	// Distributed manifests are siblings of the skill directory; repository installs
	// may omit them. Verify every declared byte before checking or writing the target.
	const explicitManifest = manifest !== undefined;
	const distributedInstaller = new URL(import.meta.url).pathname.endsWith('/install.mjs');
	manifest ??= resolve(dirname(source), 'manifest.json');
	if ((explicitManifest || distributedInstaller) && !existsSync(manifest))
		throw new Error(`Missing manifest: ${manifest}`);
	if (existsSync(manifest)) {
		rejectLinks(manifest);
		const metadata = JSON.parse(readFileSync(manifest, 'utf8'));
		const records = new Map();
		for (const item of metadata.files ?? []) {
			if (
				typeof item.path !== 'string' ||
				!/^[A-Za-z0-9_./-]+$/.test(item.path) ||
				item.path.startsWith('/') ||
				item.path.split('/').includes('..') ||
				records.has(item.path)
			)
				throw new Error('Invalid or duplicate manifest path');
			const file = resolve(dirname(manifest), item.path);
			rejectLinks(file);
			if (
				!existsSync(file) ||
				!lstatSync(file).isFile() ||
				createHash('sha256').update(readFileSync(file)).digest('hex') !== item.sha256
			)
				throw new Error(`Manifest hash mismatch: ${item.path}`);
			records.set(item.path, item.sha256);
		}
		for (const name of files) {
			const path = relative(dirname(manifest), resolve(source, name)).split(sep).join('/');
			if (!records.has(path)) throw new Error(`Skill file missing from manifest: ${name}`);
		}
		if (distributedInstaller) {
			const installerPath = relative(dirname(manifest), fileURLToPath(import.meta.url))
				.split(sep)
				.join('/');
			if (!records.has(installerPath))
				throw new Error(`Installer file missing from manifest: ${installerPath}`);
		}
	}
	const changes = [];
	for (const name of files) {
		const output = resolve(destination, name);
		rejectLinks(output);
		const data = readFileSync(resolve(source, name));
		if (existsSync(output)) {
			if (!lstatSync(output).isFile() || !readFileSync(output).equals(data)) {
				throw new Error(
					`Existing Skill differs; review and merge it without overwriting: ${output}`
				);
			}
		} else
			changes.push({ path: name, sha256: createHash('sha256').update(data).digest('hex') });
	}
	// Preflight every conflict before the first write. Never touch application files or AGENTS.
	if (apply)
		for (const { path } of changes) {
			const output = resolve(destination, path);
			mkdirSync(dirname(output), { recursive: true });
			writeFileSync(output, readFileSync(resolve(source, path)), { flag: 'wx' });
		}
	return {
		destination,
		applied: apply,
		changes,
		status: changes.length ? (apply ? 'installed' : 'planned') : 'unchanged'
	};
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
	const args = process.argv.slice(2);
	const options = {};
	for (let i = 0; i < args.length; i++) {
		if (args[i] === '--apply') options.apply = true;
		else if (['--source', '--target', '--manifest'].includes(args[i]) && args[i + 1])
			options[args[i].slice(2)] = args[++i];
		else throw new Error(`Unknown or incomplete option: ${args[i]}`);
	}
	if (!options.target)
		throw new Error(
			'Usage: node install.mjs --target <project> [--apply] [--source <skill-directory>]'
		);
	options.source ??= resolve(import.meta.dirname, 'asam-ui-usage');
	console.log(JSON.stringify(installUsage(options), null, 2));
}
